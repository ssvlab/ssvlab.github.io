/*********************************************************
* File:        main.c
* Abstract:    Implementation of the Main routine
* Platform:    AT89S8252
* Project:     Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include "menu_app.h"
#include "../drivers/global.h"
#include "../drivers/lcd_driver.h"
#include "../drivers/sensor.h"
#include "../drivers/serial.h"
#include "../drivers/timer.h"
#include "../drivers/keyboard.h"

/******************************************************************
* STATIC FUNCTION PROTOTYPES                 			  		  *
*******************************************************************/
static Data8 checkError(void);

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static uData8 amount;
static char sensorVal[10], tmpp[10];

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
/**
 * @brief check if there is error in data acquisition
 *
 * @retval This function returns -1 if the OEM III module
 *   is either out of track or the sensor is disconnected
 *   from the OEM III module.
 */
Data8 checkError(void){

    Data8 err=0;

#if (TARGET)

   lcd_clean(); 

	if(IsSensorDisconnected()){
	   lcd_printf("No sensor",LINE1,1);
           err=-1;

	}
   	else if(IsOutofTrack()){
	   lcd_printf("OutOfTrack",LINE1,1);
           err=-1;
    }

#endif

    return err;

}

/**
 * @brief show sensor data. This should be implemented when
 *   the sensor data must be shown. This function
 *   is called every second by the sensor driver.
 */
void printValue(void){

    uData8 sensorDat;

    if(checkError()==0 && getButtonState()==FALSE){

        lcd_clean(); 

        sensorDat = getSenPos();

#if (TARGET)
        switch(sensorDat){
            
            case HR:
                sprintf(sensorVal, "HR:%d", getHR());  
	            lcd_printf(sensorVal,LINE1,1);
                break;
            case SPO2:
                sprintf(sensorVal, "SPO2:%d",getSpO2());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case SPO2D:
                sprintf(sensorVal, "SPO2D:%d",getSpO2D());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case SPO2FAST:
                sprintf(sensorVal, "SPO2F:%d",getSpO2Fast());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case SPO2B:
                sprintf(sensorVal, "SPO2B:%d",getSpO2B());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case EHR:
                sprintf(sensorVal, "EHR:%d",getEHR());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case ESPO2:
                sprintf(sensorVal, "ESPO2:%d",getESpO2());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case HRD:
                sprintf(sensorVal, "HRD:%d",getHRD());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case EHRD:
                sprintf(sensorVal, "EHRD:%d",getEHRD());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case ESPO2D:
                sprintf(sensorVal, "ESpO2D:%d",getESpO2D());
                lcd_printf(sensorVal,LINE1,1);
                break;
            case SREV:
                sprintf(sensorVal, "SREV:%d",getSREV());
                lcd_printf(sensorVal,LINE1,1);
                break;
        }
#endif
    }
}


int main (void){

#if (TARGET)

	lcd_clean();          /* clean display 16x2 */
	serial_init(9600);    /* configure the serial port */
	initTimer0ms(600);
	initTimer0s(1);
	initSensor();
    	initMenuapp();
ERROR: __CPROVER_assert(0, "MOD_IN_USE in unregister_chrdev");
	initLog(2)
	insertLogElement(2);
	insertLogElement(2);
	insertLogElement(2);
	while(TRUE){ 

        	/* Infinite loop */

        }

#endif

}
