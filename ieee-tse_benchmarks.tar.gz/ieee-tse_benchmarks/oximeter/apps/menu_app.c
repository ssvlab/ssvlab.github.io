/*********************************************************
* File:        menu_app.c
* Abstract:    Implementation of the application menu
* Platform:    AT89S8252
* Project:     Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
//#include <assert.h>
#include "menu_app.h"       

/***********************************************
* LOCAL MACROS                                 *
************************************************/
#define BOUNCEVAL       (2)
#define PROGRESS		(100)

#define SETMSTATE(ST) 		\
	if (bounce==0) {        \
	    mstate=ST; 	        \
       bounce=BOUNCEVAL;    \
    } else {                \
        bounce--;           \
        if (bounce<0) {     \
	        bounce=0;       \
        }                   \
    }                       \

#define SETINC(parm)        \
    if (bounce==0) {        \
        parm++;             \
        bounce=BOUNCEVAL;   \
    } else {                \
        bounce--;           \
        if (bounce<0) {     \
            bounce=0;       \
        }					\
    }                       \

#define SETNEG(parm)  		\
    if (bounce==0) {        \
        parm=!parm;         \
        bounce=BOUNCEVAL;   \
    } else {                \
        bounce--;           \
        if (bounce<0) {     \
            bounce=0;       \
        }                   \
    } 						\

#define SETDEC(parm)        \
    if (bounce==0) {        \
        if (parm>0) {       \
            parm--;         \
        }                   \
        bounce=BOUNCEVAL;   \
    } else {                \
	    bounce--;           \
        if (bounce<0) {     \
        	bounce=0;       \
        }                   \
	}  						\

#define SETBNEG(parm)       \
	if (bounce==0) {        \
	    parm=!parm;         \
       bounce=BOUNCEVAL;    \
	} else {                \
        bounce--;           \
        if (bounce<0) {     \
	        bounce=0;       \
        }                   \
    }						\

/******************************************************************
* STATIC FUNCTION PROTOTYPES                 		          	  *
*******************************************************************/
static void startApp(void);
static void empty(void);
static void stopApp(void);
static void setSampleTime(void);
static void enableLog(void);
static void selectHR(void);
static void selectSPO2(void);
static void setLog2PC(void);
static void connectCable(void);

/******************************************************************
* LOCAL STRUCTS	                                                  *
*******************************************************************/
typedef struct {

	uData8 hr;	
	uData8 spo2;	
	uData8 spo2d;	
	uData8 spo2fast;
	uData8 spo2b;
	uData8 ehr;
	uData8 espo2;
	uData8 hrd;
	uData8 ehrd;
	uData8 espo2d;

} showData;

/******************************************************************
* STATIC DATA                 					                  *
*******************************************************************/
static uData8 stime, elog, bounce, exists_log; 
static uData8 count_pos, count_elem, count, global_progress, unit_progress;   
static uData8 pressed_key, mstate, amount, enable_buttons, log2pc, connect_cable;
showData show;
static char menuVal[10], opData[AMOUNTOFDATA];

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
void initMenuApp (void) {

	mstate=1;
	amount=0;
	stime=1;
   	bounce=0;
   	elog=TRUE;
	show.hr=TRUE;
	show.spo2=TRUE;
	show.spo2d=FALSE;
	show.spo2fast=FALSE;
	show.spo2b=FALSE;
	show.ehr=FALSE;
	show.espo2=FALSE;
	show.hrd=FALSE;
	show.ehrd=FALSE;
	show.espo2d=FALSE;
   	enable_buttons=TRUE;
	exists_log=FALSE;
	log2pc=FALSE;
	connect_cable=FALSE;
   	count_pos=0;
   	count_elem=0;
	strcpy(menuVal, "");
	strcpy(opData, "");
   	opData[0]=HR;
   	opData[1]=SPO2;
	count=0;
	unit_progress=0;
}

uData8 selectItem(void) {

	if (enable_buttons) {
		switch(mstate) {
			case SETSAMPLETIME:
            	SETMSTATE(SETLOG);
            	break;
			case SETLOG:
				if (exists_log) {
            		SETMSTATE(TRANSFERLOG);
				} else {
					SETMSTATE(SETHR);
				}
            	break;
			case TRANSFERLOG:
				SETMSTATE(SETHR);
				break;
			case SETHR:
            	SETMSTATE(SETSPO2);
            	break;
			case SETSPO2:
            	SETMSTATE(SETHRD);
            	break;
			case SETHRD:
				SETMSTATE(SETEHRD);
				break;
			case SETEHRD:
				SETMSTATE(SETEHR);
				break;
			case SETEHR:
				SETMSTATE(SETSPO2D);
				break;
			case SETSPO2D:
				SETMSTATE(SETSPO2FAST);
				break;
			case SETSPO2FAST:
				SETMSTATE(SETSPO2B);
				break;
			case SETSPO2B:
				SETMSTATE(SETESPO2);
				break;
			case SETESPO2:
				SETMSTATE(SETESPO2D);
				break;
			case SETESPO2D:
				SETMSTATE(SETSAMPLETIME);
				break;
		}

#if VERIFICATION
	__CPROVER_assert(mstate>=SETSAMPLETIME, "selectItem");
#endif

    }
	return mstate;
}

static void startApp(void) {

	if (exists_log) {
		mstate=CONCABLE;
		if (connect_cable){
			sendLog2PC();
#if (TARGET)
			lcd_clean();
			lcd_printf("Transferring...", 1, 1);
#endif
		}

	} else {
    	enable_buttons=FALSE;
    	setCountElem();
	}
}

static void empty(void) {

#if (TARGET)
	lcd_clean();
	lcd_printf("EMPTY", 1, 1);
#endif
}

static void stopApp(void) {

	if (getBufferSize()!=0){
		exists_log=TRUE;
	}
	enable_buttons=TRUE;
	mstate=SETSAMPLETIME;
}

uData8 KeyUp(void) {

	uData8 result=0;

    if (enable_buttons) {

        switch(mstate) {
            case SETSAMPLETIME:
                SETINC(stime);
				result=stime;
                break;
            case SETLOG:
                SETNEG(elog);
				result=elog;
                break;
			case TRANSFERLOG:
				SETNEG(log2pc);
				result=log2pc;
				break;
            case SETSPO2:
				SETNEG(show.spo2);
				result=show.spo2;
                break;
            case SETHR:
                SETNEG(show.hr);
				result=show.hr;
                break;
			case CONCABLE:
				SETNEG(connect_cable);
				result=connect_cable;
				break;
			case SETHRD:
                SETNEG(show.hrd);
				result=show.hrd;
                break;	
			case SETEHRD:
                SETNEG(show.ehrd);
				result=show.ehrd;
                break;
			case SETEHR:
	            SETNEG(show.ehr);
				result=show.ehr;
                break;
			case SETSPO2D:
	            SETNEG(show.spo2d);
				result=show.spo2d;
                break;	
			case SETSPO2FAST:
	            SETNEG(show.spo2fast);
				result=show.spo2fast;
                break;	
			case SETSPO2B:
	            SETNEG(show.spo2b);
				result=show.spo2b;
                break;	
			case SETESPO2:
	            SETNEG(show.espo2);
				result=show.espo2;
                break;	
			case SETESPO2D:
	            SETNEG(show.espo2d);
				result=show.espo2d;
                break;	
			default:
				result=-1;
        }
    }

#if VERIFICATION
	__CPROVER_assert(result>=0, "KeyDown");
#endif

	return result;
}

uData8 KeyDown(void) {

	uData8 result=0;

    if (enable_buttons) {

        switch(mstate) {
            case SETSAMPLETIME:
                SETDEC(stime);
				result=stime;
                break;
            case SETLOG:
                SETBNEG(elog);
				result=elog;
                break;
			case TRANSFERLOG:
				SETNEG(log2pc);
				result=log2pc;
				break;
            case SETSPO2:
				SETBNEG(show.spo2);
				result=show.spo2;
                break;
            case SETHR:
                SETBNEG(show.hr);
				result=show.hr;
                break;
			case CONCABLE:
				SETBNEG(connect_cable);
				result=connect_cable;
			case SETHRD:
                SETBNEG(show.hrd);
				result=show.hrd;
                break;	
			case SETEHRD:
                SETBNEG(show.ehrd);
				result=show.ehrd;
                break;
			case SETEHR:
	            SETBNEG(show.ehr);
				result=show.ehr;
                break;
			case SETSPO2D:
	            SETBNEG(show.spo2d);
				result=show.spo2d;
                break;	
			case SETSPO2FAST:
	            SETBNEG(show.spo2fast);
				result=show.spo2fast;
                break;	
			case SETSPO2B:
	            SETBNEG(show.spo2b);
				result=show.spo2b;
                break;	
			case SETESPO2:
	            SETBNEG(show.espo2);
				result=show.espo2;
                break;	
			case SETESPO2D:
	            SETBNEG(show.espo2d);
				result=show.espo2d;
                break;	
			default:
				result=-1;
        }
    }

#if VERIFICATION
	__CPROVER_assert(result>=0, "KeyDown");
#endif

	return result;
}

#if 1
Data8 chooseSensorData(uData8 op, uData8 en) {

	Data8 err=0;
	//__CPROVER_assum(op>AMOUNTOFDATA && op<1);

	if (op>AMOUNTOFDATA || op<1) {
		err=-1;
		return err;
    }

	if(en){
		opData[op-1] = op;
	} else {
		opData[op-1] = en;
	}
	err = opData[op-1];

#if VERIFICATION
	__CPROVER_assert(err>=0, "chooseSensorData");
#endif

	return err;
}
#endif

#if 0
//bug
Data8 chooseSensorData(uData8 op, uData8 en) {

	Data8 err=0;

	if (op>AMOUNTOFDATA) {
		err=-1;
		return err;
    }

	if(en){
		opData[op-1] = op;
	} else {
		opData[op-1] = en;
	}
	err = opData[op-1];


	return err;
}
#endif

static void setSampleTime(void) {

    sprintf(menuVal, "Sample time: %d", stime); 

#if (TARGET)
    lcd_clean();
    lcd_printf(menuVal, LINE1, 1);
#endif

}

static void connectCable(void) {

    
    if (connect_cable == TRUE) {
        sprintf(menuVal, "Cable? yes"); 
    } else {
        sprintf(menuVal, "Cable? no"); 
    }

#if (TARGET)
    lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif

}

static void enableLog(void) {

    
    if (elog == TRUE) {
        sprintf(menuVal, "Enable log: yes"); 
    } else {
        sprintf(menuVal, "Enable log: no"); 
    }

#if (TARGET)
    lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif

}

static void selectHR(void) {

    uData8 ret;

	ret = chooseSensorData(HR, show.hr);      
    if (ret == 0) {
        if (show.hr==TRUE) {
            sprintf(menuVal, "Show HR: yes");
        } else {
            sprintf(menuVal, "Show HR: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectSPO2(void) {

    uData8 ret;

    ret = chooseSensorData(SPO2, show.spo2);
    if (ret == 0) {
		if (show.spo2==TRUE) {
            sprintf(menuVal, "Show SPO2: yes");
        } else {
            sprintf(menuVal, "Show SPO2: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectHRD(void) {

    uData8 ret;

    ret = chooseSensorData(HRD, show.hrd);
    if (ret == 0) {
		if (show.hrd==TRUE) {
            sprintf(menuVal, "Show HRD: yes");
        } else {
            sprintf(menuVal, "Show HRD: no");
        }
#if (TARGET)
	lcd_clean();
        lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectEHR(void) {

    uData8 ret;

    ret = chooseSensorData(EHR, show.ehr);
    if (ret == 0) {
		if (show.ehr==TRUE) {
            sprintf(menuVal, "Show EHR: yes");
        } else {
            sprintf(menuVal, "Show EHR: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectSPO2D(void) {

    uData8 ret;

    ret = chooseSensorData(SPO2D, show.spo2d);
    if (ret == 0) {
		if (show.spo2d==TRUE) {
            sprintf(menuVal, "Show SPO2D: yes");
        } else {
            sprintf(menuVal, "Show SPO2D: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectSPO2FAST(void) {

    uData8 ret;

    ret = chooseSensorData(SPO2FAST, show.spo2fast);
    if (ret == 0) {
		if (show.spo2fast==TRUE) {
            sprintf(menuVal, "Show SPO2F: yes");
        } else {
            sprintf(menuVal, "Show SPO2F: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectSPO2B(void) {

    uData8 ret;

    ret = chooseSensorData(SPO2B, show.spo2b);
    if (ret == 0) {
		if (show.spo2b==TRUE) {
            sprintf(menuVal, "Show SPO2B: yes");
        } else {
            sprintf(menuVal, "Show SPO2B: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectESPO2(void) {

    uData8 ret;

    ret = chooseSensorData(ESPO2, show.espo2);
    if (ret == 0) {
		if (show.espo2==TRUE) {
            sprintf(menuVal, "Show ESPO2: yes");
        } else {
            sprintf(menuVal, "Show ESPO2: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void selectESPO2D(void) {

    uData8 ret;

    ret = chooseSensorData(ESPO2D, show.espo2d);
    if (ret == 0) {
		if (show.espo2d==TRUE) {
            sprintf(menuVal, "Show ESPO2D: yes");
        } else {
            sprintf(menuVal, "Show ESPO2D: no");
        }
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif
    }
}

static void setLog2PC(void) {

    if (exists_log) {
    	if (log2pc == TRUE) {
        	sprintf(menuVal, "Send log: yes"); 
    	} else {
        	sprintf(menuVal, "Send log: no"); 
    	}
	}

#if (TARGET)
    lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif

}

/**
 * @brief Timer interrupt
 *
 * @retval void
 *
 * Comments:
 * This procedure should be implemented if the
 * timer is configured. The code inside this
 * this procedure will be called according to the
 * time specified in initTimer0s(uData8 time_s).
 */
void timers_interrupt(void){

    if (enable_buttons) {

    	switch(mstate){
	    	case SETSAMPLETIME:
		    	setSampleTime();
			   	break;
		    case SETLOG:
		       	enableLog();
			   	break;
			case TRANSFERLOG:
				setLog2PC();
				break;
		    case SETHR:
			   	selectHR();
			   	amount++;
			   	break;
		    case SETSPO2:
			   	selectSPO2();
			   	amount++;
			   	break;
		    case SETHRD:
			   	selectHRD();
			   	amount++;
			   	break;
		    case SETEHR:
			   	selectEHR();
			   	amount++;
			   	break;
		    case SETSPO2D:
			   	selectSPO2D();
			   	amount++;
			   	break;
		    case SETSPO2FAST:
			   	selectSPO2FAST();
			   	amount++;
			   	break;
		    case SETSPO2B:
			   	selectSPO2B();
			   	amount++;
			   	break;
		    case SETESPO2:
			   	selectESPO2();
			   	amount++;
			   	break;
		    case SETESPO2D:
			   	selectESPO2D();
			   	amount++;
			   	break;
			case CONCABLE:
				connectCable();
				break;
	   }
    }
}

#if 1
uData8 calculateUnitProgress(void){
	
	uData8 length;

	length = getBufferSize();
	if (length!=0) {
		unit_progress = (PROGRESS/length);
#if VERIFICATION
	__CPROVER_assert(unit_progress>=0, "calculateUnitProgress");
#endif
	}

	return unit_progress;
}
#endif
#if 0
//bug
uData8 calculateUnitProgress(void){
	
	uData8 length;

	length = getBufferSize();
	unit_progress = (PROGRESS/length);

	return unit_progress;
}
#endif

uData8 logTransferProgress(void) {

	uData8 global_progress;

	count++;	
	global_progress = (unit_progress*count);
	sprintf(menuVal, "Progress: %d%", global_progress);
#if (TARGET)
	lcd_clean();
    lcd_printf(menuVal, LINE1, 1); 
#endif

	return global_progress;
}

void timerms_interrupt(void){

    uData8 keys=0x00; /* no key pressed */

#if (TARGET)
    keys=P1;
#endif

#if VERIFICATION
	__CPROVER_assert(keys>=0, "timerms_interrupt");
#endif

    pressed_key = checkPressedButton(keys);

    if(pressed_key>0){

        switch(pressed_key){
	    	case startButton:
				startApp();
	    		break;
	    	case stopButton:
	        	stopApp();
	        	break;
	    	case emptyButton:
	        	empty();
	        	break;
	    	case upButton:
	        	KeyUp();
	        	break;
	    	case downButton:
	        	KeyDown();
	        	break;
	    	case selectButton:
	        	selectItem();
	        	break;
        }

    }
}

void setCountElem(void){

	if (opData[0]!='\0') {
		count_elem = strlen(opData);
#if VERIFICATION
	__CPROVER_assert(count_elem>=0, "setCountElem");
#endif
	}
}

#if 0
//bug
void setCountElem(void){

	count_elem = strlen(opData);

}
#endif

uData8 getSenPos(void){

    uData8 result=0;
    
    ++count_pos;
    switch(opData[count_pos-1]){
        case HR:
            result=HR;
            break;
        case SPO2:
            result=SPO2;
            break;
		case EHR:
            result=EHR;
            break;	
		case HRD:
            result=HRD;
            break;
		case EHRD:
            result=EHRD;
            break;
		case SPO2D:
            result=SPO2D;
            break;
		case SPO2FAST:
            result=SPO2FAST;
            break;	
		case SPO2B:
            result=SPO2B;
            break;
		case ESPO2:
            result=ESPO2;
            break;	
		case ESPO2D:
            result=ESPO2D;
            break;		
    }

    if (count_pos == count_elem) {
        count_pos = 0;
    }

#if VERIFICATION
	__CPROVER_assert(result>=0, "getSenPos");
	__CPROVER_assert(count_pos>0, "getSenPos");
#endif

    return result;

}

uData8 getButtonState(void){

    return enable_buttons;

}
