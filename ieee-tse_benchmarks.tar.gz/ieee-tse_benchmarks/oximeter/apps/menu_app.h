/*********************************************************
* File:        menu_app.h
* Abstract:    Interface of the application menu
* Platform:    AT89S8252
* Project:     Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/*******************
* INCLUDE FILES    *
********************/
#if (TARGET)
#include <REG51.H>
#endif

#include "../drivers/global.h"
#include "../drivers/sensor.h"
#include "../drivers/lcd_driver.h"
#include "../drivers/keyboard.h"
#include "../utils/log.h"

/*******************
* EXPORTED MACROS  *
********************/
/**
 * @brief indicate the amount of sensor data to be displayed.
 */
#define AMOUNTOFDATA	(11)

/***********************************************
* ENUMERATIONS					               *
************************************************/
enum MenuSates { SETSAMPLETIME=1, SETLOG, TRANSFERLOG, SETHR, 
				SETSPO2, CONCABLE, SETHRD, SETEHRD, SETEHR,
				SETSPO2D, SETSPO2FAST, SETSPO2B, SETESPO2, SETESPO2D,
				SETSREV };

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
 *   @brief Function used to initialize the menu internal variables.
 *
 *   @retval void
 */
extern void initMenuApp(void);

/**
 *   @brief Function used to get the sensor data that must be shown 
 *	 		currently to the user.
 *
 *   @retval The sensor data to be shown. Otherwise, -1 is returned.
 */
extern uData8 getSenPos(void);

/**
 *   @brief Function used to know which buttons are enables at a given moment.
 *
 *   @retval uData8
 */
extern uData8 getButtonState(void);

/**
 *   @brief Function used to choose which sensor data will be displayed to the user.
 *
 *   @retval 0 success, else failure.
 */
extern Data8 chooseSensorData(uData8 op, uData8 en);

/**
 *   @brief Function used to set the amount of elements to be displayed on the display.
 *
 *   @retval void
 */
extern void setCountElem(void);

/**
 *   @brief Function used to calculate the value of the progress unit.
 *
 *   @retval The value of the progress unit. Otherwise, -1 is returned.
 */
extern uData8 calculateUnitProgress(void);

/**
 *   @brief Function used to select the data item that will be shown to the user.
 *
 *   @retval The value of the menu state. Otherwise, -1 is returned.
 */
extern uData8 selectItem(void);

/**
 *   @brief Function used to increase the value of a menu item.
 *
 *   @retval The value of the item that has been increased. Otherwise, -1 is returned.
 */
extern uData8 KeyUp(void);

/**
 *   @brief Function used to deacrease the value of a menu item.
 *
 *   @retval The value of the item that has been deacreased. Otherwise, -1 is returned.
 */
extern uData8 KeyDown(void);
