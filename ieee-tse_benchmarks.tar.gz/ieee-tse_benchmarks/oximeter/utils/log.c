/*********************************************************
* File:        buffer.c
* Abstract:    Implementation of the log system
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include <string.h>
//#include <assert.h>
#include "log.h"

/***********************************************
* LOCAL MACROS                                 *
************************************************/
#define BUFFER_MAX  6400

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static char buffer[BUFFER_MAX];     /* BUFFER */

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
void initLog(Data8 max) {

	buffer_size = max;
	first = next = 0;
}

Data8 removeLogElement(void) {

#if VERIFICATION
	__CPROVER_assert(first>=0, "removeLogElement");
#endif
	if (next >= 0 && first < buffer_size) {
		first++;
		return buffer[first-1];
	}
	else {
		return LOGERROR;
	}
}  

#if 0
bug found by NuSMV2
Data8 removeLogElement(void) {

	first++;
	return buffer[first-1];
}  
#endif

#if 1
Data8 insertLogElement(Data8 b) {

	if (next < buffer_size & buffer_size > 0) {
		buffer[next] = b;
		next = (next+1)%buffer_size;
#if VERIFICATION
	__CPROVER_assert(next<buffer_size, "insertLogElement");
#endif
	} else {
		return LOGERROR;
	}

	return b;
}
#endif
#if 0
//bug
void insertLogElement(Data8 b) {

	buffer[next] = b;
	next = (next+1)%buffer_size;
}
#endif

void logm(char *msg) {

	size_t size;
	int i;

	if (msg!=NULL) {
		size = strlen(msg);
#if VERIFICATION
	__CPROVER_assert(size>=0, "logm");
#endif
	}

	for(i=0; i<size; i++){
		insertLogElement(msg[i]);
	}

}

#if 0
void logm(char *msg) {

	size_t size;
	int i;

	if (msg!=NULL)
		size = strlen(msg);

	for(i=0; i<size; i++){
		insertLogElement(msg[i]);
	}

}
#endif

#if 1
Data8 getBufferSize(void) {

	if (buffer[0]!='\0') {
#if VERIFICATION
	__CPROVER_assert(strlen(buffer)>=0, "logm");
#endif
		return strlen(buffer);
	}

}
#endif

#if 0
//bug
Data8 getBufferSize(void) {

	return strlen(buffer);

}
#endif
#if 0
Data8 sendLog2PC(void)	{

	uData8 i, err=0;
	size_t bsize;

	if (buffer[0]!='\0')
		bsize = strlen(buffer);

	if (bsize<=0){
		err=-1;
	}
	
	for(i=0; i<bsize; i++){
	#if (TARGET)
		SBUF=buffer[i];
		while(TI==0);
   		TI=0; 
	#endif
		logTransferProgress();
	}

	return err;
}
#endif
#if 1
//bug
Data8 sendLog2PC(void)	{

	uData8 i, err=0;
	size_t bsize;

	bsize = strlen(buffer);

	if (bsize<=0){
		err=-1;
	}
	
	for(i=0; i<bsize; i++){
	#if (TARGET)
		SBUF=buffer[i];
		while(TI==0);
   		TI=0; 
	#endif
		logTransferProgress();
	}

	return err;

}
#endif
int nondet_int();

void testCircularBuffer(void){
	int input=nondet_int();
//	__CPROVER_assume(input!=89 && input!=113 && input!=-57 && input!=0 && input!=1 && input!=-128 && input!=98 && input!=88 && input!=59 && input!=1 && input!=-128 && input!=90 && input!=0 && input!=-37 && input!=43 && input!=-28 && input!=-98 && input!=18 && input!=-90 && input!=0 && input!=-1 && input!=1 && input!=0 && input!=-37);
    __CPROVER_assume(input > -128 && input < 128);
	int i, size;
	size=1;
	int senData[size];
	
	initLog(size);

	for(i=0; i<size; i++){
//		senData[i]=nondet_int();
		senData[i]=input;
	}

	for(i=0; i<size; i++){
		insertLogElement(senData[0]);
	}

	for(i=0; i<size; i++){
		assert(senData[0] == removeLogElement());
	}

}

