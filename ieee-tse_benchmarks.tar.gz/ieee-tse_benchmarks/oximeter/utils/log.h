/*********************************************************
* File:        log.h
* Abstract:    Interface of the log system
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#ifndef _LOG_H
#define _LOG_H

/*******************
* INCLUDE FILES    *
********************/
#include "../drivers/global.h"
#include "../drivers/sensor.h"

/*******************
* EXPORTED MACROS  *
********************/
#define TOKEN	(#)

#ifdef DEBUG
#define debug(parms...) logm(parms);
#else
#define debug(parms...)
#endif

#define LOGERROR 100

static uData8 first;                 /* Pointer to the input buffer   */
static uData8 next;                  /* Pointer to the output pointer */
static uData8  buffer_size;           /* Max amount of elements in the buffer */

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
*   @brief Procedure used to set the amount of elements in the buffer
*   and initializes the input and output pointers.
*
*   @retval void
*/
extern void initLog(Data8);

/**
*   @brief Procedure used to remove the current element pointed 
*   by the output pointer. It just increments the output
*   pointer.
*
*   @retval The buffer element.
*/
extern Data8 removeLogElement(void);

/**
*   @brief Procedure used to insert an element into the position
*   pointed by the input pointer and increments the input 
*   pointer.
*
*   @retval void
*/
extern Data8 insertLogElement(Data8);

/**
*   @brief Procedure used to write in the circular buffer
*
*   @retval void
*/
extern void logm(char *msg);

/**
*   @brief Function used to send the log messages to the PC
*
*   @retval This function returns 0 if the log is sent successfully. 
*			If an error occurs then -1 is returned.
*/
extern Data8 sendLog2PC(void);

/**
*   @brief Function used to get the buffer size of the log messages
*
*   @retval The length of string
*/
extern Data8 getBufferSize(void);

/**
*   @brief Procedure used to provide the status of transferring 
*		   the log messages to the PC.
*
*   @retval The progress of the transferring operation.
*/
extern uData8 logTransferProgress(void);

#endif /* _LOG_H */
