/*********************************************************
* File:        serial.c
* Abstract:    Implementation of the serial driver
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include "serial.h"


#define OC8051_RST_SCON 0x00 	// serial control
#define OC8051_SFR_SCON 0x98 	// serial control 0
#define OC8051_SFR_B_SCON 0x13 	// serial control

/******************************************************************
* FUNCTION PROTOTYPES                 			  		          *
*******************************************************************/
static void Comm(void);
void next_timeframe(); /* Next Timeframe  */

/******************************************************************
* EXTERN DATA                 					  				  *
*******************************************************************/
extern const unsigned int bound; /* Unwinding Bound */

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static char sensorword; /* Array with receicved bytes */
static uData8 cont=0;	/* Count received bytes       */

/******************************************************************
* EXTERN STRUCTS                                                  *
*******************************************************************/

extern const struct module_oc8051_uart oc8051_uart;
extern const struct module_oc8051_tc oc8051_tc;
extern const struct module_oc8051_int oc8051_int;

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
uData8 calculateTimerVal(uData8 BR){

	Data8 timerVal=-1;

    switch(BR){

        case br1200:
            timerVal = reg1200;
            break;
        case br2400:
            timerVal = reg2400;
            break;
        case br9600:
            timerVal = reg9600; 
            break;
        case br19200:
            timerVal = reg19200;
            break;
    }

	assert(timerVal>0);
	return timerVal;

}

/**
 * @brief configure the serial port to the 
 *   baud rate passed in the function call,
 *   no parity, no flow control, stop bits equal to 1, 
 *   and data bits equal to 8.
 */
void serial_init(uData8 baudRate){

	int cycle; 
	unsigned char scon_test,wr_addr_bit;

#if (TARGET)

	SCON = 0x50;		/* SCON mode 1, 8-bit UART */
	TMOD = 0x20;		/* TMOD: timer 1, mode 2, 8-bit automatic reload */
	TR1 = 1;			/* TR1: enable timer 1 */
	IE = 0x90;			/* enable serial interruption */
	TH1 = calculateTimerVal(baudRate);

#endif

#if (VERIFICATION)

	__CPROVER_assume(oc8051_uart.scon=0x50);
	__CPROVER_assume(oc8051_tc.tmod=0x20);
	__CPROVER_assume(oc8051_int.tr1=1);
	__CPROVER_assume(oc8051_int.ie=0x90);
	__CPROVER_assume(oc8051_tc.th1 =calculateTimerVal(baudRate));
	__CPROVER_assume(oc8051_uart.rst==1);

	wr_addr_bit = oc8051_uart.wr_addr&0x07;

	for(cycle=0; cycle<bound; cycle++) {
		if (oc8051_uart.rst) {
 	    	scon_test = OC8051_RST_SCON;
		} else if ((oc8051_uart.wr) && !(oc8051_uart.wr_bit) && (oc8051_uart.wr_addr==OC8051_SFR_SCON)) {
			scon_test = oc8051_uart.data_in;
		} else if ((oc8051_uart.wr) && (oc8051_uart.wr_bit) && (((oc8051_uart.wr_addr&0xF8)>>3)==OC8051_SFR_B_SCON)) {
			scon_test = oc8051_uart.bit_in;
		} else if (oc8051_uart.tx_done) {
			scon_test = scon_test|0x02;
		} else if (!oc8051_uart.rx_done) {
			if ((oc8051_uart.scon&0xC0) == 0x00) {
				scon_test = scon_test|0x01;
			} else if ((oc8051_uart.sbuf_rxd_tmp[11]) || !(oc8051_uart.scon&0x20)) {
				scon_test = scon_test|0x01;
      			scon_test = (scon_test|((scon_test&0x40)&oc8051_uart.sbuf_rxd_tmp[11]));
			} else {
		        scon_test = (scon_test|((scon_test&0x40)&oc8051_uart.sbuf_rxd_tmp[11]));
			}
		}
        next_timeframe();
   		assert(oc8051_uart.scon==(scon_test&0xFF));
	}

	assert(oc8051_tc.tmod==0x20);
	assert(oc8051_int.tr1==1);
	assert(oc8051_int.ie==0x90);

#endif


}

/**
 * @brief serial interruption. This is called if there are sensor 
 * data available in the serial port.
 */

#if (TARGET)
static void Comm(void) interrupt 4 { /* Routine to handle the serial interruption */
	if (RI){  
		RI=0;    				/* set the received flag */
		sensorword=SBUF;	 	/* read buffer that contains the sensor data */
		collectData(sensorword);
	}

   		
}
#endif

#if (VERIFICATION)
static void Comm(void) { /* Routine to handle the serial interruption */

	if (oc8051_uart.ri){  
		oc8051_uart.ri=0;    					/* set the received flag */
		sensorword=oc8051_uart.sbuf;	 	/* read buffer that contains the sensor data */
		collectData(sensorword);
		assert(oc8051_uart.ri==0);
	}	
}
#endif



