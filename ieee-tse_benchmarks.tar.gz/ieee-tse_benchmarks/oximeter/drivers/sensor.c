/*****************************************************************
* File:        sensor.c											
* Abstract:    Implementation of the sensor interface
* Platform:    AT89S8252
* Project:     Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
******************************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include "sensor.h"
#include "../utils/log.h"

/******************************************************************
* STATIC FUNCTION PROTOTYPES                 			  		  *
*******************************************************************/
static void fillArrays(Data8 rawData, uData8 cont);

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static Data8 itr=0, checkSum[SIZEOFFRAME];
static uData8 contPos=0, contCHK=0, flag1=FALSE, flag2=FALSE, frame=0;
static char serialData[MAXNUMOFBYTE];
static char tmp[10];static uData8 srev;	/* Oximeter Firmware Revision Level */
#if (TARGET)
bit OutofTrack=FALSE;
#else
static Data8 OutofTrack=FALSE;
#endif

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
void initSensor(void){

	Data8 i;

	df2_ptr = &df2;
	sf_ptr = &sf;
	avg_ptr = &avg;
	
	for(i=0; i<ELEMEN; i++){
	
		df2_ptr->hrmsb[i]=0;
		df2_ptr->hrlsb[i]=0;
		df2_ptr->spo2[i]=0;
		df2_ptr->spo2d[i]=0;
		df2_ptr->spo2fast[i]=0;
		df2_ptr->spo2b[i]=0;
		df2_ptr->ehrmsb[i]=0;
		df2_ptr->ehrlsb[i]=0;
		df2_ptr->espo2[i]=0;
		df2_ptr->hrdmsb[i]=0;
		df2_ptr->hrdlsb[i]=0;
		df2_ptr->ehrdmsb[i]=0;
		df2_ptr->ehrdlsb[i]=0;
		df2_ptr->espo2d[i]=0;
		
	}

}

#if 1
void initStatus(void){

	if (sf_ptr != NULL)	{
		sf_ptr->sync = FALSE;
		sf_ptr->gprf = FALSE;
		sf_ptr->rprf = FALSE;
		sf_ptr->yprf = FALSE;
		sf_ptr->snsa = FALSE;
		sf_ptr->oot  = FALSE;
		sf_ptr->artf = FALSE;
		sf_ptr->snsd = FALSE;
		sf_ptr->bit7 = FALSE;	
	}
}
#else
//bug
void initStatus(void){

	sf_ptr->sync = FALSE;
	sf_ptr->gprf = FALSE;
	sf_ptr->rprf = FALSE;
	sf_ptr->yprf = FALSE;
	sf_ptr->snsa = FALSE;
	sf_ptr->oot  = FALSE;
	sf_ptr->artf = FALSE;
	sf_ptr->snsd = FALSE;
	sf_ptr->bit7 = FALSE;	

}
#endif

/**
 * @biref: Calculate the average of the sensor data
 * @retval: integer
 *
 * Comments:
 * - This function returns the average value of the data
 *   read by the sensor. For instance, the sensor provides 
 *   the HR and SpO2 three times within one second then 
 *   this function sums three HR or SpO2 values and 
 *   divides them by the amount was read.
 */
uData8 showAverage(Data8 *sensorData){  

	Data8 i=0, sensorValue=0, numElements=0, aux=0;

#if 1
    sensorData = (Data8 *) malloc(sizeof(Data8) * ELEMEN);
	__CPROVER_assume (sensorData[0]==0);
	__CPROVER_assume (sensorData[1]==1);
	__CPROVER_assume (sensorData[2]==2);
#endif

	for(i=0; i<ELEMEN; i++){
		if ( sensorData[i]!=0 ){
			sensorValue = sensorValue + sensorData[i];
			++numElements;
		}
	}
	if (numElements!=0){
		aux = sensorValue/numElements;
	}
	else{
		aux=0;
	}	

#if VERIFICATION
	__CPROVER_assert(aux>=0, "showAverage");
#endif
	
	return aux;

}

uData8 signalInverter(Data8 signal) {

	uData8 inverter;

	if(signal >= 0) {
		inverter = signal;
	} else {
		inverter = INV*signal;
	}

#if VERIFICATION
	__CPROVER_assert(inverter>=0, "signalInverter");
#endif

	return inverter;
}

uData8 checkValidBytes(Data8 *chBytes) {

	uData8 i, chSum=0, result=0, err=0;

	for(i=0; i<(SIZEOFFRAME-1); i++) {
		chSum = chSum + signalInverter(chBytes[i]);
	}

	result = (chSum%BIT8);

	if(result!=chBytes[SIZEOFFRAME-1]) {
		err=-1;
	}

	return err;
}

/**
 * @brief: Collect the data from the sensor
 * Return value: none
 *
 * Comments:
 * - This procedures is called when there is data available
 *   in the serial port. Then it stores the data from the sensor
 *   in an array that will be used further in order to fill in 
 *   other arrays.
 */
void collectData(Data8 sensorByte) {

	int chkerr, i;

	debug("%dSENSOR->sensor.c:%d(%d), Testing...", TOKEN, __FUNCTION__, __LINE__);

	if ( contPos==125) {              
	    contPos=0;
		frame=0;
		flag1=FALSE;
		flag2=FALSE;
	}

	if (sensorByte == 1 || flag2 == TRUE) {

		if (flag2 == FALSE) {
			checkSum[contCHK]=sensorByte;
			contCHK++;
			flag2=TRUE;
		}
		else if ((SYNC&sensorByte) == TRUE || flag1 == TRUE) {
			checkSum[contCHK]=sensorByte;
			contCHK++;
		}	flag1=TRUE;
	}
	if(frame==3){
		srev = checkSum[3];
	}

	if (contCHK == 5){
		chkerr = checkValidBytes(checkSum);
		if (chkerr == FALSE){
			for(i=0; i<SIZEOFFRAME; i++){
				fillArrays(checkSum[i], contPos);
				contPos++;
			}
		}
		else{
			for(i=0; i<SIZEOFFRAME; i++){
				if(i==3){
					fillArrays(0, contPos);
					contPos++;
				}
				else{
					fillArrays(checkSum[i], contPos);
					contPos++;
				}
			}
		}
		frame++;
		contCHK=0;
	}	


#if VERIFICATION
	__CPROVER_assert(contPos>=0, "collectData");
	__CPROVER_assert(contCHK>=0, "collectData");
#endif

}

#if 1
uData8 sensorCheckStatus(Data8 statusByte){

	if (sf_ptr != NULL)
	{
		sf_ptr->sync = SYNC&statusByte;
		sf_ptr->gprf = GPRF&statusByte;
		sf_ptr->rprf = RPRF&statusByte;
		sf_ptr->yprf = YPRF&statusByte;
		sf_ptr->snsa = SNSA&statusByte;
		sf_ptr->oot  = OOT&statusByte;
		sf_ptr->artf = ARTF&statusByte;
		sf_ptr->snsd = SNSD&statusByte;
		sf_ptr->bit7 = SBIT7&statusByte;
	} else {
		return NULL_POINTER;
	}

	return SENSOR_OK;	
}
#else
//bug
static void sensorCheckStatus(Data8 statusByte){

	sf_ptr->sync = SYNC&statusByte;
	sf_ptr->gprf = GPRF&statusByte;
	sf_ptr->rprf = RPRF&statusByte;
	sf_ptr->yprf = YPRF&statusByte;
	sf_ptr->snsa = SNSA&statusByte;
	sf_ptr->oot  = OOT&statusByte;
	sf_ptr->artf = ARTF&statusByte;
	sf_ptr->snsd = SNSD&statusByte;
	sf_ptr->bit7 = SBIT7&statusByte;

}
#endif

/**
 * @brief: Fill in arrays with sensor data
 * Return value: none
 *
 * Comments:
 * - This procedures is called in order to fill in
 *   the heart rate and SpO2 arrays in standard and
 *   display modes. When SpO2 and HR cannot be computed, 
 *   the sensor will send a missing data indicator. 
 *   For missing data, the HR equals 511 and the 
 *   SpO2 equals 127.
 */

static void fillArrays(Data8 rawData, uData8 cont){

	if (cont==124){           /* verify if the packet is complete with 25 frames */
		itr++;
	}
	
	if (itr==3){            /* check if three packets were already read */
        itr=0;
	    setSensorData();
	    //printValue();
     }
        
	if (df2_ptr != NULL)
	{
		switch(cont){

			case posStatus:
				sensorCheckStatus(rawData);
				break;	
			case posHRMSB:
				if (rawData != 3){
					df2_ptr->hrmsb[itr]= rawData*BIT7;
				}
				else{
					df2_ptr->hrmsb[itr]=0;
				}
				break;
			case posHRLSB:
				if (rawData != 127){
					df2_ptr->hrlsb[itr]= rawData; 
				}
				else{
					df2_ptr->hrlsb[itr]=0;
				}
				break;
			case posSpO2:
				if (rawData != 127){
					df2_ptr->spo2[itr]= rawData;
				}
				else{
					df2_ptr->spo2[itr]=0;
				}
				break;
#if 0
		case posREV:
			srev = rawData;
			break;
#endif
			case posSpO2D:
				if (rawData != 127){
					df2_ptr->spo2d[itr]= rawData;
				}
				else{
					df2_ptr->spo2d[itr]=0;
				}
				break;	
			case posSpO2Fast:		
				if (rawData != 127){
					df2_ptr->spo2fast[itr]= rawData;
				}
				else{
					df2_ptr->spo2fast[itr]=0;
				}
				break;	
			case posSpO2BB:
				if (rawData != 127){
					df2_ptr->spo2b[itr]= rawData;
				}
				else{
					df2_ptr->spo2b[itr]=0;
				}
				break;	
			case posEHRMSB:
				if (rawData != 3){
					df2_ptr->ehrmsb[itr]= rawData*BIT7;
				}
				else{
					df2_ptr->ehrmsb[itr]=0;
				}
				break;	
			case posEHRLSB:
				if (rawData != 127){
					df2_ptr->ehrlsb[itr]= rawData;
				}
				else{
					df2_ptr->ehrlsb[itr]=0;
				}
				break;	
			case posESpO2:
				if (rawData != 127){
					df2_ptr->espo2[itr]= rawData;
				}
				else{
					df2_ptr->espo2[itr]=0;
				}
				break;	
			case posESpO2D:
				if (rawData != 127){
					df2_ptr->espo2d[itr]= rawData;
				}
				else{
					df2_ptr->espo2d[itr]=0;
				}
				break;	
			case posHRDMSB:
				if (rawData != 3){
					df2_ptr->hrdmsb[itr]= rawData*BIT7;
				}
				else{
					df2_ptr->hrdmsb[itr]=0;
				}
				break;	
			case posHRDLSB:
				if (rawData != 127){
					df2_ptr->hrdlsb[itr]= rawData;
				}
				else{
					df2_ptr->hrdlsb[itr]=0;
				}
				break;	
			case posEHRDMSB:
				if (rawData != 3){
					df2_ptr->ehrdmsb[itr]= rawData*BIT7;
				}
				else{
					df2_ptr->ehrdmsb[itr]=0;
				}
				break;	
			case posEHRDLSB:
				if (rawData != 127){
					df2_ptr->ehrdlsb[itr]= rawData;
				}
				else{
					df2_ptr->ehrdlsb[itr]=0;
				}
				break;
		}
	}
#if VERIFICATION
	__CPROVER_assert(itr<4, "fillArrays");
#endif
}

/**
 * @brief This sets all HR and SpO2 data in standard
 *   	  and display mode. 
 * 
 * Comments: This procedure is called every second.
 */
uData8 setSensorData(void){

	if (df2_ptr != NULL)
	{
		avg_ptr->hr = showAverage(df2_ptr->hrmsb) + showAverage(df2_ptr->hrlsb);
		avg_ptr->hrd = (showAverage(df2_ptr->hrdmsb) + showAverage(df2_ptr->hrdlsb));
		avg_ptr->ehrd = (showAverage(df2_ptr->ehrdmsb) + showAverage(df2_ptr->ehrdlsb));
		avg_ptr->ehr = (showAverage(df2_ptr->ehrmsb) + showAverage(df2_ptr->ehrlsb));
		avg_ptr->spo2 = showAverage(df2_ptr->spo2);
		avg_ptr->spo2d = showAverage(df2_ptr->spo2d);
		avg_ptr->spo2fast = showAverage(df2_ptr->spo2fast);
		avg_ptr->spo2b = showAverage(df2_ptr->spo2b);
		avg_ptr->espo2 = showAverage(df2_ptr->espo2);
		avg_ptr->espo2d = showAverage(df2_ptr->espo2d);
	} else {
		return NULL_POINTER;
	}

	return SENSOR_OK;
}

#if 0
//bug
void setSensorData(void){

	avg_ptr->hr = showAverage(df2_ptr->hrmsb) + showAverage(df2_ptr->hrlsb);
	avg_ptr->hrd = (showAverage(df2_ptr->hrdmsb) + showAverage(df2_ptr->hrdlsb));
	avg_ptr->ehrd = (showAverage(df2_ptr->ehrdmsb) + showAverage(df2_ptr->ehrdlsb));
	avg_ptr->ehr = (showAverage(df2_ptr->ehrmsb) + showAverage(df2_ptr->ehrlsb));
	avg_ptr->spo2 = showAverage(df2_ptr->spo2);
	avg_ptr->spo2d = showAverage(df2_ptr->spo2d);
	avg_ptr->spo2fast = showAverage(df2_ptr->spo2fast);
	avg_ptr->spo2b = showAverage(df2_ptr->spo2b);
	avg_ptr->espo2 = showAverage(df2_ptr->espo2);
	avg_ptr->espo2d = showAverage(df2_ptr->espo2d);
}
#endif

uData8 getHR(void){

	if (avg_ptr !=NULL)
   		return avg_ptr->hr;	/* Provide the HR value in standard mode */	else 
		return NULL_POINTER;
}

uData8 getHRD(void){

	if (avg_ptr !=NULL)
		return avg_ptr->hrd;	/* Provide the HR value in display mode */
	else
		return NULL_POINTER;

}

uData8 getEHRD(void){

	if (avg_ptr !=NULL)
		return avg_ptr->ehrd;	/* Provide the EHRD value in display mode */
	else 
		return NULL_POINTER;
}

uData8 getEHR(void){

	if (avg_ptr !=NULL)
		return avg_ptr->ehr;	/* Provide the EHR value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getSpO2(void){

	if (avg_ptr !=NULL)
		return avg_ptr->spo2;	/* Provide the SpO2 value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getSpO2D(void){

	if (avg_ptr !=NULL)	
		return avg_ptr->spo2d;	/* Provide the SpO2 value in display mode */
	else
		return NULL_POINTER;
}

uData8 getSpO2Fast(void){

	if (avg_ptr !=NULL)
		return avg_ptr->spo2fast;	/* Provide the SpO2 Fast value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getSpO2B(void){

	if (avg_ptr !=NULL)
		return avg_ptr->spo2b;	/* Provide the SpO2B-B value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getESpO2(void){

	if (avg_ptr !=NULL)
		return avg_ptr->espo2; /* Provide the ESpO2 value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getESpO2D(void){

	if (avg_ptr!=NULL)
		return avg_ptr->espo2d;	/* Provide the ESpO2D value in standard mode */
	else
		return NULL_POINTER;
}

uData8 getSREV(void){

	return srev;	/* Provide the firmware version */

}


#if (TARGET)
bit IsOutofTrack(){

   return OutofTrack;   /* indicates if the sensor is out of track or not */

}

bit IsSensorDisconnected(void){

    return sf_ptr->snsd;

}

#else

uData8 IsOutofTrack(){

   return OutofTrack;   /* indicates if the sensor is out of track or not */

}

uData8 IsSensorDisconnected(void){

	if (sf_ptr != NULL)
    	return sf_ptr->snsd;
	else
		return NULL_POINTER;

}

#endif



