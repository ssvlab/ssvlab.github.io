/*********************************************************
* File:        global.h
* Abstract:    Global variables of the system
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#ifndef _GLOBAL_H
#define _GLOBAL_H

/*******************
* INCLUDE FILES    *
********************/
#include <string.h>	 /* functions to manipulate the strings */
#include <stdio.h>
#include <stdlib.h>

#define TRUE  (1)
#define FALSE (0)
#define NULL_POINTER	(0)

/**
*  @brief 0 -> indicates that the software must be
*		  compiled using GCC. 1 -> indicates that
*		  the software must be compiled using sdcc.
*/
#define TARGET (0) 

/**
*  @brief 1 -> indicates that the hardware dependent
*		  software will be verified by model checker
*		  tools. 0 -> otherwise.
*/
#define VERIFICATION (1)

#define BIT0 (0x01)
#define BIT1 (0x02)
#define BIT2 (0x04)
#define BIT3 (0x08)
#define BIT4 (0x10)
#define BIT5 (0x20)
#define BIT6 (0x40)
#define BIT7 (0x80)
#define BIT8 (BIT7<<1)

#define LCDSIZE 	(32)
#define LINE1 1
#define LINE2 2

/********************************
* ENUMERATIONS
*********************************/
enum sensorOp { HR=1, SPO2, SPO2D, SPO2FAST, SPO2B, EHR,
                ESPO2, HRD, EHRD, ESPO2D, SREV };


/******************************************************************
* TYPEDEF DECLARATION                 			  		          *
*******************************************************************/
typedef unsigned char _uchar;
typedef _Bool _array_of_2_Bool[2];
typedef _Bool _array_of_3_Bool[3];
typedef _Bool _array_of_4_Bool[4];
typedef _Bool _array_of_6_Bool[6];
typedef _Bool _array_of_12_Bool[12];
typedef _Bool _array_of_11_Bool[11];
typedef _array_of_3_Bool _array_of_2__array_of_3_Bool[2];
typedef _array_of_2_Bool _array_of_2__array_of_2_Bool[2];


/*********************
* EXPORTED STRUCT    *
**********************/

struct module_oc8051_uart {
  _Bool rst;
  _Bool clk;
  _Bool bit_in;
  _Bool wr;
  _Bool rxd;
  _Bool wr_bit;
  _Bool t1_ow;
  _Bool brate2;
  _Bool pres_ow;
  _Bool rclk;
  _Bool tclk;
  _uchar data_in;
  _uchar wr_addr;
  _Bool txd;
  _Bool intr;
  _uchar scon;
  _uchar pcon;
  _uchar sbuf;
  _Bool t1_ow_buf;
  _Bool trans;
  _Bool receive;
  _Bool tx_done;
  _Bool rx_done;
  _Bool rxd_r;
  _Bool shift_tr;
  _Bool shift_re;
  _array_of_2_Bool rx_sam;
  _array_of_4_Bool tr_count;
  _array_of_4_Bool re_count;
  _uchar sbuf_rxd;
  _array_of_12_Bool sbuf_rxd_tmp;
  _array_of_11_Bool sbuf_txd;
  _Bool ren;
  _Bool tb8;
  _Bool rb8;
  _Bool ri;
  _Bool smod;
  _Bool wr_sbuf;
  _Bool sc_clk_tr;
  _Bool smod_clk_tr;
  _Bool sc_clk_re;
  _Bool smod_clk_re;
};

struct module_oc8051_tc {
  _uchar wr_addr;
  _uchar data_in;
  _Bool clk;
  _Bool rst;
  _Bool wr;
  _Bool wr_bit;
  _Bool ie0;
  _Bool ie1;
  _Bool tr0;
  _Bool tr1;
  _Bool t0;
  _Bool t1;
  _Bool pres_ow;
  _uchar tmod;
  _uchar tl0;
  _uchar th0;
  _uchar tl1;
  _uchar th1;
  _Bool tf0;
  _Bool tf1;
  _Bool tf1_0;
  _Bool tf1_1;
  _Bool t0_buff;
  _Bool t1_buff;
  _Bool tc0_add;
  _Bool tc1_add;
};

struct module_oc8051_int {
  _uchar wr_addr;
  _uchar data_in;
  _Bool wr;
  _Bool tf0;
  _Bool tf1;
  _Bool t2_int;
  _Bool ie0;
  _Bool ie1;
  _Bool clk;
  _Bool rst;
  _Bool reti;
  _Bool wr_bit;
  _Bool bit_in;
  _Bool ack;
  _Bool uart_int;
  _Bool tr0;
  _Bool tr1;
  _Bool intr;
  _uchar int_vec;
  _uchar ie;
  _uchar tcon;
  _uchar ip;
  _array_of_4_Bool tcon_s;
  _Bool tcon_tf1;
  _Bool tcon_tf0;
  _Bool tcon_ie1;
  _Bool tcon_ie0;
  _array_of_3_Bool isrc_cur;
  _array_of_2__array_of_3_Bool isrc;
  _array_of_2_Bool int_dept;
  _array_of_2_Bool int_dept_1;
  _Bool int_proc;
  _array_of_2__array_of_2_Bool int_lev;
  _Bool cur_lev;
  _array_of_6_Bool int_l0;
  _array_of_6_Bool int_l1;
  _array_of_6_Bool ip_l0;
  _array_of_6_Bool ip_l1;
  _array_of_6_Bool int_src;
  _Bool il0;
  _Bool il1;
  _Bool tf0_buff;
  _Bool tf1_buff;
  _Bool ie0_buff;
  _Bool ie1_buff;
};


/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/

#endif /* _GLOBAL_H */
