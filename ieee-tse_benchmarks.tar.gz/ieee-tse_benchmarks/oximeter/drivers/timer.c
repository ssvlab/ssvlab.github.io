/*********************************************************
* File:        timer.c
* Abstract:    Implementation of the timer
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include "timer.h"

/***********************************************
* LOCAL MACROS                                 *
************************************************/
#define THIGH		(0x3C)
#define TLOW  		(0xAF)
#define MAXCOUNTER 	(65535)
#define TC 		(1000)
#define MASKMSB 	(0xFF00)
#define MASKLSB 	(0x00FF)
#define ONESECOND 	(20)
#define SECOND 		(1000)

/******************************************************************
* VERILOG EXTERN STRUCTS                                          *
*******************************************************************/

extern const struct module_oc8051_int oc8051_int;
extern const struct module_oc8051_tc oc8051_tc;


extern const struct module_DW8051_intr_1 DW8051_intr_1;
extern const struct module_DW8051_intr_0 DW8051_intr_0;
extern const struct module_DW8051_timer DW8051_timer;

/******************************************************************
* STATIC FUNCTION PROTOTYPES                 			  		  *
*******************************************************************/
static void system_tick(void);
void next_timeframe();

/******************************************************************
* EXTERN DATA                 					  				  *
*******************************************************************/
extern const unsigned int bound; /* Unwinding Bound */

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static uData8 count_ticks, ticks, tms;

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
void initTimers(void) {
	count_ticks=0;
	ticks=0;
	tms=0;
}

uData8 calculateTRegVal(uData8 t) {

	uData8 tms;

	if ((t*TC) < MAXCOUNTER )
		tms = MAXCOUNTER - (t*TC);
	else
		tms = 0;
#if VERIFICATION
	__CPROVER_assert(tms>=0, "calculateTRegVal: tms should be greater or igual to 0");
#endif

	return tms;
}

#if 0
bug found by NuSMV2
uData8 calculateTRegVal(uData8 t) {

	uData8 tms;

	tms = MAXCOUNTER - (t*TC);

	return tms;
}
#endif

uData8 calculateTH(uData8 t) {

	uData8 tReg, result;

	tReg = calculateTRegVal(t);
	result = ((tReg&MASKMSB) >> 8);

	assert(result>0);
#if VERIFICATION
	__CPROVER_assert(result>=0, "calculateTH");
#endif

	return result;

}

uData8 calculateTL(uData8 t) {

	uData8 tReg, result;

	tReg = calculateTRegVal(t);
	result = tReg&MASKLSB;

#if VERIFICATION
	__CPROVER_assert(result>=0, "calculateTL");
#endif

	return result;
}

/**
 * @brief configure the timer according to the parameter passed 
 *   in the function call. The time parameter must be in the range 
 *   of 1 ms to 50ms.
 */
Data8 initTimer0ms(uData8 time_ms) {

	int cycle;

	tms=time_ms;

#if (TARGET)
	EA = 0;				/* disable all interruptions (IE register) 	*/
	TR0 = 0;			/* stop timer0 (TCON register)			*/
	TMOD = (TMOD&0xF0)|0x01;	/* timer0 mode 1 (TMOD register)		*/
	TH0 = calculateTH(time_ms);	/* load TH0 with high order byte (TH)	*/
	TL0 = calculateTL(time_ms);	/* load TL0 with low order byte (TLO)	*/
	TR0 = 1;			/* enable counter of timer0 (TCON register)		*/
	ET0 = 1;			/* enable interruption of timer0 (IE register)	*/
	EA = 1;				/* enable all interruptions (IE register)	*/
#endif

#if (VERIFICATION)
	__CPROVER_assume(oc8051_int.ie==(oc8051_int.ie&0x7F));
	__CPROVER_assume(oc8051_int.tr0==0);
	__CPROVER_assume(oc8051_tc.tmod==((oc8051_tc.tmod&0xF0)|0x01));
	__CPROVER_assume(oc8051_tc.th0==calculateTH(time_ms));
	__CPROVER_assume(oc8051_tc.tl0==calculateTL(time_ms));
	__CPROVER_assume(oc8051_tc.tr0==1);
	__CPROVER_assume(oc8051_int.ie==(oc8051_int.ie|0x02));
	__CPROVER_assume(oc8051_int.ie==(oc8051_int.ie|0x80));

	for(cycle=0; cycle<bound; cycle++) {
		__CPROVER_assume(oc8051_tc.rst==0);
		next_timeframe();
	}

	assert(oc8051_tc.th0==calculateTH(time_ms));
	assert(oc8051_tc.tl0==calculateTL(time_ms));
	assert((oc8051_tc.tmod&0x01)==0x01);
	assert((oc8051_int.ie&0x82)==0x82);
	assert(oc8051_tc.tr0==1);
#endif

	return (tms <= 0) ? -1:tms;
}

/**
 * @brief configure the timer in scale of seconds.
 *        
 */
Data8 initTimer0s(uData8 time_s) {

	if (tms==0) {
		initTimer0ms(50);
		ticks = (time_s*ONESECOND);
	} else if (tms>0){
		ticks = (time_s*(SECOND/tms));
	}
	
	return (ticks<0) ? -1:ticks;

}
#if 0
bug found by NuSMV2
Data8 initTimer0s(uData8 time_s) {

	if (tms==0) {
		initTimer0ms(50);
		ticks = (time_s*ONESECOND);
	} else {
		ticks = (time_s*(SECOND/tms));
	}
	
	return (ticks<0) ? -1:ticks;

}
#endif

/**
 * @brief deactivate the timer and check if the count_ticks
 *   variable has already expired. If it expried, i.e.
 *   it elapsed one second then it calls the printValue()
 *   in order to print the sensor data. 
 */

#if (TARGET)
static void system_tick(void) interrupt 1
{
   TR0 = 0;              /* stop timer0 (TCON register) */
   TH0 = THIGH;           
   TL0 = TLOW;           
   timerms_interrupt();
   if (count_ticks++ == ticks){  /* checks if one second has expired */
       
      count_ticks=0;		   
      timers_interrupt();  

    }

   TR0 = 1;          	       /* enable timer0 count (TCON register) */

}
#endif

#if (VERIFICATION)
static void system_tick(void)
{
	int cycle;

   __CPROVER_assume(oc8051_tc.rst==1);

   __CPROVER_assume(oc8051_tc.tr0 == 0);   /* stop timer0 (TCON register) */
   __CPROVER_assume(oc8051_tc.th0==THIGH); 
   __CPROVER_assume(oc8051_tc.tl0==TLOW);   
   timerms_interrupt();

   if (count_ticks++ == ticks){  /* checks if one second has expired */
   	  count_ticks=0;		   
      timers_interrupt();  
   }

	oc8051_tc.tr0 = 1;			/* enable timer0 count (TCON register) */

	for(cycle=0; cycle<bound; cycle++) {
		__CPROVER_assume(oc8051_tc.rst==0);
		next_timeframe();
	}
	assert(oc8051_tc.th0 == THIGH);
	assert(oc8051_tc.tl0 == TLOW);
	assert(oc8051_tc.tr0==1);

}
#endif


