/*********************************************************
* File:        sensor.h
* Abstract:    Interface of the sensor driver
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/
#ifndef _SENSOR_H
#define _SENSOR_H

/*******************
* INCLUDE FILES    *
********************/
#include "global.h"

/*******************
* EXPORTED MACROS  *
********************/
#define ELEMEN 3  /* define the number of elements in the sensor data array */
#define MAXNUMOFBYTE	(125)
#define VALIDDATA		(1)
#define SIZEOFFRAME		(5)
#define INV				(-1)
#define SENSOR_OK		(1)

/*********************
* EXPORTED TYPEDEFS  *
**********************/
typedef int Data8;
typedef unsigned int uData8;

/*********************
* ENUMERATIONS	     *				
**********************/
/* This enum defines the position of the sensor data in the packets */
enum sensorPosition {posStatus=1, posPleth=2, posHRMSB=3, posCHKSUM=4, posHRLSB=8,
				  posSpO2=13, posREV=18, posSpO2D=43, posSpO2Fast=48,
				  posSpO2BB=53, posEHRMSB=68, posEHRLSB=73, posESpO2=78,
				  posESpO2D=83, posHRDMSB=98, posHRDLSB=103, 
				  posEHRDMSB=108, posEHRDLSB=113};

enum sensorStatus {SYNC=0x01, GPRF=0x02, RPRF=0x03, YPRF=0x07, SNSA=0x08,
			OOT=0x10, ARTF=0x20, SNSD=0x40, SBIT7=0x80};


/******************************************************************
* EXTERNAL STRUCTS	                                              *
*******************************************************************/
/* Standard: SpO2 and HR updated on every pulse beat. */
/* Display: SpO2 and HR updated every 1.5 seconds. */

struct dataFormat{

	Data8 hrmsb[ELEMEN];	/* 4-beat average values in standard mode (MSB). */
	Data8 hrlsb[ELEMEN];	/* 4-beat average values in standard mode (LSB). */
	Data8 spo2[ELEMEN];		/* 4-beat average values in standard mode. 	 */
	Data8 spo2d[ELEMEN];	/* 4-beat average displayed values in display mode */
	Data8 spo2fast[ELEMEN];	/* Non-slew limited saturation with 4-beat averaging in standard mode. */
	Data8 spo2b[ELEMEN];	/* Un-averaged, non-slew limited, beat to beat value in standard mode. */
	Data8 ehrmsb[ELEMEN];	/* 8-beat average values in standard mode. */
	Data8 ehrlsb[ELEMEN];	/* 8-beat average values in standard mode. */
	Data8 espo2[ELEMEN];	/* 8-beat average values in standard mode. */
	Data8 hrdmsb[ELEMEN];	/* 4-beat average displayed values in display mode (MSB) */
	Data8 hrdlsb[ELEMEN];	/* 4-beat average displayed values in display mode (LSB) */
	Data8 ehrdmsb[ELEMEN];	/* 8-beat average displayed values in display mode (MSB) */
	Data8 ehrdlsb[ELEMEN];	/* 8-beat average displayed values in display mode (LSB) */
	Data8 espo2d[ELEMEN];	/* 8-beat average displayed values in display mode */

} df2;


struct sensorAvgVal{

	Data8 hr;	
	Data8 spo2;	
	Data8 spo2d;	
	Data8 spo2fast;
	Data8 spo2b;
	Data8 ehr;
	Data8 espo2;
	Data8 hrd;
	Data8 ehrd;
	Data8 espo2d;

} avg;

struct statusFormat{

#if (TARGET)
	bit sync;
	bit gprf;
	bit rprf;
	bit yprf;
	bit snsa;
	bit oot;
	bit artf;
	bit snsd;
	bit bit7;
#else
	uData8 sync;
	uData8 gprf;
	uData8 rprf;
	uData8 yprf;
	uData8 snsa;
	uData8 oot;
	uData8 artf;
	uData8 snsd;
	uData8 bit7;
#endif
} sf;

struct dataFormat *df2_ptr;
struct statusFormat *sf_ptr;
struct sensorAvgVal *avg_ptr;

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
extern uData8 showAverage(Data8 sensorData[]);
extern uData8 getHR(void);
extern uData8 getHRD(void);
extern uData8 getEHRD(void);
extern uData8 getEHR(void);
extern uData8 getSpO2(void);
extern uData8 getSpO2D(void);
extern uData8 getSpO2Fast(void);
extern uData8 getSpO2B(void);
extern uData8 getESpO2(void);
extern uData8 getESpO2D(void);
extern uData8 getSREV(void);
extern uData8 checkValidBytes(Data8 *chBytes);
extern uData8 signalInverter(Data8 signal);
extern void initSensor(void);
extern uData8 setSensorData(void);
extern uData8 checkStatus(void);

#if (TARGET)
   bit IsOutofTrack(void);
   bit IsSensorDisconnected(void);
   bit IsSensorAlarmOn(void);
#else
   extern uData8 IsOutofTrack(void);
   extern uData8 IsSensorDisconnected(void);
   extern uData8 IsSensorAlarmOn(void);
#endif

extern void collectData(Data8 sensorData);
extern void initStatus(void);
extern void printValue(void);

#endif /* _SENSOR_H */
