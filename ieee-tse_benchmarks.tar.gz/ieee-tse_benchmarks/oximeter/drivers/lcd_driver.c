/*********************************************************
* File:        LCD.c
* Abstract:    Implementation of the LCD
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#include <string.h>	/* functions to manipulate strings */

/***********************************************
* INCLUDE FILES                                *
************************************************/
#include "lcd_driver.h"

/* Assembly routines called from C program */
extern void write2lcd(unsigned char dado);
extern void lcd_init(void);

/******************************************************************
* STATIC DATA                 					  				  *
*******************************************************************/
static int length=0;

/*******************************************************************************
* FUNCTION IMPLEMENTATION						       						   *
********************************************************************************/
void lcd_write(const char *sPtr, int line, int column){

	size_t size;
	int i, flag_l1=FALSE, flag_l2=FALSE;
	char line1[LCDSIZE/2], line2[LCDSIZE/2];
	const char msg[LCDSIZE/2]="Message too long";

	if (sPtr!=NULL)
		size = strlen(sPtr);

	for(i=0; i<LCDSIZE/2; i++){
		line1[i]='\0';
		line2[i]='\0';
	}

	if(size<=LCDSIZE/2){
		flag_l1=1;
		for(i=0; i<LCDSIZE/2; i++){
			line1[i]=sPtr[i];
		}
	}
	else if (size>LCDSIZE/2 && size<=LCDSIZE){
		flag_l1=1;
		flag_l2=1;
		for(i=0; i<size; i++){

			if(i<LCDSIZE/2){
				line1[i]=sPtr[i];
			}
			else{
				line2[i-(LCDSIZE/2)]=sPtr[i];
			}
		}

	}
	else{
		flag_l1=1;
		for(i=0; i<(LCDSIZE/2); i++){
			line1[i]=msg[i];
		}
	}

	if(flag_l1==TRUE){
		lcd_printf(line1, line, column);
	}
	if(flag_l2==TRUE){
		lcd_printf(line2, line, column);
	}

}

/**
 * @brief Clean the display
 *
 * @retval void
 *
 * Comments:
 * - This procedures initializes the LCD in order to allow
 *   the programmer to write new strings on the LCD.
 */

uData8 lcd_clean(void){

#if (TARGET)   
	lcd_init();
#endif

	length=0;

	return LCD_OK;
}

/**
 * @brief: Write text to LCD
 *
 * retval: void
 *
 * Comments:
 * - This routine outputs some text to the LCD display
 *   according to the line and column parameters passed
 *   by the programmer.
 */

uData8 lcd_printf(const char *sPtr, _Bool line, int column)
{

	int i,j;

	if (line==1){
   	   for(i=0; i<(column-1); i++){
#if (TARGET)
	      write2lcd(0x20); /* write "null" to LCD */
#endif
	   }
	}
	else if (line == 2){  
	   for(i=0; i<(40-length); i++){
#if (TARGET)
	      write2lcd(0x20); /* write "null" to LCD */
#endif
	   }
	   for(j=0; j<(column-1); j++){
#if (TARGET)
	      write2lcd(0x20); /* write "null" to LCD */
#endif
	   }
	}

	if (sPtr != NULL) {
	    for ( ; *sPtr != '\0'; sPtr++ ){
	#if (TARGET)
		    write2lcd(*sPtr);
	#endif
			length++;
	   }
	} else {
		return NULL_POINTER;
	}

	return length;
}

#if 0
inconsistency found by NuSMV2
void lcd_printf(const char *sPtr, int line, int column)
{

#if (TARGET)

	int i,j;

	if (line==1){
   	   for(i=0; i<(column-1); i++){
	      write2lcd(0x20); /* write "null" to LCD */
	   }
	}
	else if (line == 2){  
	   for(i=0; i<(40-length); i++){
	      write2lcd(0x20); /* write "null" to LCD */
	   }
	   for(j=0; j<(column-1); j++){
	      write2lcd(0x20); /* write "null" to LCD */
	   }
	}

    for ( ; *sPtr != '\0'; sPtr++ ){
	    write2lcd(*sPtr);
		length++;
   }

#endif
}
#endif
