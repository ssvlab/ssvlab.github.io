/*********************************************************
* File:        timer.h
* Abstract:    Interface of the timer
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#ifndef _TIMER_H
#define _TIMER_H

/*******************
* INCLUDE FILES    *
********************/
#include "global.h"
#include "sensor.h"

#if (TARGET)
#include <8051.h>
#endif

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
 *   @brief Function used to configure the timer in miliseconds.
 *
 *   @retval  The time in miliseconds.
 */
extern Data8 initTimer0ms(uData8 time_ms);

/**
 *   @brief Function used to configure the timer in seconds.
 *
 *   @retval The time in seconds. Otherwise, -1 is returned.
 */
extern Data8 initTimer0s(uData8 time_s);

/**
 *   @brief Function used to calculate the timer register value
 *
 *   @retval The timer register value
 */
extern uData8 calculateTRegVal(uData8 t);

/**
 *   @brief Function used to calculate the timer high order byte
 *
 *   @retval The timer high order byte
 */
extern uData8 calculateTH(uData8 t);

/**
 *   @brief Function used to calculate the timer low order byte
 *
 *   @retval The timer low order byte
 */
extern uData8 calculateTL(uData8 t);

/**
 *   @brief Procedure that is called according to the timer ticks 
 *
 *   @retval void
 */
extern void timers_interrupt(void);

/**
 *   @brief Procedure that is called according to the timer ticks 
 *
 *   @retval void
 */
extern void timerms_interrupt(void);

/**
 *   @brief Procedure to initialize the timer
 *
 *   @retval void
 */
extern void initTimers(void);

#endif /* _TIMER_H */
