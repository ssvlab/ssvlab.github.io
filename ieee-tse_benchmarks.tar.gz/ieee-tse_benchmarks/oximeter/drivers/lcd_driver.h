/*********************************************************
* File:        LCD.h
* Abstract:    Interface of the LCD
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#ifndef _LCD_DRIVER_H
#define _LCD_DRIVER_H

/*******************
* INCLUDE FILES    *
********************/
#include "global.h"
#include "sensor.h"

#define LCD_OK	(1)

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
*   @brief Function used to write text to LCD 16x2
*
*   @retval void
*/
uData8 lcd_printf(const char *sPtr, _Bool line, int column);
//inconsistency found by NuSMV2
//void lcd_printf(const char *sPtr, int line, int column);

/**
*   @brief Function used to clean the LCD 16x2
*
*   @retval void
*/
extern uData8 lcd_clean(void);

#endif /* _LCD_DRIVER_H */
