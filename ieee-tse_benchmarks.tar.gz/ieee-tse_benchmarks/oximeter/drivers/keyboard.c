/******************************************************************
* File:        keyboard.c
* Abstract:    Implementation of the keyboard functions
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
******************************************************************/

/******************************************************************
* INCLUDE FILES    						  						  *
******************************************************************/
//#include <assert.h>
#include "keyboard.h"

/******************************************************************
* ENUMARATIONS	                                                  *
*******************************************************************/
enum Key_State {START=BIT0, STOP=BIT1, EMPTY1=BIT2, EMPTY2=BIT3, 
	        UP=BIT4, DOWN=BIT5, SELECT=BIT6, EMPTY3=BIT7};

/*******************************************************************************
* FUNCTION IMPLEMENTATION  					               					   *
********************************************************************************/

Data8 checkPressedButton(uData8 Key){

    int command=-1;

    switch(Key){

		case START:		command=startButton;    break;
		case STOP:		command=stopButton;     break;
		case UP:        command=upButton;       break;
		case DOWN:      command=downButton;     break;
		case SELECT:    command=selectButton;   break;
		case EMPTY1:    command=emptyButton;    break;
		case EMPTY2:    command=emptyButton;    break;
		case EMPTY3:    command=emptyButton;    break;	

    }

#if VERIFICATION
	__CPROVER_assert(command>=-1, "checkPressedButton");
#endif

    return command;

}
