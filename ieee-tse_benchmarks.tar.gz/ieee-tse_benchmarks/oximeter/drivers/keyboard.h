/*********************************************************
* File:        serial.h
* Abstract:    Interface of the keyboard driver
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/
#ifndef _KEYBOARD_H
#define _KEYBOARD_H

/*******************
* INCLUDE FILES    *
********************/
#include "global.h"
#include "sensor.h"
#include "lcd_driver.h"

/*******************
* ENUMARATIONS	   *
********************/
/**
 * @brief indicate the all available buttons of the keyboard.
 */
enum Key_Value {startButton=1, stopButton, emptyButton, upButton,
		downButton, selectButton};

/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
*   @brief Function used to detect the key that the user pressed
*
*   @retval Data8
*/
extern Data8 checkPressedButton(uData8);

#endif /* _KEYBOARD_H */
