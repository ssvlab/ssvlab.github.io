/*********************************************************
* File:        serial.h
* Abstract:    Interface of the serial driver
* Platform:    AT89S8252
* Project      Pulse Oximeter
* Author(s):   Lucas Cordeiro
* Copyright (C)2007 DCC, Federal University of Amazonas
*********************************************************/

#ifndef _SERIAL_H
#define _SERIAL_H

/*******************
* INCLUDE FILES    *
********************/
#include "global.h"
#include "sensor.h"

#if (TARGET)
#include <8051.h>
#endif

/********************************
* ENUMERATIONS					*
*********************************/
/**
 * @brief indicate the baud rates that can be set.
 */
enum BaudRateT {br1200=1200, br2400=2400, br9600=9600,
                    br19200=19200};

/**
 * @brief provide the register value for each baud rate.
 */
enum BaudRateReg {reg1200=0xE8, reg2400=0xF4, 
                    reg9600=0xFD, reg19200=0xFD};


/********************************
* EXPORTED FUNCTIONS PROTOTYPES *
*********************************/
/**
*   @brief Function used to initialize the serial communication
*
*   @retval void
*/
extern void serial_init(uData8 baudRate);

/**
*   @brief Function used to calculate the value of the TH01 register
*
*   @retval The register value of the baud rate
*/
extern uData8 calculateTimerVal(uData8 baudRate);
#endif /* _SERIAL_H */
