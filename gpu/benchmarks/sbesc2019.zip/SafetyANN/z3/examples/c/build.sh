gcc -fopenmp -o test_capi test_capi.c -I ../../include -L ../../lib -lz3
