/*******************************************************************\

Module: 

Author: Mário Angel

Date: 

\*******************************************************************/
#ifndef _QMUTEX_H
#define _QMUTEX_H

#include "../QtDefines.h"
#include <pthread.h>

class QMutex {
private:
    pthread_mutex_t _mutex;

public:
        enum RecursionMode { NonRecursive, Recursive };
	
        QMutex(RecursionMode mode = NonRecursive)
        {
          pthread_mutex_init(&_mutex, NULL);
        }
	     ~QMutex()
        {
          pthread_mutex_unlock(&_mutex);
        }

        void lock()
        {
          pthread_mutex_lock(&_mutex);
        }
        void unlock()
        {
          pthread_mutex_unlock(&_mutex);
        }
	
};

class QMutexLocker {
private:
    pthread_mutex_t _mutex;
public:

   QMutexLocker(QMutex *)
   {
      pthread_mutex_init(&_mutex, NULL);
      pthread_mutex_lock(&_mutex);
   }
   ~QMutexLocker()
   {
      pthread_mutex_unlock(&_mutex);
   }

};

#endif //_QMUTEX_H
