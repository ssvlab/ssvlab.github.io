## Experimental Evaluation

ESBMC-GPU is a context-bounded model checker based on the satisfiability
modulo theories (SMT) to check data race, deadlock, pointer safety,
array bounds, arithmetic overflow, division by zero, and user-specified
assertions in programs written in Compute Unified Device Architecture (CUDA).

* http://esbmc.org/gpu

This document has the execution process of ESBMC-GPU benchmarks used in the experimental evalution of this journal, with support to Ubuntu OS 16.04.

#### Dependencies

* `boost` library __v1.43__ or higher
* `clang` __v3.8__
* `/usr/bin/time` executable

#### Content

This folder contains the benchmarks used in the experimental evaluation of the paper as well as the scripts needed to collect the metrics regarding the verification tasks.

* _data_
    * _VERIFIER_
        * _benchmarks_
            * Each test case folder here contains the _main.cu_ file (the program itself) and its _test.desc_ file (a description of the test case containing additional data, _e.g._, expected result and how to verify it).
* _scripts_
    * This folder contains the scripts used to collect the metrics for each verifier.
* _tools_
    * This folder contains the _ESBMC-GPU_ binary and its libraries.

#### How to Run the Experiments

1. The user needs to build the verification metrics collector script. This is achieved by running `make` inside the _scripts_ folder. When it finishes, the built executable named `verification_metrics` will be available inside the _data_ folder.

2. Then, the user needs to choose which verifier they want to validate. To do so, the built executable needs to be moved to the respective _VERIFIER_ folder the user wants to test, _e.g._, `mv verification_metrics esbmc-gpu/` from the _data_ folder, in case the user wants to collect verification metrics for _ESBMC-GPU_.

3. Then the user must run the script with the desired verifier inside its respective folder inside the _data_ folder. This is achieved by running `./verification_metrics <VERIFIER>`, where `<VERIFIER>` is the verifier to be used in the evaluation, _i.e._, `CIVL`, `ESBMC-GPU`, `GKLEE`, or `GPUVERIFY`, from within the respective `<VERIFIER>` folder, _i.e._, `civl`, `esbmc-gpu`, `gklee`, or `gpuverify`. If one wants to save the results to a text file for later use, one should append `> <FILENAME>` to the latter command, where `<FILENAME>` is the desired filename.

Obs.: Each verifier needs to be installed in user's computer and they need to be in user's _PATH_.

#### Verifiers Availability

The verifiers used in this paper can be found at:

- _CIVL_ - http://vsl.cis.udel.edu/civl/
- _ESBMC-GPU_ - https://github.com/ssvlab/esbmc-gpu
- _GKLEE_ - http://formalverification.cs.utah.edu/GKLEE/
- _GPUVERIFY_ - http://multicore.doc.ic.ac.uk/tools/GPUVerify/


#### Running ESBMC-GPU

###### Dependencies

* The user must install the following packages before installation:

```
sudo apt-get install build-essential libtool
sudo apt-get install automake
sudo apt-get install byacc flex
sudo apt-get install libboost-all-dev
sudo apt-get install libgmp3-dev
sudo apt-get install libssl-dev
sudo apt-get install clang-3.8
sudo apt-get install clang-3.8-dev
sudo apt-get install lldb-3.8
sudo apt-get install bison
sudo apt-get install gcc-multilib g++-multilib
sudo apt-get install libc6 libc6-dev
sudo apt-get install openssl
```

* Download the solvers from http://svlab.hussamaismail.eti.br/gpu/wp-content/uploads/2016/10/solvers_esbmc-gpu.zip

* Move all solvers and lingeling to the home directory using the following commands:

```
mv boolector ~/
mv z3 ~/
mv lingeling ~/
```

* Edit the `.bashrc` file (in the home directory) and add at the end the following paths:

```
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/boolector/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/z3/lib/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:~/lingeling/
```

* Restart the `.bashrc` file using the following command:

```
source ~/.bashrc
```

###### Installation and Execution

* Copy the `esbmc-gpu` folder from the `tools` folder to your `$HOME` directory.

* Create a symbolic link to `esbmc-gpu/libraries` from your `$HOME` directory as follows:

```
cd $HOME
ln -s esbmc-gpu/libraries libraries
```

* Add the binary `esbmc-gpu` to your `.bashrc` as follows:

```
cd $HOME
vi .bashrc
export PATH=$PATH:$HOME/esbmc-gpu
source .bashrc
```
