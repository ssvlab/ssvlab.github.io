#ifndef _UNISTD_H
#define _UNISTD_H 

unsigned int getpid ();

#endif
