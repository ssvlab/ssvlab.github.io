#ifndef SC_WAIT_H
#define SC_WAIT_H

void wait(){ /* nothing has been implemented yet */ }

#endif
