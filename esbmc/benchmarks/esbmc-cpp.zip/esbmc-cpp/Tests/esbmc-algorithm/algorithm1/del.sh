$(rm *.o *.bc *.c)

