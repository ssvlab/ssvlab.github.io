/*
#
# ESBMC - Parallel Runner
#
#               Universidade Federal do Amazonas - UFAM
# Author:       Hussama Ismail <hussamaismail@gmail.com>
#
# ------------------------------------------------------
#
# Execute many esbmc instances using OpenMP Library
# 
# Usage Example:
# $ ./esbmc-parallel filename hmax
#
# ------------------------------------------------------
#
*/

#include <iostream>
#include <omp.h>
#include <string>
#include <stdio.h>
#include <ctime>
#include <vector>
#include <set>
#include <time.h>

std::string execute_cmd(std::string command){
	FILE* pipe = popen(command.c_str(), "r");
	if (!pipe) return "ERROR";
	char buffer[128];
	std::string result = "";
	while(!feof(pipe)) {
		if(fgets(buffer, 128, pipe) != NULL)
			result += buffer;
	}
	pclose(pipe);
	return result;
}

long timediff(clock_t t1, clock_t t2) {
    long elapsed;
    elapsed = ((double)t2 - t1) / CLOCKS_PER_SEC * 1000;
    return elapsed;
}

typedef std::vector<std::string> Arguments;
int main(int argc, char *argv[]){
       
	Arguments arguments(&argv[0], &argv[0 + argc]);

	if (arguments.size() != 4){
		std::cout << "missing arguments (use: ./esbmc-parallel filename.c nrprod hmin_value hmax_value)" << std::endl;
		exit(1);
	}

	std::time_t start, end;
	start = std::time(NULL);

	std::string executable = "esbmc";
	std::string filename = arguments.at(1);
	std::string esbmc_parameters  = "--boolector --quiet";

	int hmin = std::atoi(arguments.at(2).c_str());
	int hmax = std::atoi(arguments.at(3).c_str());

	std::string esbmc_version = execute_cmd(executable + " --version");
	size_t nl_version = esbmc_version.find("\n");
	esbmc_version.replace(nl_version, std::string("\n").length(), "");
	
	std::string execution_date = execute_cmd("date");
	size_t nl_exdate = execution_date.find("\n");
	execution_date.replace(nl_exdate, std::string("\n").length(), "");

	std::string hardware = execute_cmd("echo \"CPU:$(cat /proc/cpuinfo | grep \"model name\" | tail -n1 | cut -d \":\" -f2) ($(cat /proc/cpuinfo | grep processor | wc -l) core(s)) ~ RAM: $(cat /proc/meminfo | grep \"MemTotal\" | cut -d \":\" -f2 | cut -d \" \" -f8) kB\"");
	size_t nl_hw = hardware.find("\n");
	hardware.replace(nl_hw, std::string("\n").length(), "");

	std::string core_number = execute_cmd("echo \"$(cat /proc/cpuinfo | grep processor | wc -l)\"");
	size_t nl_cn = core_number.find("\n");
	core_number.replace(nl_cn, std::string("\n").length(), "");
	int cores = std::atoi(core_number.c_str());

	std::cout << std::endl;
	std::cout << "*** ESBMC Parallel Runner v1.0 ***" << std::endl;
	std::cout << "Tool: ESBMC " << esbmc_version << std::endl;
	std::cout << "Date of run: " <<  execution_date << std::endl;
	std::cout << "Hardware: " <<  hardware << std::endl << std::endl;
	std::cout << "RUNNING:" << std::endl;

	int current_min = hmin;	
	int current_max = 1;

	std::set<int> founds;

	do {

		if (hmax <= cores){
			current_max = hmax;
		}else{
			current_max = current_min + cores - 1;
		}

		if (current_max > hmax){
			current_max = hmax;
		}
	
		#pragma omp parallel for		
		for(int thread = current_min + 1; thread <= current_max; thread++){
	
			long time = 0;
			std::string command_line = " { time " + executable + " " + filename + " " + esbmc_parameters + " -Dvalordeh=" + std::to_string(thread) + "; } 2>> /dev/null";

			std::string result = execute_cmd(command_line);
			end = std::time(NULL);
			time = end - start;
			std::size_t verification_failed = result.find("VERIFICATION FAILED");
	  		if ( verification_failed != std::string::npos ){
				founds.insert(thread);
				std::cout << "ESBMC found a violation at VALORDEH using " << thread << " in " << time <<  "s" << std::endl;
			} 
		}

		current_min = current_max;

		if (founds.size() > 0 ){
			std::cout << std::endl;
			std::cout << "The best solution is: " << * founds.begin() << std::endl;
			break;
		}	
	
	}while(current_min < hmax);

	if (founds.size() == 0 ){
		std::cout << std::endl;
	    std::cout << "Not found a solution :(" << std::endl;
	}
}
