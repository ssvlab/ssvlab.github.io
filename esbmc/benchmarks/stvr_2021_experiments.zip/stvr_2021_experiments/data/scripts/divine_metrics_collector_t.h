#ifndef __DIVINE_METRICS_COLLECTOR_T_H
#define __DIVINE_METRICS_COLLECTOR_T_H

#include <regex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include "metrics_collector_t.h"

#define DIVINE_ERROR_BUILDING_MESSAGE "ERROR: Error building main.cpp"
#define DIVINE_ERROR_DETECTED_MESSAGE "error found: yes"
#define DIVINE_RUN_COMMAND "/usr/bin/time -v timeout 900s divine verify --max-time 900 --max-memory 14G main.cpp 2>&1"
#define DIVINE_NO_ERROR_DETECTED_MESSAGE "error found: no"

class divine_metrics_collector_t : public metrics_collector_t
{
public:
    divine_metrics_collector_t()
    {
    }

    ~divine_metrics_collector_t()
    {
    }

    void prepare_verification_task()
    {
        m_command = DIVINE_RUN_COMMAND;
    }

    std::string run_verification_task()
    {
        bool successful = true, supported = false, has_result = false;
        double system_cpu_time, user_cpu_time, wall_time, memory;
        std::vector<std::string> run_command_output = utils::execute_command(m_command.c_str());
        parse_time_output(run_command_output, system_cpu_time, user_cpu_time, wall_time, memory);
        m_cpu_time += system_cpu_time + user_cpu_time;
        m_wall_time += wall_time;
        m_memory += memory;
        for (const auto &message : run_command_output)
        {
            if (message.find(DIVINE_NO_ERROR_DETECTED_MESSAGE) != std::string::npos)
            {
                has_result = true;
                successful = true;
                supported = true;
                break;
            }
            else if (message.find(DIVINE_ERROR_DETECTED_MESSAGE) != std::string::npos)
            {
                has_result = true;
                successful = false;
                supported = true;
                break;
            }
        }
        std::string expected_result = get_expected_result();
        std::string actual_result;
        if (memory > MEMORY_OUT_THRESHOLD)
        {
            ++m_memory_out;
            actual_result = MEMORY_OUT_RESULT;
        }
        else if (wall_time > TIMEOUT_THRESHOLD)
        {
            ++m_timeout;
            actual_result = TIMEOUT_RESULT;
        }
        if (actual_result.size() == 0)
        {
            if (has_result)
            {
                if (!supported)
                {
                    if (expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0)
                    {
                        ++m_incorrect;
                        actual_result = INCORRECT_RESULT;
                    }
                    else
                    {
                        ++m_not_supported;
                        actual_result = NOT_SUPPORTED_RESULT;
                    }
                }
                else
                {
                    if (successful && expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0)
                    {
                        ++m_correct;
                        actual_result = CORRECT_RESULT;
                    }
                    else if (successful && expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0)
                    {
                        ++m_false_correct;
                        actual_result = FALSE_CORRECT_RESULT;
                    }
                    else if (!successful && (expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0
                            || expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0))
                    {
                        ++m_incorrect;
                        actual_result = INCORRECT_RESULT;
                    }
                    else if (!successful && (expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0
                            || expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0))
                    {
                        ++m_false_incorrect;
                        actual_result = FALSE_INCORRECT_RESULT;
                    }
                }
            }
            else
            {
                ++m_not_supported;
                actual_result = NOT_SUPPORTED_RESULT;
            }
        }
        std::stringstream stream;
        stream << " Wall Time: " << std::to_string(wall_time) << "s,";
        stream << " CPU Time: " << std::to_string(system_cpu_time + user_cpu_time) << "s,";
        stream << " Memory: " << memory << "KB";
        actual_result += stream.str();
        return actual_result;
    }
private:
    std::string m_command;
};

#endif
