#include "utils.h"
#include <iostream>

std::vector<std::string> utils::execute_command(const char *command) {

	//std::cout << "*command: " << command << std::endl;
    std::array<char, BUFFER_SIZE> buffer;
    std::vector<std::string> result;
    std::shared_ptr<FILE> pipe(popen(command, PIPE_READ_MODE), pclose);
    if (pipe)
    {
        while (!feof(pipe.get()))
        {
            if (fgets(buffer.data(), BUFFER_SIZE, pipe.get()) != nullptr)
            {
                auto data = std::string(buffer.data());
                result.push_back(data.substr(0, data.length() - 1));
            }
        }
    }
    return result;
}

std::vector<std::string> utils::GetStdoutFromCommand(const char* cmd) {

    FILE * stream;
    std::vector<std::string> result;
    std::array<char, BUFFER_SIZE> buffer;
    stream = popen(cmd, PIPE_READ_MODE);
	std::cout << "[utils::GetStdoutFromCommand] command: " << cmd << std::endl;
    if (stream) {
        while (!feof(stream))
        {
            if (fgets(buffer.data(), BUFFER_SIZE, stream) != NULL)
            {
	        auto data = std::string(buffer.data());
                result.push_back(data.substr(0, data.length() - 1));
	    }
        }
        pclose(stream);
    }
    return result;
}

std::vector<std::string> utils::get_dirs()
{
    DIR *dir;
    struct dirent *ent;
    std::vector<std::string> dirs;
    if ((dir = opendir(CURRENT_FOLDER_SYMLINK)) != nullptr)
    {
        while ((ent = readdir(dir)) != nullptr)
        {
            if (ent->d_type == DT_DIR)
            {
                auto current_dir = std::string(ent->d_name);
                if (current_dir.compare(CURRENT_FOLDER_SYMLINK) != 0 &&
                    current_dir.compare(PARENT_FOLDER_SYMLINK) != 0)
                    dirs.push_back(current_dir);
            }
        }
        closedir(dir);
        std::sort(dirs.begin(), dirs.end());
    }
    return dirs;
}
