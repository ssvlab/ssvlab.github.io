#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include "cbmc_metrics_collector_t.h"
#include "divine_metrics_collector_t.h"
#include "esbmc_metrics_collector_t.h"
#include "llbmc_metrics_collector_t.h"
#include "metrics_collector_t.h"
#include "utils.h"

#define CBMC_VERIFIER "CBMC"
#define DIVINE_VERIFIER "DIVINE"
#define ESBMC_VERIFIER "ESBMC"
#define LLBMC_VERIFIER "LLBMC"

void calculate_metrics(metrics_collector_t &metrics_collector)
{
    std::vector<std::string> suites;
    std::vector<std::string> sub_suites;
    std::vector<std::string> test_cases;
    suites = utils::get_dirs();
    std::ofstream test_cases_summary;
    test_cases_summary.open ("test_cases_summary.dat");
    test_cases_summary << "# CPU-time Memory" << std::endl;
    for (auto suite = suites.begin(); suite != suites.end(); ++suite)
    {
        chdir((*suite).c_str());
        std::cout << "========== SUITE: " << *suite << " ========== " << std::endl << std::endl;
        sub_suites = utils::get_dirs();
        double suite_cpu_time = 0.0, suite_wall_time = 0.0, suite_memory = 0.0;
        int suite_correct = 0, suite_incorrect = 0, suite_false_correct = 0;
        int suite_false_incorrect = 0, suite_not_supported = 0;
        int suite_memory_out = 0, suite_timeout = 0;
        suite_cpu_time = metrics_collector.cpu_time();
        suite_wall_time = metrics_collector.wall_time();
        suite_memory = metrics_collector.memory();
        suite_correct = metrics_collector.correct();
        suite_incorrect = metrics_collector.incorrect();
        suite_false_correct = metrics_collector.false_correct();
        suite_false_incorrect = metrics_collector.false_incorrect();
        suite_not_supported = metrics_collector.not_supported();
        suite_memory_out = metrics_collector.memory_out();
        suite_timeout = metrics_collector.timeout();
        std::ofstream suite_summary("../" + std::string(*suite) + "_summary.dat");
        suite_summary << "# CPU-time Memory" << std::endl;
        for (auto sub_suite = sub_suites.begin(); sub_suite != sub_suites.end(); ++sub_suite) {
            chdir((*sub_suite).c_str());
            std::cout << "====== SUBSUITE: " << *sub_suite << " ====== " << std::endl << std::endl;
            test_cases = utils::get_dirs();
            double sub_suite_cpu_time = 0.0, sub_suite_wall_time = 0.0;
            double sub_suite_memory = 0.0;
            int sub_suite_correct = 0, sub_suite_incorrect = 0, sub_suite_false_correct = 0;
            int sub_suite_false_incorrect = 0, sub_suite_not_supported = 0;
            int sub_suite_memory_out = 0, sub_suite_timeout = 0;
            sub_suite_correct = metrics_collector.correct();
            sub_suite_incorrect = metrics_collector.incorrect();
            sub_suite_false_correct = metrics_collector.false_correct();
            sub_suite_false_incorrect = metrics_collector.false_incorrect();
            sub_suite_not_supported = metrics_collector.not_supported();
            sub_suite_memory_out = metrics_collector.memory_out();
            sub_suite_timeout = metrics_collector.timeout();
            for (auto test_case = test_cases.begin(); test_case != test_cases.end(); ++test_case) {
                chdir((*test_case).c_str());
                metrics_collector.prepare_verification_task();
                double cpu_time = metrics_collector.cpu_time(), wall_time = metrics_collector.wall_time();
                double memory = metrics_collector.memory();
                auto actual_result = metrics_collector.run_verification_task();
                sub_suite_cpu_time += metrics_collector.cpu_time() - cpu_time;
                sub_suite_wall_time += metrics_collector.wall_time() - wall_time;
                sub_suite_memory += metrics_collector.memory() - memory;
                std::cout << " ---- " << *test_case << " " << actual_result << std::endl;
                test_cases_summary << metrics_collector.cpu_time() << " ";
                test_cases_summary << metrics_collector.memory() << " " << std::endl;
                suite_summary << (metrics_collector.cpu_time() - suite_cpu_time) << " ";
                suite_summary << (metrics_collector.memory() - suite_memory) << " " << std::endl;
                chdir("../.");
            }
            sub_suite_correct = metrics_collector.correct() - sub_suite_correct;
            sub_suite_incorrect = metrics_collector.incorrect() - sub_suite_incorrect;
            sub_suite_false_correct = metrics_collector.false_correct() - sub_suite_false_correct;
            sub_suite_false_incorrect = metrics_collector.false_incorrect() - sub_suite_false_incorrect;
            sub_suite_not_supported = metrics_collector.not_supported() - sub_suite_not_supported;
            sub_suite_memory_out = metrics_collector.memory_out() - sub_suite_memory_out;
            sub_suite_timeout = metrics_collector.timeout() - sub_suite_timeout;
            std::cout << std::endl << std:: endl << "=====================================" << std::endl;
            std::stringstream stream;
            stream << std::endl << std::endl << "SUBSUITE: " << *sub_suite << " summary:" << std::endl;
            stream << "Wall Time: " << std::to_string(sub_suite_wall_time) << "s, ";
            stream << "CPU Time: " << std::to_string(sub_suite_cpu_time) << "s, ";
            stream << "Memory: " << sub_suite_memory << "KB" << std::endl;
            stream << "TRUE: " << sub_suite_correct << std::endl;
            stream << "FALSE: " << sub_suite_incorrect << std::endl;
            stream << "TRUE INCORRECT: " << sub_suite_false_correct << std::endl;
            stream << "FALSE INCORRECT: " << sub_suite_false_incorrect << std::endl;
            stream << "MEMORY OUT: " << sub_suite_memory_out << std::endl;
            stream << "NOT SUPPORTED: " << sub_suite_not_supported << std::endl;
            stream << "TIMEOUT: " << sub_suite_timeout << std::endl;
            std::cout << stream.str() << std::endl;
            std::cout << "=====================================" << std::endl << std::endl << std::endl;
            test_cases.clear();
            std::cout << std::endl;
            chdir("../.");
        }
        sub_suites.clear();
        suite_cpu_time = metrics_collector.cpu_time() - suite_cpu_time;
        suite_wall_time = metrics_collector.wall_time() - suite_wall_time;
        suite_memory = metrics_collector.memory() - suite_memory;
        suite_correct = metrics_collector.correct() - suite_correct;
        suite_incorrect = metrics_collector.incorrect() - suite_incorrect;
        suite_false_correct = metrics_collector.false_correct() - suite_false_correct;
        suite_false_incorrect = metrics_collector.false_incorrect() - suite_false_incorrect;
        suite_not_supported = metrics_collector.not_supported() - suite_not_supported;
        suite_memory_out = metrics_collector.memory_out() - suite_memory_out;
        suite_timeout = metrics_collector.timeout() - suite_timeout;
        std::cout << std::endl << std:: endl << "=====================================" << std::endl;
        std::stringstream stream;
        stream << std::endl << std::endl << "SUITE: " << *suite << " summary:" << std::endl;
        stream << "Wall Time: " << std::to_string(suite_wall_time) << "s, ";
        stream << "CPU Time: " << std::to_string(suite_cpu_time) << "s, ";
        stream << "Memory: " << suite_memory << "KB" << std::endl;
        stream << "TRUE: " << suite_correct << std::endl;
        stream << "FALSE: " << suite_incorrect << std::endl;
        stream << "TRUE INCORRECT: " << suite_false_correct << std::endl;
        stream << "FALSE INCORRECT: " << suite_false_incorrect << std::endl;
        stream << "MEMORY OUT: " << suite_memory_out << std::endl;
        stream << "NOT SUPPORTED: " << suite_not_supported << std::endl;
        stream << "TIMEOUT: " << suite_timeout << std::endl;
        std::cout << stream.str() << std::endl;
        std::cout << "=====================================" << std::endl << std::endl << std::endl;
        std::cout << std::endl << std::endl;
        suite_summary.close();
        chdir("../.");
    }
    test_cases_summary.close();
    suites.clear();
    std::cout << "==========================================" << std::endl;
    std::cout << "TRUE: " << metrics_collector.correct() << std::endl;
    std::cout << "FALSE: " << metrics_collector.incorrect() << std::endl;
    std::cout << "TRUE INCORRECT: " << metrics_collector.false_correct() << std::endl;
    std::cout << "FALSE INCORRECT: " << metrics_collector.false_incorrect() << std::endl;
    std::cout << "MEMORY OUT: " << metrics_collector.memory_out() << std::endl;
    std::cout << "NOT SUPPORTED: " << metrics_collector.not_supported() << std::endl;
    std::cout << "TIMEOUT: " << metrics_collector.timeout() << std::endl;
    std::cout << "TOTAL TIME: Wall time = " <<
            metrics_collector.wall_time() << "s, CPU time = " <<
            metrics_collector.cpu_time() << "s | MEMORY: " << metrics_collector.memory() << " KB" << std::endl;
    std::cout << "==========================================" << std::endl;
}

int main(int argc, const char **argv)
{
    if (argc == 2)
    {
        metrics_collector_t *metrics_collector = nullptr;
        std::string verifier_to_use(argv[1]);
        if (verifier_to_use.compare(CBMC_VERIFIER) == 0)
        {
            std::cout << std::endl << "========== Running CBMC ==========" << std::endl << std::endl;
            metrics_collector = new cbmc_metrics_collector_t;
        }
        else if (verifier_to_use.compare(DIVINE_VERIFIER) == 0)
        {
            std::cout << std::endl << "========== Running DIVINE ==========" << std::endl << std::endl;
            metrics_collector = new divine_metrics_collector_t;
        }
        else if (verifier_to_use.compare(ESBMC_VERIFIER) == 0)
        {
            std::cout << std::endl << "========== Running ESBMC ==========" << std::endl << std::endl;
            metrics_collector = new esbmc_metrics_collector_t;
        }
        else if (verifier_to_use.compare(LLBMC_VERIFIER) == 0)
        {
            std::cout << std::endl << "========== Running LLBMC ==========" << std::endl << std::endl;
            metrics_collector = new llbmc_metrics_collector_t;
        }
        if (metrics_collector != nullptr)
        {
            calculate_metrics(*metrics_collector);
            delete metrics_collector;
        }
        else
            std::cout << "ERROR::Unknown verifier." << std::endl;
    }
    else if (argc == 1)
    {
        std::cout << "ERROR::You need to specify which verifier you want to use, ";
        std::cout << "i.e., CBMC, DIVINE, ESBMC, or LLBMC.";
        std::cout << std::endl;
    }
    else
    {
        std::cout << "ERROR::Too many arguments provided." << std::endl;
    }
    return 0;
}
