#ifndef __LLBMC_METRICS_COLLECTOR_T_H
#define __LLBMC_METRICS_COLLECTOR_T_H

#include <regex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include "metrics_collector_t.h"

#define ERROR_DETECTED_MESSAGE "Error detected."
#define LLBMC_RUN_COMMAND_BASE "/usr/bin/time -v timeout 900s llbmc 2>&1 main.bc "
#define LLBMC_PREPARE_COMMAND "clang++ -c -g -emit-llvm *.cpp -fno-exceptions -o main.bc 2>/dev/null"
#define LLBMC_LIBRARIES_INPUT_PARAMETER_REGEX ".*--max-loop-iterations=.*"
#define NO_ERROR_DETECTED_MESSAGE "No error detected."

class llbmc_metrics_collector_t : public metrics_collector_t
{
public:
    llbmc_metrics_collector_t()
    {
    }

    ~llbmc_metrics_collector_t()
    {
    }

    void prepare_verification_task()
    {
        std::ifstream test_description;
        std::string line, command;
        test_description.open(TEST_DESCRIPTION_FILE_LLBMC);
        while(!(test_description.eof()))
        {
           std::getline(test_description, line);
           if (std::regex_match(line, std::regex(LLBMC_LIBRARIES_INPUT_PARAMETER_REGEX)))
           {
              size_t start = line.find('>') + 1;
              size_t end = line.find('<', start);
              command = line.substr(start, end - start);
              break;
           }
        }
        test_description.close();
        m_command = LLBMC_RUN_COMMAND_BASE + command;
    }

    std::string run_verification_task()
    {
        bool successful = true, supported = false;
        std::string prepare_command = LLBMC_PREPARE_COMMAND;
        utils::execute_command(prepare_command.c_str());
        double system_cpu_time, user_cpu_time, wall_time, memory;
        std::vector<std::string> run_command_output = utils::execute_command(m_command.c_str());
        parse_time_output(run_command_output, system_cpu_time, user_cpu_time, wall_time, memory);
        m_cpu_time += system_cpu_time + user_cpu_time;
        m_wall_time += wall_time;
        m_memory += memory;
        for (const auto &message : run_command_output)
        {
            if (message.find(NO_ERROR_DETECTED_MESSAGE) != std::string::npos)
            {
                successful = true;
                supported = true;
                break;
            }
            else if (message.find(ERROR_DETECTED_MESSAGE) != std::string::npos)
            {
                successful = false;
                supported = true;
                break;
            }
        }
        std::string expected_result = get_expected_result();
        std::string actual_result;
        if (memory > MEMORY_OUT_THRESHOLD)
        {
            ++m_memory_out;
            actual_result = MEMORY_OUT_RESULT;
        }
        else if (wall_time > TIMEOUT_THRESHOLD)
        {
            ++m_timeout;
            actual_result = TIMEOUT_RESULT;
        }
        if (actual_result.size() == 0)
        {
            if (!supported)
            {
                ++m_not_supported;
                actual_result = NOT_SUPPORTED_RESULT;
            }
            else
            {
                if (successful && expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0)
                {
                    ++m_correct;
                    actual_result = CORRECT_RESULT;
                }
                else if (successful && expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0)
                {
                    ++m_false_correct;
                    actual_result = FALSE_CORRECT_RESULT;
                }
                else if (!successful && (expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0
                        || expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0))
                {
                    ++m_incorrect;
                    actual_result = INCORRECT_RESULT;
                }
                else if (!successful && (expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0
                        || expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0))
                {
                    ++m_false_incorrect;
                    actual_result = FALSE_INCORRECT_RESULT;
                }
            }
        }
        std::stringstream stream;
        stream << " Wall Time: " << std::to_string(wall_time) << "s,";
        stream << " CPU Time: " << std::to_string(system_cpu_time + user_cpu_time) << "s,";
        stream << " Memory: " << memory << "KB";
        actual_result += stream.str();
        return actual_result;
    }
private:
    std::string m_command;
};

#endif
