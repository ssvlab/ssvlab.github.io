#ifndef __METRICS_COLLECTOR_T_H
#define __METRICS_COLLECTOR_T_H

#include <fstream>
#include <iostream>
#include <regex>
#include <string>
#include <thread>
#include <vector>
#include "utils.h"

#define BILLION 1E9
#define MINUTES_TO_SECONDS_FACTOR 60
#define CORRECT_RESULT "[TRUE]"
#define CONVERSION_ERROR_MESSAGE "CONVERSION ERROR"
#define FALSE_CORRECT_RESULT "[TRUE INCORRECT]"
#define FALSE_INCORRECT_RESULT "[FALSE INCORRECT]"
#define INCORRECT_RESULT "[FALSE]"
#define MAXIMUM_RESIDENT_SET_SIZE_REGEX ".*Maximum resident set size \\(kbytes\\):.*"
#define MEMORY_OUT_RESULT "[MEMORY_OUT]"
#define NOT_SUPPORTED_RESULT "[NOT SUPPORTED]"
#define SEMICOLON ":"
#define SYSTEM_CPU_TIME_REGEX ".*System time \\(seconds\\):.*"
#define TEST_DESCRIPTION_DELIMITER '^'
#define TEST_DESCRIPTION_FILE "test.desc"
#define TEST_DESCRIPTION_FILE_LLBMC "testllvm.desc"
#define TIMEOUT_RESULT "[TIMEOUT]"
#define USER_CPU_TIME_REGEX ".*User time \\(seconds\\):.*"
#define VERIFICATION_FAILED_MESSAGE "VERIFICATION FAILED"
#define VERIFICATION_SUCCESSFUL_MESSAGE "VERIFICATION SUCCESSFUL"
#define WALL_TIME_REGEX ".*Elapsed \\(wall clock\\) time \\(h:mm:ss or m:ss\\):.*"
#define WHITESPACE " "

#define KILOBYTES "KiB"
#define MEGABYTES "MiB"
#define MEGABYTES_FACTOR 1
#define GIGABYTES "GiB"
#define GIGABYTES_FACTOR 1024
#define MEMORY_OUT_THRESHOLD 14680064
#define TIMEOUT_THRESHOLD 900

class metrics_collector_t {
public:
    metrics_collector_t() : m_correct(0), m_false_correct(0), m_false_incorrect(0), m_incorrect(0),
                            m_memory_out(0), m_not_supported(0), m_timeout(0),
                            m_cpu_time(0.0), m_wall_time(0.0), m_memory(0.0)
    {
    }

    virtual ~metrics_collector_t() = 0;

    void parse_time_output(const std::vector<std::string>& output,
                           double& system_cpu_time,
                           double& user_cpu_time,
                           double& wall_time,
                           double& memory) const;

    virtual void prepare_verification_task() = 0;

    std::string get_expected_result() const;

    virtual std::string run_verification_task() = 0;

    unsigned int correct() const
    {
        return m_correct;
    }

    unsigned int false_correct() const
    {
        return m_false_correct;
    }

    unsigned int false_incorrect() const
    {
        return m_false_incorrect;
    }

    unsigned int incorrect() const
    {
        return m_incorrect;
    }

    unsigned int memory_out() const
    {
        return m_memory_out;
    }

    unsigned int not_supported() const
    {
        return m_not_supported;
    }

    unsigned int timeout() const
    {
        return m_timeout;
    }

    double cpu_time() const
    {
        return m_cpu_time;
    }

    double memory() const
    {
        return m_memory;
    }

    double wall_time() const
    {
        return m_wall_time;
    }
protected:
    unsigned int m_correct;
    unsigned int m_false_correct;
    unsigned int m_false_incorrect;
    unsigned int m_incorrect;
    unsigned int m_memory_out;
    unsigned int m_not_supported;
    unsigned int m_timeout;
    double m_memory;
    double m_cpu_time;
    double m_wall_time;
};
#endif
