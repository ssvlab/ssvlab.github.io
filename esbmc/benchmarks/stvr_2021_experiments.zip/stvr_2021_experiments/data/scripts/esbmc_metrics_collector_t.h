#ifndef __ESBMC_METRICS_COLLECTOR_T_H
#define __ESBMC_METRICS_COLLECTOR_T_H

#include <regex>
#include <sstream>
#include <string>
#include <vector>
#include "metrics_collector_t.h"

#define CONVERSION_ERROR_REGEX ".*CONVERSION ERROR.*"
#define ESBMC_RUN_COMMAND_BASE "/usr/bin/time -v timeout 900s esbmc 2>&1 main.cpp --z3 "
#define ESBMC_LIBRARIES_INPUT_PARAMETER_REGEX ".*-I ~/libraries.*"
#define PARSING_ERROR_REGEX ".*PARSING ERROR.*"
#define UNWINDING_ASSERTION_LOOP_REGEX ".*unwinding assertion loop.*"

class esbmc_metrics_collector_t : public metrics_collector_t
{
public:
    esbmc_metrics_collector_t()
    {
    }

    ~esbmc_metrics_collector_t()
    {
    }

    void prepare_verification_task()
    {
        std::ifstream test_description;
        std::string line, command;
        test_description.open(TEST_DESCRIPTION_FILE);
        while(!(test_description.eof()))
        {
           std::getline(test_description, line);
           if (std::regex_match(line, std::regex(ESBMC_LIBRARIES_INPUT_PARAMETER_REGEX)))
           {
              size_t start = line.find('>') + 1;
              size_t end = line.find('<', start);
              command = line.substr(start, end - start);
              break;
           }
        }
        test_description.close();
        m_command = ESBMC_RUN_COMMAND_BASE + command;
    }

    std::string run_verification_task()
    {
        bool successful = true, supported = true, has_result = false;
        double system_cpu_time, user_cpu_time, wall_time, memory;
        std::vector<std::string> run_command_output = utils::execute_command(m_command.c_str());
        parse_time_output(run_command_output, system_cpu_time, user_cpu_time, wall_time, memory);
        m_cpu_time += system_cpu_time + user_cpu_time;
        m_wall_time += wall_time;
        m_memory += memory;
        for (const auto &message : run_command_output)
        {
            if (message.find(VERIFICATION_SUCCESSFUL_MESSAGE) != std::string::npos)
            {
                has_result = true;
                successful = true;
                break;
            }
            if (message.find(VERIFICATION_FAILED_MESSAGE) != std::string::npos)
            {
                has_result = true;
                successful = false;
                break;
            }
            else if (std::regex_match(message, std::regex(CONVERSION_ERROR_REGEX)))
            {
                has_result = true;
                supported = false;
                break;
            }
            else if (std::regex_match(message, std::regex(PARSING_ERROR_REGEX)) ||
                     std::regex_match(message, std::regex(UNWINDING_ASSERTION_LOOP_REGEX)))
            {
                supported = false;
                break;
            }
        }
        std::string expected_result = get_expected_result();
        std::string actual_result;
        if (memory > MEMORY_OUT_THRESHOLD)
        {
            ++m_memory_out;
            actual_result = MEMORY_OUT_RESULT;
        }
        else if (wall_time > TIMEOUT_THRESHOLD)
        {
            ++m_timeout;
            actual_result = TIMEOUT_RESULT;
        }
        if (actual_result.size() == 0)
        {
            if (has_result)
            {
                if (!supported)
                {
                    if (expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0)
                    {
                        ++m_incorrect;
                        actual_result = INCORRECT_RESULT;
                    }
                    else
                    {
                        ++m_not_supported;
                        actual_result = NOT_SUPPORTED_RESULT;
                    }
                }
                else
                {
                    if (successful && expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0)
                    {
                        ++m_correct;
                        actual_result = CORRECT_RESULT;
                    }
                    else if (successful && (expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0
                            || expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0))
                    {
                        ++m_false_correct;
                        actual_result = FALSE_CORRECT_RESULT;
                    }
                    else if (!successful && expected_result.compare(VERIFICATION_FAILED_MESSAGE) == 0)
                    {
                        ++m_incorrect;
                        actual_result = INCORRECT_RESULT;
                    }
                    else if (!successful && expected_result.compare(VERIFICATION_SUCCESSFUL_MESSAGE) == 0)
                    {
                        ++m_false_incorrect;
                        actual_result = FALSE_INCORRECT_RESULT;
                    }
                    else if (!successful && expected_result.compare(CONVERSION_ERROR_MESSAGE) == 0)
                    {
                        ++m_not_supported;
                        actual_result = NOT_SUPPORTED_RESULT;
                    }
                }
            }
            else
            {
                ++m_not_supported;
                actual_result = NOT_SUPPORTED_RESULT;
            }
        }
        std::stringstream stream;
        stream << " Wall Time: " << std::to_string(wall_time) << "s,";
        stream << " CPU Time: " << std::to_string(system_cpu_time + user_cpu_time) << "s,";
        stream << " Memory: " << memory << "KB";
        actual_result += stream.str();
        return actual_result;
    }
private:
    std::string m_command;
};

#endif
