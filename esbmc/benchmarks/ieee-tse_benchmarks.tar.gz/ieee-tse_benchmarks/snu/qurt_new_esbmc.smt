(benchmark ESBMC
:status unknown
:logic QF_AUFBV
:extrafuns ((ported_type_for_mod__  Array[32:64]))
:extrafuns ((c__a_0_1  Array[32:64]))
:extrafuns ((nondet_symex__nondet0  BitVec[64]))
:extrafuns ((c__a_0_2  Array[32:64]))
:extrafuns ((nondet_symex__nondet1  BitVec[64]))
:extrafuns ((c__a_0_3  Array[32:64]))
:extrafuns ((nondet_symex__nondet2  BitVec[64]))
:extrafuns ((c__a_0_4  Array[32:64]))
:extrafuns ((c__qurt_new__qurt__1__d_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__qurt__1__w1_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_1_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_1_0_0_4  BitVec[64]))
:extrafuns ((c__qurt___tmp__return_value_fabs_1_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__val_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_1  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_4  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_2_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_2_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_2  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_3  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_3_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_3_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_4  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_5  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_6  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_6  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_7  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_7  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_9  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_4_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_4_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_4_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_4_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_8  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_9  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_10  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_10  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_12  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_11  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_13  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_5_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_5_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_5_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_5_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_12  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_13  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_14  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_15  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_16  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_15  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_6_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_6_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_6_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_6_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_16  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_17  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_18  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_18  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_19  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_19  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_21  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_7_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_7_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_7_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_7_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_20  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_21  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_22  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_22  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_24  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_23  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_25  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_8_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_8_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_8_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_8_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_24  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_25  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_26  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_27  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_28  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_27  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_9_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_9_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_9_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_9_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_28  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_29  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_30  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_30  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_31  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_31  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_33  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_10_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_10_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_10_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_10_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_32  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_33  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_34  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_34  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_36  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_35  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_37  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_11_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_11_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_11_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_11_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_36  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_37  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_38  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_39  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_40  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_39  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_12_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_12_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_12_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_12_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_40  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_41  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_42  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_42  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_43  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_43  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_45  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_13_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_13_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_13_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_13_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_44  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_45  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_46  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_46  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_48  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_47  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_49  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_14_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_14_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_14_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_14_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_48  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_49  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_50  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_51  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_52  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_51  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_15_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_15_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_15_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_15_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_52  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_53  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_54  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_54  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_55  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_56  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_55  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_57  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_16_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_16_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_16_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_16_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_56  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_57  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_58  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_58  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_59  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_60  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_59  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_61  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_17_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_17_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_17_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_17_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_60  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_61  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_62  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_62  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_63  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_64  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_63  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_65  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_18_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_18_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_18_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_18_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_64  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_65  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_66  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_66  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_67  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_68  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_67  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_69  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_19_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_19_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_19_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_19_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_68  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_69  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_70  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_70  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_71  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_72  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_1_0_0_71  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_1_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_1_0_0_73  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_1_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_20_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_20_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_20_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_20_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_1_0_0_53  BitVec[64]))
:extrafuns ((nondet_symex__nondet3  BitVec[64]))
:extrafuns ((c__a_0_5  Array[32:64]))
:extrafuns ((nondet_symex__nondet4  BitVec[64]))
:extrafuns ((c__a_0_6  Array[32:64]))
:extrafuns ((nondet_symex__nondet5  BitVec[64]))
:extrafuns ((c__a_0_7  Array[32:64]))
:extrafuns ((c__qurt_new__qurt__1__d_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__qurt__1__w1_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_21_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_21_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_21_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_21_0_0_4  BitVec[64]))
:extrafuns ((c__qurt___tmp__return_value_fabs_1_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__val_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_1  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_4  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_22_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_22_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_22_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_22_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_2  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_3  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_23_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_23_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_23_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_23_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_4  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_5  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_6  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_6  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_7  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_7  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_9  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_24_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_24_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_24_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_24_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_8  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_9  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_10  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_10  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_12  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_11  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_13  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_25_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_25_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_25_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_25_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_12  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_13  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_14  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_15  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_16  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_15  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_26_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_26_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_26_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_26_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_16  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_17  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_18  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_18  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_19  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_19  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_21  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_27_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_27_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_27_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_27_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_20  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_21  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_22  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_22  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_24  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_23  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_25  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_28_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_28_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_28_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_28_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_24  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_25  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_26  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_27  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_28  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_27  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_29_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_29_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_29_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_29_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_28  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_29  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_30  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_30  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_31  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_31  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_33  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_30_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_30_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_30_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_30_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_32  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_33  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_34  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_34  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_36  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_35  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_37  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_31_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_31_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_31_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_31_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_36  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_37  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_38  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_39  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_40  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_39  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_32_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_32_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_32_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_32_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_40  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_41  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_42  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_42  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_43  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_43  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_45  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_33_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_33_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_33_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_33_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_44  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_45  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_46  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_46  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_48  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_47  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_49  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_34_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_34_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_34_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_34_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_48  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_49  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_50  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_51  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_52  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_51  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_35_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_35_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_35_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_35_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_52  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_53  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_54  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_54  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_55  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_56  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_55  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_57  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_36_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_36_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_36_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_36_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_56  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_57  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_58  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_58  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_59  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_60  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_59  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_61  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_37_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_37_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_37_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_37_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_60  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_61  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_62  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_62  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_63  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_64  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_63  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_65  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_38_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_38_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_38_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_38_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_64  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_65  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_66  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_66  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_67  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_68  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_67  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_69  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_39_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_39_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_39_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_39_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_68  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_69  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_70  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_70  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_71  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_72  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_2_0_0_71  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_2_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_2_0_0_73  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_2_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_40_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_40_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_40_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_40_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_2_0_0_53  BitVec[64]))
:extrafuns ((nondet_symex__nondet6  BitVec[64]))
:extrafuns ((c__a_0_8  Array[32:64]))
:extrafuns ((nondet_symex__nondet7  BitVec[64]))
:extrafuns ((c__a_0_9  Array[32:64]))
:extrafuns ((nondet_symex__nondet8  BitVec[64]))
:extrafuns ((c__a_0_10  Array[32:64]))
:extrafuns ((c__qurt_new__qurt__1__d_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__qurt__1__w1_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_41_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_41_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_41_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_41_0_0_4  BitVec[64]))
:extrafuns ((c__qurt___tmp__return_value_fabs_1_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__val_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_1  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_4  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_42_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_42_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_42_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_42_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_2  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_3  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_43_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_43_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_43_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_43_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_2  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_4  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_5  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_6  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_6  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_7  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_7  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_9  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_44_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_44_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_44_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_44_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_5  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_8  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_9  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_10  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_10  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_12  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_11  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_13  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_45_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_45_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_45_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_45_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_8  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_12  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_13  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_14  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_15  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_16  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_15  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_46_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_46_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_46_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_46_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_11  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_16  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_17  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_18  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_18  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_19  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_19  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_21  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_47_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_47_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_47_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_47_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_14  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_20  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_21  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_22  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_22  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_24  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_23  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_25  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_48_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_48_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_48_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_48_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_17  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_24  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_25  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_26  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_27  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_28  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_27  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_49_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_49_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_49_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_49_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_20  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_28  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_29  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_30  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_30  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_31  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_31  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_33  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_50_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_50_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_50_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_50_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_23  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_32  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_33  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_34  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_34  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_36  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_35  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_37  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_51_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_51_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_51_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_51_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_26  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_36  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_37  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_38  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_39  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_40  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_39  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_52_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_52_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_52_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_52_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_29  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_40  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_41  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_42  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_42  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_43  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_43  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_45  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_53_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_53_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_53_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_53_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_32  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_44  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_45  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_46  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_46  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_48  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_47  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_49  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_54_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_54_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_54_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_54_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_35  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_48  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_49  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_50  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_51  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_52  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_51  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_55_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_55_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_55_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_55_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_38  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_52  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_53  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_54  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_54  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_55  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_56  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_55  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_57  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_56_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_56_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_56_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_56_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_41  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_56  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_57  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_58  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_58  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_59  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_60  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_59  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_61  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_57_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_57_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_57_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_57_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_44  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_60  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_61  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_62  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_62  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_63  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_64  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_63  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_65  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_58_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_58_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_58_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_58_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_47  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_64  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_65  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_66  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_66  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_67  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_68  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_67  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_69  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_59_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_59_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_59_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_59_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_50  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_68  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_69  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_70  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_70  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_71  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_72  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__flag_3_0_0_71  BitVec[32]))
:extrafuns ((c__qurt_new__sqrt__1__dx_3_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__x_3_0_0_73  BitVec[64]))
:extrafuns ((c__qurt_new__sqrt__1__diff_3_0_0_53  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__n_60_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_60_0_0_1  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_60_0_0_3  BitVec[64]))
:extrafuns ((c__qurt_new__fabs__1__f_60_0_0_4  BitVec[64]))
:extrafuns ((c__sqrt___tmp__return_value_fabs_2_3_0_0_53  BitVec[64]))
:extrapreds ((l2 ))
:extrapreds ((l1 ))
:extrapreds ((l3 ))
:extrapreds ((l4 ))
:extrapreds ((l5 ))
:extrapreds ((l6 ))
:extrapreds ((l7 ))
:extrapreds ((l8 ))
:extrapreds ((l9 ))
:extrapreds ((l10 ))
:extrapreds ((l11 ))
:extrapreds ((l12 ))
:extrapreds ((l13 ))
:extrapreds ((l14 ))
:extrapreds ((l15 ))
:extrapreds ((l16 ))
:extrapreds ((l17 ))
:extrapreds ((l18 ))
:extrapreds ((l19 ))
:extrapreds ((l20 ))
:extrapreds ((l21 ))
:extrapreds ((l22 ))
:extrapreds ((l23 ))
:extrapreds ((l24 ))
:extrapreds ((l25 ))
:extrapreds ((l26 ))
:extrapreds ((l27 ))
:extrapreds ((l28 ))
:extrapreds ((l29 ))
:extrapreds ((l30 ))
:extrapreds ((l31 ))
:extrapreds ((l32 ))
:extrapreds ((l33 ))
:extrapreds ((l34 ))
:extrapreds ((l35 ))
:extrapreds ((l36 ))
:extrapreds ((l37 ))
:extrapreds ((l38 ))
:extrapreds ((l39 ))
:extrapreds ((l40 ))
:extrapreds ((l41 ))
:extrapreds ((l42 ))
:extrapreds ((l43 ))
:extrapreds ((l44 ))
:extrapreds ((l45 ))
:extrapreds ((l46 ))
:extrapreds ((l47 ))
:extrapreds ((l48 ))
:extrapreds ((l49 ))
:extrapreds ((l50 ))
:extrapreds ((l51 ))
:extrapreds ((l52 ))
:extrapreds ((l53 ))
:extrapreds ((l54 ))
:extrapreds ((l55 ))
:extrapreds ((l56 ))
:extrapreds ((l57 ))
:extrapreds ((l58 ))
:extrapreds ((l59 ))
:extrapreds ((l60 ))
:extrapreds ((l61 ))
:extrapreds ((l62 ))
:extrapreds ((l63 ))
:extrapreds ((l64 ))
:extrapreds ((l65 ))
:extrapreds ((l66 ))
:extrapreds ((l67 ))
:extrapreds ((l68 ))
:extrapreds ((l69 ))
:extrapreds ((l70 ))
:extrapreds ((l71 ))
:extrapreds ((l72 ))
:extrapreds ((l73 ))
:extrapreds ((l74 ))
:extrapreds ((l75 ))
:extrapreds ((l76 ))
:extrapreds ((l77 ))
:extrapreds ((l78 ))
:extrapreds ((l79 ))
:extrapreds ((l80 ))
:extrapreds ((l81 ))
:extrapreds ((l82 ))
:extrapreds ((l83 ))
:extrapreds ((l84 ))
:extrapreds ((l85 ))
:extrapreds ((l86 ))
:extrapreds ((l87 ))
:extrapreds ((l88 ))
:extrapreds ((l89 ))
:extrapreds ((l90 ))
:extrapreds ((l91 ))
:extrapreds ((l92 ))
:extrapreds ((l93 ))
:extrapreds ((l94 ))
:extrapreds ((l95 ))
:extrapreds ((l96 ))
:extrapreds ((l97 ))
:extrapreds ((l98 ))
:extrapreds ((l99 ))
:extrapreds ((l100 ))
:extrapreds ((l101 ))
:extrapreds ((l102 ))
:extrapreds ((l103 ))
:extrapreds ((l104 ))
:extrapreds ((l105 ))
:extrapreds ((l106 ))
:extrapreds ((l107 ))
:extrapreds ((l108 ))
:extrapreds ((l109 ))
:extrapreds ((l110 ))
:extrapreds ((l111 ))
:extrapreds ((l112 ))
:extrapreds ((l113 ))
:extrapreds ((l114 ))
:extrapreds ((l115 ))
:extrapreds ((l116 ))
:extrapreds ((l117 ))
:extrapreds ((l118 ))
:extrapreds ((l119 ))
:extrapreds ((l120 ))
:extrapreds ((l121 ))
:extrapreds ((l122 ))
:extrapreds ((l123 ))
:extrapreds ((l124 ))
:extrapreds ((l125 ))
:extrapreds ((l126 ))
:extrapreds ((l127 ))
:extrapreds ((l128 ))
:extrapreds ((l129 ))
:extrapreds ((l130 ))
:extrapreds ((l131 ))
:extrapreds ((l132 ))
:extrapreds ((l133 ))
:extrapreds ((l134 ))
:extrapreds ((l135 ))
:extrapreds ((l136 ))
:extrapreds ((l137 ))
:extrapreds ((l138 ))
:extrapreds ((l139 ))
:extrapreds ((l140 ))
:extrapreds ((l141 ))
:extrapreds ((l142 ))
:extrapreds ((l143 ))
:extrapreds ((l144 ))
:extrapreds ((l145 ))
:extrapreds ((l146 ))
:extrapreds ((l147 ))
:extrapreds ((l148 ))
:extrapreds ((l149 ))
:extrapreds ((l150 ))
:extrapreds ((l151 ))
:extrapreds ((l152 ))
:extrapreds ((l153 ))
:extrapreds ((l154 ))
:extrapreds ((l155 ))
:extrapreds ((l156 ))
:extrapreds ((l157 ))
:extrapreds ((l158 ))
:extrapreds ((l159 ))
:extrapreds ((l160 ))
:extrapreds ((l161 ))
:extrapreds ((l162 ))
:extrapreds ((l163 ))
:extrapreds ((l164 ))
:extrapreds ((l165 ))
:extrapreds ((l166 ))
:extrapreds ((l167 ))
:extrapreds ((l168 ))
:extrapreds ((l169 ))
:extrapreds ((l170 ))
:extrapreds ((l171 ))
:extrapreds ((l172 ))
:extrapreds ((l173 ))
:extrapreds ((l174 ))
:extrapreds ((l175 ))
:extrapreds ((l176 ))
:extrapreds ((l177 ))
:extrapreds ((l178 ))
:extrapreds ((l179 ))
:extrapreds ((l180 ))
:extrapreds ((l181 ))
:extrapreds ((l182 ))
:extrapreds ((l183 ))
:extrapreds ((l184 ))
:extrapreds ((l185 ))
:extrapreds ((l186 ))
:extrapreds ((l187 ))
:extrapreds ((l188 ))
:extrapreds ((l189 ))
:extrapreds ((l190 ))
:extrapreds ((l191 ))
:extrapreds ((l192 ))
:extrapreds ((l193 ))
:extrapreds ((l194 ))
:extrapreds ((l195 ))
:extrapreds ((l196 ))
:extrapreds ((l197 ))
:extrapreds ((l198 ))
:extrapreds ((l199 ))
:extrapreds ((l200 ))
:extrapreds ((l201 ))
:extrapreds ((l202 ))
:extrapreds ((l203 ))
:extrapreds ((l204 ))
:extrapreds ((l205 ))
:extrapreds ((l206 ))
:extrapreds ((l207 ))
:extrapreds ((l208 ))
:extrapreds ((l209 ))
:extrapreds ((l210 ))
:extrapreds ((l211 ))
:extrapreds ((l212 ))
:extrapreds ((l213 ))
:extrapreds ((l214 ))
:extrapreds ((l215 ))
:extrapreds ((l216 ))
:extrapreds ((l217 ))
:extrapreds ((l218 ))
:extrapreds ((l219 ))
:extrapreds ((l220 ))
:extrapreds ((l221 ))
:extrapreds ((l222 ))
:extrapreds ((l223 ))
:extrapreds ((l224 ))
:extrapreds ((l225 ))
:extrapreds ((l226 ))
:extrapreds ((l227 ))
:extrapreds ((l228 ))
:extrapreds ((l229 ))
:extrapreds ((l230 ))
:extrapreds ((l231 ))
:extrapreds ((l232 ))
:extrapreds ((l233 ))
:extrapreds ((l234 ))
:extrapreds ((l235 ))
:extrapreds ((l236 ))
:extrapreds ((l237 ))
:extrapreds ((l238 ))
:extrapreds ((l239 ))
:extrapreds ((l240 ))
:extrapreds ((l241 ))
:extrapreds ((l242 ))
:extrapreds ((l243 ))
:extrapreds ((l244 ))
:extrapreds ((l245 ))
:extrapreds ((l246 ))
:extrapreds ((l247 ))
:extrapreds ((l248 ))
:extrapreds ((l249 ))
:extrapreds ((l250 ))
:extrapreds ((l251 ))
:extrapreds ((l252 ))
:extrapreds ((l253 ))
:extrapreds ((l254 ))
:extrapreds ((l255 ))
:extrapreds ((l256 ))
:extrapreds ((l257 ))
:extrapreds ((l258 ))
:extrapreds ((l259 ))
:extrapreds ((l260 ))
:extrapreds ((l261 ))
:extrapreds ((l262 ))
:extrapreds ((l263 ))
:extrapreds ((l264 ))
:extrapreds ((l265 ))
:extrapreds ((l266 ))
:extrapreds ((l267 ))
:extrapreds ((l268 ))
:extrapreds ((l269 ))
:extrapreds ((l270 ))
:extrapreds ((l271 ))
:extrapreds ((l272 ))
:extrapreds ((l273 ))
:extrapreds ((l274 ))
:extrapreds ((l275 ))
:extrapreds ((l276 ))
:extrapreds ((l277 ))
:extrapreds ((l278 ))
:extrapreds ((l279 ))
:extrapreds ((l280 ))
:extrapreds ((l281 ))
:extrapreds ((l282 ))
:extrapreds ((l283 ))
:extrapreds ((l284 ))
:extrapreds ((l285 ))
:extrapreds ((l286 ))
:extrapreds ((l287 ))
:extrapreds ((l288 ))
:extrapreds ((l289 ))
:extrapreds ((l290 ))
:extrapreds ((l291 ))
:extrapreds ((l292 ))
:extrapreds ((l293 ))
:extrapreds ((l294 ))
:extrapreds ((l295 ))
:extrapreds ((l296 ))
:extrapreds ((l297 ))
:extrapreds ((l298 ))
:extrapreds ((l299 ))
:extrapreds ((l300 ))
:extrapreds ((l301 ))
:extrapreds ((l302 ))
:extrapreds ((l303 ))
:extrapreds ((l304 ))
:extrapreds ((l305 ))
:extrapreds ((l306 ))
:extrapreds ((l307 ))
:extrapreds ((l308 ))
:extrapreds ((l309 ))
:extrapreds ((l310 ))
:extrapreds ((l311 ))
:extrapreds ((l312 ))
:extrapreds ((l313 ))
:extrapreds ((l314 ))
:extrapreds ((l315 ))
:extrapreds ((l316 ))
:extrapreds ((l317 ))
:extrapreds ((l318 ))
:extrapreds ((l319 ))
:extrapreds ((l320 ))
:extrapreds ((l321 ))
:extrapreds ((l322 ))
:extrapreds ((l323 ))
:extrapreds ((l324 ))
:extrapreds ((l325 ))
:extrapreds ((l326 ))
:extrapreds ((l327 ))
:extrapreds ((l328 ))
:extrapreds ((l329 ))
:extrapreds ((l330 ))
:extrapreds ((l331 ))
:extrapreds ((l332 ))
:extrapreds ((l333 ))
:extrapreds ((l334 ))
:extrapreds ((l335 ))
:extrapreds ((l336 ))
:extrapreds ((l337 ))
:extrapreds ((l338 ))
:extrapreds ((l339 ))
:extrapreds ((l340 ))
:extrapreds ((l341 ))
:extrapreds ((l342 ))
:extrapreds ((l343 ))
:extrapreds ((l344 ))
:extrapreds ((l345 ))
:extrapreds ((l346 ))
:extrapreds ((l347 ))
:extrapreds ((l348 ))
:extrapreds ((l349 ))
:extrapreds ((l350 ))
:extrapreds ((l351 ))
:extrapreds ((l352 ))
:extrapreds ((l353 ))
:extrapreds ((l354 ))
:extrapreds ((l355 ))
:extrapreds ((l356 ))
:extrapreds ((l357 ))
:extrapreds ((l358 ))
:extrapreds ((l359 ))
:extrapreds ((l360 ))
:extrapreds ((l361 ))
:extrapreds ((l362 ))
:extrapreds ((l363 ))
:extrapreds ((l364 ))
:extrapreds ((l365 ))
:extrapreds ((l366 ))
:extrapreds ((l367 ))
:extrapreds ((l368 ))
:extrapreds ((l369 ))
:extrapreds ((l370 ))
:extrapreds ((l371 ))
:extrapreds ((l372 ))
:extrapreds ((l373 ))
:extrapreds ((l374 ))
:extrapreds ((l375 ))
:extrapreds ((l376 ))
:extrapreds ((l377 ))
:extrapreds ((l378 ))
:extrapreds ((l379 ))
:extrapreds ((l380 ))
:extrapreds ((l381 ))
:extrapreds ((l382 ))
:extrapreds ((l383 ))
:extrapreds ((l384 ))
:extrapreds ((l385 ))
:extrapreds ((l386 ))
:extrapreds ((l387 ))
:extrapreds ((l388 ))
:extrapreds ((l389 ))
:extrapreds ((l390 ))
:extrapreds ((l391 ))
:extrapreds ((l392 ))
:extrapreds ((l393 ))
:extrapreds ((l394 ))
:extrapreds ((l395 ))
:extrapreds ((l396 ))
:extrapreds ((l397 ))
:extrapreds ((l398 ))
:extrapreds ((l399 ))
:extrapreds ((l400 ))
:extrapreds ((l401 ))
:extrapreds ((l402 ))
:extrapreds ((l403 ))
:extrapreds ((l404 ))
:extrapreds ((l405 ))
:extrapreds ((l406 ))
:extrapreds ((l407 ))
:extrapreds ((l408 ))
:extrapreds ((l409 ))
:extrapreds ((l410 ))
:extrapreds ((l411 ))
:extrapreds ((l412 ))
:extrapreds ((l413 ))
:extrapreds ((l414 ))
:extrapreds ((l415 ))
:extrapreds ((l416 ))
:extrapreds ((l417 ))
:extrapreds ((l418 ))
:extrapreds ((l419 ))
:extrapreds ((l420 ))
:extrapreds ((l421 ))
:extrapreds ((l422 ))
:extrapreds ((l423 ))
:extrapreds ((l424 ))
:extrapreds ((l425 ))
:extrapreds ((l426 ))
:extrapreds ((l427 ))
:extrapreds ((l428 ))
:extrapreds ((l429 ))
:extrapreds ((l430 ))
:extrapreds ((l431 ))
:extrapreds ((l432 ))
:extrapreds ((l433 ))
:extrapreds ((l434 ))
:extrapreds ((l435 ))
:extrapreds ((l436 ))
:extrapreds ((l437 ))
:extrapreds ((l438 ))
:extrapreds ((l439 ))
:extrapreds ((l440 ))
:extrapreds ((l441 ))
:extrapreds ((l442 ))
:extrapreds ((l443 ))
:extrapreds ((l444 ))
:extrapreds ((l445 ))
:extrapreds ((l446 ))
:extrapreds ((l447 ))
:extrapreds ((l448 ))
:extrapreds ((l449 ))
:extrapreds ((l450 ))
:extrapreds ((l451 ))
:extrapreds ((l452 ))
:extrapreds ((l453 ))
:extrapreds ((l454 ))
:extrapreds ((l455 ))
:extrapreds ((l456 ))
:extrapreds ((l457 ))
:extrapreds ((l458 ))
:extrapreds ((l459 ))
:extrapreds ((l460 ))
:extrapreds ((l461 ))
:extrapreds ((l462 ))
:extrapreds ((l463 ))
:extrapreds ((l464 ))
:extrapreds ((l465 ))
:extrapreds ((l466 ))
:extrapreds ((l467 ))
:extrapreds ((l468 ))
:extrapreds ((l469 ))
:extrapreds ((l470 ))
:extrapreds ((l471 ))
:extrapreds ((l472 ))
:extrapreds ((l473 ))
:extrapreds ((l474 ))
:extrapreds ((l475 ))
:extrapreds ((l476 ))
:extrapreds ((l477 ))
:extrapreds ((l478 ))
:extrapreds ((l479 ))
:extrapreds ((l480 ))
:extrapreds ((l481 ))
:extrapreds ((l482 ))
:extrapreds ((l483 ))
:extrapreds ((l484 ))
:extrapreds ((execution_statet___guard_exec_0_0_0_0_1 ))
:extrapreds ((l485 ))
:extrapreds ((l486 ))
:extrapreds ((l487 ))
:extrapreds ((l488 ))
:extrapreds ((l489 ))
:extrapreds ((l490 ))
:extrapreds ((goto_symex___guard_0_0_1 ))
:extrapreds ((l491 ))
:extrapreds ((l492 ))
:extrapreds ((l493 ))
:extrapreds ((l494 ))
:extrapreds ((l495 ))
:extrapreds ((goto_symex___guard_0_0_2 ))
:extrapreds ((l496 ))
:extrapreds ((l497 ))
:extrapreds ((l498 ))
:extrapreds ((l499 ))
:extrapreds ((l500 ))
:extrapreds ((l501 ))
:extrapreds ((l502 ))
:extrapreds ((l503 ))
:extrapreds ((l504 ))
:extrapreds ((goto_symex___guard_0_0_3 ))
:extrapreds ((l505 ))
:extrapreds ((l506 ))
:extrapreds ((l507 ))
:extrapreds ((l508 ))
:extrapreds ((l509 ))
:extrapreds ((l510 ))
:extrapreds ((l511 ))
:extrapreds ((goto_symex___guard_0_0_4 ))
:extrapreds ((l512 ))
:extrapreds ((l513 ))
:extrapreds ((l514 ))
:extrapreds ((l515 ))
:extrapreds ((l516 ))
:extrapreds ((l517 ))
:extrapreds ((goto_symex___guard_0_0_5 ))
:extrapreds ((l518 ))
:extrapreds ((l519 ))
:extrapreds ((l520 ))
:extrapreds ((l521 ))
:extrapreds ((goto_symex___guard_0_0_6 ))
:extrapreds ((l522 ))
:extrapreds ((l523 ))
:extrapreds ((l524 ))
:extrapreds ((l525 ))
:extrapreds ((l526 ))
:extrapreds ((l527 ))
:extrapreds ((goto_symex___guard_0_0_7 ))
:extrapreds ((l528 ))
:extrapreds ((l529 ))
:extrapreds ((l530 ))
:extrapreds ((l531 ))
:extrapreds ((l532 ))
:extrapreds ((l533 ))
:extrapreds ((goto_symex___guard_0_0_8 ))
:extrapreds ((l534 ))
:extrapreds ((l535 ))
:extrapreds ((l536 ))
:extrapreds ((l537 ))
:extrapreds ((l538 ))
:extrapreds ((l539 ))
:extrapreds ((l540 ))
:extrapreds ((l541 ))
:extrapreds ((l542 ))
:extrapreds ((goto_symex___guard_0_0_9 ))
:extrapreds ((l543 ))
:extrapreds ((l544 ))
:extrapreds ((l545 ))
:extrapreds ((l546 ))
:extrapreds ((l547 ))
:extrapreds ((l548 ))
:extrapreds ((goto_symex___guard_0_0_10 ))
:extrapreds ((l549 ))
:extrapreds ((l550 ))
:extrapreds ((l551 ))
:extrapreds ((l552 ))
:extrapreds ((l553 ))
:extrapreds ((l554 ))
:extrapreds ((goto_symex___guard_0_0_11 ))
:extrapreds ((l555 ))
:extrapreds ((l556 ))
:extrapreds ((l557 ))
:extrapreds ((l558 ))
:extrapreds ((l559 ))
:extrapreds ((l560 ))
:extrapreds ((l561 ))
:extrapreds ((l562 ))
:extrapreds ((l563 ))
:extrapreds ((goto_symex___guard_0_0_12 ))
:extrapreds ((l564 ))
:extrapreds ((l565 ))
:extrapreds ((l566 ))
:extrapreds ((l567 ))
:extrapreds ((l568 ))
:extrapreds ((l569 ))
:extrapreds ((goto_symex___guard_0_0_13 ))
:extrapreds ((l570 ))
:extrapreds ((l571 ))
:extrapreds ((l572 ))
:extrapreds ((l573 ))
:extrapreds ((l574 ))
:extrapreds ((l575 ))
:extrapreds ((goto_symex___guard_0_0_14 ))
:extrapreds ((l576 ))
:extrapreds ((l577 ))
:extrapreds ((l578 ))
:extrapreds ((l579 ))
:extrapreds ((l580 ))
:extrapreds ((l581 ))
:extrapreds ((l582 ))
:extrapreds ((l583 ))
:extrapreds ((l584 ))
:extrapreds ((goto_symex___guard_0_0_15 ))
:extrapreds ((l585 ))
:extrapreds ((l586 ))
:extrapreds ((l587 ))
:extrapreds ((l588 ))
:extrapreds ((l589 ))
:extrapreds ((l590 ))
:extrapreds ((goto_symex___guard_0_0_16 ))
:extrapreds ((l591 ))
:extrapreds ((l592 ))
:extrapreds ((l593 ))
:extrapreds ((l594 ))
:extrapreds ((l595 ))
:extrapreds ((l596 ))
:extrapreds ((goto_symex___guard_0_0_17 ))
:extrapreds ((l597 ))
:extrapreds ((l598 ))
:extrapreds ((l599 ))
:extrapreds ((l600 ))
:extrapreds ((l601 ))
:extrapreds ((l602 ))
:extrapreds ((l603 ))
:extrapreds ((l604 ))
:extrapreds ((l605 ))
:extrapreds ((goto_symex___guard_0_0_18 ))
:extrapreds ((l606 ))
:extrapreds ((l607 ))
:extrapreds ((l608 ))
:extrapreds ((l609 ))
:extrapreds ((l610 ))
:extrapreds ((l611 ))
:extrapreds ((goto_symex___guard_0_0_19 ))
:extrapreds ((l612 ))
:extrapreds ((l613 ))
:extrapreds ((l614 ))
:extrapreds ((l615 ))
:extrapreds ((l616 ))
:extrapreds ((l617 ))
:extrapreds ((goto_symex___guard_0_0_20 ))
:extrapreds ((l618 ))
:extrapreds ((l619 ))
:extrapreds ((l620 ))
:extrapreds ((l621 ))
:extrapreds ((l622 ))
:extrapreds ((l623 ))
:extrapreds ((l624 ))
:extrapreds ((l625 ))
:extrapreds ((l626 ))
:extrapreds ((goto_symex___guard_0_0_21 ))
:extrapreds ((l627 ))
:extrapreds ((l628 ))
:extrapreds ((l629 ))
:extrapreds ((l630 ))
:extrapreds ((l631 ))
:extrapreds ((l632 ))
:extrapreds ((goto_symex___guard_0_0_22 ))
:extrapreds ((l633 ))
:extrapreds ((l634 ))
:extrapreds ((l635 ))
:extrapreds ((l636 ))
:extrapreds ((l637 ))
:extrapreds ((l638 ))
:extrapreds ((goto_symex___guard_0_0_23 ))
:extrapreds ((l639 ))
:extrapreds ((l640 ))
:extrapreds ((l641 ))
:extrapreds ((l642 ))
:extrapreds ((l643 ))
:extrapreds ((l644 ))
:extrapreds ((l645 ))
:extrapreds ((l646 ))
:extrapreds ((l647 ))
:extrapreds ((goto_symex___guard_0_0_24 ))
:extrapreds ((l648 ))
:extrapreds ((l649 ))
:extrapreds ((l650 ))
:extrapreds ((l651 ))
:extrapreds ((l652 ))
:extrapreds ((l653 ))
:extrapreds ((goto_symex___guard_0_0_25 ))
:extrapreds ((l654 ))
:extrapreds ((l655 ))
:extrapreds ((l656 ))
:extrapreds ((l657 ))
:extrapreds ((l658 ))
:extrapreds ((l659 ))
:extrapreds ((goto_symex___guard_0_0_26 ))
:extrapreds ((l660 ))
:extrapreds ((l661 ))
:extrapreds ((l662 ))
:extrapreds ((l663 ))
:extrapreds ((l664 ))
:extrapreds ((l665 ))
:extrapreds ((l666 ))
:extrapreds ((l667 ))
:extrapreds ((l668 ))
:extrapreds ((goto_symex___guard_0_0_27 ))
:extrapreds ((l669 ))
:extrapreds ((l670 ))
:extrapreds ((l671 ))
:extrapreds ((l672 ))
:extrapreds ((l673 ))
:extrapreds ((l674 ))
:extrapreds ((goto_symex___guard_0_0_28 ))
:extrapreds ((l675 ))
:extrapreds ((l676 ))
:extrapreds ((l677 ))
:extrapreds ((l678 ))
:extrapreds ((l679 ))
:extrapreds ((l680 ))
:extrapreds ((goto_symex___guard_0_0_29 ))
:extrapreds ((l681 ))
:extrapreds ((l682 ))
:extrapreds ((l683 ))
:extrapreds ((l684 ))
:extrapreds ((l685 ))
:extrapreds ((l686 ))
:extrapreds ((l687 ))
:extrapreds ((l688 ))
:extrapreds ((l689 ))
:extrapreds ((goto_symex___guard_0_0_30 ))
:extrapreds ((l690 ))
:extrapreds ((l691 ))
:extrapreds ((l692 ))
:extrapreds ((l693 ))
:extrapreds ((l694 ))
:extrapreds ((l695 ))
:extrapreds ((goto_symex___guard_0_0_31 ))
:extrapreds ((l696 ))
:extrapreds ((l697 ))
:extrapreds ((l698 ))
:extrapreds ((l699 ))
:extrapreds ((l700 ))
:extrapreds ((l701 ))
:extrapreds ((goto_symex___guard_0_0_32 ))
:extrapreds ((l702 ))
:extrapreds ((l703 ))
:extrapreds ((l704 ))
:extrapreds ((l705 ))
:extrapreds ((l706 ))
:extrapreds ((l707 ))
:extrapreds ((l708 ))
:extrapreds ((l709 ))
:extrapreds ((l710 ))
:extrapreds ((goto_symex___guard_0_0_33 ))
:extrapreds ((l711 ))
:extrapreds ((l712 ))
:extrapreds ((l713 ))
:extrapreds ((l714 ))
:extrapreds ((l715 ))
:extrapreds ((l716 ))
:extrapreds ((goto_symex___guard_0_0_34 ))
:extrapreds ((l717 ))
:extrapreds ((l718 ))
:extrapreds ((l719 ))
:extrapreds ((l720 ))
:extrapreds ((l721 ))
:extrapreds ((l722 ))
:extrapreds ((goto_symex___guard_0_0_35 ))
:extrapreds ((l723 ))
:extrapreds ((l724 ))
:extrapreds ((l725 ))
:extrapreds ((l726 ))
:extrapreds ((l727 ))
:extrapreds ((l728 ))
:extrapreds ((l729 ))
:extrapreds ((l730 ))
:extrapreds ((l731 ))
:extrapreds ((goto_symex___guard_0_0_36 ))
:extrapreds ((l732 ))
:extrapreds ((l733 ))
:extrapreds ((l734 ))
:extrapreds ((l735 ))
:extrapreds ((l736 ))
:extrapreds ((l737 ))
:extrapreds ((goto_symex___guard_0_0_37 ))
:extrapreds ((l738 ))
:extrapreds ((l739 ))
:extrapreds ((l740 ))
:extrapreds ((l741 ))
:extrapreds ((l742 ))
:extrapreds ((l743 ))
:extrapreds ((goto_symex___guard_0_0_38 ))
:extrapreds ((l744 ))
:extrapreds ((l745 ))
:extrapreds ((l746 ))
:extrapreds ((l747 ))
:extrapreds ((l748 ))
:extrapreds ((l749 ))
:extrapreds ((l750 ))
:extrapreds ((l751 ))
:extrapreds ((l752 ))
:extrapreds ((goto_symex___guard_0_0_39 ))
:extrapreds ((l753 ))
:extrapreds ((l754 ))
:extrapreds ((l755 ))
:extrapreds ((l756 ))
:extrapreds ((l757 ))
:extrapreds ((l758 ))
:extrapreds ((goto_symex___guard_0_0_40 ))
:extrapreds ((l759 ))
:extrapreds ((l760 ))
:extrapreds ((l761 ))
:extrapreds ((l762 ))
:extrapreds ((l763 ))
:extrapreds ((l764 ))
:extrapreds ((goto_symex___guard_0_0_41 ))
:extrapreds ((l765 ))
:extrapreds ((l766 ))
:extrapreds ((l767 ))
:extrapreds ((l768 ))
:extrapreds ((l769 ))
:extrapreds ((l770 ))
:extrapreds ((l771 ))
:extrapreds ((l772 ))
:extrapreds ((l773 ))
:extrapreds ((goto_symex___guard_0_0_42 ))
:extrapreds ((l774 ))
:extrapreds ((l775 ))
:extrapreds ((l776 ))
:extrapreds ((l777 ))
:extrapreds ((l778 ))
:extrapreds ((l779 ))
:extrapreds ((goto_symex___guard_0_0_43 ))
:extrapreds ((l780 ))
:extrapreds ((l781 ))
:extrapreds ((l782 ))
:extrapreds ((l783 ))
:extrapreds ((l784 ))
:extrapreds ((l785 ))
:extrapreds ((goto_symex___guard_0_0_44 ))
:extrapreds ((l786 ))
:extrapreds ((l787 ))
:extrapreds ((l788 ))
:extrapreds ((l789 ))
:extrapreds ((l790 ))
:extrapreds ((l791 ))
:extrapreds ((l792 ))
:extrapreds ((l793 ))
:extrapreds ((l794 ))
:extrapreds ((goto_symex___guard_0_0_45 ))
:extrapreds ((l795 ))
:extrapreds ((l796 ))
:extrapreds ((l797 ))
:extrapreds ((l798 ))
:extrapreds ((l799 ))
:extrapreds ((l800 ))
:extrapreds ((goto_symex___guard_0_0_46 ))
:extrapreds ((l801 ))
:extrapreds ((l802 ))
:extrapreds ((l803 ))
:extrapreds ((l804 ))
:extrapreds ((l805 ))
:extrapreds ((l806 ))
:extrapreds ((goto_symex___guard_0_0_47 ))
:extrapreds ((l807 ))
:extrapreds ((l808 ))
:extrapreds ((l809 ))
:extrapreds ((l810 ))
:extrapreds ((l811 ))
:extrapreds ((l812 ))
:extrapreds ((l813 ))
:extrapreds ((l814 ))
:extrapreds ((l815 ))
:extrapreds ((goto_symex___guard_0_0_48 ))
:extrapreds ((l816 ))
:extrapreds ((l817 ))
:extrapreds ((l818 ))
:extrapreds ((l819 ))
:extrapreds ((l820 ))
:extrapreds ((l821 ))
:extrapreds ((goto_symex___guard_0_0_49 ))
:extrapreds ((l822 ))
:extrapreds ((l823 ))
:extrapreds ((l824 ))
:extrapreds ((l825 ))
:extrapreds ((l826 ))
:extrapreds ((l827 ))
:extrapreds ((goto_symex___guard_0_0_50 ))
:extrapreds ((l828 ))
:extrapreds ((l829 ))
:extrapreds ((l830 ))
:extrapreds ((l831 ))
:extrapreds ((l832 ))
:extrapreds ((l833 ))
:extrapreds ((l834 ))
:extrapreds ((l835 ))
:extrapreds ((l836 ))
:extrapreds ((goto_symex___guard_0_0_51 ))
:extrapreds ((l837 ))
:extrapreds ((l838 ))
:extrapreds ((l839 ))
:extrapreds ((l840 ))
:extrapreds ((l841 ))
:extrapreds ((l842 ))
:extrapreds ((goto_symex___guard_0_0_52 ))
:extrapreds ((l843 ))
:extrapreds ((l844 ))
:extrapreds ((l845 ))
:extrapreds ((l846 ))
:extrapreds ((l847 ))
:extrapreds ((l848 ))
:extrapreds ((goto_symex___guard_0_0_53 ))
:extrapreds ((l849 ))
:extrapreds ((l850 ))
:extrapreds ((l851 ))
:extrapreds ((l852 ))
:extrapreds ((l853 ))
:extrapreds ((l854 ))
:extrapreds ((l855 ))
:extrapreds ((l856 ))
:extrapreds ((l857 ))
:extrapreds ((goto_symex___guard_0_0_54 ))
:extrapreds ((l858 ))
:extrapreds ((l859 ))
:extrapreds ((l860 ))
:extrapreds ((l861 ))
:extrapreds ((l862 ))
:extrapreds ((l863 ))
:extrapreds ((goto_symex___guard_0_0_55 ))
:extrapreds ((l864 ))
:extrapreds ((l865 ))
:extrapreds ((l866 ))
:extrapreds ((l867 ))
:extrapreds ((l868 ))
:extrapreds ((l869 ))
:extrapreds ((goto_symex___guard_0_0_56 ))
:extrapreds ((l870 ))
:extrapreds ((l871 ))
:extrapreds ((l872 ))
:extrapreds ((l873 ))
:extrapreds ((l874 ))
:extrapreds ((l875 ))
:extrapreds ((l876 ))
:extrapreds ((l877 ))
:extrapreds ((l878 ))
:extrapreds ((goto_symex___guard_0_0_57 ))
:extrapreds ((l879 ))
:extrapreds ((l880 ))
:extrapreds ((l881 ))
:extrapreds ((l882 ))
:extrapreds ((l883 ))
:extrapreds ((l884 ))
:extrapreds ((goto_symex___guard_0_0_58 ))
:extrapreds ((l885 ))
:extrapreds ((l886 ))
:extrapreds ((l887 ))
:extrapreds ((l888 ))
:extrapreds ((l890 ))
:extrapreds ((l889 ))
:extrapreds ((l891 ))
:extrapreds ((goto_symex___guard_0_0_59 ))
:extrapreds ((l892 ))
:extrapreds ((l893 ))
:extrapreds ((goto_symex___guard_0_0_60 ))
:extrapreds ((l894 ))
:extrapreds ((l895 ))
:extrapreds ((goto_symex___guard_0_0_61 ))
:extrapreds ((l896 ))
:extrapreds ((l897 ))
:extrapreds ((l898 ))
:extrapreds ((l899 ))
:extrapreds ((l900 ))
:extrapreds ((goto_symex___guard_0_0_62 ))
:extrapreds ((l901 ))
:extrapreds ((l902 ))
:extrapreds ((l903 ))
:extrapreds ((l904 ))
:extrapreds ((l905 ))
:extrapreds ((goto_symex___guard_0_0_63 ))
:extrapreds ((l906 ))
:extrapreds ((l907 ))
:extrapreds ((l908 ))
:extrapreds ((l909 ))
:extrapreds ((l910 ))
:extrapreds ((l911 ))
:extrapreds ((l912 ))
:extrapreds ((l913 ))
:extrapreds ((l914 ))
:extrapreds ((goto_symex___guard_0_0_64 ))
:extrapreds ((l915 ))
:extrapreds ((l916 ))
:extrapreds ((l917 ))
:extrapreds ((l918 ))
:extrapreds ((l919 ))
:extrapreds ((l920 ))
:extrapreds ((l921 ))
:extrapreds ((goto_symex___guard_0_0_65 ))
:extrapreds ((l922 ))
:extrapreds ((l923 ))
:extrapreds ((l924 ))
:extrapreds ((l925 ))
:extrapreds ((l926 ))
:extrapreds ((l927 ))
:extrapreds ((goto_symex___guard_0_0_66 ))
:extrapreds ((l928 ))
:extrapreds ((l929 ))
:extrapreds ((l930 ))
:extrapreds ((l931 ))
:extrapreds ((goto_symex___guard_0_0_67 ))
:extrapreds ((l932 ))
:extrapreds ((l933 ))
:extrapreds ((l934 ))
:extrapreds ((l935 ))
:extrapreds ((l936 ))
:extrapreds ((l937 ))
:extrapreds ((goto_symex___guard_0_0_68 ))
:extrapreds ((l938 ))
:extrapreds ((l939 ))
:extrapreds ((l940 ))
:extrapreds ((l941 ))
:extrapreds ((l942 ))
:extrapreds ((l943 ))
:extrapreds ((goto_symex___guard_0_0_69 ))
:extrapreds ((l944 ))
:extrapreds ((l945 ))
:extrapreds ((l946 ))
:extrapreds ((l947 ))
:extrapreds ((l948 ))
:extrapreds ((l949 ))
:extrapreds ((l950 ))
:extrapreds ((l951 ))
:extrapreds ((l952 ))
:extrapreds ((goto_symex___guard_0_0_70 ))
:extrapreds ((l953 ))
:extrapreds ((l954 ))
:extrapreds ((l955 ))
:extrapreds ((l956 ))
:extrapreds ((l957 ))
:extrapreds ((l958 ))
:extrapreds ((goto_symex___guard_0_0_71 ))
:extrapreds ((l959 ))
:extrapreds ((l960 ))
:extrapreds ((l961 ))
:extrapreds ((l962 ))
:extrapreds ((l963 ))
:extrapreds ((l964 ))
:extrapreds ((goto_symex___guard_0_0_72 ))
:extrapreds ((l965 ))
:extrapreds ((l966 ))
:extrapreds ((l967 ))
:extrapreds ((l968 ))
:extrapreds ((l969 ))
:extrapreds ((l970 ))
:extrapreds ((l971 ))
:extrapreds ((l972 ))
:extrapreds ((l973 ))
:extrapreds ((goto_symex___guard_0_0_73 ))
:extrapreds ((l974 ))
:extrapreds ((l975 ))
:extrapreds ((l976 ))
:extrapreds ((l977 ))
:extrapreds ((l978 ))
:extrapreds ((l979 ))
:extrapreds ((goto_symex___guard_0_0_74 ))
:extrapreds ((l980 ))
:extrapreds ((l981 ))
:extrapreds ((l982 ))
:extrapreds ((l983 ))
:extrapreds ((l984 ))
:extrapreds ((l985 ))
:extrapreds ((goto_symex___guard_0_0_75 ))
:extrapreds ((l986 ))
:extrapreds ((l987 ))
:extrapreds ((l988 ))
:extrapreds ((l989 ))
:extrapreds ((l990 ))
:extrapreds ((l991 ))
:extrapreds ((l992 ))
:extrapreds ((l993 ))
:extrapreds ((l994 ))
:extrapreds ((goto_symex___guard_0_0_76 ))
:extrapreds ((l995 ))
:extrapreds ((l996 ))
:extrapreds ((l997 ))
:extrapreds ((l998 ))
:extrapreds ((l999 ))
:extrapreds ((l1000 ))
:extrapreds ((goto_symex___guard_0_0_77 ))
:extrapreds ((l1001 ))
:extrapreds ((l1002 ))
:extrapreds ((l1003 ))
:extrapreds ((l1004 ))
:extrapreds ((l1005 ))
:extrapreds ((l1006 ))
:extrapreds ((goto_symex___guard_0_0_78 ))
:extrapreds ((l1007 ))
:extrapreds ((l1008 ))
:extrapreds ((l1009 ))
:extrapreds ((l1010 ))
:extrapreds ((l1011 ))
:extrapreds ((l1012 ))
:extrapreds ((l1013 ))
:extrapreds ((l1014 ))
:extrapreds ((l1015 ))
:extrapreds ((goto_symex___guard_0_0_79 ))
:extrapreds ((l1016 ))
:extrapreds ((l1017 ))
:extrapreds ((l1018 ))
:extrapreds ((l1019 ))
:extrapreds ((l1020 ))
:extrapreds ((l1021 ))
:extrapreds ((goto_symex___guard_0_0_80 ))
:extrapreds ((l1022 ))
:extrapreds ((l1023 ))
:extrapreds ((l1024 ))
:extrapreds ((l1025 ))
:extrapreds ((l1026 ))
:extrapreds ((l1027 ))
:extrapreds ((goto_symex___guard_0_0_81 ))
:extrapreds ((l1028 ))
:extrapreds ((l1029 ))
:extrapreds ((l1030 ))
:extrapreds ((l1031 ))
:extrapreds ((l1032 ))
:extrapreds ((l1033 ))
:extrapreds ((l1034 ))
:extrapreds ((l1035 ))
:extrapreds ((l1036 ))
:extrapreds ((goto_symex___guard_0_0_82 ))
:extrapreds ((l1037 ))
:extrapreds ((l1038 ))
:extrapreds ((l1039 ))
:extrapreds ((l1040 ))
:extrapreds ((l1041 ))
:extrapreds ((l1042 ))
:extrapreds ((goto_symex___guard_0_0_83 ))
:extrapreds ((l1043 ))
:extrapreds ((l1044 ))
:extrapreds ((l1045 ))
:extrapreds ((l1046 ))
:extrapreds ((l1047 ))
:extrapreds ((l1048 ))
:extrapreds ((goto_symex___guard_0_0_84 ))
:extrapreds ((l1049 ))
:extrapreds ((l1050 ))
:extrapreds ((l1051 ))
:extrapreds ((l1052 ))
:extrapreds ((l1053 ))
:extrapreds ((l1054 ))
:extrapreds ((l1055 ))
:extrapreds ((l1056 ))
:extrapreds ((l1057 ))
:extrapreds ((goto_symex___guard_0_0_85 ))
:extrapreds ((l1058 ))
:extrapreds ((l1059 ))
:extrapreds ((l1060 ))
:extrapreds ((l1061 ))
:extrapreds ((l1062 ))
:extrapreds ((l1063 ))
:extrapreds ((goto_symex___guard_0_0_86 ))
:extrapreds ((l1064 ))
:extrapreds ((l1065 ))
:extrapreds ((l1066 ))
:extrapreds ((l1067 ))
:extrapreds ((l1068 ))
:extrapreds ((l1069 ))
:extrapreds ((goto_symex___guard_0_0_87 ))
:extrapreds ((l1070 ))
:extrapreds ((l1071 ))
:extrapreds ((l1072 ))
:extrapreds ((l1073 ))
:extrapreds ((l1074 ))
:extrapreds ((l1075 ))
:extrapreds ((l1076 ))
:extrapreds ((l1077 ))
:extrapreds ((l1078 ))
:extrapreds ((goto_symex___guard_0_0_88 ))
:extrapreds ((l1079 ))
:extrapreds ((l1080 ))
:extrapreds ((l1081 ))
:extrapreds ((l1082 ))
:extrapreds ((l1083 ))
:extrapreds ((l1084 ))
:extrapreds ((goto_symex___guard_0_0_89 ))
:extrapreds ((l1085 ))
:extrapreds ((l1086 ))
:extrapreds ((l1087 ))
:extrapreds ((l1088 ))
:extrapreds ((l1089 ))
:extrapreds ((l1090 ))
:extrapreds ((goto_symex___guard_0_0_90 ))
:extrapreds ((l1091 ))
:extrapreds ((l1092 ))
:extrapreds ((l1093 ))
:extrapreds ((l1094 ))
:extrapreds ((l1095 ))
:extrapreds ((l1096 ))
:extrapreds ((l1097 ))
:extrapreds ((l1098 ))
:extrapreds ((l1099 ))
:extrapreds ((goto_symex___guard_0_0_91 ))
:extrapreds ((l1100 ))
:extrapreds ((l1101 ))
:extrapreds ((l1102 ))
:extrapreds ((l1103 ))
:extrapreds ((l1104 ))
:extrapreds ((l1105 ))
:extrapreds ((goto_symex___guard_0_0_92 ))
:extrapreds ((l1106 ))
:extrapreds ((l1107 ))
:extrapreds ((l1108 ))
:extrapreds ((l1109 ))
:extrapreds ((l1110 ))
:extrapreds ((l1111 ))
:extrapreds ((goto_symex___guard_0_0_93 ))
:extrapreds ((l1112 ))
:extrapreds ((l1113 ))
:extrapreds ((l1114 ))
:extrapreds ((l1115 ))
:extrapreds ((l1116 ))
:extrapreds ((l1117 ))
:extrapreds ((l1118 ))
:extrapreds ((l1119 ))
:extrapreds ((l1120 ))
:extrapreds ((goto_symex___guard_0_0_94 ))
:extrapreds ((l1121 ))
:extrapreds ((l1122 ))
:extrapreds ((l1123 ))
:extrapreds ((l1124 ))
:extrapreds ((l1125 ))
:extrapreds ((l1126 ))
:extrapreds ((goto_symex___guard_0_0_95 ))
:extrapreds ((l1127 ))
:extrapreds ((l1128 ))
:extrapreds ((l1129 ))
:extrapreds ((l1130 ))
:extrapreds ((l1131 ))
:extrapreds ((l1132 ))
:extrapreds ((goto_symex___guard_0_0_96 ))
:extrapreds ((l1133 ))
:extrapreds ((l1134 ))
:extrapreds ((l1135 ))
:extrapreds ((l1136 ))
:extrapreds ((l1137 ))
:extrapreds ((l1138 ))
:extrapreds ((l1139 ))
:extrapreds ((l1140 ))
:extrapreds ((l1141 ))
:extrapreds ((goto_symex___guard_0_0_97 ))
:extrapreds ((l1142 ))
:extrapreds ((l1143 ))
:extrapreds ((l1144 ))
:extrapreds ((l1145 ))
:extrapreds ((l1146 ))
:extrapreds ((l1147 ))
:extrapreds ((goto_symex___guard_0_0_98 ))
:extrapreds ((l1148 ))
:extrapreds ((l1149 ))
:extrapreds ((l1150 ))
:extrapreds ((l1151 ))
:extrapreds ((l1152 ))
:extrapreds ((l1153 ))
:extrapreds ((goto_symex___guard_0_0_99 ))
:extrapreds ((l1154 ))
:extrapreds ((l1155 ))
:extrapreds ((l1156 ))
:extrapreds ((l1157 ))
:extrapreds ((l1158 ))
:extrapreds ((l1159 ))
:extrapreds ((l1160 ))
:extrapreds ((l1161 ))
:extrapreds ((l1162 ))
:extrapreds ((goto_symex___guard_0_0_100 ))
:extrapreds ((l1163 ))
:extrapreds ((l1164 ))
:extrapreds ((l1165 ))
:extrapreds ((l1166 ))
:extrapreds ((l1167 ))
:extrapreds ((l1168 ))
:extrapreds ((goto_symex___guard_0_0_101 ))
:extrapreds ((l1169 ))
:extrapreds ((l1170 ))
:extrapreds ((l1171 ))
:extrapreds ((l1172 ))
:extrapreds ((l1173 ))
:extrapreds ((l1174 ))
:extrapreds ((goto_symex___guard_0_0_102 ))
:extrapreds ((l1175 ))
:extrapreds ((l1176 ))
:extrapreds ((l1177 ))
:extrapreds ((l1178 ))
:extrapreds ((l1179 ))
:extrapreds ((l1180 ))
:extrapreds ((l1181 ))
:extrapreds ((l1182 ))
:extrapreds ((l1183 ))
:extrapreds ((goto_symex___guard_0_0_103 ))
:extrapreds ((l1184 ))
:extrapreds ((l1185 ))
:extrapreds ((l1186 ))
:extrapreds ((l1187 ))
:extrapreds ((l1188 ))
:extrapreds ((l1189 ))
:extrapreds ((goto_symex___guard_0_0_104 ))
:extrapreds ((l1190 ))
:extrapreds ((l1191 ))
:extrapreds ((l1192 ))
:extrapreds ((l1193 ))
:extrapreds ((l1194 ))
:extrapreds ((l1195 ))
:extrapreds ((goto_symex___guard_0_0_105 ))
:extrapreds ((l1196 ))
:extrapreds ((l1197 ))
:extrapreds ((l1198 ))
:extrapreds ((l1199 ))
:extrapreds ((l1200 ))
:extrapreds ((l1201 ))
:extrapreds ((l1202 ))
:extrapreds ((l1203 ))
:extrapreds ((l1204 ))
:extrapreds ((goto_symex___guard_0_0_106 ))
:extrapreds ((l1205 ))
:extrapreds ((l1206 ))
:extrapreds ((l1207 ))
:extrapreds ((l1208 ))
:extrapreds ((l1209 ))
:extrapreds ((l1210 ))
:extrapreds ((goto_symex___guard_0_0_107 ))
:extrapreds ((l1211 ))
:extrapreds ((l1212 ))
:extrapreds ((l1213 ))
:extrapreds ((l1214 ))
:extrapreds ((l1215 ))
:extrapreds ((l1216 ))
:extrapreds ((goto_symex___guard_0_0_108 ))
:extrapreds ((l1217 ))
:extrapreds ((l1218 ))
:extrapreds ((l1219 ))
:extrapreds ((l1220 ))
:extrapreds ((l1221 ))
:extrapreds ((l1222 ))
:extrapreds ((l1223 ))
:extrapreds ((l1224 ))
:extrapreds ((l1225 ))
:extrapreds ((goto_symex___guard_0_0_109 ))
:extrapreds ((l1226 ))
:extrapreds ((l1227 ))
:extrapreds ((l1228 ))
:extrapreds ((l1229 ))
:extrapreds ((l1230 ))
:extrapreds ((l1231 ))
:extrapreds ((goto_symex___guard_0_0_110 ))
:extrapreds ((l1232 ))
:extrapreds ((l1233 ))
:extrapreds ((l1234 ))
:extrapreds ((l1235 ))
:extrapreds ((l1236 ))
:extrapreds ((l1237 ))
:extrapreds ((goto_symex___guard_0_0_111 ))
:extrapreds ((l1238 ))
:extrapreds ((l1239 ))
:extrapreds ((l1240 ))
:extrapreds ((l1241 ))
:extrapreds ((l1242 ))
:extrapreds ((l1243 ))
:extrapreds ((l1244 ))
:extrapreds ((l1245 ))
:extrapreds ((l1246 ))
:extrapreds ((goto_symex___guard_0_0_112 ))
:extrapreds ((l1247 ))
:extrapreds ((l1248 ))
:extrapreds ((l1249 ))
:extrapreds ((l1250 ))
:extrapreds ((l1251 ))
:extrapreds ((l1252 ))
:extrapreds ((goto_symex___guard_0_0_113 ))
:extrapreds ((l1253 ))
:extrapreds ((l1254 ))
:extrapreds ((l1255 ))
:extrapreds ((l1256 ))
:extrapreds ((l1257 ))
:extrapreds ((l1258 ))
:extrapreds ((goto_symex___guard_0_0_114 ))
:extrapreds ((l1259 ))
:extrapreds ((l1260 ))
:extrapreds ((l1261 ))
:extrapreds ((l1262 ))
:extrapreds ((l1263 ))
:extrapreds ((l1264 ))
:extrapreds ((l1265 ))
:extrapreds ((l1266 ))
:extrapreds ((l1267 ))
:extrapreds ((goto_symex___guard_0_0_115 ))
:extrapreds ((l1268 ))
:extrapreds ((l1269 ))
:extrapreds ((l1270 ))
:extrapreds ((l1271 ))
:extrapreds ((l1272 ))
:extrapreds ((l1273 ))
:extrapreds ((goto_symex___guard_0_0_116 ))
:extrapreds ((l1274 ))
:extrapreds ((l1275 ))
:extrapreds ((l1276 ))
:extrapreds ((l1277 ))
:extrapreds ((l1278 ))
:extrapreds ((l1279 ))
:extrapreds ((goto_symex___guard_0_0_117 ))
:extrapreds ((l1280 ))
:extrapreds ((l1281 ))
:extrapreds ((l1282 ))
:extrapreds ((l1283 ))
:extrapreds ((l1284 ))
:extrapreds ((l1285 ))
:extrapreds ((l1286 ))
:extrapreds ((l1287 ))
:extrapreds ((l1288 ))
:extrapreds ((goto_symex___guard_0_0_118 ))
:extrapreds ((l1289 ))
:extrapreds ((l1290 ))
:extrapreds ((l1291 ))
:extrapreds ((l1292 ))
:extrapreds ((l1293 ))
:extrapreds ((l1294 ))
:extrapreds ((goto_symex___guard_0_0_119 ))
:extrapreds ((l1295 ))
:extrapreds ((l1296 ))
:extrapreds ((l1297 ))
:extrapreds ((l1298 ))
:extrapreds ((l1300 ))
:extrapreds ((l1299 ))
:extrapreds ((l1301 ))
:extrapreds ((goto_symex___guard_0_0_120 ))
:extrapreds ((l1302 ))
:extrapreds ((l1303 ))
:extrapreds ((goto_symex___guard_0_0_121 ))
:extrapreds ((l1304 ))
:extrapreds ((l1305 ))
:extrapreds ((goto_symex___guard_0_0_122 ))
:extrapreds ((l1306 ))
:extrapreds ((l1307 ))
:extrapreds ((l1308 ))
:extrapreds ((l1309 ))
:extrapreds ((l1310 ))
:extrapreds ((goto_symex___guard_0_0_123 ))
:extrapreds ((l1311 ))
:extrapreds ((l1312 ))
:extrapreds ((l1313 ))
:extrapreds ((l1314 ))
:extrapreds ((l1315 ))
:extrapreds ((goto_symex___guard_0_0_124 ))
:extrapreds ((l1316 ))
:extrapreds ((l1317 ))
:extrapreds ((l1318 ))
:extrapreds ((l1319 ))
:extrapreds ((l1320 ))
:extrapreds ((l1321 ))
:extrapreds ((l1322 ))
:extrapreds ((l1323 ))
:extrapreds ((l1324 ))
:extrapreds ((goto_symex___guard_0_0_125 ))
:extrapreds ((l1325 ))
:extrapreds ((l1326 ))
:extrapreds ((l1327 ))
:extrapreds ((l1328 ))
:extrapreds ((l1329 ))
:extrapreds ((l1330 ))
:extrapreds ((l1331 ))
:extrapreds ((goto_symex___guard_0_0_126 ))
:extrapreds ((l1332 ))
:extrapreds ((l1333 ))
:extrapreds ((l1334 ))
:extrapreds ((l1335 ))
:extrapreds ((l1336 ))
:extrapreds ((l1337 ))
:extrapreds ((goto_symex___guard_0_0_127 ))
:extrapreds ((l1338 ))
:extrapreds ((l1339 ))
:extrapreds ((l1340 ))
:extrapreds ((l1341 ))
:extrapreds ((goto_symex___guard_0_0_128 ))
:extrapreds ((l1342 ))
:extrapreds ((l1343 ))
:extrapreds ((l1344 ))
:extrapreds ((l1345 ))
:extrapreds ((l1346 ))
:extrapreds ((l1347 ))
:extrapreds ((goto_symex___guard_0_0_129 ))
:extrapreds ((l1348 ))
:extrapreds ((l1349 ))
:extrapreds ((l1350 ))
:extrapreds ((l1351 ))
:extrapreds ((l1352 ))
:extrapreds ((l1353 ))
:extrapreds ((goto_symex___guard_0_0_130 ))
:extrapreds ((l1354 ))
:extrapreds ((l1355 ))
:extrapreds ((l1356 ))
:extrapreds ((l1357 ))
:extrapreds ((l1358 ))
:extrapreds ((l1359 ))
:extrapreds ((l1360 ))
:extrapreds ((l1361 ))
:extrapreds ((l1362 ))
:extrapreds ((goto_symex___guard_0_0_131 ))
:extrapreds ((l1363 ))
:extrapreds ((l1364 ))
:extrapreds ((l1365 ))
:extrapreds ((l1366 ))
:extrapreds ((l1367 ))
:extrapreds ((l1368 ))
:extrapreds ((goto_symex___guard_0_0_132 ))
:extrapreds ((l1369 ))
:extrapreds ((l1370 ))
:extrapreds ((l1371 ))
:extrapreds ((l1372 ))
:extrapreds ((l1373 ))
:extrapreds ((l1374 ))
:extrapreds ((goto_symex___guard_0_0_133 ))
:extrapreds ((l1375 ))
:extrapreds ((l1376 ))
:extrapreds ((l1377 ))
:extrapreds ((l1378 ))
:extrapreds ((l1379 ))
:extrapreds ((l1380 ))
:extrapreds ((l1381 ))
:extrapreds ((l1382 ))
:extrapreds ((l1383 ))
:extrapreds ((goto_symex___guard_0_0_134 ))
:extrapreds ((l1384 ))
:extrapreds ((l1385 ))
:extrapreds ((l1386 ))
:extrapreds ((l1387 ))
:extrapreds ((l1388 ))
:extrapreds ((l1389 ))
:extrapreds ((goto_symex___guard_0_0_135 ))
:extrapreds ((l1390 ))
:extrapreds ((l1391 ))
:extrapreds ((l1392 ))
:extrapreds ((l1393 ))
:extrapreds ((l1394 ))
:extrapreds ((l1395 ))
:extrapreds ((goto_symex___guard_0_0_136 ))
:extrapreds ((l1396 ))
:extrapreds ((l1397 ))
:extrapreds ((l1398 ))
:extrapreds ((l1399 ))
:extrapreds ((l1400 ))
:extrapreds ((l1401 ))
:extrapreds ((l1402 ))
:extrapreds ((l1403 ))
:extrapreds ((l1404 ))
:extrapreds ((goto_symex___guard_0_0_137 ))
:extrapreds ((l1405 ))
:extrapreds ((l1406 ))
:extrapreds ((l1407 ))
:extrapreds ((l1408 ))
:extrapreds ((l1409 ))
:extrapreds ((l1410 ))
:extrapreds ((goto_symex___guard_0_0_138 ))
:extrapreds ((l1411 ))
:extrapreds ((l1412 ))
:extrapreds ((l1413 ))
:extrapreds ((l1414 ))
:extrapreds ((l1415 ))
:extrapreds ((l1416 ))
:extrapreds ((goto_symex___guard_0_0_139 ))
:extrapreds ((l1417 ))
:extrapreds ((l1418 ))
:extrapreds ((l1419 ))
:extrapreds ((l1420 ))
:extrapreds ((l1421 ))
:extrapreds ((l1422 ))
:extrapreds ((l1423 ))
:extrapreds ((l1424 ))
:extrapreds ((l1425 ))
:extrapreds ((goto_symex___guard_0_0_140 ))
:extrapreds ((l1426 ))
:extrapreds ((l1427 ))
:extrapreds ((l1428 ))
:extrapreds ((l1429 ))
:extrapreds ((l1430 ))
:extrapreds ((l1431 ))
:extrapreds ((goto_symex___guard_0_0_141 ))
:extrapreds ((l1432 ))
:extrapreds ((l1433 ))
:extrapreds ((l1434 ))
:extrapreds ((l1435 ))
:extrapreds ((l1436 ))
:extrapreds ((l1437 ))
:extrapreds ((goto_symex___guard_0_0_142 ))
:extrapreds ((l1438 ))
:extrapreds ((l1439 ))
:extrapreds ((l1440 ))
:extrapreds ((l1441 ))
:extrapreds ((l1442 ))
:extrapreds ((l1443 ))
:extrapreds ((l1444 ))
:extrapreds ((l1445 ))
:extrapreds ((l1446 ))
:extrapreds ((goto_symex___guard_0_0_143 ))
:extrapreds ((l1447 ))
:extrapreds ((l1448 ))
:extrapreds ((l1449 ))
:extrapreds ((l1450 ))
:extrapreds ((l1451 ))
:extrapreds ((l1452 ))
:extrapreds ((goto_symex___guard_0_0_144 ))
:extrapreds ((l1453 ))
:extrapreds ((l1454 ))
:extrapreds ((l1455 ))
:extrapreds ((l1456 ))
:extrapreds ((l1457 ))
:extrapreds ((l1458 ))
:extrapreds ((goto_symex___guard_0_0_145 ))
:extrapreds ((l1459 ))
:extrapreds ((l1460 ))
:extrapreds ((l1461 ))
:extrapreds ((l1462 ))
:extrapreds ((l1463 ))
:extrapreds ((l1464 ))
:extrapreds ((l1465 ))
:extrapreds ((l1466 ))
:extrapreds ((l1467 ))
:extrapreds ((goto_symex___guard_0_0_146 ))
:extrapreds ((l1468 ))
:extrapreds ((l1469 ))
:extrapreds ((l1470 ))
:extrapreds ((l1471 ))
:extrapreds ((l1472 ))
:extrapreds ((l1473 ))
:extrapreds ((goto_symex___guard_0_0_147 ))
:extrapreds ((l1474 ))
:extrapreds ((l1475 ))
:extrapreds ((l1476 ))
:extrapreds ((l1477 ))
:extrapreds ((l1478 ))
:extrapreds ((l1479 ))
:extrapreds ((goto_symex___guard_0_0_148 ))
:extrapreds ((l1480 ))
:extrapreds ((l1481 ))
:extrapreds ((l1482 ))
:extrapreds ((l1483 ))
:extrapreds ((l1484 ))
:extrapreds ((l1485 ))
:extrapreds ((l1486 ))
:extrapreds ((l1487 ))
:extrapreds ((l1488 ))
:extrapreds ((goto_symex___guard_0_0_149 ))
:extrapreds ((l1489 ))
:extrapreds ((l1490 ))
:extrapreds ((l1491 ))
:extrapreds ((l1492 ))
:extrapreds ((l1493 ))
:extrapreds ((l1494 ))
:extrapreds ((goto_symex___guard_0_0_150 ))
:extrapreds ((l1495 ))
:extrapreds ((l1496 ))
:extrapreds ((l1497 ))
:extrapreds ((l1498 ))
:extrapreds ((l1499 ))
:extrapreds ((l1500 ))
:extrapreds ((goto_symex___guard_0_0_151 ))
:extrapreds ((l1501 ))
:extrapreds ((l1502 ))
:extrapreds ((l1503 ))
:extrapreds ((l1504 ))
:extrapreds ((l1505 ))
:extrapreds ((l1506 ))
:extrapreds ((l1507 ))
:extrapreds ((l1508 ))
:extrapreds ((l1509 ))
:extrapreds ((goto_symex___guard_0_0_152 ))
:extrapreds ((l1510 ))
:extrapreds ((l1511 ))
:extrapreds ((l1512 ))
:extrapreds ((l1513 ))
:extrapreds ((l1514 ))
:extrapreds ((l1515 ))
:extrapreds ((goto_symex___guard_0_0_153 ))
:extrapreds ((l1516 ))
:extrapreds ((l1517 ))
:extrapreds ((l1518 ))
:extrapreds ((l1519 ))
:extrapreds ((l1520 ))
:extrapreds ((l1521 ))
:extrapreds ((goto_symex___guard_0_0_154 ))
:extrapreds ((l1522 ))
:extrapreds ((l1523 ))
:extrapreds ((l1524 ))
:extrapreds ((l1525 ))
:extrapreds ((l1526 ))
:extrapreds ((l1527 ))
:extrapreds ((l1528 ))
:extrapreds ((l1529 ))
:extrapreds ((l1530 ))
:extrapreds ((goto_symex___guard_0_0_155 ))
:extrapreds ((l1531 ))
:extrapreds ((l1532 ))
:extrapreds ((l1533 ))
:extrapreds ((l1534 ))
:extrapreds ((l1535 ))
:extrapreds ((l1536 ))
:extrapreds ((goto_symex___guard_0_0_156 ))
:extrapreds ((l1537 ))
:extrapreds ((l1538 ))
:extrapreds ((l1539 ))
:extrapreds ((l1540 ))
:extrapreds ((l1541 ))
:extrapreds ((l1542 ))
:extrapreds ((goto_symex___guard_0_0_157 ))
:extrapreds ((l1543 ))
:extrapreds ((l1544 ))
:extrapreds ((l1545 ))
:extrapreds ((l1546 ))
:extrapreds ((l1547 ))
:extrapreds ((l1548 ))
:extrapreds ((l1549 ))
:extrapreds ((l1550 ))
:extrapreds ((l1551 ))
:extrapreds ((goto_symex___guard_0_0_158 ))
:extrapreds ((l1552 ))
:extrapreds ((l1553 ))
:extrapreds ((l1554 ))
:extrapreds ((l1555 ))
:extrapreds ((l1556 ))
:extrapreds ((l1557 ))
:extrapreds ((goto_symex___guard_0_0_159 ))
:extrapreds ((l1558 ))
:extrapreds ((l1559 ))
:extrapreds ((l1560 ))
:extrapreds ((l1561 ))
:extrapreds ((l1562 ))
:extrapreds ((l1563 ))
:extrapreds ((goto_symex___guard_0_0_160 ))
:extrapreds ((l1564 ))
:extrapreds ((l1565 ))
:extrapreds ((l1566 ))
:extrapreds ((l1567 ))
:extrapreds ((l1568 ))
:extrapreds ((l1569 ))
:extrapreds ((l1570 ))
:extrapreds ((l1571 ))
:extrapreds ((l1572 ))
:extrapreds ((goto_symex___guard_0_0_161 ))
:extrapreds ((l1573 ))
:extrapreds ((l1574 ))
:extrapreds ((l1575 ))
:extrapreds ((l1576 ))
:extrapreds ((l1577 ))
:extrapreds ((l1578 ))
:extrapreds ((goto_symex___guard_0_0_162 ))
:extrapreds ((l1579 ))
:extrapreds ((l1580 ))
:extrapreds ((l1581 ))
:extrapreds ((l1582 ))
:extrapreds ((l1583 ))
:extrapreds ((l1584 ))
:extrapreds ((goto_symex___guard_0_0_163 ))
:extrapreds ((l1585 ))
:extrapreds ((l1586 ))
:extrapreds ((l1587 ))
:extrapreds ((l1588 ))
:extrapreds ((l1589 ))
:extrapreds ((l1590 ))
:extrapreds ((l1591 ))
:extrapreds ((l1592 ))
:extrapreds ((l1593 ))
:extrapreds ((goto_symex___guard_0_0_164 ))
:extrapreds ((l1594 ))
:extrapreds ((l1595 ))
:extrapreds ((l1596 ))
:extrapreds ((l1597 ))
:extrapreds ((l1598 ))
:extrapreds ((l1599 ))
:extrapreds ((goto_symex___guard_0_0_165 ))
:extrapreds ((l1600 ))
:extrapreds ((l1601 ))
:extrapreds ((l1602 ))
:extrapreds ((l1603 ))
:extrapreds ((l1604 ))
:extrapreds ((l1605 ))
:extrapreds ((goto_symex___guard_0_0_166 ))
:extrapreds ((l1606 ))
:extrapreds ((l1607 ))
:extrapreds ((l1608 ))
:extrapreds ((l1609 ))
:extrapreds ((l1610 ))
:extrapreds ((l1611 ))
:extrapreds ((l1612 ))
:extrapreds ((l1613 ))
:extrapreds ((l1614 ))
:extrapreds ((goto_symex___guard_0_0_167 ))
:extrapreds ((l1615 ))
:extrapreds ((l1616 ))
:extrapreds ((l1617 ))
:extrapreds ((l1618 ))
:extrapreds ((l1619 ))
:extrapreds ((l1620 ))
:extrapreds ((goto_symex___guard_0_0_168 ))
:extrapreds ((l1621 ))
:extrapreds ((l1622 ))
:extrapreds ((l1623 ))
:extrapreds ((l1624 ))
:extrapreds ((l1625 ))
:extrapreds ((l1626 ))
:extrapreds ((goto_symex___guard_0_0_169 ))
:extrapreds ((l1627 ))
:extrapreds ((l1628 ))
:extrapreds ((l1629 ))
:extrapreds ((l1630 ))
:extrapreds ((l1631 ))
:extrapreds ((l1632 ))
:extrapreds ((l1633 ))
:extrapreds ((l1634 ))
:extrapreds ((l1635 ))
:extrapreds ((goto_symex___guard_0_0_170 ))
:extrapreds ((l1636 ))
:extrapreds ((l1637 ))
:extrapreds ((l1638 ))
:extrapreds ((l1639 ))
:extrapreds ((l1640 ))
:extrapreds ((l1641 ))
:extrapreds ((goto_symex___guard_0_0_171 ))
:extrapreds ((l1642 ))
:extrapreds ((l1643 ))
:extrapreds ((l1644 ))
:extrapreds ((l1645 ))
:extrapreds ((l1646 ))
:extrapreds ((l1647 ))
:extrapreds ((goto_symex___guard_0_0_172 ))
:extrapreds ((l1648 ))
:extrapreds ((l1649 ))
:extrapreds ((l1650 ))
:extrapreds ((l1651 ))
:extrapreds ((l1652 ))
:extrapreds ((l1653 ))
:extrapreds ((l1654 ))
:extrapreds ((l1655 ))
:extrapreds ((l1656 ))
:extrapreds ((goto_symex___guard_0_0_173 ))
:extrapreds ((l1657 ))
:extrapreds ((l1658 ))
:extrapreds ((l1659 ))
:extrapreds ((l1660 ))
:extrapreds ((l1661 ))
:extrapreds ((l1662 ))
:extrapreds ((goto_symex___guard_0_0_174 ))
:extrapreds ((l1663 ))
:extrapreds ((l1664 ))
:extrapreds ((l1665 ))
:extrapreds ((l1666 ))
:extrapreds ((l1667 ))
:extrapreds ((l1668 ))
:extrapreds ((goto_symex___guard_0_0_175 ))
:extrapreds ((l1669 ))
:extrapreds ((l1670 ))
:extrapreds ((l1671 ))
:extrapreds ((l1672 ))
:extrapreds ((l1673 ))
:extrapreds ((l1674 ))
:extrapreds ((l1675 ))
:extrapreds ((l1676 ))
:extrapreds ((l1677 ))
:extrapreds ((goto_symex___guard_0_0_176 ))
:extrapreds ((l1678 ))
:extrapreds ((l1679 ))
:extrapreds ((l1680 ))
:extrapreds ((l1681 ))
:extrapreds ((l1682 ))
:extrapreds ((l1683 ))
:extrapreds ((goto_symex___guard_0_0_177 ))
:extrapreds ((l1684 ))
:extrapreds ((l1685 ))
:extrapreds ((l1686 ))
:extrapreds ((l1687 ))
:extrapreds ((l1688 ))
:extrapreds ((l1689 ))
:extrapreds ((goto_symex___guard_0_0_178 ))
:extrapreds ((l1690 ))
:extrapreds ((l1691 ))
:extrapreds ((l1692 ))
:extrapreds ((l1693 ))
:extrapreds ((l1694 ))
:extrapreds ((l1695 ))
:extrapreds ((l1696 ))
:extrapreds ((l1697 ))
:extrapreds ((l1698 ))
:extrapreds ((goto_symex___guard_0_0_179 ))
:extrapreds ((l1699 ))
:extrapreds ((l1700 ))
:extrapreds ((l1701 ))
:extrapreds ((l1702 ))
:extrapreds ((l1703 ))
:extrapreds ((l1704 ))
:extrapreds ((goto_symex___guard_0_0_180 ))
:extrapreds ((l1705 ))
:extrapreds ((l1706 ))
:extrapreds ((l1707 ))
:extrapreds ((l1708 ))
:extrapreds ((l1710 ))
:extrapreds ((l1709 ))
:extrapreds ((l1711 ))
:extrapreds ((goto_symex___guard_0_0_181 ))
:extrapreds ((l1712 ))
:extrapreds ((l1713 ))
:extrapreds ((goto_symex___guard_0_0_182 ))
:extrapreds ((l1714 ))
:extrapreds ((l1715 ))
:extrapreds ((goto_symex___guard_0_0_183 ))
:extrapreds ((l1716 ))
:extrapreds ((l1717 ))
:extrapreds ((l1718 ))
:extrapreds ((l1719 ))
:extrapreds ((l1720 ))
:extrapreds ((l1721 ))
:extrapreds ((l1722 ))
:extrapreds ((l1723 ))
:extrapreds ((l1724 ))
:extrapreds ((l1725 ))
:extrapreds ((l1726 ))
:extrapreds ((l1727 ))
:extrapreds ((l1728 ))
:extrapreds ((l1729 ))
:extrapreds ((l1730 ))
:extrapreds ((l1731 ))
:extrapreds ((l1732 ))
:extrapreds ((l1733 ))
:extrapreds ((l1734 ))
:extrapreds ((l1735 ))
:extrapreds ((l1736 ))
:extrapreds ((l1737 ))
:extrapreds ((l1738 ))
:extrapreds ((l1739 ))
:extrapreds ((l1740 ))
:extrapreds ((l1741 ))
:extrapreds ((l1742 ))
:extrapreds ((l1743 ))
:extrapreds ((l1744 ))
:extrapreds ((l1745 ))
:extrapreds ((l1746 ))
:extrapreds ((l1747 ))
:extrapreds ((l1748 ))
:extrapreds ((l1749 ))
:extrapreds ((l1750 ))
:extrapreds ((l1751 ))
:extrapreds ((l1752 ))
:extrapreds ((l1753 ))
:extrapreds ((l1754 ))
:extrapreds ((l1755 ))
:extrapreds ((l1756 ))
:extrapreds ((l1757 ))
:extrapreds ((l1758 ))
:extrapreds ((l1759 ))
:extrapreds ((l1760 ))
:extrapreds ((l1761 ))
:extrapreds ((l1762 ))
:extrapreds ((l1763 ))
:extrapreds ((l1764 ))
:extrapreds ((l1765 ))
:extrapreds ((l1766 ))
:extrapreds ((l1767 ))
:extrapreds ((l1768 ))
:extrapreds ((l1769 ))
:extrapreds ((l1770 ))
:extrapreds ((l1771 ))
:extrapreds ((l1772 ))
:extrapreds ((l1773 ))
:extrapreds ((l1774 ))
:extrapreds ((l1775 ))
:extrapreds ((l1776 ))
:extrapreds ((l1777 ))
:extrapreds ((l1778 ))
:extrapreds ((l1779 ))
:extrapreds ((l1780 ))
:extrapreds ((l1781 ))
:extrapreds ((l1782 ))
:extrapreds ((l1783 ))
:extrapreds ((l1784 ))
:extrapreds ((l1785 ))
:extrapreds ((l1786 ))
:extrapreds ((l1787 ))
:extrapreds ((l1788 ))
:extrapreds ((l1789 ))
:extrapreds ((l1790 ))
:extrapreds ((l1791 ))
:extrapreds ((l1792 ))
:extrapreds ((l1793 ))
:extrapreds ((l1794 ))
:extrapreds ((l1795 ))
:extrapreds ((l1796 ))
:extrapreds ((l1797 ))
:extrapreds ((l1798 ))
:extrapreds ((l1799 ))
:extrapreds ((l1800 ))
:extrapreds ((l1801 ))
:extrapreds ((l1802 ))
:extrapreds ((l1803 ))
:extrapreds ((l1804 ))
:extrapreds ((l1805 ))
:extrapreds ((l1806 ))
:extrapreds ((l1807 ))
:extrapreds ((l1808 ))
:extrapreds ((l1809 ))
:extrapreds ((l1810 ))
:extrapreds ((l1811 ))
:extrapreds ((l1812 ))
:extrapreds ((l1813 ))
:extrapreds ((l1814 ))
:extrapreds ((l1815 ))
:extrapreds ((l1816 ))
:extrapreds ((l1817 ))
:extrapreds ((l1818 ))
:extrapreds ((l1819 ))
:extrapreds ((l1820 ))
:extrapreds ((l1821 ))
:extrapreds ((l1822 ))
:extrapreds ((l1823 ))
:extrapreds ((l1824 ))
:extrapreds ((l1825 ))
:extrapreds ((l1826 ))
:extrapreds ((l1827 ))
:extrapreds ((l1828 ))
:extrapreds ((l1829 ))
:extrapreds ((l1830 ))
:extrapreds ((l1831 ))
:extrapreds ((l1832 ))
:extrapreds ((l1833 ))
:extrapreds ((l1834 ))
:extrapreds ((l1835 ))
:extrapreds ((l1836 ))
:extrapreds ((l1837 ))
:extrapreds ((l1838 ))
:extrapreds ((l1839 ))
:extrapreds ((l1840 ))
:extrapreds ((l1841 ))
:extrapreds ((l1842 ))
:extrapreds ((l1843 ))
:extrapreds ((l1844 ))
:extrapreds ((l1845 ))
:extrapreds ((l1846 ))
:extrapreds ((l1847 ))
:extrapreds ((l1848 ))
:extrapreds ((l1849 ))
:extrapreds ((l1850 ))
:extrapreds ((l1851 ))
:extrapreds ((l1852 ))
:extrapreds ((l1853 ))
:extrapreds ((l1854 ))
:extrapreds ((l1855 ))
:extrapreds ((l1856 ))
:extrapreds ((l1857 ))
:extrapreds ((l1858 ))
:extrapreds ((l1859 ))
:extrapreds ((l1860 ))
:extrapreds ((l1861 ))
:extrapreds ((l1862 ))
:extrapreds ((l1863 ))
:extrapreds ((l1864 ))
:extrapreds ((l1865 ))
:extrapreds ((l1866 ))
:extrapreds ((l1867 ))
:extrapreds ((l1868 ))
:extrapreds ((l1869 ))
:extrapreds ((l1870 ))
:extrapreds ((l1871 ))
:extrapreds ((l1872 ))
:extrapreds ((l1873 ))
:extrapreds ((l1874 ))
:extrapreds ((l1875 ))
:extrapreds ((l1876 ))
:extrapreds ((l1877 ))
:extrapreds ((l1878 ))
:extrapreds ((l1879 ))
:extrapreds ((l1880 ))
:extrapreds ((l1881 ))
:extrapreds ((l1882 ))
:extrapreds ((l1883 ))
:extrapreds ((l1884 ))
:extrapreds ((l1885 ))
:extrapreds ((l1886 ))
:extrapreds ((l1887 ))
:extrapreds ((l1888 ))
:extrapreds ((l1889 ))
:extrapreds ((l1890 ))
:extrapreds ((l1891 ))
:extrapreds ((l1892 ))
:extrapreds ((l1893 ))
:extrapreds ((l1894 ))
:extrapreds ((l1895 ))
:extrapreds ((l1896 ))
:extrapreds ((l1897 ))
:extrapreds ((l1898 ))
:extrapreds ((l1899 ))
:extrapreds ((l1900 ))
:extrapreds ((l1901 ))
:extrapreds ((l1902 ))
:extrapreds ((l1903 ))
:extrapreds ((l1904 ))
:extrapreds ((l1905 ))
:extrapreds ((l1906 ))
:extrapreds ((l1907 ))
:extrapreds ((l1908 ))
:extrapreds ((l1909 ))
:extrapreds ((l1910 ))
:extrapreds ((l1911 ))
:extrapreds ((l1912 ))
:extrapreds ((l1913 ))
:extrapreds ((l1914 ))
:extrapreds ((l1915 ))
:extrapreds ((l1916 ))
:extrapreds ((l1917 ))
:extrapreds ((l1918 ))
:extrapreds ((l1919 ))
:extrapreds ((l1920 ))
:extrapreds ((l1921 ))
:assumption
(flet ($x23 (and l1 l2))
(iff l3 $x23))
:assumption
(flet ($x27 (not l2))
(flet ($x28 (and l1 $x27))
(iff l4 $x28)))
:assumption
(flet ($x27 (not l2))
(flet ($x33 (and l1 $x27 l5))
(iff l6 $x33)))
:assumption
(flet ($x37 (not l5))
(flet ($x27 (not l2))
(flet ($x38 (and l1 $x27 $x37))
(iff l7 $x38))))
:assumption
(flet ($x27 (not l2))
(flet ($x43 (and l1 $x27 l8))
(iff l9 $x43)))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x48 (and l1 $x27 $x47))
(iff l10 $x48))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x53 (and l1 $x27 $x47 l11))
(iff l12 $x53))))
:assumption
(flet ($x57 (not l11))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x58 (and l1 $x27 $x47 $x57))
(iff l13 $x58)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x63 (and l1 $x27 $x47 l14))
(iff l15 $x63))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x68 (and l1 $x27 $x47 l16))
(iff l17 $x68))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x73 (and l1 $x27 $x47 l16 l18))
(iff l19 $x73))))
:assumption
(flet ($x77 (not l18))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x78 (and l1 $x27 $x47 l16 $x77))
(iff l20 $x78)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x83 (and l1 $x27 $x47 l16 l21))
(iff l22 $x83))))
:assumption
(flet ($x87 (not l16))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x88 (and l1 $x27 $x47 $x87))
(iff l23 $x88)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x93 (and l1 $x27 $x47 l24))
(iff l25 $x93))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x98 (and l1 $x27 $x47 l24 l26))
(iff l27 $x98))))
:assumption
(flet ($x102 (not l26))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x103 (and l1 $x27 $x47 l24 $x102))
(iff l28 $x103)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x108 (and l1 $x27 $x47 l24 l29))
(iff l30 $x108))))
:assumption
(flet ($x112 (not l24))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x113 (and l1 $x27 $x47 $x112))
(iff l31 $x113)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x118 (and l1 $x27 $x47 l32))
(iff l33 $x118))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x123 (and l1 $x27 $x47 l32 l34))
(iff l35 $x123))))
:assumption
(flet ($x127 (not l34))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x128 (and l1 $x27 $x47 l32 $x127))
(iff l36 $x128)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x133 (and l1 $x27 $x47 l32 l37))
(iff l38 $x133))))
:assumption
(flet ($x137 (not l32))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x138 (and l1 $x27 $x47 $x137))
(iff l39 $x138)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x143 (and l1 $x27 $x47 l40))
(iff l41 $x143))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x148 (and l1 $x27 $x47 l40 l42))
(iff l43 $x148))))
:assumption
(flet ($x152 (not l42))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x153 (and l1 $x27 $x47 l40 $x152))
(iff l44 $x153)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x158 (and l1 $x27 $x47 l40 l45))
(iff l46 $x158))))
:assumption
(flet ($x162 (not l40))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x163 (and l1 $x27 $x47 $x162))
(iff l47 $x163)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x168 (and l1 $x27 $x47 l48))
(iff l49 $x168))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x173 (and l1 $x27 $x47 l48 l50))
(iff l51 $x173))))
:assumption
(flet ($x177 (not l50))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x178 (and l1 $x27 $x47 l48 $x177))
(iff l52 $x178)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x183 (and l1 $x27 $x47 l48 l53))
(iff l54 $x183))))
:assumption
(flet ($x187 (not l48))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x188 (and l1 $x27 $x47 $x187))
(iff l55 $x188)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x193 (and l1 $x27 $x47 l56))
(iff l57 $x193))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x198 (and l1 $x27 $x47 l56 l58))
(iff l59 $x198))))
:assumption
(flet ($x202 (not l58))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x203 (and l1 $x27 $x47 l56 $x202))
(iff l60 $x203)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x208 (and l1 $x27 $x47 l56 l61))
(iff l62 $x208))))
:assumption
(flet ($x212 (not l56))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x213 (and l1 $x27 $x47 $x212))
(iff l63 $x213)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x218 (and l1 $x27 $x47 l64))
(iff l65 $x218))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x223 (and l1 $x27 $x47 l64 l66))
(iff l67 $x223))))
:assumption
(flet ($x227 (not l66))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x228 (and l1 $x27 $x47 l64 $x227))
(iff l68 $x228)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x233 (and l1 $x27 $x47 l64 l69))
(iff l70 $x233))))
:assumption
(flet ($x237 (not l64))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x238 (and l1 $x27 $x47 $x237))
(iff l71 $x238)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x243 (and l1 $x27 $x47 l72))
(iff l73 $x243))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x248 (and l1 $x27 $x47 l72 l74))
(iff l75 $x248))))
:assumption
(flet ($x252 (not l74))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x253 (and l1 $x27 $x47 l72 $x252))
(iff l76 $x253)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x258 (and l1 $x27 $x47 l72 l77))
(iff l78 $x258))))
:assumption
(flet ($x262 (not l72))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x263 (and l1 $x27 $x47 $x262))
(iff l79 $x263)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x268 (and l1 $x27 $x47 l80))
(iff l81 $x268))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x273 (and l1 $x27 $x47 l80 l82))
(iff l83 $x273))))
:assumption
(flet ($x277 (not l82))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x278 (and l1 $x27 $x47 l80 $x277))
(iff l84 $x278)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x283 (and l1 $x27 $x47 l80 l85))
(iff l86 $x283))))
:assumption
(flet ($x287 (not l80))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x288 (and l1 $x27 $x47 $x287))
(iff l87 $x288)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x293 (and l1 $x27 $x47 l88))
(iff l89 $x293))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x298 (and l1 $x27 $x47 l88 l90))
(iff l91 $x298))))
:assumption
(flet ($x302 (not l90))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x303 (and l1 $x27 $x47 l88 $x302))
(iff l92 $x303)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x308 (and l1 $x27 $x47 l88 l93))
(iff l94 $x308))))
:assumption
(flet ($x312 (not l88))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x313 (and l1 $x27 $x47 $x312))
(iff l95 $x313)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x318 (and l1 $x27 $x47 l96))
(iff l97 $x318))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x323 (and l1 $x27 $x47 l96 l98))
(iff l99 $x323))))
:assumption
(flet ($x327 (not l98))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x328 (and l1 $x27 $x47 l96 $x327))
(iff l100 $x328)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x333 (and l1 $x27 $x47 l96 l101))
(iff l102 $x333))))
:assumption
(flet ($x337 (not l96))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x338 (and l1 $x27 $x47 $x337))
(iff l103 $x338)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x343 (and l1 $x27 $x47 l104))
(iff l105 $x343))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x348 (and l1 $x27 $x47 l104 l106))
(iff l107 $x348))))
:assumption
(flet ($x352 (not l106))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x353 (and l1 $x27 $x47 l104 $x352))
(iff l108 $x353)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x358 (and l1 $x27 $x47 l104 l109))
(iff l110 $x358))))
:assumption
(flet ($x362 (not l104))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x363 (and l1 $x27 $x47 $x362))
(iff l111 $x363)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x368 (and l1 $x27 $x47 l112))
(iff l113 $x368))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x373 (and l1 $x27 $x47 l112 l114))
(iff l115 $x373))))
:assumption
(flet ($x377 (not l114))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x378 (and l1 $x27 $x47 l112 $x377))
(iff l116 $x378)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x383 (and l1 $x27 $x47 l112 l117))
(iff l118 $x383))))
:assumption
(flet ($x387 (not l112))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x388 (and l1 $x27 $x47 $x387))
(iff l119 $x388)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x393 (and l1 $x27 $x47 l120))
(iff l121 $x393))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x398 (and l1 $x27 $x47 l120 l122))
(iff l123 $x398))))
:assumption
(flet ($x402 (not l122))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x403 (and l1 $x27 $x47 l120 $x402))
(iff l124 $x403)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x408 (and l1 $x27 $x47 l120 l125))
(iff l126 $x408))))
:assumption
(flet ($x412 (not l120))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x413 (and l1 $x27 $x47 $x412))
(iff l127 $x413)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x418 (and l1 $x27 $x47 l128))
(iff l129 $x418))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x423 (and l1 $x27 $x47 l128 l130))
(iff l131 $x423))))
:assumption
(flet ($x427 (not l130))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x428 (and l1 $x27 $x47 l128 $x427))
(iff l132 $x428)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x433 (and l1 $x27 $x47 l128 l133))
(iff l134 $x433))))
:assumption
(flet ($x437 (not l128))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x438 (and l1 $x27 $x47 $x437))
(iff l135 $x438)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x443 (and l1 $x27 $x47 l136))
(iff l137 $x443))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x448 (and l1 $x27 $x47 l136 l138))
(iff l139 $x448))))
:assumption
(flet ($x452 (not l138))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x453 (and l1 $x27 $x47 l136 $x452))
(iff l140 $x453)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x458 (and l1 $x27 $x47 l136 l141))
(iff l142 $x458))))
:assumption
(flet ($x462 (not l136))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x463 (and l1 $x27 $x47 $x462))
(iff l143 $x463)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x468 (and l1 $x27 $x47 l144))
(iff l145 $x468))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x473 (and l1 $x27 $x47 l144 l146))
(iff l147 $x473))))
:assumption
(flet ($x477 (not l146))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x478 (and l1 $x27 $x47 l144 $x477))
(iff l148 $x478)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x483 (and l1 $x27 $x47 l144 l149))
(iff l150 $x483))))
:assumption
(flet ($x487 (not l144))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x488 (and l1 $x27 $x47 $x487))
(iff l151 $x488)))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x493 (and l1 $x27 $x47 l152))
(iff l153 $x493))))
:assumption
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x498 (and l1 $x27 $x47 l152 l154))
(iff l155 $x498))))
:assumption
(flet ($x502 (not l154))
(flet ($x47 (not l8))
(flet ($x27 (not l2))
(flet ($x503 (and l1 $x27 $x47 l152 $x502))
(iff l156 $x503)))))
:assumption
(flet ($x27 (not l2))
(flet ($x508 (and l1 $x27 l157))
(iff l158 $x508)))
:assumption
(flet ($x512 (not l157))
(flet ($x27 (not l2))
(flet ($x513 (and l1 $x27 $x512))
(iff l159 $x513))))
:assumption
(flet ($x512 (not l157))
(flet ($x27 (not l2))
(flet ($x518 (and l1 $x27 $x512 l160))
(iff l161 $x518))))
:assumption
(flet ($x522 (not l160))
(flet ($x512 (not l157))
(flet ($x27 (not l2))
(flet ($x523 (and l1 $x27 $x512 $x522))
(iff l162 $x523)))))
:assumption
(flet ($x528 (and l1 l163))
(iff l164 $x528))
:assumption
(flet ($x532 (not l163))
(flet ($x533 (and l1 $x532))
(iff l165 $x533)))
:assumption
(flet ($x532 (not l163))
(flet ($x538 (and l1 $x532 l166))
(iff l167 $x538)))
:assumption
(flet ($x542 (not l166))
(flet ($x532 (not l163))
(flet ($x543 (and l1 $x532 $x542))
(iff l168 $x543))))
:assumption
(flet ($x532 (not l163))
(flet ($x548 (and l1 $x532 l169))
(iff l170 $x548)))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x553 (and l1 $x532 $x552))
(iff l171 $x553))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x558 (and l1 $x532 $x552 l172))
(iff l173 $x558))))
:assumption
(flet ($x562 (not l172))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x563 (and l1 $x532 $x552 $x562))
(iff l174 $x563)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x568 (and l1 $x532 $x552 l175))
(iff l176 $x568))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x573 (and l1 $x532 $x552 l177))
(iff l178 $x573))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x578 (and l1 $x532 $x552 l177 l179))
(iff l180 $x578))))
:assumption
(flet ($x582 (not l179))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x583 (and l1 $x532 $x552 l177 $x582))
(iff l181 $x583)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x588 (and l1 $x532 $x552 l177 l182))
(iff l183 $x588))))
:assumption
(flet ($x592 (not l177))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x593 (and l1 $x532 $x552 $x592))
(iff l184 $x593)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x598 (and l1 $x532 $x552 l185))
(iff l186 $x598))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x603 (and l1 $x532 $x552 l185 l187))
(iff l188 $x603))))
:assumption
(flet ($x607 (not l187))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x608 (and l1 $x532 $x552 l185 $x607))
(iff l189 $x608)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x613 (and l1 $x532 $x552 l185 l190))
(iff l191 $x613))))
:assumption
(flet ($x617 (not l185))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x618 (and l1 $x532 $x552 $x617))
(iff l192 $x618)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x623 (and l1 $x532 $x552 l193))
(iff l194 $x623))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x628 (and l1 $x532 $x552 l193 l195))
(iff l196 $x628))))
:assumption
(flet ($x632 (not l195))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x633 (and l1 $x532 $x552 l193 $x632))
(iff l197 $x633)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x638 (and l1 $x532 $x552 l193 l198))
(iff l199 $x638))))
:assumption
(flet ($x642 (not l193))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x643 (and l1 $x532 $x552 $x642))
(iff l200 $x643)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x648 (and l1 $x532 $x552 l201))
(iff l202 $x648))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x653 (and l1 $x532 $x552 l201 l203))
(iff l204 $x653))))
:assumption
(flet ($x657 (not l203))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x658 (and l1 $x532 $x552 l201 $x657))
(iff l205 $x658)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x663 (and l1 $x532 $x552 l201 l206))
(iff l207 $x663))))
:assumption
(flet ($x667 (not l201))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x668 (and l1 $x532 $x552 $x667))
(iff l208 $x668)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x673 (and l1 $x532 $x552 l209))
(iff l210 $x673))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x678 (and l1 $x532 $x552 l209 l211))
(iff l212 $x678))))
:assumption
(flet ($x682 (not l211))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x683 (and l1 $x532 $x552 l209 $x682))
(iff l213 $x683)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x688 (and l1 $x532 $x552 l209 l214))
(iff l215 $x688))))
:assumption
(flet ($x692 (not l209))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x693 (and l1 $x532 $x552 $x692))
(iff l216 $x693)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x698 (and l1 $x532 $x552 l217))
(iff l218 $x698))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x703 (and l1 $x532 $x552 l217 l219))
(iff l220 $x703))))
:assumption
(flet ($x707 (not l219))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x708 (and l1 $x532 $x552 l217 $x707))
(iff l221 $x708)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x713 (and l1 $x532 $x552 l217 l222))
(iff l223 $x713))))
:assumption
(flet ($x717 (not l217))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x718 (and l1 $x532 $x552 $x717))
(iff l224 $x718)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x723 (and l1 $x532 $x552 l225))
(iff l226 $x723))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x728 (and l1 $x532 $x552 l225 l227))
(iff l228 $x728))))
:assumption
(flet ($x732 (not l227))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x733 (and l1 $x532 $x552 l225 $x732))
(iff l229 $x733)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x738 (and l1 $x532 $x552 l225 l230))
(iff l231 $x738))))
:assumption
(flet ($x742 (not l225))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x743 (and l1 $x532 $x552 $x742))
(iff l232 $x743)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x748 (and l1 $x532 $x552 l233))
(iff l234 $x748))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x753 (and l1 $x532 $x552 l233 l235))
(iff l236 $x753))))
:assumption
(flet ($x757 (not l235))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x758 (and l1 $x532 $x552 l233 $x757))
(iff l237 $x758)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x763 (and l1 $x532 $x552 l233 l238))
(iff l239 $x763))))
:assumption
(flet ($x767 (not l233))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x768 (and l1 $x532 $x552 $x767))
(iff l240 $x768)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x773 (and l1 $x532 $x552 l241))
(iff l242 $x773))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x778 (and l1 $x532 $x552 l241 l243))
(iff l244 $x778))))
:assumption
(flet ($x782 (not l243))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x783 (and l1 $x532 $x552 l241 $x782))
(iff l245 $x783)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x788 (and l1 $x532 $x552 l241 l246))
(iff l247 $x788))))
:assumption
(flet ($x792 (not l241))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x793 (and l1 $x532 $x552 $x792))
(iff l248 $x793)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x798 (and l1 $x532 $x552 l249))
(iff l250 $x798))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x803 (and l1 $x532 $x552 l249 l251))
(iff l252 $x803))))
:assumption
(flet ($x807 (not l251))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x808 (and l1 $x532 $x552 l249 $x807))
(iff l253 $x808)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x813 (and l1 $x532 $x552 l249 l254))
(iff l255 $x813))))
:assumption
(flet ($x817 (not l249))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x818 (and l1 $x532 $x552 $x817))
(iff l256 $x818)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x823 (and l1 $x532 $x552 l257))
(iff l258 $x823))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x828 (and l1 $x532 $x552 l257 l259))
(iff l260 $x828))))
:assumption
(flet ($x832 (not l259))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x833 (and l1 $x532 $x552 l257 $x832))
(iff l261 $x833)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x838 (and l1 $x532 $x552 l257 l262))
(iff l263 $x838))))
:assumption
(flet ($x842 (not l257))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x843 (and l1 $x532 $x552 $x842))
(iff l264 $x843)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x848 (and l1 $x532 $x552 l265))
(iff l266 $x848))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x853 (and l1 $x532 $x552 l265 l267))
(iff l268 $x853))))
:assumption
(flet ($x857 (not l267))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x858 (and l1 $x532 $x552 l265 $x857))
(iff l269 $x858)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x863 (and l1 $x532 $x552 l265 l270))
(iff l271 $x863))))
:assumption
(flet ($x867 (not l265))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x868 (and l1 $x532 $x552 $x867))
(iff l272 $x868)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x873 (and l1 $x532 $x552 l273))
(iff l274 $x873))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x878 (and l1 $x532 $x552 l273 l275))
(iff l276 $x878))))
:assumption
(flet ($x882 (not l275))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x883 (and l1 $x532 $x552 l273 $x882))
(iff l277 $x883)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x888 (and l1 $x532 $x552 l273 l278))
(iff l279 $x888))))
:assumption
(flet ($x892 (not l273))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x893 (and l1 $x532 $x552 $x892))
(iff l280 $x893)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x898 (and l1 $x532 $x552 l281))
(iff l282 $x898))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x903 (and l1 $x532 $x552 l281 l283))
(iff l284 $x903))))
:assumption
(flet ($x907 (not l283))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x908 (and l1 $x532 $x552 l281 $x907))
(iff l285 $x908)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x913 (and l1 $x532 $x552 l281 l286))
(iff l287 $x913))))
:assumption
(flet ($x917 (not l281))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x918 (and l1 $x532 $x552 $x917))
(iff l288 $x918)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x923 (and l1 $x532 $x552 l289))
(iff l290 $x923))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x928 (and l1 $x532 $x552 l289 l291))
(iff l292 $x928))))
:assumption
(flet ($x932 (not l291))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x933 (and l1 $x532 $x552 l289 $x932))
(iff l293 $x933)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x938 (and l1 $x532 $x552 l289 l294))
(iff l295 $x938))))
:assumption
(flet ($x942 (not l289))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x943 (and l1 $x532 $x552 $x942))
(iff l296 $x943)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x948 (and l1 $x532 $x552 l297))
(iff l298 $x948))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x953 (and l1 $x532 $x552 l297 l299))
(iff l300 $x953))))
:assumption
(flet ($x957 (not l299))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x958 (and l1 $x532 $x552 l297 $x957))
(iff l301 $x958)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x963 (and l1 $x532 $x552 l297 l302))
(iff l303 $x963))))
:assumption
(flet ($x967 (not l297))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x968 (and l1 $x532 $x552 $x967))
(iff l304 $x968)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x973 (and l1 $x532 $x552 l305))
(iff l306 $x973))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x978 (and l1 $x532 $x552 l305 l307))
(iff l308 $x978))))
:assumption
(flet ($x982 (not l307))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x983 (and l1 $x532 $x552 l305 $x982))
(iff l309 $x983)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x988 (and l1 $x532 $x552 l305 l310))
(iff l311 $x988))))
:assumption
(flet ($x992 (not l305))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x993 (and l1 $x532 $x552 $x992))
(iff l312 $x993)))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x998 (and l1 $x532 $x552 l313))
(iff l314 $x998))))
:assumption
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x1003 (and l1 $x532 $x552 l313 l315))
(iff l316 $x1003))))
:assumption
(flet ($x1007 (not l315))
(flet ($x552 (not l169))
(flet ($x532 (not l163))
(flet ($x1008 (and l1 $x532 $x552 l313 $x1007))
(iff l317 $x1008)))))
:assumption
(flet ($x532 (not l163))
(flet ($x1013 (and l1 $x532 l318))
(iff l319 $x1013)))
:assumption
(flet ($x1017 (not l318))
(flet ($x532 (not l163))
(flet ($x1018 (and l1 $x532 $x1017))
(iff l320 $x1018))))
:assumption
(flet ($x1017 (not l318))
(flet ($x532 (not l163))
(flet ($x1023 (and l1 $x532 $x1017 l321))
(iff l322 $x1023))))
:assumption
(flet ($x1027 (not l321))
(flet ($x1017 (not l318))
(flet ($x532 (not l163))
(flet ($x1028 (and l1 $x532 $x1017 $x1027))
(iff l323 $x1028)))))
:assumption
(flet ($x1033 (and l1 l324))
(iff l325 $x1033))
:assumption
(flet ($x1037 (not l324))
(flet ($x1038 (and l1 $x1037))
(iff l326 $x1038)))
:assumption
(flet ($x1037 (not l324))
(flet ($x1043 (and l1 $x1037 l327))
(iff l328 $x1043)))
:assumption
(flet ($x1047 (not l327))
(flet ($x1037 (not l324))
(flet ($x1048 (and l1 $x1037 $x1047))
(iff l329 $x1048))))
:assumption
(flet ($x1037 (not l324))
(flet ($x1053 (and l1 $x1037 l330))
(iff l331 $x1053)))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1058 (and l1 $x1037 $x1057))
(iff l332 $x1058))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1063 (and l1 $x1037 $x1057 l333))
(iff l334 $x1063))))
:assumption
(flet ($x1067 (not l333))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1068 (and l1 $x1037 $x1057 $x1067))
(iff l335 $x1068)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1073 (and l1 $x1037 $x1057 l336))
(iff l337 $x1073))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1078 (and l1 $x1037 $x1057 l338))
(iff l339 $x1078))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1083 (and l1 $x1037 $x1057 l338 l340))
(iff l341 $x1083))))
:assumption
(flet ($x1087 (not l340))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1088 (and l1 $x1037 $x1057 l338 $x1087))
(iff l342 $x1088)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1093 (and l1 $x1037 $x1057 l338 l343))
(iff l344 $x1093))))
:assumption
(flet ($x1097 (not l338))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1098 (and l1 $x1037 $x1057 $x1097))
(iff l345 $x1098)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1103 (and l1 $x1037 $x1057 l346))
(iff l347 $x1103))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1108 (and l1 $x1037 $x1057 l346 l348))
(iff l349 $x1108))))
:assumption
(flet ($x1112 (not l348))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1113 (and l1 $x1037 $x1057 l346 $x1112))
(iff l350 $x1113)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1118 (and l1 $x1037 $x1057 l346 l351))
(iff l352 $x1118))))
:assumption
(flet ($x1122 (not l346))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1123 (and l1 $x1037 $x1057 $x1122))
(iff l353 $x1123)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1128 (and l1 $x1037 $x1057 l354))
(iff l355 $x1128))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1133 (and l1 $x1037 $x1057 l354 l356))
(iff l357 $x1133))))
:assumption
(flet ($x1137 (not l356))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1138 (and l1 $x1037 $x1057 l354 $x1137))
(iff l358 $x1138)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1143 (and l1 $x1037 $x1057 l354 l359))
(iff l360 $x1143))))
:assumption
(flet ($x1147 (not l354))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1148 (and l1 $x1037 $x1057 $x1147))
(iff l361 $x1148)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1153 (and l1 $x1037 $x1057 l362))
(iff l363 $x1153))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1158 (and l1 $x1037 $x1057 l362 l364))
(iff l365 $x1158))))
:assumption
(flet ($x1162 (not l364))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1163 (and l1 $x1037 $x1057 l362 $x1162))
(iff l366 $x1163)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1168 (and l1 $x1037 $x1057 l362 l367))
(iff l368 $x1168))))
:assumption
(flet ($x1172 (not l362))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1173 (and l1 $x1037 $x1057 $x1172))
(iff l369 $x1173)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1178 (and l1 $x1037 $x1057 l370))
(iff l371 $x1178))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1183 (and l1 $x1037 $x1057 l370 l372))
(iff l373 $x1183))))
:assumption
(flet ($x1187 (not l372))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1188 (and l1 $x1037 $x1057 l370 $x1187))
(iff l374 $x1188)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1193 (and l1 $x1037 $x1057 l370 l375))
(iff l376 $x1193))))
:assumption
(flet ($x1197 (not l370))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1198 (and l1 $x1037 $x1057 $x1197))
(iff l377 $x1198)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1203 (and l1 $x1037 $x1057 l378))
(iff l379 $x1203))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1208 (and l1 $x1037 $x1057 l378 l380))
(iff l381 $x1208))))
:assumption
(flet ($x1212 (not l380))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1213 (and l1 $x1037 $x1057 l378 $x1212))
(iff l382 $x1213)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1218 (and l1 $x1037 $x1057 l378 l383))
(iff l384 $x1218))))
:assumption
(flet ($x1222 (not l378))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1223 (and l1 $x1037 $x1057 $x1222))
(iff l385 $x1223)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1228 (and l1 $x1037 $x1057 l386))
(iff l387 $x1228))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1233 (and l1 $x1037 $x1057 l386 l388))
(iff l389 $x1233))))
:assumption
(flet ($x1237 (not l388))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1238 (and l1 $x1037 $x1057 l386 $x1237))
(iff l390 $x1238)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1243 (and l1 $x1037 $x1057 l386 l391))
(iff l392 $x1243))))
:assumption
(flet ($x1247 (not l386))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1248 (and l1 $x1037 $x1057 $x1247))
(iff l393 $x1248)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1253 (and l1 $x1037 $x1057 l394))
(iff l395 $x1253))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1258 (and l1 $x1037 $x1057 l394 l396))
(iff l397 $x1258))))
:assumption
(flet ($x1262 (not l396))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1263 (and l1 $x1037 $x1057 l394 $x1262))
(iff l398 $x1263)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1268 (and l1 $x1037 $x1057 l394 l399))
(iff l400 $x1268))))
:assumption
(flet ($x1272 (not l394))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1273 (and l1 $x1037 $x1057 $x1272))
(iff l401 $x1273)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1278 (and l1 $x1037 $x1057 l402))
(iff l403 $x1278))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1283 (and l1 $x1037 $x1057 l402 l404))
(iff l405 $x1283))))
:assumption
(flet ($x1287 (not l404))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1288 (and l1 $x1037 $x1057 l402 $x1287))
(iff l406 $x1288)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1293 (and l1 $x1037 $x1057 l402 l407))
(iff l408 $x1293))))
:assumption
(flet ($x1297 (not l402))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1298 (and l1 $x1037 $x1057 $x1297))
(iff l409 $x1298)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1303 (and l1 $x1037 $x1057 l410))
(iff l411 $x1303))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1308 (and l1 $x1037 $x1057 l410 l412))
(iff l413 $x1308))))
:assumption
(flet ($x1312 (not l412))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1313 (and l1 $x1037 $x1057 l410 $x1312))
(iff l414 $x1313)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1318 (and l1 $x1037 $x1057 l410 l415))
(iff l416 $x1318))))
:assumption
(flet ($x1322 (not l410))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1323 (and l1 $x1037 $x1057 $x1322))
(iff l417 $x1323)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1328 (and l1 $x1037 $x1057 l418))
(iff l419 $x1328))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1333 (and l1 $x1037 $x1057 l418 l420))
(iff l421 $x1333))))
:assumption
(flet ($x1337 (not l420))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1338 (and l1 $x1037 $x1057 l418 $x1337))
(iff l422 $x1338)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1343 (and l1 $x1037 $x1057 l418 l423))
(iff l424 $x1343))))
:assumption
(flet ($x1347 (not l418))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1348 (and l1 $x1037 $x1057 $x1347))
(iff l425 $x1348)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1353 (and l1 $x1037 $x1057 l426))
(iff l427 $x1353))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1358 (and l1 $x1037 $x1057 l426 l428))
(iff l429 $x1358))))
:assumption
(flet ($x1362 (not l428))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1363 (and l1 $x1037 $x1057 l426 $x1362))
(iff l430 $x1363)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1368 (and l1 $x1037 $x1057 l426 l431))
(iff l432 $x1368))))
:assumption
(flet ($x1372 (not l426))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1373 (and l1 $x1037 $x1057 $x1372))
(iff l433 $x1373)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1378 (and l1 $x1037 $x1057 l434))
(iff l435 $x1378))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1383 (and l1 $x1037 $x1057 l434 l436))
(iff l437 $x1383))))
:assumption
(flet ($x1387 (not l436))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1388 (and l1 $x1037 $x1057 l434 $x1387))
(iff l438 $x1388)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1393 (and l1 $x1037 $x1057 l434 l439))
(iff l440 $x1393))))
:assumption
(flet ($x1397 (not l434))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1398 (and l1 $x1037 $x1057 $x1397))
(iff l441 $x1398)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1403 (and l1 $x1037 $x1057 l442))
(iff l443 $x1403))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1408 (and l1 $x1037 $x1057 l442 l444))
(iff l445 $x1408))))
:assumption
(flet ($x1412 (not l444))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1413 (and l1 $x1037 $x1057 l442 $x1412))
(iff l446 $x1413)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1418 (and l1 $x1037 $x1057 l442 l447))
(iff l448 $x1418))))
:assumption
(flet ($x1422 (not l442))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1423 (and l1 $x1037 $x1057 $x1422))
(iff l449 $x1423)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1428 (and l1 $x1037 $x1057 l450))
(iff l451 $x1428))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1433 (and l1 $x1037 $x1057 l450 l452))
(iff l453 $x1433))))
:assumption
(flet ($x1437 (not l452))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1438 (and l1 $x1037 $x1057 l450 $x1437))
(iff l454 $x1438)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1443 (and l1 $x1037 $x1057 l450 l455))
(iff l456 $x1443))))
:assumption
(flet ($x1447 (not l450))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1448 (and l1 $x1037 $x1057 $x1447))
(iff l457 $x1448)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1453 (and l1 $x1037 $x1057 l458))
(iff l459 $x1453))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1458 (and l1 $x1037 $x1057 l458 l460))
(iff l461 $x1458))))
:assumption
(flet ($x1462 (not l460))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1463 (and l1 $x1037 $x1057 l458 $x1462))
(iff l462 $x1463)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1468 (and l1 $x1037 $x1057 l458 l463))
(iff l464 $x1468))))
:assumption
(flet ($x1472 (not l458))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1473 (and l1 $x1037 $x1057 $x1472))
(iff l465 $x1473)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1478 (and l1 $x1037 $x1057 l466))
(iff l467 $x1478))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1483 (and l1 $x1037 $x1057 l466 l468))
(iff l469 $x1483))))
:assumption
(flet ($x1487 (not l468))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1488 (and l1 $x1037 $x1057 l466 $x1487))
(iff l470 $x1488)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1493 (and l1 $x1037 $x1057 l466 l471))
(iff l472 $x1493))))
:assumption
(flet ($x1497 (not l466))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1498 (and l1 $x1037 $x1057 $x1497))
(iff l473 $x1498)))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1503 (and l1 $x1037 $x1057 l474))
(iff l475 $x1503))))
:assumption
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1508 (and l1 $x1037 $x1057 l474 l476))
(iff l477 $x1508))))
:assumption
(flet ($x1512 (not l476))
(flet ($x1057 (not l330))
(flet ($x1037 (not l324))
(flet ($x1513 (and l1 $x1037 $x1057 l474 $x1512))
(iff l478 $x1513)))))
:assumption
(flet ($x1037 (not l324))
(flet ($x1518 (and l1 $x1037 l479))
(iff l480 $x1518)))
:assumption
(flet ($x1522 (not l479))
(flet ($x1037 (not l324))
(flet ($x1523 (and l1 $x1037 $x1522))
(iff l481 $x1523))))
:assumption
(flet ($x1522 (not l479))
(flet ($x1037 (not l324))
(flet ($x1528 (and l1 $x1037 $x1522 l482))
(iff l483 $x1528))))
:assumption
(flet ($x1532 (not l482))
(flet ($x1522 (not l479))
(flet ($x1037 (not l324))
(flet ($x1533 (and l1 $x1037 $x1522 $x1532))
(iff l484 $x1533)))))
:assumption
l1
:assumption
(= execution_statet___guard_exec_0_0_0_0_1 true)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1544 (store ported_type_for_mod__ bv0[32] ?x1542))
(let (?x1546 (store ?x1544 bv1[32] ?x1542))
(let (?x1548 (store ?x1546 bv2[32] ?x1542))
(flet ($x1549 (= c__a_0_1 ?x1548))
(iff l485 $x1549))))))
:assumption
l485
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1544 (store ported_type_for_mod__ bv0[32] ?x1542))
(let (?x1546 (store ?x1544 bv1[32] ?x1542))
(let (?x1548 (store ?x1546 bv2[32] ?x1542))
(= c__a_0_1 ?x1548)))))
:assumption
(let (?x1560 (store c__a_0_1 bv0[32] nondet_symex__nondet0))
(flet ($x1561 (= c__a_0_2 ?x1560))
(iff l486 $x1561)))
:assumption
l486
:assumption
(let (?x1560 (store c__a_0_1 bv0[32] nondet_symex__nondet0))
(= c__a_0_2 ?x1560))
:assumption
(let (?x1567 (store c__a_0_2 bv1[32] nondet_symex__nondet1))
(flet ($x1568 (= c__a_0_3 ?x1567))
(iff l487 $x1568)))
:assumption
l487
:assumption
(let (?x1567 (store c__a_0_2 bv1[32] nondet_symex__nondet1))
(= c__a_0_3 ?x1567))
:assumption
(let (?x1574 (store c__a_0_3 bv2[32] nondet_symex__nondet2))
(flet ($x1575 (= c__a_0_4 ?x1574))
(iff l488 $x1575)))
:assumption
l488
:assumption
(let (?x1574 (store c__a_0_3 bv2[32] nondet_symex__nondet2))
(= c__a_0_4 ?x1574))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1579 (select c__a_0_4 bv0[32]))
(flet ($x1580 (= ?x1579 ?x1542))
(iff l489 $x1580))))
:assumption
(flet ($x1585 (xor l2 l489))
(iff l490 $x1585))
:assumption
(not l490)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1579 (select c__a_0_4 bv0[32]))
(flet ($x1580 (= ?x1579 ?x1542))
(= goto_symex___guard_0_0_1 $x1580))))
:assumption
(let (?x1606 (select c__a_0_4 bv2[32]))
(let (?x1607 (sign_extend[32] ?x1606))
(let (?x1579 (select c__a_0_4 bv0[32]))
(let (?x1602 (sign_extend[32] ?x1579))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x1603 (bvmul ?x1601 ?x1602))
(let (?x1604 (extract[95:32] ?x1603))
(let (?x1605 (sign_extend[32] ?x1604))
(let (?x1608 (bvmul ?x1605 ?x1607))
(let (?x1609 (extract[95:32] ?x1608))
(let (?x1611 (bvmul bv18446744073709551615[64] ?x1609))
(let (?x1595 (select c__a_0_4 bv1[32]))
(let (?x1596 (sign_extend[32] ?x1595))
(let (?x1597 (bvmul ?x1596 ?x1596))
(let (?x1598 (extract[95:32] ?x1597))
(let (?x1612 (bvadd ?x1598 ?x1611))
(flet ($x1613 (= c__qurt_new__qurt__1__d_1_0_0_1 ?x1612))
(iff l491 $x1613)))))))))))))))))))
:assumption
l491
:assumption
(let (?x1606 (select c__a_0_4 bv2[32]))
(let (?x1607 (sign_extend[32] ?x1606))
(let (?x1579 (select c__a_0_4 bv0[32]))
(let (?x1602 (sign_extend[32] ?x1579))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x1603 (bvmul ?x1601 ?x1602))
(let (?x1604 (extract[95:32] ?x1603))
(let (?x1605 (sign_extend[32] ?x1604))
(let (?x1608 (bvmul ?x1605 ?x1607))
(let (?x1609 (extract[95:32] ?x1608))
(let (?x1611 (bvmul bv18446744073709551615[64] ?x1609))
(let (?x1595 (select c__a_0_4 bv1[32]))
(let (?x1596 (sign_extend[32] ?x1595))
(let (?x1597 (bvmul ?x1596 ?x1596))
(let (?x1598 (extract[95:32] ?x1597))
(let (?x1612 (bvadd ?x1598 ?x1611))
(= c__qurt_new__qurt__1__d_1_0_0_1 ?x1612))))))))))))))))))
:assumption
(let (?x1579 (select c__a_0_4 bv0[32]))
(let (?x1602 (sign_extend[32] ?x1579))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1630 (bvmul ?x1629 ?x1602))
(let (?x1631 (extract[95:32] ?x1630))
(flet ($x1632 (= c__qurt_new__qurt__1__w1_1_0_0_1 ?x1631))
(iff l492 $x1632))))))))
:assumption
l492
:assumption
(let (?x1579 (select c__a_0_4 bv0[32]))
(let (?x1602 (sign_extend[32] ?x1579))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1630 (bvmul ?x1629 ?x1602))
(let (?x1631 (extract[95:32] ?x1630))
(= c__qurt_new__qurt__1__w1_1_0_0_1 ?x1631)))))))
:assumption
(flet ($x1642 (= c__qurt_new__fabs__n_1_0_0_1 c__qurt_new__qurt__1__d_1_0_0_1))
(iff l493 $x1642))
:assumption
l493
:assumption
(= c__qurt_new__fabs__n_1_0_0_1 c__qurt_new__qurt__1__d_1_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1647 (bvsge c__qurt_new__fabs__n_1_0_0_1 ?x1542))
(iff l494 $x1647)))
:assumption
(flet ($x1654 (xor l5 l494))
(iff l495 $x1654))
:assumption
(not l495)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1647 (bvsge c__qurt_new__fabs__n_1_0_0_1 ?x1542))
(= goto_symex___guard_0_0_2 $x1647)))
:assumption
(flet ($x1665 (= c__qurt_new__fabs__1__f_1_0_0_1 c__qurt_new__fabs__n_1_0_0_1))
(iff l496 $x1665))
:assumption
l496
:assumption
(= c__qurt_new__fabs__1__f_1_0_0_1 c__qurt_new__fabs__n_1_0_0_1)
:assumption
(let (?x1671 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_1_0_0_1))
(flet ($x1672 (= c__qurt_new__fabs__1__f_1_0_0_3 ?x1671))
(iff l497 $x1672)))
:assumption
l497
:assumption
(let (?x1671 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_1_0_0_1))
(= c__qurt_new__fabs__1__f_1_0_0_3 ?x1671))
:assumption
(let (?x1677 (ite goto_symex___guard_0_0_2 c__qurt_new__fabs__1__f_1_0_0_1 c__qurt_new__fabs__1__f_1_0_0_3))
(flet ($x1678 (= c__qurt_new__fabs__1__f_1_0_0_4 ?x1677))
(iff l498 $x1678)))
:assumption
l498
:assumption
(let (?x1677 (ite goto_symex___guard_0_0_2 c__qurt_new__fabs__1__f_1_0_0_1 c__qurt_new__fabs__1__f_1_0_0_3))
(= c__qurt_new__fabs__1__f_1_0_0_4 ?x1677))
:assumption
(flet ($x1683 (= c__qurt___tmp__return_value_fabs_1_1_0_0_1 c__qurt_new__fabs__1__f_1_0_0_4))
(iff l499 $x1683))
:assumption
l499
:assumption
(= c__qurt___tmp__return_value_fabs_1_1_0_0_1 c__qurt_new__fabs__1__f_1_0_0_4)
:assumption
(flet ($x1689 (= c__qurt_new__sqrt__val_1_0_0_1 c__qurt___tmp__return_value_fabs_1_1_0_0_1))
(iff l500 $x1689))
:assumption
l500
:assumption
(= c__qurt_new__sqrt__val_1_0_0_1 c__qurt___tmp__return_value_fabs_1_1_0_0_1)
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x1698 (concat c__qurt_new__sqrt__val_1_0_0_1 bv0[32]))
(let (?x1699 (bvsdiv ?x1698 ?x1697))
(let (?x1700 (extract[63:0] ?x1699))
(flet ($x1701 (= c__qurt_new__sqrt__1__x_1_0_0_1 ?x1700))
(iff l501 $x1701)))))))
:assumption
l501
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x1698 (concat c__qurt_new__sqrt__val_1_0_0_1 bv0[32]))
(let (?x1699 (bvsdiv ?x1698 ?x1697))
(let (?x1700 (extract[63:0] ?x1699))
(= c__qurt_new__sqrt__1__x_1_0_0_1 ?x1700))))))
:assumption
(flet ($x1711 (= c__qurt_new__sqrt__1__flag_1_0_0_1 bv0[32]))
(iff l502 $x1711))
:assumption
l502
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_1 bv0[32])
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1716 (= c__qurt_new__sqrt__val_1_0_0_1 ?x1542))
(iff l503 $x1716)))
:assumption
(flet ($x1721 (xor l8 l503))
(iff l504 $x1721))
:assumption
(not l504)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1716 (= c__qurt_new__sqrt__val_1_0_0_1 ?x1542))
(= goto_symex___guard_0_0_3 $x1716)))
:assumption
(flet ($x1731 (= c__qurt_new__sqrt__1__x_1_0_0_3 c__qurt_new__sqrt__1__x_1_0_0_1))
(iff l505 $x1731))
:assumption
l505
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_3 c__qurt_new__sqrt__1__x_1_0_0_1)
:assumption
(let (?x1737 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1742 (bvmul ?x1629 ?x1737))
(let (?x1743 (extract[95:32] ?x1742))
(let (?x1744 (sign_extend[32] ?x1743))
(let (?x1738 (bvmul ?x1737 ?x1737))
(let (?x1739 (extract[95:32] ?x1738))
(let (?x1740 (bvmul bv18446744073709551615[64] ?x1739))
(let (?x1741 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1740))
(let (?x1745 (concat ?x1741 bv0[32]))
(let (?x1746 (bvsdiv ?x1745 ?x1744))
(let (?x1747 (extract[63:0] ?x1746))
(flet ($x1748 (= c__qurt_new__sqrt__1__dx_1_0_0_1 ?x1747))
(iff l506 $x1748)))))))))))))))
:assumption
l506
:assumption
(let (?x1737 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1742 (bvmul ?x1629 ?x1737))
(let (?x1743 (extract[95:32] ?x1742))
(let (?x1744 (sign_extend[32] ?x1743))
(let (?x1738 (bvmul ?x1737 ?x1737))
(let (?x1739 (extract[95:32] ?x1738))
(let (?x1740 (bvmul bv18446744073709551615[64] ?x1739))
(let (?x1741 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1740))
(let (?x1745 (concat ?x1741 bv0[32]))
(let (?x1746 (bvsdiv ?x1745 ?x1744))
(let (?x1747 (extract[63:0] ?x1746))
(= c__qurt_new__sqrt__1__dx_1_0_0_1 ?x1747))))))))))))))
:assumption
(let (?x1765 (bvadd c__qurt_new__sqrt__1__x_1_0_0_3 c__qurt_new__sqrt__1__dx_1_0_0_1))
(flet ($x1766 (= c__qurt_new__sqrt__1__x_1_0_0_4 ?x1765))
(iff l507 $x1766)))
:assumption
l507
:assumption
(let (?x1765 (bvadd c__qurt_new__sqrt__1__x_1_0_0_3 c__qurt_new__sqrt__1__dx_1_0_0_1))
(= c__qurt_new__sqrt__1__x_1_0_0_4 ?x1765))
:assumption
(let (?x1771 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_4))
(let (?x1772 (bvmul ?x1771 ?x1771))
(let (?x1773 (extract[95:32] ?x1772))
(let (?x1774 (bvmul bv18446744073709551615[64] ?x1773))
(let (?x1775 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1774))
(flet ($x1776 (= c__qurt_new__sqrt__1__diff_1_0_0_1 ?x1775))
(iff l508 $x1776)))))))
:assumption
l508
:assumption
(let (?x1771 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_4))
(let (?x1772 (bvmul ?x1771 ?x1771))
(let (?x1773 (extract[95:32] ?x1772))
(let (?x1774 (bvmul bv18446744073709551615[64] ?x1773))
(let (?x1775 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1774))
(= c__qurt_new__sqrt__1__diff_1_0_0_1 ?x1775))))))
:assumption
(flet ($x1781 (= c__qurt_new__fabs__n_2_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_1))
(iff l509 $x1781))
:assumption
l509
:assumption
(= c__qurt_new__fabs__n_2_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1786 (bvsge c__qurt_new__fabs__n_2_0_0_1 ?x1542))
(iff l510 $x1786)))
:assumption
(flet ($x1793 (xor l11 l510))
(iff l511 $x1793))
:assumption
(not l511)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1786 (bvsge c__qurt_new__fabs__n_2_0_0_1 ?x1542))
(= goto_symex___guard_0_0_4 $x1786)))
:assumption
(flet ($x1804 (= c__qurt_new__fabs__1__f_2_0_0_1 c__qurt_new__fabs__n_2_0_0_1))
(iff l512 $x1804))
:assumption
l512
:assumption
(= c__qurt_new__fabs__1__f_2_0_0_1 c__qurt_new__fabs__n_2_0_0_1)
:assumption
(let (?x1810 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_2_0_0_1))
(flet ($x1811 (= c__qurt_new__fabs__1__f_2_0_0_3 ?x1810))
(iff l513 $x1811)))
:assumption
l513
:assumption
(let (?x1810 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_2_0_0_1))
(= c__qurt_new__fabs__1__f_2_0_0_3 ?x1810))
:assumption
(let (?x1816 (ite goto_symex___guard_0_0_4 c__qurt_new__fabs__1__f_2_0_0_1 c__qurt_new__fabs__1__f_2_0_0_3))
(flet ($x1817 (= c__qurt_new__fabs__1__f_2_0_0_4 ?x1816))
(iff l514 $x1817)))
:assumption
l514
:assumption
(let (?x1816 (ite goto_symex___guard_0_0_4 c__qurt_new__fabs__1__f_2_0_0_1 c__qurt_new__fabs__1__f_2_0_0_3))
(= c__qurt_new__fabs__1__f_2_0_0_4 ?x1816))
:assumption
(flet ($x1822 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_1 c__qurt_new__fabs__1__f_2_0_0_4))
(iff l515 $x1822))
:assumption
l515
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_1 c__qurt_new__fabs__1__f_2_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x1829 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_1 ?x1828))
(iff l516 $x1829)))
:assumption
(flet ($x1835 (xor l14 l516))
(iff l517 $x1835))
:assumption
(not l517)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x1829 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_1 ?x1828))
(= goto_symex___guard_0_0_5 $x1829)))
:assumption
(flet ($x1846 (= c__qurt_new__sqrt__1__flag_1_0_0_2 bv1[32]))
(iff l518 $x1846))
:assumption
l518
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_2 bv1[32])
:assumption
(flet ($x1852 (not goto_symex___guard_0_0_5))
(let (?x1853 (ite $x1852 c__qurt_new__sqrt__1__flag_1_0_0_1 c__qurt_new__sqrt__1__flag_1_0_0_2))
(flet ($x1854 (= c__qurt_new__sqrt__1__flag_1_0_0_3 ?x1853))
(iff l519 $x1854))))
:assumption
l519
:assumption
(flet ($x1852 (not goto_symex___guard_0_0_5))
(let (?x1853 (ite $x1852 c__qurt_new__sqrt__1__flag_1_0_0_1 c__qurt_new__sqrt__1__flag_1_0_0_2))
(= c__qurt_new__sqrt__1__flag_1_0_0_3 ?x1853)))
:assumption
(flet ($x1860 (= c__qurt_new__sqrt__1__flag_1_0_0_3 bv0[32]))
(iff l520 $x1860))
:assumption
(flet ($x1865 (xor l16 l520))
(iff l521 $x1865))
:assumption
(not l521)
:assumption
(flet ($x1860 (= c__qurt_new__sqrt__1__flag_1_0_0_3 bv0[32]))
(= goto_symex___guard_0_0_6 $x1860))
:assumption
(let (?x1771 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1875 (bvmul ?x1629 ?x1771))
(let (?x1876 (extract[95:32] ?x1875))
(let (?x1877 (sign_extend[32] ?x1876))
(let (?x1772 (bvmul ?x1771 ?x1771))
(let (?x1773 (extract[95:32] ?x1772))
(let (?x1774 (bvmul bv18446744073709551615[64] ?x1773))
(let (?x1775 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1774))
(let (?x1878 (concat ?x1775 bv0[32]))
(let (?x1879 (bvsdiv ?x1878 ?x1877))
(let (?x1880 (extract[63:0] ?x1879))
(flet ($x1881 (= c__qurt_new__sqrt__1__dx_1_0_0_2 ?x1880))
(iff l522 $x1881)))))))))))))))
:assumption
l522
:assumption
(let (?x1771 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1875 (bvmul ?x1629 ?x1771))
(let (?x1876 (extract[95:32] ?x1875))
(let (?x1877 (sign_extend[32] ?x1876))
(let (?x1772 (bvmul ?x1771 ?x1771))
(let (?x1773 (extract[95:32] ?x1772))
(let (?x1774 (bvmul bv18446744073709551615[64] ?x1773))
(let (?x1775 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1774))
(let (?x1878 (concat ?x1775 bv0[32]))
(let (?x1879 (bvsdiv ?x1878 ?x1877))
(let (?x1880 (extract[63:0] ?x1879))
(= c__qurt_new__sqrt__1__dx_1_0_0_2 ?x1880))))))))))))))
:assumption
(let (?x1901 (bvadd c__qurt_new__sqrt__1__x_1_0_0_4 c__qurt_new__sqrt__1__dx_1_0_0_2))
(flet ($x1902 (= c__qurt_new__sqrt__1__x_1_0_0_5 ?x1901))
(iff l523 $x1902)))
:assumption
l523
:assumption
(let (?x1901 (bvadd c__qurt_new__sqrt__1__x_1_0_0_4 c__qurt_new__sqrt__1__dx_1_0_0_2))
(= c__qurt_new__sqrt__1__x_1_0_0_5 ?x1901))
:assumption
(let (?x1907 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_5))
(let (?x1908 (bvmul ?x1907 ?x1907))
(let (?x1909 (extract[95:32] ?x1908))
(let (?x1910 (bvmul bv18446744073709551615[64] ?x1909))
(let (?x1911 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1910))
(flet ($x1912 (= c__qurt_new__sqrt__1__diff_1_0_0_2 ?x1911))
(iff l524 $x1912)))))))
:assumption
l524
:assumption
(let (?x1907 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_5))
(let (?x1908 (bvmul ?x1907 ?x1907))
(let (?x1909 (extract[95:32] ?x1908))
(let (?x1910 (bvmul bv18446744073709551615[64] ?x1909))
(let (?x1911 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x1910))
(= c__qurt_new__sqrt__1__diff_1_0_0_2 ?x1911))))))
:assumption
(flet ($x1917 (= c__qurt_new__fabs__n_3_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_2))
(iff l525 $x1917))
:assumption
l525
:assumption
(= c__qurt_new__fabs__n_3_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_2)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1922 (bvsge c__qurt_new__fabs__n_3_0_0_1 ?x1542))
(iff l526 $x1922)))
:assumption
(flet ($x1929 (xor l18 l526))
(iff l527 $x1929))
:assumption
(not l527)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x1922 (bvsge c__qurt_new__fabs__n_3_0_0_1 ?x1542))
(= goto_symex___guard_0_0_7 $x1922)))
:assumption
(flet ($x1940 (= c__qurt_new__fabs__1__f_3_0_0_1 c__qurt_new__fabs__n_3_0_0_1))
(iff l528 $x1940))
:assumption
l528
:assumption
(= c__qurt_new__fabs__1__f_3_0_0_1 c__qurt_new__fabs__n_3_0_0_1)
:assumption
(let (?x1946 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_3_0_0_1))
(flet ($x1947 (= c__qurt_new__fabs__1__f_3_0_0_3 ?x1946))
(iff l529 $x1947)))
:assumption
l529
:assumption
(let (?x1946 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_3_0_0_1))
(= c__qurt_new__fabs__1__f_3_0_0_3 ?x1946))
:assumption
(let (?x1952 (ite goto_symex___guard_0_0_7 c__qurt_new__fabs__1__f_3_0_0_1 c__qurt_new__fabs__1__f_3_0_0_3))
(flet ($x1953 (= c__qurt_new__fabs__1__f_3_0_0_4 ?x1952))
(iff l530 $x1953)))
:assumption
l530
:assumption
(let (?x1952 (ite goto_symex___guard_0_0_7 c__qurt_new__fabs__1__f_3_0_0_1 c__qurt_new__fabs__1__f_3_0_0_3))
(= c__qurt_new__fabs__1__f_3_0_0_4 ?x1952))
:assumption
(flet ($x1958 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_2 c__qurt_new__fabs__1__f_3_0_0_4))
(iff l531 $x1958))
:assumption
l531
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_2 c__qurt_new__fabs__1__f_3_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x1963 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_2 ?x1828))
(iff l532 $x1963)))
:assumption
(flet ($x1968 (xor l21 l532))
(iff l533 $x1968))
:assumption
(not l533)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x1963 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_2 ?x1828))
(= goto_symex___guard_0_0_8 $x1963)))
:assumption
(flet ($x1979 (= c__qurt_new__sqrt__1__flag_1_0_0_4 bv1[32]))
(iff l534 $x1979))
:assumption
l534
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_4 bv1[32])
:assumption
(flet ($x1985 (not goto_symex___guard_0_0_8))
(let (?x1986 (ite $x1985 c__qurt_new__sqrt__1__flag_1_0_0_3 c__qurt_new__sqrt__1__flag_1_0_0_4))
(flet ($x1987 (= c__qurt_new__sqrt__1__flag_1_0_0_5 ?x1986))
(iff l535 $x1987))))
:assumption
l535
:assumption
(flet ($x1985 (not goto_symex___guard_0_0_8))
(let (?x1986 (ite $x1985 c__qurt_new__sqrt__1__flag_1_0_0_3 c__qurt_new__sqrt__1__flag_1_0_0_4))
(= c__qurt_new__sqrt__1__flag_1_0_0_5 ?x1986)))
:assumption
(flet ($x1994 (= c__qurt_new__sqrt__1__x_1_0_0_6 c__qurt_new__sqrt__1__x_1_0_0_4))
(iff l536 $x1994))
:assumption
l536
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_6 c__qurt_new__sqrt__1__x_1_0_0_4)
:assumption
(flet ($x2000 (= c__qurt_new__sqrt__1__flag_1_0_0_6 c__qurt_new__sqrt__1__flag_1_0_0_3))
(iff l537 $x2000))
:assumption
l537
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_6 c__qurt_new__sqrt__1__flag_1_0_0_3)
:assumption
(flet ($x2006 (= c__qurt_new__sqrt__1__x_1_0_0_7 c__qurt_new__sqrt__1__x_1_0_0_6))
(iff l538 $x2006))
:assumption
l538
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_7 c__qurt_new__sqrt__1__x_1_0_0_6)
:assumption
(let (?x2012 (ite goto_symex___guard_0_0_6 c__qurt_new__sqrt__1__x_1_0_0_5 c__qurt_new__sqrt__1__x_1_0_0_7))
(flet ($x2013 (= c__qurt_new__sqrt__1__x_1_0_0_8 ?x2012))
(iff l539 $x2013)))
:assumption
l539
:assumption
(let (?x2012 (ite goto_symex___guard_0_0_6 c__qurt_new__sqrt__1__x_1_0_0_5 c__qurt_new__sqrt__1__x_1_0_0_7))
(= c__qurt_new__sqrt__1__x_1_0_0_8 ?x2012))
:assumption
(let (?x2018 (ite goto_symex___guard_0_0_6 c__qurt_new__sqrt__1__flag_1_0_0_5 c__qurt_new__sqrt__1__flag_1_0_0_6))
(flet ($x2019 (= c__qurt_new__sqrt__1__flag_1_0_0_7 ?x2018))
(iff l540 $x2019)))
:assumption
l540
:assumption
(let (?x2018 (ite goto_symex___guard_0_0_6 c__qurt_new__sqrt__1__flag_1_0_0_5 c__qurt_new__sqrt__1__flag_1_0_0_6))
(= c__qurt_new__sqrt__1__flag_1_0_0_7 ?x2018))
:assumption
(flet ($x2023 (= c__qurt_new__sqrt__1__flag_1_0_0_7 bv0[32]))
(iff l541 $x2023))
:assumption
(flet ($x2028 (xor l24 l541))
(iff l542 $x2028))
:assumption
(not l542)
:assumption
(flet ($x2023 (= c__qurt_new__sqrt__1__flag_1_0_0_7 bv0[32]))
(= goto_symex___guard_0_0_9 $x2023))
:assumption
(let (?x2038 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2043 (bvmul ?x1629 ?x2038))
(let (?x2044 (extract[95:32] ?x2043))
(let (?x2045 (sign_extend[32] ?x2044))
(let (?x2039 (bvmul ?x2038 ?x2038))
(let (?x2040 (extract[95:32] ?x2039))
(let (?x2041 (bvmul bv18446744073709551615[64] ?x2040))
(let (?x2042 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2041))
(let (?x2046 (concat ?x2042 bv0[32]))
(let (?x2047 (bvsdiv ?x2046 ?x2045))
(let (?x2048 (extract[63:0] ?x2047))
(flet ($x2049 (= c__qurt_new__sqrt__1__dx_1_0_0_5 ?x2048))
(iff l543 $x2049)))))))))))))))
:assumption
l543
:assumption
(let (?x2038 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2043 (bvmul ?x1629 ?x2038))
(let (?x2044 (extract[95:32] ?x2043))
(let (?x2045 (sign_extend[32] ?x2044))
(let (?x2039 (bvmul ?x2038 ?x2038))
(let (?x2040 (extract[95:32] ?x2039))
(let (?x2041 (bvmul bv18446744073709551615[64] ?x2040))
(let (?x2042 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2041))
(let (?x2046 (concat ?x2042 bv0[32]))
(let (?x2047 (bvsdiv ?x2046 ?x2045))
(let (?x2048 (extract[63:0] ?x2047))
(= c__qurt_new__sqrt__1__dx_1_0_0_5 ?x2048))))))))))))))
:assumption
(let (?x2069 (bvadd c__qurt_new__sqrt__1__x_1_0_0_8 c__qurt_new__sqrt__1__dx_1_0_0_5))
(flet ($x2070 (= c__qurt_new__sqrt__1__x_1_0_0_9 ?x2069))
(iff l544 $x2070)))
:assumption
l544
:assumption
(let (?x2069 (bvadd c__qurt_new__sqrt__1__x_1_0_0_8 c__qurt_new__sqrt__1__dx_1_0_0_5))
(= c__qurt_new__sqrt__1__x_1_0_0_9 ?x2069))
:assumption
(let (?x2075 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_9))
(let (?x2076 (bvmul ?x2075 ?x2075))
(let (?x2077 (extract[95:32] ?x2076))
(let (?x2078 (bvmul bv18446744073709551615[64] ?x2077))
(let (?x2079 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2078))
(flet ($x2080 (= c__qurt_new__sqrt__1__diff_1_0_0_5 ?x2079))
(iff l545 $x2080)))))))
:assumption
l545
:assumption
(let (?x2075 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_9))
(let (?x2076 (bvmul ?x2075 ?x2075))
(let (?x2077 (extract[95:32] ?x2076))
(let (?x2078 (bvmul bv18446744073709551615[64] ?x2077))
(let (?x2079 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2078))
(= c__qurt_new__sqrt__1__diff_1_0_0_5 ?x2079))))))
:assumption
(flet ($x2085 (= c__qurt_new__fabs__n_4_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_5))
(iff l546 $x2085))
:assumption
l546
:assumption
(= c__qurt_new__fabs__n_4_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_5)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2090 (bvsge c__qurt_new__fabs__n_4_0_0_1 ?x1542))
(iff l547 $x2090)))
:assumption
(flet ($x2097 (xor l26 l547))
(iff l548 $x2097))
:assumption
(not l548)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2090 (bvsge c__qurt_new__fabs__n_4_0_0_1 ?x1542))
(= goto_symex___guard_0_0_10 $x2090)))
:assumption
(flet ($x2108 (= c__qurt_new__fabs__1__f_4_0_0_1 c__qurt_new__fabs__n_4_0_0_1))
(iff l549 $x2108))
:assumption
l549
:assumption
(= c__qurt_new__fabs__1__f_4_0_0_1 c__qurt_new__fabs__n_4_0_0_1)
:assumption
(let (?x2114 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_4_0_0_1))
(flet ($x2115 (= c__qurt_new__fabs__1__f_4_0_0_3 ?x2114))
(iff l550 $x2115)))
:assumption
l550
:assumption
(let (?x2114 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_4_0_0_1))
(= c__qurt_new__fabs__1__f_4_0_0_3 ?x2114))
:assumption
(let (?x2120 (ite goto_symex___guard_0_0_10 c__qurt_new__fabs__1__f_4_0_0_1 c__qurt_new__fabs__1__f_4_0_0_3))
(flet ($x2121 (= c__qurt_new__fabs__1__f_4_0_0_4 ?x2120))
(iff l551 $x2121)))
:assumption
l551
:assumption
(let (?x2120 (ite goto_symex___guard_0_0_10 c__qurt_new__fabs__1__f_4_0_0_1 c__qurt_new__fabs__1__f_4_0_0_3))
(= c__qurt_new__fabs__1__f_4_0_0_4 ?x2120))
:assumption
(flet ($x2126 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_5 c__qurt_new__fabs__1__f_4_0_0_4))
(iff l552 $x2126))
:assumption
l552
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_5 c__qurt_new__fabs__1__f_4_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2131 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_5 ?x1828))
(iff l553 $x2131)))
:assumption
(flet ($x2136 (xor l29 l553))
(iff l554 $x2136))
:assumption
(not l554)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2131 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_5 ?x1828))
(= goto_symex___guard_0_0_11 $x2131)))
:assumption
(flet ($x2147 (= c__qurt_new__sqrt__1__flag_1_0_0_8 bv1[32]))
(iff l555 $x2147))
:assumption
l555
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_8 bv1[32])
:assumption
(flet ($x2153 (not goto_symex___guard_0_0_11))
(let (?x2154 (ite $x2153 c__qurt_new__sqrt__1__flag_1_0_0_7 c__qurt_new__sqrt__1__flag_1_0_0_8))
(flet ($x2155 (= c__qurt_new__sqrt__1__flag_1_0_0_9 ?x2154))
(iff l556 $x2155))))
:assumption
l556
:assumption
(flet ($x2153 (not goto_symex___guard_0_0_11))
(let (?x2154 (ite $x2153 c__qurt_new__sqrt__1__flag_1_0_0_7 c__qurt_new__sqrt__1__flag_1_0_0_8))
(= c__qurt_new__sqrt__1__flag_1_0_0_9 ?x2154)))
:assumption
(flet ($x2162 (= c__qurt_new__sqrt__1__x_1_0_0_10 c__qurt_new__sqrt__1__x_1_0_0_8))
(iff l557 $x2162))
:assumption
l557
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_10 c__qurt_new__sqrt__1__x_1_0_0_8)
:assumption
(flet ($x2168 (= c__qurt_new__sqrt__1__flag_1_0_0_10 c__qurt_new__sqrt__1__flag_1_0_0_7))
(iff l558 $x2168))
:assumption
l558
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_10 c__qurt_new__sqrt__1__flag_1_0_0_7)
:assumption
(flet ($x2174 (= c__qurt_new__sqrt__1__x_1_0_0_11 c__qurt_new__sqrt__1__x_1_0_0_10))
(iff l559 $x2174))
:assumption
l559
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_11 c__qurt_new__sqrt__1__x_1_0_0_10)
:assumption
(let (?x2180 (ite goto_symex___guard_0_0_9 c__qurt_new__sqrt__1__x_1_0_0_9 c__qurt_new__sqrt__1__x_1_0_0_11))
(flet ($x2181 (= c__qurt_new__sqrt__1__x_1_0_0_12 ?x2180))
(iff l560 $x2181)))
:assumption
l560
:assumption
(let (?x2180 (ite goto_symex___guard_0_0_9 c__qurt_new__sqrt__1__x_1_0_0_9 c__qurt_new__sqrt__1__x_1_0_0_11))
(= c__qurt_new__sqrt__1__x_1_0_0_12 ?x2180))
:assumption
(let (?x2186 (ite goto_symex___guard_0_0_9 c__qurt_new__sqrt__1__flag_1_0_0_9 c__qurt_new__sqrt__1__flag_1_0_0_10))
(flet ($x2187 (= c__qurt_new__sqrt__1__flag_1_0_0_11 ?x2186))
(iff l561 $x2187)))
:assumption
l561
:assumption
(let (?x2186 (ite goto_symex___guard_0_0_9 c__qurt_new__sqrt__1__flag_1_0_0_9 c__qurt_new__sqrt__1__flag_1_0_0_10))
(= c__qurt_new__sqrt__1__flag_1_0_0_11 ?x2186))
:assumption
(flet ($x2191 (= c__qurt_new__sqrt__1__flag_1_0_0_11 bv0[32]))
(iff l562 $x2191))
:assumption
(flet ($x2196 (xor l32 l562))
(iff l563 $x2196))
:assumption
(not l563)
:assumption
(flet ($x2191 (= c__qurt_new__sqrt__1__flag_1_0_0_11 bv0[32]))
(= goto_symex___guard_0_0_12 $x2191))
:assumption
(let (?x2206 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2211 (bvmul ?x1629 ?x2206))
(let (?x2212 (extract[95:32] ?x2211))
(let (?x2213 (sign_extend[32] ?x2212))
(let (?x2207 (bvmul ?x2206 ?x2206))
(let (?x2208 (extract[95:32] ?x2207))
(let (?x2209 (bvmul bv18446744073709551615[64] ?x2208))
(let (?x2210 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2209))
(let (?x2214 (concat ?x2210 bv0[32]))
(let (?x2215 (bvsdiv ?x2214 ?x2213))
(let (?x2216 (extract[63:0] ?x2215))
(flet ($x2217 (= c__qurt_new__sqrt__1__dx_1_0_0_8 ?x2216))
(iff l564 $x2217)))))))))))))))
:assumption
l564
:assumption
(let (?x2206 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2211 (bvmul ?x1629 ?x2206))
(let (?x2212 (extract[95:32] ?x2211))
(let (?x2213 (sign_extend[32] ?x2212))
(let (?x2207 (bvmul ?x2206 ?x2206))
(let (?x2208 (extract[95:32] ?x2207))
(let (?x2209 (bvmul bv18446744073709551615[64] ?x2208))
(let (?x2210 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2209))
(let (?x2214 (concat ?x2210 bv0[32]))
(let (?x2215 (bvsdiv ?x2214 ?x2213))
(let (?x2216 (extract[63:0] ?x2215))
(= c__qurt_new__sqrt__1__dx_1_0_0_8 ?x2216))))))))))))))
:assumption
(let (?x2237 (bvadd c__qurt_new__sqrt__1__x_1_0_0_12 c__qurt_new__sqrt__1__dx_1_0_0_8))
(flet ($x2238 (= c__qurt_new__sqrt__1__x_1_0_0_13 ?x2237))
(iff l565 $x2238)))
:assumption
l565
:assumption
(let (?x2237 (bvadd c__qurt_new__sqrt__1__x_1_0_0_12 c__qurt_new__sqrt__1__dx_1_0_0_8))
(= c__qurt_new__sqrt__1__x_1_0_0_13 ?x2237))
:assumption
(let (?x2243 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_13))
(let (?x2244 (bvmul ?x2243 ?x2243))
(let (?x2245 (extract[95:32] ?x2244))
(let (?x2246 (bvmul bv18446744073709551615[64] ?x2245))
(let (?x2247 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2246))
(flet ($x2248 (= c__qurt_new__sqrt__1__diff_1_0_0_8 ?x2247))
(iff l566 $x2248)))))))
:assumption
l566
:assumption
(let (?x2243 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_13))
(let (?x2244 (bvmul ?x2243 ?x2243))
(let (?x2245 (extract[95:32] ?x2244))
(let (?x2246 (bvmul bv18446744073709551615[64] ?x2245))
(let (?x2247 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2246))
(= c__qurt_new__sqrt__1__diff_1_0_0_8 ?x2247))))))
:assumption
(flet ($x2253 (= c__qurt_new__fabs__n_5_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_8))
(iff l567 $x2253))
:assumption
l567
:assumption
(= c__qurt_new__fabs__n_5_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_8)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2258 (bvsge c__qurt_new__fabs__n_5_0_0_1 ?x1542))
(iff l568 $x2258)))
:assumption
(flet ($x2265 (xor l34 l568))
(iff l569 $x2265))
:assumption
(not l569)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2258 (bvsge c__qurt_new__fabs__n_5_0_0_1 ?x1542))
(= goto_symex___guard_0_0_13 $x2258)))
:assumption
(flet ($x2276 (= c__qurt_new__fabs__1__f_5_0_0_1 c__qurt_new__fabs__n_5_0_0_1))
(iff l570 $x2276))
:assumption
l570
:assumption
(= c__qurt_new__fabs__1__f_5_0_0_1 c__qurt_new__fabs__n_5_0_0_1)
:assumption
(let (?x2282 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_5_0_0_1))
(flet ($x2283 (= c__qurt_new__fabs__1__f_5_0_0_3 ?x2282))
(iff l571 $x2283)))
:assumption
l571
:assumption
(let (?x2282 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_5_0_0_1))
(= c__qurt_new__fabs__1__f_5_0_0_3 ?x2282))
:assumption
(let (?x2288 (ite goto_symex___guard_0_0_13 c__qurt_new__fabs__1__f_5_0_0_1 c__qurt_new__fabs__1__f_5_0_0_3))
(flet ($x2289 (= c__qurt_new__fabs__1__f_5_0_0_4 ?x2288))
(iff l572 $x2289)))
:assumption
l572
:assumption
(let (?x2288 (ite goto_symex___guard_0_0_13 c__qurt_new__fabs__1__f_5_0_0_1 c__qurt_new__fabs__1__f_5_0_0_3))
(= c__qurt_new__fabs__1__f_5_0_0_4 ?x2288))
:assumption
(flet ($x2294 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_8 c__qurt_new__fabs__1__f_5_0_0_4))
(iff l573 $x2294))
:assumption
l573
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_8 c__qurt_new__fabs__1__f_5_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2299 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_8 ?x1828))
(iff l574 $x2299)))
:assumption
(flet ($x2304 (xor l37 l574))
(iff l575 $x2304))
:assumption
(not l575)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2299 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_8 ?x1828))
(= goto_symex___guard_0_0_14 $x2299)))
:assumption
(flet ($x2315 (= c__qurt_new__sqrt__1__flag_1_0_0_12 bv1[32]))
(iff l576 $x2315))
:assumption
l576
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_12 bv1[32])
:assumption
(flet ($x2321 (not goto_symex___guard_0_0_14))
(let (?x2322 (ite $x2321 c__qurt_new__sqrt__1__flag_1_0_0_11 c__qurt_new__sqrt__1__flag_1_0_0_12))
(flet ($x2323 (= c__qurt_new__sqrt__1__flag_1_0_0_13 ?x2322))
(iff l577 $x2323))))
:assumption
l577
:assumption
(flet ($x2321 (not goto_symex___guard_0_0_14))
(let (?x2322 (ite $x2321 c__qurt_new__sqrt__1__flag_1_0_0_11 c__qurt_new__sqrt__1__flag_1_0_0_12))
(= c__qurt_new__sqrt__1__flag_1_0_0_13 ?x2322)))
:assumption
(flet ($x2330 (= c__qurt_new__sqrt__1__x_1_0_0_14 c__qurt_new__sqrt__1__x_1_0_0_12))
(iff l578 $x2330))
:assumption
l578
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_14 c__qurt_new__sqrt__1__x_1_0_0_12)
:assumption
(flet ($x2336 (= c__qurt_new__sqrt__1__flag_1_0_0_14 c__qurt_new__sqrt__1__flag_1_0_0_11))
(iff l579 $x2336))
:assumption
l579
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_14 c__qurt_new__sqrt__1__flag_1_0_0_11)
:assumption
(flet ($x2342 (= c__qurt_new__sqrt__1__x_1_0_0_15 c__qurt_new__sqrt__1__x_1_0_0_14))
(iff l580 $x2342))
:assumption
l580
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_15 c__qurt_new__sqrt__1__x_1_0_0_14)
:assumption
(let (?x2348 (ite goto_symex___guard_0_0_12 c__qurt_new__sqrt__1__x_1_0_0_13 c__qurt_new__sqrt__1__x_1_0_0_15))
(flet ($x2349 (= c__qurt_new__sqrt__1__x_1_0_0_16 ?x2348))
(iff l581 $x2349)))
:assumption
l581
:assumption
(let (?x2348 (ite goto_symex___guard_0_0_12 c__qurt_new__sqrt__1__x_1_0_0_13 c__qurt_new__sqrt__1__x_1_0_0_15))
(= c__qurt_new__sqrt__1__x_1_0_0_16 ?x2348))
:assumption
(let (?x2354 (ite goto_symex___guard_0_0_12 c__qurt_new__sqrt__1__flag_1_0_0_13 c__qurt_new__sqrt__1__flag_1_0_0_14))
(flet ($x2355 (= c__qurt_new__sqrt__1__flag_1_0_0_15 ?x2354))
(iff l582 $x2355)))
:assumption
l582
:assumption
(let (?x2354 (ite goto_symex___guard_0_0_12 c__qurt_new__sqrt__1__flag_1_0_0_13 c__qurt_new__sqrt__1__flag_1_0_0_14))
(= c__qurt_new__sqrt__1__flag_1_0_0_15 ?x2354))
:assumption
(flet ($x2359 (= c__qurt_new__sqrt__1__flag_1_0_0_15 bv0[32]))
(iff l583 $x2359))
:assumption
(flet ($x2364 (xor l40 l583))
(iff l584 $x2364))
:assumption
(not l584)
:assumption
(flet ($x2359 (= c__qurt_new__sqrt__1__flag_1_0_0_15 bv0[32]))
(= goto_symex___guard_0_0_15 $x2359))
:assumption
(let (?x2374 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2379 (bvmul ?x1629 ?x2374))
(let (?x2380 (extract[95:32] ?x2379))
(let (?x2381 (sign_extend[32] ?x2380))
(let (?x2375 (bvmul ?x2374 ?x2374))
(let (?x2376 (extract[95:32] ?x2375))
(let (?x2377 (bvmul bv18446744073709551615[64] ?x2376))
(let (?x2378 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2377))
(let (?x2382 (concat ?x2378 bv0[32]))
(let (?x2383 (bvsdiv ?x2382 ?x2381))
(let (?x2384 (extract[63:0] ?x2383))
(flet ($x2385 (= c__qurt_new__sqrt__1__dx_1_0_0_11 ?x2384))
(iff l585 $x2385)))))))))))))))
:assumption
l585
:assumption
(let (?x2374 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2379 (bvmul ?x1629 ?x2374))
(let (?x2380 (extract[95:32] ?x2379))
(let (?x2381 (sign_extend[32] ?x2380))
(let (?x2375 (bvmul ?x2374 ?x2374))
(let (?x2376 (extract[95:32] ?x2375))
(let (?x2377 (bvmul bv18446744073709551615[64] ?x2376))
(let (?x2378 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2377))
(let (?x2382 (concat ?x2378 bv0[32]))
(let (?x2383 (bvsdiv ?x2382 ?x2381))
(let (?x2384 (extract[63:0] ?x2383))
(= c__qurt_new__sqrt__1__dx_1_0_0_11 ?x2384))))))))))))))
:assumption
(let (?x2405 (bvadd c__qurt_new__sqrt__1__x_1_0_0_16 c__qurt_new__sqrt__1__dx_1_0_0_11))
(flet ($x2406 (= c__qurt_new__sqrt__1__x_1_0_0_17 ?x2405))
(iff l586 $x2406)))
:assumption
l586
:assumption
(let (?x2405 (bvadd c__qurt_new__sqrt__1__x_1_0_0_16 c__qurt_new__sqrt__1__dx_1_0_0_11))
(= c__qurt_new__sqrt__1__x_1_0_0_17 ?x2405))
:assumption
(let (?x2411 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_17))
(let (?x2412 (bvmul ?x2411 ?x2411))
(let (?x2413 (extract[95:32] ?x2412))
(let (?x2414 (bvmul bv18446744073709551615[64] ?x2413))
(let (?x2415 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2414))
(flet ($x2416 (= c__qurt_new__sqrt__1__diff_1_0_0_11 ?x2415))
(iff l587 $x2416)))))))
:assumption
l587
:assumption
(let (?x2411 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_17))
(let (?x2412 (bvmul ?x2411 ?x2411))
(let (?x2413 (extract[95:32] ?x2412))
(let (?x2414 (bvmul bv18446744073709551615[64] ?x2413))
(let (?x2415 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2414))
(= c__qurt_new__sqrt__1__diff_1_0_0_11 ?x2415))))))
:assumption
(flet ($x2421 (= c__qurt_new__fabs__n_6_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_11))
(iff l588 $x2421))
:assumption
l588
:assumption
(= c__qurt_new__fabs__n_6_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_11)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2426 (bvsge c__qurt_new__fabs__n_6_0_0_1 ?x1542))
(iff l589 $x2426)))
:assumption
(flet ($x2433 (xor l42 l589))
(iff l590 $x2433))
:assumption
(not l590)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2426 (bvsge c__qurt_new__fabs__n_6_0_0_1 ?x1542))
(= goto_symex___guard_0_0_16 $x2426)))
:assumption
(flet ($x2444 (= c__qurt_new__fabs__1__f_6_0_0_1 c__qurt_new__fabs__n_6_0_0_1))
(iff l591 $x2444))
:assumption
l591
:assumption
(= c__qurt_new__fabs__1__f_6_0_0_1 c__qurt_new__fabs__n_6_0_0_1)
:assumption
(let (?x2450 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_6_0_0_1))
(flet ($x2451 (= c__qurt_new__fabs__1__f_6_0_0_3 ?x2450))
(iff l592 $x2451)))
:assumption
l592
:assumption
(let (?x2450 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_6_0_0_1))
(= c__qurt_new__fabs__1__f_6_0_0_3 ?x2450))
:assumption
(let (?x2456 (ite goto_symex___guard_0_0_16 c__qurt_new__fabs__1__f_6_0_0_1 c__qurt_new__fabs__1__f_6_0_0_3))
(flet ($x2457 (= c__qurt_new__fabs__1__f_6_0_0_4 ?x2456))
(iff l593 $x2457)))
:assumption
l593
:assumption
(let (?x2456 (ite goto_symex___guard_0_0_16 c__qurt_new__fabs__1__f_6_0_0_1 c__qurt_new__fabs__1__f_6_0_0_3))
(= c__qurt_new__fabs__1__f_6_0_0_4 ?x2456))
:assumption
(flet ($x2462 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_11 c__qurt_new__fabs__1__f_6_0_0_4))
(iff l594 $x2462))
:assumption
l594
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_11 c__qurt_new__fabs__1__f_6_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2467 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_11 ?x1828))
(iff l595 $x2467)))
:assumption
(flet ($x2472 (xor l45 l595))
(iff l596 $x2472))
:assumption
(not l596)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2467 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_11 ?x1828))
(= goto_symex___guard_0_0_17 $x2467)))
:assumption
(flet ($x2483 (= c__qurt_new__sqrt__1__flag_1_0_0_16 bv1[32]))
(iff l597 $x2483))
:assumption
l597
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_16 bv1[32])
:assumption
(flet ($x2489 (not goto_symex___guard_0_0_17))
(let (?x2490 (ite $x2489 c__qurt_new__sqrt__1__flag_1_0_0_15 c__qurt_new__sqrt__1__flag_1_0_0_16))
(flet ($x2491 (= c__qurt_new__sqrt__1__flag_1_0_0_17 ?x2490))
(iff l598 $x2491))))
:assumption
l598
:assumption
(flet ($x2489 (not goto_symex___guard_0_0_17))
(let (?x2490 (ite $x2489 c__qurt_new__sqrt__1__flag_1_0_0_15 c__qurt_new__sqrt__1__flag_1_0_0_16))
(= c__qurt_new__sqrt__1__flag_1_0_0_17 ?x2490)))
:assumption
(flet ($x2498 (= c__qurt_new__sqrt__1__x_1_0_0_18 c__qurt_new__sqrt__1__x_1_0_0_16))
(iff l599 $x2498))
:assumption
l599
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_18 c__qurt_new__sqrt__1__x_1_0_0_16)
:assumption
(flet ($x2504 (= c__qurt_new__sqrt__1__flag_1_0_0_18 c__qurt_new__sqrt__1__flag_1_0_0_15))
(iff l600 $x2504))
:assumption
l600
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_18 c__qurt_new__sqrt__1__flag_1_0_0_15)
:assumption
(flet ($x2510 (= c__qurt_new__sqrt__1__x_1_0_0_19 c__qurt_new__sqrt__1__x_1_0_0_18))
(iff l601 $x2510))
:assumption
l601
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_19 c__qurt_new__sqrt__1__x_1_0_0_18)
:assumption
(let (?x2516 (ite goto_symex___guard_0_0_15 c__qurt_new__sqrt__1__x_1_0_0_17 c__qurt_new__sqrt__1__x_1_0_0_19))
(flet ($x2517 (= c__qurt_new__sqrt__1__x_1_0_0_20 ?x2516))
(iff l602 $x2517)))
:assumption
l602
:assumption
(let (?x2516 (ite goto_symex___guard_0_0_15 c__qurt_new__sqrt__1__x_1_0_0_17 c__qurt_new__sqrt__1__x_1_0_0_19))
(= c__qurt_new__sqrt__1__x_1_0_0_20 ?x2516))
:assumption
(let (?x2522 (ite goto_symex___guard_0_0_15 c__qurt_new__sqrt__1__flag_1_0_0_17 c__qurt_new__sqrt__1__flag_1_0_0_18))
(flet ($x2523 (= c__qurt_new__sqrt__1__flag_1_0_0_19 ?x2522))
(iff l603 $x2523)))
:assumption
l603
:assumption
(let (?x2522 (ite goto_symex___guard_0_0_15 c__qurt_new__sqrt__1__flag_1_0_0_17 c__qurt_new__sqrt__1__flag_1_0_0_18))
(= c__qurt_new__sqrt__1__flag_1_0_0_19 ?x2522))
:assumption
(flet ($x2527 (= c__qurt_new__sqrt__1__flag_1_0_0_19 bv0[32]))
(iff l604 $x2527))
:assumption
(flet ($x2532 (xor l48 l604))
(iff l605 $x2532))
:assumption
(not l605)
:assumption
(flet ($x2527 (= c__qurt_new__sqrt__1__flag_1_0_0_19 bv0[32]))
(= goto_symex___guard_0_0_18 $x2527))
:assumption
(let (?x2542 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2547 (bvmul ?x1629 ?x2542))
(let (?x2548 (extract[95:32] ?x2547))
(let (?x2549 (sign_extend[32] ?x2548))
(let (?x2543 (bvmul ?x2542 ?x2542))
(let (?x2544 (extract[95:32] ?x2543))
(let (?x2545 (bvmul bv18446744073709551615[64] ?x2544))
(let (?x2546 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2545))
(let (?x2550 (concat ?x2546 bv0[32]))
(let (?x2551 (bvsdiv ?x2550 ?x2549))
(let (?x2552 (extract[63:0] ?x2551))
(flet ($x2553 (= c__qurt_new__sqrt__1__dx_1_0_0_14 ?x2552))
(iff l606 $x2553)))))))))))))))
:assumption
l606
:assumption
(let (?x2542 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2547 (bvmul ?x1629 ?x2542))
(let (?x2548 (extract[95:32] ?x2547))
(let (?x2549 (sign_extend[32] ?x2548))
(let (?x2543 (bvmul ?x2542 ?x2542))
(let (?x2544 (extract[95:32] ?x2543))
(let (?x2545 (bvmul bv18446744073709551615[64] ?x2544))
(let (?x2546 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2545))
(let (?x2550 (concat ?x2546 bv0[32]))
(let (?x2551 (bvsdiv ?x2550 ?x2549))
(let (?x2552 (extract[63:0] ?x2551))
(= c__qurt_new__sqrt__1__dx_1_0_0_14 ?x2552))))))))))))))
:assumption
(let (?x2573 (bvadd c__qurt_new__sqrt__1__x_1_0_0_20 c__qurt_new__sqrt__1__dx_1_0_0_14))
(flet ($x2574 (= c__qurt_new__sqrt__1__x_1_0_0_21 ?x2573))
(iff l607 $x2574)))
:assumption
l607
:assumption
(let (?x2573 (bvadd c__qurt_new__sqrt__1__x_1_0_0_20 c__qurt_new__sqrt__1__dx_1_0_0_14))
(= c__qurt_new__sqrt__1__x_1_0_0_21 ?x2573))
:assumption
(let (?x2579 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_21))
(let (?x2580 (bvmul ?x2579 ?x2579))
(let (?x2581 (extract[95:32] ?x2580))
(let (?x2582 (bvmul bv18446744073709551615[64] ?x2581))
(let (?x2583 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2582))
(flet ($x2584 (= c__qurt_new__sqrt__1__diff_1_0_0_14 ?x2583))
(iff l608 $x2584)))))))
:assumption
l608
:assumption
(let (?x2579 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_21))
(let (?x2580 (bvmul ?x2579 ?x2579))
(let (?x2581 (extract[95:32] ?x2580))
(let (?x2582 (bvmul bv18446744073709551615[64] ?x2581))
(let (?x2583 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2582))
(= c__qurt_new__sqrt__1__diff_1_0_0_14 ?x2583))))))
:assumption
(flet ($x2589 (= c__qurt_new__fabs__n_7_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_14))
(iff l609 $x2589))
:assumption
l609
:assumption
(= c__qurt_new__fabs__n_7_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_14)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2594 (bvsge c__qurt_new__fabs__n_7_0_0_1 ?x1542))
(iff l610 $x2594)))
:assumption
(flet ($x2601 (xor l50 l610))
(iff l611 $x2601))
:assumption
(not l611)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2594 (bvsge c__qurt_new__fabs__n_7_0_0_1 ?x1542))
(= goto_symex___guard_0_0_19 $x2594)))
:assumption
(flet ($x2612 (= c__qurt_new__fabs__1__f_7_0_0_1 c__qurt_new__fabs__n_7_0_0_1))
(iff l612 $x2612))
:assumption
l612
:assumption
(= c__qurt_new__fabs__1__f_7_0_0_1 c__qurt_new__fabs__n_7_0_0_1)
:assumption
(let (?x2618 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_7_0_0_1))
(flet ($x2619 (= c__qurt_new__fabs__1__f_7_0_0_3 ?x2618))
(iff l613 $x2619)))
:assumption
l613
:assumption
(let (?x2618 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_7_0_0_1))
(= c__qurt_new__fabs__1__f_7_0_0_3 ?x2618))
:assumption
(let (?x2624 (ite goto_symex___guard_0_0_19 c__qurt_new__fabs__1__f_7_0_0_1 c__qurt_new__fabs__1__f_7_0_0_3))
(flet ($x2625 (= c__qurt_new__fabs__1__f_7_0_0_4 ?x2624))
(iff l614 $x2625)))
:assumption
l614
:assumption
(let (?x2624 (ite goto_symex___guard_0_0_19 c__qurt_new__fabs__1__f_7_0_0_1 c__qurt_new__fabs__1__f_7_0_0_3))
(= c__qurt_new__fabs__1__f_7_0_0_4 ?x2624))
:assumption
(flet ($x2630 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_14 c__qurt_new__fabs__1__f_7_0_0_4))
(iff l615 $x2630))
:assumption
l615
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_14 c__qurt_new__fabs__1__f_7_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2635 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_14 ?x1828))
(iff l616 $x2635)))
:assumption
(flet ($x2640 (xor l53 l616))
(iff l617 $x2640))
:assumption
(not l617)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2635 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_14 ?x1828))
(= goto_symex___guard_0_0_20 $x2635)))
:assumption
(flet ($x2651 (= c__qurt_new__sqrt__1__flag_1_0_0_20 bv1[32]))
(iff l618 $x2651))
:assumption
l618
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_20 bv1[32])
:assumption
(flet ($x2657 (not goto_symex___guard_0_0_20))
(let (?x2658 (ite $x2657 c__qurt_new__sqrt__1__flag_1_0_0_19 c__qurt_new__sqrt__1__flag_1_0_0_20))
(flet ($x2659 (= c__qurt_new__sqrt__1__flag_1_0_0_21 ?x2658))
(iff l619 $x2659))))
:assumption
l619
:assumption
(flet ($x2657 (not goto_symex___guard_0_0_20))
(let (?x2658 (ite $x2657 c__qurt_new__sqrt__1__flag_1_0_0_19 c__qurt_new__sqrt__1__flag_1_0_0_20))
(= c__qurt_new__sqrt__1__flag_1_0_0_21 ?x2658)))
:assumption
(flet ($x2666 (= c__qurt_new__sqrt__1__x_1_0_0_22 c__qurt_new__sqrt__1__x_1_0_0_20))
(iff l620 $x2666))
:assumption
l620
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_22 c__qurt_new__sqrt__1__x_1_0_0_20)
:assumption
(flet ($x2672 (= c__qurt_new__sqrt__1__flag_1_0_0_22 c__qurt_new__sqrt__1__flag_1_0_0_19))
(iff l621 $x2672))
:assumption
l621
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_22 c__qurt_new__sqrt__1__flag_1_0_0_19)
:assumption
(flet ($x2678 (= c__qurt_new__sqrt__1__x_1_0_0_23 c__qurt_new__sqrt__1__x_1_0_0_22))
(iff l622 $x2678))
:assumption
l622
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_23 c__qurt_new__sqrt__1__x_1_0_0_22)
:assumption
(let (?x2684 (ite goto_symex___guard_0_0_18 c__qurt_new__sqrt__1__x_1_0_0_21 c__qurt_new__sqrt__1__x_1_0_0_23))
(flet ($x2685 (= c__qurt_new__sqrt__1__x_1_0_0_24 ?x2684))
(iff l623 $x2685)))
:assumption
l623
:assumption
(let (?x2684 (ite goto_symex___guard_0_0_18 c__qurt_new__sqrt__1__x_1_0_0_21 c__qurt_new__sqrt__1__x_1_0_0_23))
(= c__qurt_new__sqrt__1__x_1_0_0_24 ?x2684))
:assumption
(let (?x2690 (ite goto_symex___guard_0_0_18 c__qurt_new__sqrt__1__flag_1_0_0_21 c__qurt_new__sqrt__1__flag_1_0_0_22))
(flet ($x2691 (= c__qurt_new__sqrt__1__flag_1_0_0_23 ?x2690))
(iff l624 $x2691)))
:assumption
l624
:assumption
(let (?x2690 (ite goto_symex___guard_0_0_18 c__qurt_new__sqrt__1__flag_1_0_0_21 c__qurt_new__sqrt__1__flag_1_0_0_22))
(= c__qurt_new__sqrt__1__flag_1_0_0_23 ?x2690))
:assumption
(flet ($x2695 (= c__qurt_new__sqrt__1__flag_1_0_0_23 bv0[32]))
(iff l625 $x2695))
:assumption
(flet ($x2700 (xor l56 l625))
(iff l626 $x2700))
:assumption
(not l626)
:assumption
(flet ($x2695 (= c__qurt_new__sqrt__1__flag_1_0_0_23 bv0[32]))
(= goto_symex___guard_0_0_21 $x2695))
:assumption
(let (?x2710 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2715 (bvmul ?x1629 ?x2710))
(let (?x2716 (extract[95:32] ?x2715))
(let (?x2717 (sign_extend[32] ?x2716))
(let (?x2711 (bvmul ?x2710 ?x2710))
(let (?x2712 (extract[95:32] ?x2711))
(let (?x2713 (bvmul bv18446744073709551615[64] ?x2712))
(let (?x2714 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2713))
(let (?x2718 (concat ?x2714 bv0[32]))
(let (?x2719 (bvsdiv ?x2718 ?x2717))
(let (?x2720 (extract[63:0] ?x2719))
(flet ($x2721 (= c__qurt_new__sqrt__1__dx_1_0_0_17 ?x2720))
(iff l627 $x2721)))))))))))))))
:assumption
l627
:assumption
(let (?x2710 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2715 (bvmul ?x1629 ?x2710))
(let (?x2716 (extract[95:32] ?x2715))
(let (?x2717 (sign_extend[32] ?x2716))
(let (?x2711 (bvmul ?x2710 ?x2710))
(let (?x2712 (extract[95:32] ?x2711))
(let (?x2713 (bvmul bv18446744073709551615[64] ?x2712))
(let (?x2714 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2713))
(let (?x2718 (concat ?x2714 bv0[32]))
(let (?x2719 (bvsdiv ?x2718 ?x2717))
(let (?x2720 (extract[63:0] ?x2719))
(= c__qurt_new__sqrt__1__dx_1_0_0_17 ?x2720))))))))))))))
:assumption
(let (?x2741 (bvadd c__qurt_new__sqrt__1__x_1_0_0_24 c__qurt_new__sqrt__1__dx_1_0_0_17))
(flet ($x2742 (= c__qurt_new__sqrt__1__x_1_0_0_25 ?x2741))
(iff l628 $x2742)))
:assumption
l628
:assumption
(let (?x2741 (bvadd c__qurt_new__sqrt__1__x_1_0_0_24 c__qurt_new__sqrt__1__dx_1_0_0_17))
(= c__qurt_new__sqrt__1__x_1_0_0_25 ?x2741))
:assumption
(let (?x2747 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_25))
(let (?x2748 (bvmul ?x2747 ?x2747))
(let (?x2749 (extract[95:32] ?x2748))
(let (?x2750 (bvmul bv18446744073709551615[64] ?x2749))
(let (?x2751 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2750))
(flet ($x2752 (= c__qurt_new__sqrt__1__diff_1_0_0_17 ?x2751))
(iff l629 $x2752)))))))
:assumption
l629
:assumption
(let (?x2747 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_25))
(let (?x2748 (bvmul ?x2747 ?x2747))
(let (?x2749 (extract[95:32] ?x2748))
(let (?x2750 (bvmul bv18446744073709551615[64] ?x2749))
(let (?x2751 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2750))
(= c__qurt_new__sqrt__1__diff_1_0_0_17 ?x2751))))))
:assumption
(flet ($x2757 (= c__qurt_new__fabs__n_8_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_17))
(iff l630 $x2757))
:assumption
l630
:assumption
(= c__qurt_new__fabs__n_8_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_17)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2762 (bvsge c__qurt_new__fabs__n_8_0_0_1 ?x1542))
(iff l631 $x2762)))
:assumption
(flet ($x2769 (xor l58 l631))
(iff l632 $x2769))
:assumption
(not l632)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2762 (bvsge c__qurt_new__fabs__n_8_0_0_1 ?x1542))
(= goto_symex___guard_0_0_22 $x2762)))
:assumption
(flet ($x2780 (= c__qurt_new__fabs__1__f_8_0_0_1 c__qurt_new__fabs__n_8_0_0_1))
(iff l633 $x2780))
:assumption
l633
:assumption
(= c__qurt_new__fabs__1__f_8_0_0_1 c__qurt_new__fabs__n_8_0_0_1)
:assumption
(let (?x2786 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_8_0_0_1))
(flet ($x2787 (= c__qurt_new__fabs__1__f_8_0_0_3 ?x2786))
(iff l634 $x2787)))
:assumption
l634
:assumption
(let (?x2786 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_8_0_0_1))
(= c__qurt_new__fabs__1__f_8_0_0_3 ?x2786))
:assumption
(let (?x2792 (ite goto_symex___guard_0_0_22 c__qurt_new__fabs__1__f_8_0_0_1 c__qurt_new__fabs__1__f_8_0_0_3))
(flet ($x2793 (= c__qurt_new__fabs__1__f_8_0_0_4 ?x2792))
(iff l635 $x2793)))
:assumption
l635
:assumption
(let (?x2792 (ite goto_symex___guard_0_0_22 c__qurt_new__fabs__1__f_8_0_0_1 c__qurt_new__fabs__1__f_8_0_0_3))
(= c__qurt_new__fabs__1__f_8_0_0_4 ?x2792))
:assumption
(flet ($x2798 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_17 c__qurt_new__fabs__1__f_8_0_0_4))
(iff l636 $x2798))
:assumption
l636
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_17 c__qurt_new__fabs__1__f_8_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2803 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_17 ?x1828))
(iff l637 $x2803)))
:assumption
(flet ($x2808 (xor l61 l637))
(iff l638 $x2808))
:assumption
(not l638)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2803 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_17 ?x1828))
(= goto_symex___guard_0_0_23 $x2803)))
:assumption
(flet ($x2819 (= c__qurt_new__sqrt__1__flag_1_0_0_24 bv1[32]))
(iff l639 $x2819))
:assumption
l639
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_24 bv1[32])
:assumption
(flet ($x2825 (not goto_symex___guard_0_0_23))
(let (?x2826 (ite $x2825 c__qurt_new__sqrt__1__flag_1_0_0_23 c__qurt_new__sqrt__1__flag_1_0_0_24))
(flet ($x2827 (= c__qurt_new__sqrt__1__flag_1_0_0_25 ?x2826))
(iff l640 $x2827))))
:assumption
l640
:assumption
(flet ($x2825 (not goto_symex___guard_0_0_23))
(let (?x2826 (ite $x2825 c__qurt_new__sqrt__1__flag_1_0_0_23 c__qurt_new__sqrt__1__flag_1_0_0_24))
(= c__qurt_new__sqrt__1__flag_1_0_0_25 ?x2826)))
:assumption
(flet ($x2834 (= c__qurt_new__sqrt__1__x_1_0_0_26 c__qurt_new__sqrt__1__x_1_0_0_24))
(iff l641 $x2834))
:assumption
l641
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_26 c__qurt_new__sqrt__1__x_1_0_0_24)
:assumption
(flet ($x2840 (= c__qurt_new__sqrt__1__flag_1_0_0_26 c__qurt_new__sqrt__1__flag_1_0_0_23))
(iff l642 $x2840))
:assumption
l642
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_26 c__qurt_new__sqrt__1__flag_1_0_0_23)
:assumption
(flet ($x2846 (= c__qurt_new__sqrt__1__x_1_0_0_27 c__qurt_new__sqrt__1__x_1_0_0_26))
(iff l643 $x2846))
:assumption
l643
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_27 c__qurt_new__sqrt__1__x_1_0_0_26)
:assumption
(let (?x2852 (ite goto_symex___guard_0_0_21 c__qurt_new__sqrt__1__x_1_0_0_25 c__qurt_new__sqrt__1__x_1_0_0_27))
(flet ($x2853 (= c__qurt_new__sqrt__1__x_1_0_0_28 ?x2852))
(iff l644 $x2853)))
:assumption
l644
:assumption
(let (?x2852 (ite goto_symex___guard_0_0_21 c__qurt_new__sqrt__1__x_1_0_0_25 c__qurt_new__sqrt__1__x_1_0_0_27))
(= c__qurt_new__sqrt__1__x_1_0_0_28 ?x2852))
:assumption
(let (?x2858 (ite goto_symex___guard_0_0_21 c__qurt_new__sqrt__1__flag_1_0_0_25 c__qurt_new__sqrt__1__flag_1_0_0_26))
(flet ($x2859 (= c__qurt_new__sqrt__1__flag_1_0_0_27 ?x2858))
(iff l645 $x2859)))
:assumption
l645
:assumption
(let (?x2858 (ite goto_symex___guard_0_0_21 c__qurt_new__sqrt__1__flag_1_0_0_25 c__qurt_new__sqrt__1__flag_1_0_0_26))
(= c__qurt_new__sqrt__1__flag_1_0_0_27 ?x2858))
:assumption
(flet ($x2863 (= c__qurt_new__sqrt__1__flag_1_0_0_27 bv0[32]))
(iff l646 $x2863))
:assumption
(flet ($x2868 (xor l64 l646))
(iff l647 $x2868))
:assumption
(not l647)
:assumption
(flet ($x2863 (= c__qurt_new__sqrt__1__flag_1_0_0_27 bv0[32]))
(= goto_symex___guard_0_0_24 $x2863))
:assumption
(let (?x2878 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2883 (bvmul ?x1629 ?x2878))
(let (?x2884 (extract[95:32] ?x2883))
(let (?x2885 (sign_extend[32] ?x2884))
(let (?x2879 (bvmul ?x2878 ?x2878))
(let (?x2880 (extract[95:32] ?x2879))
(let (?x2881 (bvmul bv18446744073709551615[64] ?x2880))
(let (?x2882 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2881))
(let (?x2886 (concat ?x2882 bv0[32]))
(let (?x2887 (bvsdiv ?x2886 ?x2885))
(let (?x2888 (extract[63:0] ?x2887))
(flet ($x2889 (= c__qurt_new__sqrt__1__dx_1_0_0_20 ?x2888))
(iff l648 $x2889)))))))))))))))
:assumption
l648
:assumption
(let (?x2878 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2883 (bvmul ?x1629 ?x2878))
(let (?x2884 (extract[95:32] ?x2883))
(let (?x2885 (sign_extend[32] ?x2884))
(let (?x2879 (bvmul ?x2878 ?x2878))
(let (?x2880 (extract[95:32] ?x2879))
(let (?x2881 (bvmul bv18446744073709551615[64] ?x2880))
(let (?x2882 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2881))
(let (?x2886 (concat ?x2882 bv0[32]))
(let (?x2887 (bvsdiv ?x2886 ?x2885))
(let (?x2888 (extract[63:0] ?x2887))
(= c__qurt_new__sqrt__1__dx_1_0_0_20 ?x2888))))))))))))))
:assumption
(let (?x2909 (bvadd c__qurt_new__sqrt__1__x_1_0_0_28 c__qurt_new__sqrt__1__dx_1_0_0_20))
(flet ($x2910 (= c__qurt_new__sqrt__1__x_1_0_0_29 ?x2909))
(iff l649 $x2910)))
:assumption
l649
:assumption
(let (?x2909 (bvadd c__qurt_new__sqrt__1__x_1_0_0_28 c__qurt_new__sqrt__1__dx_1_0_0_20))
(= c__qurt_new__sqrt__1__x_1_0_0_29 ?x2909))
:assumption
(let (?x2915 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_29))
(let (?x2916 (bvmul ?x2915 ?x2915))
(let (?x2917 (extract[95:32] ?x2916))
(let (?x2918 (bvmul bv18446744073709551615[64] ?x2917))
(let (?x2919 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2918))
(flet ($x2920 (= c__qurt_new__sqrt__1__diff_1_0_0_20 ?x2919))
(iff l650 $x2920)))))))
:assumption
l650
:assumption
(let (?x2915 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_29))
(let (?x2916 (bvmul ?x2915 ?x2915))
(let (?x2917 (extract[95:32] ?x2916))
(let (?x2918 (bvmul bv18446744073709551615[64] ?x2917))
(let (?x2919 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x2918))
(= c__qurt_new__sqrt__1__diff_1_0_0_20 ?x2919))))))
:assumption
(flet ($x2925 (= c__qurt_new__fabs__n_9_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_20))
(iff l651 $x2925))
:assumption
l651
:assumption
(= c__qurt_new__fabs__n_9_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_20)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2930 (bvsge c__qurt_new__fabs__n_9_0_0_1 ?x1542))
(iff l652 $x2930)))
:assumption
(flet ($x2937 (xor l66 l652))
(iff l653 $x2937))
:assumption
(not l653)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x2930 (bvsge c__qurt_new__fabs__n_9_0_0_1 ?x1542))
(= goto_symex___guard_0_0_25 $x2930)))
:assumption
(flet ($x2948 (= c__qurt_new__fabs__1__f_9_0_0_1 c__qurt_new__fabs__n_9_0_0_1))
(iff l654 $x2948))
:assumption
l654
:assumption
(= c__qurt_new__fabs__1__f_9_0_0_1 c__qurt_new__fabs__n_9_0_0_1)
:assumption
(let (?x2954 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_9_0_0_1))
(flet ($x2955 (= c__qurt_new__fabs__1__f_9_0_0_3 ?x2954))
(iff l655 $x2955)))
:assumption
l655
:assumption
(let (?x2954 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_9_0_0_1))
(= c__qurt_new__fabs__1__f_9_0_0_3 ?x2954))
:assumption
(let (?x2960 (ite goto_symex___guard_0_0_25 c__qurt_new__fabs__1__f_9_0_0_1 c__qurt_new__fabs__1__f_9_0_0_3))
(flet ($x2961 (= c__qurt_new__fabs__1__f_9_0_0_4 ?x2960))
(iff l656 $x2961)))
:assumption
l656
:assumption
(let (?x2960 (ite goto_symex___guard_0_0_25 c__qurt_new__fabs__1__f_9_0_0_1 c__qurt_new__fabs__1__f_9_0_0_3))
(= c__qurt_new__fabs__1__f_9_0_0_4 ?x2960))
:assumption
(flet ($x2966 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_20 c__qurt_new__fabs__1__f_9_0_0_4))
(iff l657 $x2966))
:assumption
l657
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_20 c__qurt_new__fabs__1__f_9_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2971 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_20 ?x1828))
(iff l658 $x2971)))
:assumption
(flet ($x2976 (xor l69 l658))
(iff l659 $x2976))
:assumption
(not l659)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x2971 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_20 ?x1828))
(= goto_symex___guard_0_0_26 $x2971)))
:assumption
(flet ($x2987 (= c__qurt_new__sqrt__1__flag_1_0_0_28 bv1[32]))
(iff l660 $x2987))
:assumption
l660
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_28 bv1[32])
:assumption
(flet ($x2993 (not goto_symex___guard_0_0_26))
(let (?x2994 (ite $x2993 c__qurt_new__sqrt__1__flag_1_0_0_27 c__qurt_new__sqrt__1__flag_1_0_0_28))
(flet ($x2995 (= c__qurt_new__sqrt__1__flag_1_0_0_29 ?x2994))
(iff l661 $x2995))))
:assumption
l661
:assumption
(flet ($x2993 (not goto_symex___guard_0_0_26))
(let (?x2994 (ite $x2993 c__qurt_new__sqrt__1__flag_1_0_0_27 c__qurt_new__sqrt__1__flag_1_0_0_28))
(= c__qurt_new__sqrt__1__flag_1_0_0_29 ?x2994)))
:assumption
(flet ($x3002 (= c__qurt_new__sqrt__1__x_1_0_0_30 c__qurt_new__sqrt__1__x_1_0_0_28))
(iff l662 $x3002))
:assumption
l662
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_30 c__qurt_new__sqrt__1__x_1_0_0_28)
:assumption
(flet ($x3008 (= c__qurt_new__sqrt__1__flag_1_0_0_30 c__qurt_new__sqrt__1__flag_1_0_0_27))
(iff l663 $x3008))
:assumption
l663
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_30 c__qurt_new__sqrt__1__flag_1_0_0_27)
:assumption
(flet ($x3014 (= c__qurt_new__sqrt__1__x_1_0_0_31 c__qurt_new__sqrt__1__x_1_0_0_30))
(iff l664 $x3014))
:assumption
l664
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_31 c__qurt_new__sqrt__1__x_1_0_0_30)
:assumption
(let (?x3020 (ite goto_symex___guard_0_0_24 c__qurt_new__sqrt__1__x_1_0_0_29 c__qurt_new__sqrt__1__x_1_0_0_31))
(flet ($x3021 (= c__qurt_new__sqrt__1__x_1_0_0_32 ?x3020))
(iff l665 $x3021)))
:assumption
l665
:assumption
(let (?x3020 (ite goto_symex___guard_0_0_24 c__qurt_new__sqrt__1__x_1_0_0_29 c__qurt_new__sqrt__1__x_1_0_0_31))
(= c__qurt_new__sqrt__1__x_1_0_0_32 ?x3020))
:assumption
(let (?x3026 (ite goto_symex___guard_0_0_24 c__qurt_new__sqrt__1__flag_1_0_0_29 c__qurt_new__sqrt__1__flag_1_0_0_30))
(flet ($x3027 (= c__qurt_new__sqrt__1__flag_1_0_0_31 ?x3026))
(iff l666 $x3027)))
:assumption
l666
:assumption
(let (?x3026 (ite goto_symex___guard_0_0_24 c__qurt_new__sqrt__1__flag_1_0_0_29 c__qurt_new__sqrt__1__flag_1_0_0_30))
(= c__qurt_new__sqrt__1__flag_1_0_0_31 ?x3026))
:assumption
(flet ($x3031 (= c__qurt_new__sqrt__1__flag_1_0_0_31 bv0[32]))
(iff l667 $x3031))
:assumption
(flet ($x3036 (xor l72 l667))
(iff l668 $x3036))
:assumption
(not l668)
:assumption
(flet ($x3031 (= c__qurt_new__sqrt__1__flag_1_0_0_31 bv0[32]))
(= goto_symex___guard_0_0_27 $x3031))
:assumption
(let (?x3046 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3051 (bvmul ?x1629 ?x3046))
(let (?x3052 (extract[95:32] ?x3051))
(let (?x3053 (sign_extend[32] ?x3052))
(let (?x3047 (bvmul ?x3046 ?x3046))
(let (?x3048 (extract[95:32] ?x3047))
(let (?x3049 (bvmul bv18446744073709551615[64] ?x3048))
(let (?x3050 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3049))
(let (?x3054 (concat ?x3050 bv0[32]))
(let (?x3055 (bvsdiv ?x3054 ?x3053))
(let (?x3056 (extract[63:0] ?x3055))
(flet ($x3057 (= c__qurt_new__sqrt__1__dx_1_0_0_23 ?x3056))
(iff l669 $x3057)))))))))))))))
:assumption
l669
:assumption
(let (?x3046 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3051 (bvmul ?x1629 ?x3046))
(let (?x3052 (extract[95:32] ?x3051))
(let (?x3053 (sign_extend[32] ?x3052))
(let (?x3047 (bvmul ?x3046 ?x3046))
(let (?x3048 (extract[95:32] ?x3047))
(let (?x3049 (bvmul bv18446744073709551615[64] ?x3048))
(let (?x3050 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3049))
(let (?x3054 (concat ?x3050 bv0[32]))
(let (?x3055 (bvsdiv ?x3054 ?x3053))
(let (?x3056 (extract[63:0] ?x3055))
(= c__qurt_new__sqrt__1__dx_1_0_0_23 ?x3056))))))))))))))
:assumption
(let (?x3077 (bvadd c__qurt_new__sqrt__1__x_1_0_0_32 c__qurt_new__sqrt__1__dx_1_0_0_23))
(flet ($x3078 (= c__qurt_new__sqrt__1__x_1_0_0_33 ?x3077))
(iff l670 $x3078)))
:assumption
l670
:assumption
(let (?x3077 (bvadd c__qurt_new__sqrt__1__x_1_0_0_32 c__qurt_new__sqrt__1__dx_1_0_0_23))
(= c__qurt_new__sqrt__1__x_1_0_0_33 ?x3077))
:assumption
(let (?x3083 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_33))
(let (?x3084 (bvmul ?x3083 ?x3083))
(let (?x3085 (extract[95:32] ?x3084))
(let (?x3086 (bvmul bv18446744073709551615[64] ?x3085))
(let (?x3087 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3086))
(flet ($x3088 (= c__qurt_new__sqrt__1__diff_1_0_0_23 ?x3087))
(iff l671 $x3088)))))))
:assumption
l671
:assumption
(let (?x3083 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_33))
(let (?x3084 (bvmul ?x3083 ?x3083))
(let (?x3085 (extract[95:32] ?x3084))
(let (?x3086 (bvmul bv18446744073709551615[64] ?x3085))
(let (?x3087 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3086))
(= c__qurt_new__sqrt__1__diff_1_0_0_23 ?x3087))))))
:assumption
(flet ($x3093 (= c__qurt_new__fabs__n_10_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_23))
(iff l672 $x3093))
:assumption
l672
:assumption
(= c__qurt_new__fabs__n_10_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_23)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3098 (bvsge c__qurt_new__fabs__n_10_0_0_1 ?x1542))
(iff l673 $x3098)))
:assumption
(flet ($x3105 (xor l74 l673))
(iff l674 $x3105))
:assumption
(not l674)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3098 (bvsge c__qurt_new__fabs__n_10_0_0_1 ?x1542))
(= goto_symex___guard_0_0_28 $x3098)))
:assumption
(flet ($x3116 (= c__qurt_new__fabs__1__f_10_0_0_1 c__qurt_new__fabs__n_10_0_0_1))
(iff l675 $x3116))
:assumption
l675
:assumption
(= c__qurt_new__fabs__1__f_10_0_0_1 c__qurt_new__fabs__n_10_0_0_1)
:assumption
(let (?x3122 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_10_0_0_1))
(flet ($x3123 (= c__qurt_new__fabs__1__f_10_0_0_3 ?x3122))
(iff l676 $x3123)))
:assumption
l676
:assumption
(let (?x3122 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_10_0_0_1))
(= c__qurt_new__fabs__1__f_10_0_0_3 ?x3122))
:assumption
(let (?x3128 (ite goto_symex___guard_0_0_28 c__qurt_new__fabs__1__f_10_0_0_1 c__qurt_new__fabs__1__f_10_0_0_3))
(flet ($x3129 (= c__qurt_new__fabs__1__f_10_0_0_4 ?x3128))
(iff l677 $x3129)))
:assumption
l677
:assumption
(let (?x3128 (ite goto_symex___guard_0_0_28 c__qurt_new__fabs__1__f_10_0_0_1 c__qurt_new__fabs__1__f_10_0_0_3))
(= c__qurt_new__fabs__1__f_10_0_0_4 ?x3128))
:assumption
(flet ($x3134 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_23 c__qurt_new__fabs__1__f_10_0_0_4))
(iff l678 $x3134))
:assumption
l678
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_23 c__qurt_new__fabs__1__f_10_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3139 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_23 ?x1828))
(iff l679 $x3139)))
:assumption
(flet ($x3144 (xor l77 l679))
(iff l680 $x3144))
:assumption
(not l680)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3139 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_23 ?x1828))
(= goto_symex___guard_0_0_29 $x3139)))
:assumption
(flet ($x3155 (= c__qurt_new__sqrt__1__flag_1_0_0_32 bv1[32]))
(iff l681 $x3155))
:assumption
l681
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_32 bv1[32])
:assumption
(flet ($x3161 (not goto_symex___guard_0_0_29))
(let (?x3162 (ite $x3161 c__qurt_new__sqrt__1__flag_1_0_0_31 c__qurt_new__sqrt__1__flag_1_0_0_32))
(flet ($x3163 (= c__qurt_new__sqrt__1__flag_1_0_0_33 ?x3162))
(iff l682 $x3163))))
:assumption
l682
:assumption
(flet ($x3161 (not goto_symex___guard_0_0_29))
(let (?x3162 (ite $x3161 c__qurt_new__sqrt__1__flag_1_0_0_31 c__qurt_new__sqrt__1__flag_1_0_0_32))
(= c__qurt_new__sqrt__1__flag_1_0_0_33 ?x3162)))
:assumption
(flet ($x3170 (= c__qurt_new__sqrt__1__x_1_0_0_34 c__qurt_new__sqrt__1__x_1_0_0_32))
(iff l683 $x3170))
:assumption
l683
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_34 c__qurt_new__sqrt__1__x_1_0_0_32)
:assumption
(flet ($x3176 (= c__qurt_new__sqrt__1__flag_1_0_0_34 c__qurt_new__sqrt__1__flag_1_0_0_31))
(iff l684 $x3176))
:assumption
l684
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_34 c__qurt_new__sqrt__1__flag_1_0_0_31)
:assumption
(flet ($x3182 (= c__qurt_new__sqrt__1__x_1_0_0_35 c__qurt_new__sqrt__1__x_1_0_0_34))
(iff l685 $x3182))
:assumption
l685
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_35 c__qurt_new__sqrt__1__x_1_0_0_34)
:assumption
(let (?x3188 (ite goto_symex___guard_0_0_27 c__qurt_new__sqrt__1__x_1_0_0_33 c__qurt_new__sqrt__1__x_1_0_0_35))
(flet ($x3189 (= c__qurt_new__sqrt__1__x_1_0_0_36 ?x3188))
(iff l686 $x3189)))
:assumption
l686
:assumption
(let (?x3188 (ite goto_symex___guard_0_0_27 c__qurt_new__sqrt__1__x_1_0_0_33 c__qurt_new__sqrt__1__x_1_0_0_35))
(= c__qurt_new__sqrt__1__x_1_0_0_36 ?x3188))
:assumption
(let (?x3194 (ite goto_symex___guard_0_0_27 c__qurt_new__sqrt__1__flag_1_0_0_33 c__qurt_new__sqrt__1__flag_1_0_0_34))
(flet ($x3195 (= c__qurt_new__sqrt__1__flag_1_0_0_35 ?x3194))
(iff l687 $x3195)))
:assumption
l687
:assumption
(let (?x3194 (ite goto_symex___guard_0_0_27 c__qurt_new__sqrt__1__flag_1_0_0_33 c__qurt_new__sqrt__1__flag_1_0_0_34))
(= c__qurt_new__sqrt__1__flag_1_0_0_35 ?x3194))
:assumption
(flet ($x3199 (= c__qurt_new__sqrt__1__flag_1_0_0_35 bv0[32]))
(iff l688 $x3199))
:assumption
(flet ($x3204 (xor l80 l688))
(iff l689 $x3204))
:assumption
(not l689)
:assumption
(flet ($x3199 (= c__qurt_new__sqrt__1__flag_1_0_0_35 bv0[32]))
(= goto_symex___guard_0_0_30 $x3199))
:assumption
(let (?x3214 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3219 (bvmul ?x1629 ?x3214))
(let (?x3220 (extract[95:32] ?x3219))
(let (?x3221 (sign_extend[32] ?x3220))
(let (?x3215 (bvmul ?x3214 ?x3214))
(let (?x3216 (extract[95:32] ?x3215))
(let (?x3217 (bvmul bv18446744073709551615[64] ?x3216))
(let (?x3218 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3217))
(let (?x3222 (concat ?x3218 bv0[32]))
(let (?x3223 (bvsdiv ?x3222 ?x3221))
(let (?x3224 (extract[63:0] ?x3223))
(flet ($x3225 (= c__qurt_new__sqrt__1__dx_1_0_0_26 ?x3224))
(iff l690 $x3225)))))))))))))))
:assumption
l690
:assumption
(let (?x3214 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3219 (bvmul ?x1629 ?x3214))
(let (?x3220 (extract[95:32] ?x3219))
(let (?x3221 (sign_extend[32] ?x3220))
(let (?x3215 (bvmul ?x3214 ?x3214))
(let (?x3216 (extract[95:32] ?x3215))
(let (?x3217 (bvmul bv18446744073709551615[64] ?x3216))
(let (?x3218 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3217))
(let (?x3222 (concat ?x3218 bv0[32]))
(let (?x3223 (bvsdiv ?x3222 ?x3221))
(let (?x3224 (extract[63:0] ?x3223))
(= c__qurt_new__sqrt__1__dx_1_0_0_26 ?x3224))))))))))))))
:assumption
(let (?x3245 (bvadd c__qurt_new__sqrt__1__x_1_0_0_36 c__qurt_new__sqrt__1__dx_1_0_0_26))
(flet ($x3246 (= c__qurt_new__sqrt__1__x_1_0_0_37 ?x3245))
(iff l691 $x3246)))
:assumption
l691
:assumption
(let (?x3245 (bvadd c__qurt_new__sqrt__1__x_1_0_0_36 c__qurt_new__sqrt__1__dx_1_0_0_26))
(= c__qurt_new__sqrt__1__x_1_0_0_37 ?x3245))
:assumption
(let (?x3251 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_37))
(let (?x3252 (bvmul ?x3251 ?x3251))
(let (?x3253 (extract[95:32] ?x3252))
(let (?x3254 (bvmul bv18446744073709551615[64] ?x3253))
(let (?x3255 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3254))
(flet ($x3256 (= c__qurt_new__sqrt__1__diff_1_0_0_26 ?x3255))
(iff l692 $x3256)))))))
:assumption
l692
:assumption
(let (?x3251 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_37))
(let (?x3252 (bvmul ?x3251 ?x3251))
(let (?x3253 (extract[95:32] ?x3252))
(let (?x3254 (bvmul bv18446744073709551615[64] ?x3253))
(let (?x3255 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3254))
(= c__qurt_new__sqrt__1__diff_1_0_0_26 ?x3255))))))
:assumption
(flet ($x3261 (= c__qurt_new__fabs__n_11_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_26))
(iff l693 $x3261))
:assumption
l693
:assumption
(= c__qurt_new__fabs__n_11_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_26)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3266 (bvsge c__qurt_new__fabs__n_11_0_0_1 ?x1542))
(iff l694 $x3266)))
:assumption
(flet ($x3273 (xor l82 l694))
(iff l695 $x3273))
:assumption
(not l695)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3266 (bvsge c__qurt_new__fabs__n_11_0_0_1 ?x1542))
(= goto_symex___guard_0_0_31 $x3266)))
:assumption
(flet ($x3284 (= c__qurt_new__fabs__1__f_11_0_0_1 c__qurt_new__fabs__n_11_0_0_1))
(iff l696 $x3284))
:assumption
l696
:assumption
(= c__qurt_new__fabs__1__f_11_0_0_1 c__qurt_new__fabs__n_11_0_0_1)
:assumption
(let (?x3290 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_11_0_0_1))
(flet ($x3291 (= c__qurt_new__fabs__1__f_11_0_0_3 ?x3290))
(iff l697 $x3291)))
:assumption
l697
:assumption
(let (?x3290 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_11_0_0_1))
(= c__qurt_new__fabs__1__f_11_0_0_3 ?x3290))
:assumption
(let (?x3296 (ite goto_symex___guard_0_0_31 c__qurt_new__fabs__1__f_11_0_0_1 c__qurt_new__fabs__1__f_11_0_0_3))
(flet ($x3297 (= c__qurt_new__fabs__1__f_11_0_0_4 ?x3296))
(iff l698 $x3297)))
:assumption
l698
:assumption
(let (?x3296 (ite goto_symex___guard_0_0_31 c__qurt_new__fabs__1__f_11_0_0_1 c__qurt_new__fabs__1__f_11_0_0_3))
(= c__qurt_new__fabs__1__f_11_0_0_4 ?x3296))
:assumption
(flet ($x3302 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_26 c__qurt_new__fabs__1__f_11_0_0_4))
(iff l699 $x3302))
:assumption
l699
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_26 c__qurt_new__fabs__1__f_11_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3307 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_26 ?x1828))
(iff l700 $x3307)))
:assumption
(flet ($x3312 (xor l85 l700))
(iff l701 $x3312))
:assumption
(not l701)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3307 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_26 ?x1828))
(= goto_symex___guard_0_0_32 $x3307)))
:assumption
(flet ($x3323 (= c__qurt_new__sqrt__1__flag_1_0_0_36 bv1[32]))
(iff l702 $x3323))
:assumption
l702
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_36 bv1[32])
:assumption
(flet ($x3329 (not goto_symex___guard_0_0_32))
(let (?x3330 (ite $x3329 c__qurt_new__sqrt__1__flag_1_0_0_35 c__qurt_new__sqrt__1__flag_1_0_0_36))
(flet ($x3331 (= c__qurt_new__sqrt__1__flag_1_0_0_37 ?x3330))
(iff l703 $x3331))))
:assumption
l703
:assumption
(flet ($x3329 (not goto_symex___guard_0_0_32))
(let (?x3330 (ite $x3329 c__qurt_new__sqrt__1__flag_1_0_0_35 c__qurt_new__sqrt__1__flag_1_0_0_36))
(= c__qurt_new__sqrt__1__flag_1_0_0_37 ?x3330)))
:assumption
(flet ($x3338 (= c__qurt_new__sqrt__1__x_1_0_0_38 c__qurt_new__sqrt__1__x_1_0_0_36))
(iff l704 $x3338))
:assumption
l704
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_38 c__qurt_new__sqrt__1__x_1_0_0_36)
:assumption
(flet ($x3344 (= c__qurt_new__sqrt__1__flag_1_0_0_38 c__qurt_new__sqrt__1__flag_1_0_0_35))
(iff l705 $x3344))
:assumption
l705
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_38 c__qurt_new__sqrt__1__flag_1_0_0_35)
:assumption
(flet ($x3350 (= c__qurt_new__sqrt__1__x_1_0_0_39 c__qurt_new__sqrt__1__x_1_0_0_38))
(iff l706 $x3350))
:assumption
l706
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_39 c__qurt_new__sqrt__1__x_1_0_0_38)
:assumption
(let (?x3356 (ite goto_symex___guard_0_0_30 c__qurt_new__sqrt__1__x_1_0_0_37 c__qurt_new__sqrt__1__x_1_0_0_39))
(flet ($x3357 (= c__qurt_new__sqrt__1__x_1_0_0_40 ?x3356))
(iff l707 $x3357)))
:assumption
l707
:assumption
(let (?x3356 (ite goto_symex___guard_0_0_30 c__qurt_new__sqrt__1__x_1_0_0_37 c__qurt_new__sqrt__1__x_1_0_0_39))
(= c__qurt_new__sqrt__1__x_1_0_0_40 ?x3356))
:assumption
(let (?x3362 (ite goto_symex___guard_0_0_30 c__qurt_new__sqrt__1__flag_1_0_0_37 c__qurt_new__sqrt__1__flag_1_0_0_38))
(flet ($x3363 (= c__qurt_new__sqrt__1__flag_1_0_0_39 ?x3362))
(iff l708 $x3363)))
:assumption
l708
:assumption
(let (?x3362 (ite goto_symex___guard_0_0_30 c__qurt_new__sqrt__1__flag_1_0_0_37 c__qurt_new__sqrt__1__flag_1_0_0_38))
(= c__qurt_new__sqrt__1__flag_1_0_0_39 ?x3362))
:assumption
(flet ($x3367 (= c__qurt_new__sqrt__1__flag_1_0_0_39 bv0[32]))
(iff l709 $x3367))
:assumption
(flet ($x3372 (xor l88 l709))
(iff l710 $x3372))
:assumption
(not l710)
:assumption
(flet ($x3367 (= c__qurt_new__sqrt__1__flag_1_0_0_39 bv0[32]))
(= goto_symex___guard_0_0_33 $x3367))
:assumption
(let (?x3382 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3387 (bvmul ?x1629 ?x3382))
(let (?x3388 (extract[95:32] ?x3387))
(let (?x3389 (sign_extend[32] ?x3388))
(let (?x3383 (bvmul ?x3382 ?x3382))
(let (?x3384 (extract[95:32] ?x3383))
(let (?x3385 (bvmul bv18446744073709551615[64] ?x3384))
(let (?x3386 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3385))
(let (?x3390 (concat ?x3386 bv0[32]))
(let (?x3391 (bvsdiv ?x3390 ?x3389))
(let (?x3392 (extract[63:0] ?x3391))
(flet ($x3393 (= c__qurt_new__sqrt__1__dx_1_0_0_29 ?x3392))
(iff l711 $x3393)))))))))))))))
:assumption
l711
:assumption
(let (?x3382 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3387 (bvmul ?x1629 ?x3382))
(let (?x3388 (extract[95:32] ?x3387))
(let (?x3389 (sign_extend[32] ?x3388))
(let (?x3383 (bvmul ?x3382 ?x3382))
(let (?x3384 (extract[95:32] ?x3383))
(let (?x3385 (bvmul bv18446744073709551615[64] ?x3384))
(let (?x3386 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3385))
(let (?x3390 (concat ?x3386 bv0[32]))
(let (?x3391 (bvsdiv ?x3390 ?x3389))
(let (?x3392 (extract[63:0] ?x3391))
(= c__qurt_new__sqrt__1__dx_1_0_0_29 ?x3392))))))))))))))
:assumption
(let (?x3413 (bvadd c__qurt_new__sqrt__1__x_1_0_0_40 c__qurt_new__sqrt__1__dx_1_0_0_29))
(flet ($x3414 (= c__qurt_new__sqrt__1__x_1_0_0_41 ?x3413))
(iff l712 $x3414)))
:assumption
l712
:assumption
(let (?x3413 (bvadd c__qurt_new__sqrt__1__x_1_0_0_40 c__qurt_new__sqrt__1__dx_1_0_0_29))
(= c__qurt_new__sqrt__1__x_1_0_0_41 ?x3413))
:assumption
(let (?x3419 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_41))
(let (?x3420 (bvmul ?x3419 ?x3419))
(let (?x3421 (extract[95:32] ?x3420))
(let (?x3422 (bvmul bv18446744073709551615[64] ?x3421))
(let (?x3423 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3422))
(flet ($x3424 (= c__qurt_new__sqrt__1__diff_1_0_0_29 ?x3423))
(iff l713 $x3424)))))))
:assumption
l713
:assumption
(let (?x3419 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_41))
(let (?x3420 (bvmul ?x3419 ?x3419))
(let (?x3421 (extract[95:32] ?x3420))
(let (?x3422 (bvmul bv18446744073709551615[64] ?x3421))
(let (?x3423 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3422))
(= c__qurt_new__sqrt__1__diff_1_0_0_29 ?x3423))))))
:assumption
(flet ($x3429 (= c__qurt_new__fabs__n_12_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_29))
(iff l714 $x3429))
:assumption
l714
:assumption
(= c__qurt_new__fabs__n_12_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_29)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3434 (bvsge c__qurt_new__fabs__n_12_0_0_1 ?x1542))
(iff l715 $x3434)))
:assumption
(flet ($x3441 (xor l90 l715))
(iff l716 $x3441))
:assumption
(not l716)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3434 (bvsge c__qurt_new__fabs__n_12_0_0_1 ?x1542))
(= goto_symex___guard_0_0_34 $x3434)))
:assumption
(flet ($x3452 (= c__qurt_new__fabs__1__f_12_0_0_1 c__qurt_new__fabs__n_12_0_0_1))
(iff l717 $x3452))
:assumption
l717
:assumption
(= c__qurt_new__fabs__1__f_12_0_0_1 c__qurt_new__fabs__n_12_0_0_1)
:assumption
(let (?x3458 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_12_0_0_1))
(flet ($x3459 (= c__qurt_new__fabs__1__f_12_0_0_3 ?x3458))
(iff l718 $x3459)))
:assumption
l718
:assumption
(let (?x3458 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_12_0_0_1))
(= c__qurt_new__fabs__1__f_12_0_0_3 ?x3458))
:assumption
(let (?x3464 (ite goto_symex___guard_0_0_34 c__qurt_new__fabs__1__f_12_0_0_1 c__qurt_new__fabs__1__f_12_0_0_3))
(flet ($x3465 (= c__qurt_new__fabs__1__f_12_0_0_4 ?x3464))
(iff l719 $x3465)))
:assumption
l719
:assumption
(let (?x3464 (ite goto_symex___guard_0_0_34 c__qurt_new__fabs__1__f_12_0_0_1 c__qurt_new__fabs__1__f_12_0_0_3))
(= c__qurt_new__fabs__1__f_12_0_0_4 ?x3464))
:assumption
(flet ($x3470 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_29 c__qurt_new__fabs__1__f_12_0_0_4))
(iff l720 $x3470))
:assumption
l720
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_29 c__qurt_new__fabs__1__f_12_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3475 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_29 ?x1828))
(iff l721 $x3475)))
:assumption
(flet ($x3480 (xor l93 l721))
(iff l722 $x3480))
:assumption
(not l722)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3475 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_29 ?x1828))
(= goto_symex___guard_0_0_35 $x3475)))
:assumption
(flet ($x3491 (= c__qurt_new__sqrt__1__flag_1_0_0_40 bv1[32]))
(iff l723 $x3491))
:assumption
l723
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_40 bv1[32])
:assumption
(flet ($x3497 (not goto_symex___guard_0_0_35))
(let (?x3498 (ite $x3497 c__qurt_new__sqrt__1__flag_1_0_0_39 c__qurt_new__sqrt__1__flag_1_0_0_40))
(flet ($x3499 (= c__qurt_new__sqrt__1__flag_1_0_0_41 ?x3498))
(iff l724 $x3499))))
:assumption
l724
:assumption
(flet ($x3497 (not goto_symex___guard_0_0_35))
(let (?x3498 (ite $x3497 c__qurt_new__sqrt__1__flag_1_0_0_39 c__qurt_new__sqrt__1__flag_1_0_0_40))
(= c__qurt_new__sqrt__1__flag_1_0_0_41 ?x3498)))
:assumption
(flet ($x3506 (= c__qurt_new__sqrt__1__x_1_0_0_42 c__qurt_new__sqrt__1__x_1_0_0_40))
(iff l725 $x3506))
:assumption
l725
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_42 c__qurt_new__sqrt__1__x_1_0_0_40)
:assumption
(flet ($x3512 (= c__qurt_new__sqrt__1__flag_1_0_0_42 c__qurt_new__sqrt__1__flag_1_0_0_39))
(iff l726 $x3512))
:assumption
l726
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_42 c__qurt_new__sqrt__1__flag_1_0_0_39)
:assumption
(flet ($x3518 (= c__qurt_new__sqrt__1__x_1_0_0_43 c__qurt_new__sqrt__1__x_1_0_0_42))
(iff l727 $x3518))
:assumption
l727
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_43 c__qurt_new__sqrt__1__x_1_0_0_42)
:assumption
(let (?x3524 (ite goto_symex___guard_0_0_33 c__qurt_new__sqrt__1__x_1_0_0_41 c__qurt_new__sqrt__1__x_1_0_0_43))
(flet ($x3525 (= c__qurt_new__sqrt__1__x_1_0_0_44 ?x3524))
(iff l728 $x3525)))
:assumption
l728
:assumption
(let (?x3524 (ite goto_symex___guard_0_0_33 c__qurt_new__sqrt__1__x_1_0_0_41 c__qurt_new__sqrt__1__x_1_0_0_43))
(= c__qurt_new__sqrt__1__x_1_0_0_44 ?x3524))
:assumption
(let (?x3530 (ite goto_symex___guard_0_0_33 c__qurt_new__sqrt__1__flag_1_0_0_41 c__qurt_new__sqrt__1__flag_1_0_0_42))
(flet ($x3531 (= c__qurt_new__sqrt__1__flag_1_0_0_43 ?x3530))
(iff l729 $x3531)))
:assumption
l729
:assumption
(let (?x3530 (ite goto_symex___guard_0_0_33 c__qurt_new__sqrt__1__flag_1_0_0_41 c__qurt_new__sqrt__1__flag_1_0_0_42))
(= c__qurt_new__sqrt__1__flag_1_0_0_43 ?x3530))
:assumption
(flet ($x3535 (= c__qurt_new__sqrt__1__flag_1_0_0_43 bv0[32]))
(iff l730 $x3535))
:assumption
(flet ($x3540 (xor l96 l730))
(iff l731 $x3540))
:assumption
(not l731)
:assumption
(flet ($x3535 (= c__qurt_new__sqrt__1__flag_1_0_0_43 bv0[32]))
(= goto_symex___guard_0_0_36 $x3535))
:assumption
(let (?x3550 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3555 (bvmul ?x1629 ?x3550))
(let (?x3556 (extract[95:32] ?x3555))
(let (?x3557 (sign_extend[32] ?x3556))
(let (?x3551 (bvmul ?x3550 ?x3550))
(let (?x3552 (extract[95:32] ?x3551))
(let (?x3553 (bvmul bv18446744073709551615[64] ?x3552))
(let (?x3554 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3553))
(let (?x3558 (concat ?x3554 bv0[32]))
(let (?x3559 (bvsdiv ?x3558 ?x3557))
(let (?x3560 (extract[63:0] ?x3559))
(flet ($x3561 (= c__qurt_new__sqrt__1__dx_1_0_0_32 ?x3560))
(iff l732 $x3561)))))))))))))))
:assumption
l732
:assumption
(let (?x3550 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3555 (bvmul ?x1629 ?x3550))
(let (?x3556 (extract[95:32] ?x3555))
(let (?x3557 (sign_extend[32] ?x3556))
(let (?x3551 (bvmul ?x3550 ?x3550))
(let (?x3552 (extract[95:32] ?x3551))
(let (?x3553 (bvmul bv18446744073709551615[64] ?x3552))
(let (?x3554 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3553))
(let (?x3558 (concat ?x3554 bv0[32]))
(let (?x3559 (bvsdiv ?x3558 ?x3557))
(let (?x3560 (extract[63:0] ?x3559))
(= c__qurt_new__sqrt__1__dx_1_0_0_32 ?x3560))))))))))))))
:assumption
(let (?x3581 (bvadd c__qurt_new__sqrt__1__x_1_0_0_44 c__qurt_new__sqrt__1__dx_1_0_0_32))
(flet ($x3582 (= c__qurt_new__sqrt__1__x_1_0_0_45 ?x3581))
(iff l733 $x3582)))
:assumption
l733
:assumption
(let (?x3581 (bvadd c__qurt_new__sqrt__1__x_1_0_0_44 c__qurt_new__sqrt__1__dx_1_0_0_32))
(= c__qurt_new__sqrt__1__x_1_0_0_45 ?x3581))
:assumption
(let (?x3587 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_45))
(let (?x3588 (bvmul ?x3587 ?x3587))
(let (?x3589 (extract[95:32] ?x3588))
(let (?x3590 (bvmul bv18446744073709551615[64] ?x3589))
(let (?x3591 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3590))
(flet ($x3592 (= c__qurt_new__sqrt__1__diff_1_0_0_32 ?x3591))
(iff l734 $x3592)))))))
:assumption
l734
:assumption
(let (?x3587 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_45))
(let (?x3588 (bvmul ?x3587 ?x3587))
(let (?x3589 (extract[95:32] ?x3588))
(let (?x3590 (bvmul bv18446744073709551615[64] ?x3589))
(let (?x3591 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3590))
(= c__qurt_new__sqrt__1__diff_1_0_0_32 ?x3591))))))
:assumption
(flet ($x3597 (= c__qurt_new__fabs__n_13_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_32))
(iff l735 $x3597))
:assumption
l735
:assumption
(= c__qurt_new__fabs__n_13_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_32)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3602 (bvsge c__qurt_new__fabs__n_13_0_0_1 ?x1542))
(iff l736 $x3602)))
:assumption
(flet ($x3609 (xor l98 l736))
(iff l737 $x3609))
:assumption
(not l737)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3602 (bvsge c__qurt_new__fabs__n_13_0_0_1 ?x1542))
(= goto_symex___guard_0_0_37 $x3602)))
:assumption
(flet ($x3620 (= c__qurt_new__fabs__1__f_13_0_0_1 c__qurt_new__fabs__n_13_0_0_1))
(iff l738 $x3620))
:assumption
l738
:assumption
(= c__qurt_new__fabs__1__f_13_0_0_1 c__qurt_new__fabs__n_13_0_0_1)
:assumption
(let (?x3626 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_13_0_0_1))
(flet ($x3627 (= c__qurt_new__fabs__1__f_13_0_0_3 ?x3626))
(iff l739 $x3627)))
:assumption
l739
:assumption
(let (?x3626 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_13_0_0_1))
(= c__qurt_new__fabs__1__f_13_0_0_3 ?x3626))
:assumption
(let (?x3632 (ite goto_symex___guard_0_0_37 c__qurt_new__fabs__1__f_13_0_0_1 c__qurt_new__fabs__1__f_13_0_0_3))
(flet ($x3633 (= c__qurt_new__fabs__1__f_13_0_0_4 ?x3632))
(iff l740 $x3633)))
:assumption
l740
:assumption
(let (?x3632 (ite goto_symex___guard_0_0_37 c__qurt_new__fabs__1__f_13_0_0_1 c__qurt_new__fabs__1__f_13_0_0_3))
(= c__qurt_new__fabs__1__f_13_0_0_4 ?x3632))
:assumption
(flet ($x3638 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_32 c__qurt_new__fabs__1__f_13_0_0_4))
(iff l741 $x3638))
:assumption
l741
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_32 c__qurt_new__fabs__1__f_13_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3643 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_32 ?x1828))
(iff l742 $x3643)))
:assumption
(flet ($x3648 (xor l101 l742))
(iff l743 $x3648))
:assumption
(not l743)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3643 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_32 ?x1828))
(= goto_symex___guard_0_0_38 $x3643)))
:assumption
(flet ($x3659 (= c__qurt_new__sqrt__1__flag_1_0_0_44 bv1[32]))
(iff l744 $x3659))
:assumption
l744
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_44 bv1[32])
:assumption
(flet ($x3665 (not goto_symex___guard_0_0_38))
(let (?x3666 (ite $x3665 c__qurt_new__sqrt__1__flag_1_0_0_43 c__qurt_new__sqrt__1__flag_1_0_0_44))
(flet ($x3667 (= c__qurt_new__sqrt__1__flag_1_0_0_45 ?x3666))
(iff l745 $x3667))))
:assumption
l745
:assumption
(flet ($x3665 (not goto_symex___guard_0_0_38))
(let (?x3666 (ite $x3665 c__qurt_new__sqrt__1__flag_1_0_0_43 c__qurt_new__sqrt__1__flag_1_0_0_44))
(= c__qurt_new__sqrt__1__flag_1_0_0_45 ?x3666)))
:assumption
(flet ($x3674 (= c__qurt_new__sqrt__1__x_1_0_0_46 c__qurt_new__sqrt__1__x_1_0_0_44))
(iff l746 $x3674))
:assumption
l746
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_46 c__qurt_new__sqrt__1__x_1_0_0_44)
:assumption
(flet ($x3680 (= c__qurt_new__sqrt__1__flag_1_0_0_46 c__qurt_new__sqrt__1__flag_1_0_0_43))
(iff l747 $x3680))
:assumption
l747
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_46 c__qurt_new__sqrt__1__flag_1_0_0_43)
:assumption
(flet ($x3686 (= c__qurt_new__sqrt__1__x_1_0_0_47 c__qurt_new__sqrt__1__x_1_0_0_46))
(iff l748 $x3686))
:assumption
l748
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_47 c__qurt_new__sqrt__1__x_1_0_0_46)
:assumption
(let (?x3692 (ite goto_symex___guard_0_0_36 c__qurt_new__sqrt__1__x_1_0_0_45 c__qurt_new__sqrt__1__x_1_0_0_47))
(flet ($x3693 (= c__qurt_new__sqrt__1__x_1_0_0_48 ?x3692))
(iff l749 $x3693)))
:assumption
l749
:assumption
(let (?x3692 (ite goto_symex___guard_0_0_36 c__qurt_new__sqrt__1__x_1_0_0_45 c__qurt_new__sqrt__1__x_1_0_0_47))
(= c__qurt_new__sqrt__1__x_1_0_0_48 ?x3692))
:assumption
(let (?x3698 (ite goto_symex___guard_0_0_36 c__qurt_new__sqrt__1__flag_1_0_0_45 c__qurt_new__sqrt__1__flag_1_0_0_46))
(flet ($x3699 (= c__qurt_new__sqrt__1__flag_1_0_0_47 ?x3698))
(iff l750 $x3699)))
:assumption
l750
:assumption
(let (?x3698 (ite goto_symex___guard_0_0_36 c__qurt_new__sqrt__1__flag_1_0_0_45 c__qurt_new__sqrt__1__flag_1_0_0_46))
(= c__qurt_new__sqrt__1__flag_1_0_0_47 ?x3698))
:assumption
(flet ($x3703 (= c__qurt_new__sqrt__1__flag_1_0_0_47 bv0[32]))
(iff l751 $x3703))
:assumption
(flet ($x3708 (xor l104 l751))
(iff l752 $x3708))
:assumption
(not l752)
:assumption
(flet ($x3703 (= c__qurt_new__sqrt__1__flag_1_0_0_47 bv0[32]))
(= goto_symex___guard_0_0_39 $x3703))
:assumption
(let (?x3718 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3723 (bvmul ?x1629 ?x3718))
(let (?x3724 (extract[95:32] ?x3723))
(let (?x3725 (sign_extend[32] ?x3724))
(let (?x3719 (bvmul ?x3718 ?x3718))
(let (?x3720 (extract[95:32] ?x3719))
(let (?x3721 (bvmul bv18446744073709551615[64] ?x3720))
(let (?x3722 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3721))
(let (?x3726 (concat ?x3722 bv0[32]))
(let (?x3727 (bvsdiv ?x3726 ?x3725))
(let (?x3728 (extract[63:0] ?x3727))
(flet ($x3729 (= c__qurt_new__sqrt__1__dx_1_0_0_35 ?x3728))
(iff l753 $x3729)))))))))))))))
:assumption
l753
:assumption
(let (?x3718 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3723 (bvmul ?x1629 ?x3718))
(let (?x3724 (extract[95:32] ?x3723))
(let (?x3725 (sign_extend[32] ?x3724))
(let (?x3719 (bvmul ?x3718 ?x3718))
(let (?x3720 (extract[95:32] ?x3719))
(let (?x3721 (bvmul bv18446744073709551615[64] ?x3720))
(let (?x3722 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3721))
(let (?x3726 (concat ?x3722 bv0[32]))
(let (?x3727 (bvsdiv ?x3726 ?x3725))
(let (?x3728 (extract[63:0] ?x3727))
(= c__qurt_new__sqrt__1__dx_1_0_0_35 ?x3728))))))))))))))
:assumption
(let (?x3749 (bvadd c__qurt_new__sqrt__1__x_1_0_0_48 c__qurt_new__sqrt__1__dx_1_0_0_35))
(flet ($x3750 (= c__qurt_new__sqrt__1__x_1_0_0_49 ?x3749))
(iff l754 $x3750)))
:assumption
l754
:assumption
(let (?x3749 (bvadd c__qurt_new__sqrt__1__x_1_0_0_48 c__qurt_new__sqrt__1__dx_1_0_0_35))
(= c__qurt_new__sqrt__1__x_1_0_0_49 ?x3749))
:assumption
(let (?x3755 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_49))
(let (?x3756 (bvmul ?x3755 ?x3755))
(let (?x3757 (extract[95:32] ?x3756))
(let (?x3758 (bvmul bv18446744073709551615[64] ?x3757))
(let (?x3759 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3758))
(flet ($x3760 (= c__qurt_new__sqrt__1__diff_1_0_0_35 ?x3759))
(iff l755 $x3760)))))))
:assumption
l755
:assumption
(let (?x3755 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_49))
(let (?x3756 (bvmul ?x3755 ?x3755))
(let (?x3757 (extract[95:32] ?x3756))
(let (?x3758 (bvmul bv18446744073709551615[64] ?x3757))
(let (?x3759 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3758))
(= c__qurt_new__sqrt__1__diff_1_0_0_35 ?x3759))))))
:assumption
(flet ($x3765 (= c__qurt_new__fabs__n_14_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_35))
(iff l756 $x3765))
:assumption
l756
:assumption
(= c__qurt_new__fabs__n_14_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_35)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3770 (bvsge c__qurt_new__fabs__n_14_0_0_1 ?x1542))
(iff l757 $x3770)))
:assumption
(flet ($x3777 (xor l106 l757))
(iff l758 $x3777))
:assumption
(not l758)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3770 (bvsge c__qurt_new__fabs__n_14_0_0_1 ?x1542))
(= goto_symex___guard_0_0_40 $x3770)))
:assumption
(flet ($x3788 (= c__qurt_new__fabs__1__f_14_0_0_1 c__qurt_new__fabs__n_14_0_0_1))
(iff l759 $x3788))
:assumption
l759
:assumption
(= c__qurt_new__fabs__1__f_14_0_0_1 c__qurt_new__fabs__n_14_0_0_1)
:assumption
(let (?x3794 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_14_0_0_1))
(flet ($x3795 (= c__qurt_new__fabs__1__f_14_0_0_3 ?x3794))
(iff l760 $x3795)))
:assumption
l760
:assumption
(let (?x3794 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_14_0_0_1))
(= c__qurt_new__fabs__1__f_14_0_0_3 ?x3794))
:assumption
(let (?x3800 (ite goto_symex___guard_0_0_40 c__qurt_new__fabs__1__f_14_0_0_1 c__qurt_new__fabs__1__f_14_0_0_3))
(flet ($x3801 (= c__qurt_new__fabs__1__f_14_0_0_4 ?x3800))
(iff l761 $x3801)))
:assumption
l761
:assumption
(let (?x3800 (ite goto_symex___guard_0_0_40 c__qurt_new__fabs__1__f_14_0_0_1 c__qurt_new__fabs__1__f_14_0_0_3))
(= c__qurt_new__fabs__1__f_14_0_0_4 ?x3800))
:assumption
(flet ($x3806 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_35 c__qurt_new__fabs__1__f_14_0_0_4))
(iff l762 $x3806))
:assumption
l762
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_35 c__qurt_new__fabs__1__f_14_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3811 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_35 ?x1828))
(iff l763 $x3811)))
:assumption
(flet ($x3816 (xor l109 l763))
(iff l764 $x3816))
:assumption
(not l764)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3811 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_35 ?x1828))
(= goto_symex___guard_0_0_41 $x3811)))
:assumption
(flet ($x3827 (= c__qurt_new__sqrt__1__flag_1_0_0_48 bv1[32]))
(iff l765 $x3827))
:assumption
l765
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_48 bv1[32])
:assumption
(flet ($x3833 (not goto_symex___guard_0_0_41))
(let (?x3834 (ite $x3833 c__qurt_new__sqrt__1__flag_1_0_0_47 c__qurt_new__sqrt__1__flag_1_0_0_48))
(flet ($x3835 (= c__qurt_new__sqrt__1__flag_1_0_0_49 ?x3834))
(iff l766 $x3835))))
:assumption
l766
:assumption
(flet ($x3833 (not goto_symex___guard_0_0_41))
(let (?x3834 (ite $x3833 c__qurt_new__sqrt__1__flag_1_0_0_47 c__qurt_new__sqrt__1__flag_1_0_0_48))
(= c__qurt_new__sqrt__1__flag_1_0_0_49 ?x3834)))
:assumption
(flet ($x3842 (= c__qurt_new__sqrt__1__x_1_0_0_50 c__qurt_new__sqrt__1__x_1_0_0_48))
(iff l767 $x3842))
:assumption
l767
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_50 c__qurt_new__sqrt__1__x_1_0_0_48)
:assumption
(flet ($x3848 (= c__qurt_new__sqrt__1__flag_1_0_0_50 c__qurt_new__sqrt__1__flag_1_0_0_47))
(iff l768 $x3848))
:assumption
l768
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_50 c__qurt_new__sqrt__1__flag_1_0_0_47)
:assumption
(flet ($x3854 (= c__qurt_new__sqrt__1__x_1_0_0_51 c__qurt_new__sqrt__1__x_1_0_0_50))
(iff l769 $x3854))
:assumption
l769
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_51 c__qurt_new__sqrt__1__x_1_0_0_50)
:assumption
(let (?x3860 (ite goto_symex___guard_0_0_39 c__qurt_new__sqrt__1__x_1_0_0_49 c__qurt_new__sqrt__1__x_1_0_0_51))
(flet ($x3861 (= c__qurt_new__sqrt__1__x_1_0_0_52 ?x3860))
(iff l770 $x3861)))
:assumption
l770
:assumption
(let (?x3860 (ite goto_symex___guard_0_0_39 c__qurt_new__sqrt__1__x_1_0_0_49 c__qurt_new__sqrt__1__x_1_0_0_51))
(= c__qurt_new__sqrt__1__x_1_0_0_52 ?x3860))
:assumption
(let (?x3866 (ite goto_symex___guard_0_0_39 c__qurt_new__sqrt__1__flag_1_0_0_49 c__qurt_new__sqrt__1__flag_1_0_0_50))
(flet ($x3867 (= c__qurt_new__sqrt__1__flag_1_0_0_51 ?x3866))
(iff l771 $x3867)))
:assumption
l771
:assumption
(let (?x3866 (ite goto_symex___guard_0_0_39 c__qurt_new__sqrt__1__flag_1_0_0_49 c__qurt_new__sqrt__1__flag_1_0_0_50))
(= c__qurt_new__sqrt__1__flag_1_0_0_51 ?x3866))
:assumption
(flet ($x3871 (= c__qurt_new__sqrt__1__flag_1_0_0_51 bv0[32]))
(iff l772 $x3871))
:assumption
(flet ($x3876 (xor l112 l772))
(iff l773 $x3876))
:assumption
(not l773)
:assumption
(flet ($x3871 (= c__qurt_new__sqrt__1__flag_1_0_0_51 bv0[32]))
(= goto_symex___guard_0_0_42 $x3871))
:assumption
(let (?x3886 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3891 (bvmul ?x1629 ?x3886))
(let (?x3892 (extract[95:32] ?x3891))
(let (?x3893 (sign_extend[32] ?x3892))
(let (?x3887 (bvmul ?x3886 ?x3886))
(let (?x3888 (extract[95:32] ?x3887))
(let (?x3889 (bvmul bv18446744073709551615[64] ?x3888))
(let (?x3890 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3889))
(let (?x3894 (concat ?x3890 bv0[32]))
(let (?x3895 (bvsdiv ?x3894 ?x3893))
(let (?x3896 (extract[63:0] ?x3895))
(flet ($x3897 (= c__qurt_new__sqrt__1__dx_1_0_0_38 ?x3896))
(iff l774 $x3897)))))))))))))))
:assumption
l774
:assumption
(let (?x3886 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3891 (bvmul ?x1629 ?x3886))
(let (?x3892 (extract[95:32] ?x3891))
(let (?x3893 (sign_extend[32] ?x3892))
(let (?x3887 (bvmul ?x3886 ?x3886))
(let (?x3888 (extract[95:32] ?x3887))
(let (?x3889 (bvmul bv18446744073709551615[64] ?x3888))
(let (?x3890 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3889))
(let (?x3894 (concat ?x3890 bv0[32]))
(let (?x3895 (bvsdiv ?x3894 ?x3893))
(let (?x3896 (extract[63:0] ?x3895))
(= c__qurt_new__sqrt__1__dx_1_0_0_38 ?x3896))))))))))))))
:assumption
(let (?x3917 (bvadd c__qurt_new__sqrt__1__x_1_0_0_52 c__qurt_new__sqrt__1__dx_1_0_0_38))
(flet ($x3918 (= c__qurt_new__sqrt__1__x_1_0_0_53 ?x3917))
(iff l775 $x3918)))
:assumption
l775
:assumption
(let (?x3917 (bvadd c__qurt_new__sqrt__1__x_1_0_0_52 c__qurt_new__sqrt__1__dx_1_0_0_38))
(= c__qurt_new__sqrt__1__x_1_0_0_53 ?x3917))
:assumption
(let (?x3923 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_53))
(let (?x3924 (bvmul ?x3923 ?x3923))
(let (?x3925 (extract[95:32] ?x3924))
(let (?x3926 (bvmul bv18446744073709551615[64] ?x3925))
(let (?x3927 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3926))
(flet ($x3928 (= c__qurt_new__sqrt__1__diff_1_0_0_38 ?x3927))
(iff l776 $x3928)))))))
:assumption
l776
:assumption
(let (?x3923 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_53))
(let (?x3924 (bvmul ?x3923 ?x3923))
(let (?x3925 (extract[95:32] ?x3924))
(let (?x3926 (bvmul bv18446744073709551615[64] ?x3925))
(let (?x3927 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x3926))
(= c__qurt_new__sqrt__1__diff_1_0_0_38 ?x3927))))))
:assumption
(flet ($x3933 (= c__qurt_new__fabs__n_15_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_38))
(iff l777 $x3933))
:assumption
l777
:assumption
(= c__qurt_new__fabs__n_15_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_38)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3938 (bvsge c__qurt_new__fabs__n_15_0_0_1 ?x1542))
(iff l778 $x3938)))
:assumption
(flet ($x3945 (xor l114 l778))
(iff l779 $x3945))
:assumption
(not l779)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x3938 (bvsge c__qurt_new__fabs__n_15_0_0_1 ?x1542))
(= goto_symex___guard_0_0_43 $x3938)))
:assumption
(flet ($x3956 (= c__qurt_new__fabs__1__f_15_0_0_1 c__qurt_new__fabs__n_15_0_0_1))
(iff l780 $x3956))
:assumption
l780
:assumption
(= c__qurt_new__fabs__1__f_15_0_0_1 c__qurt_new__fabs__n_15_0_0_1)
:assumption
(let (?x3962 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_15_0_0_1))
(flet ($x3963 (= c__qurt_new__fabs__1__f_15_0_0_3 ?x3962))
(iff l781 $x3963)))
:assumption
l781
:assumption
(let (?x3962 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_15_0_0_1))
(= c__qurt_new__fabs__1__f_15_0_0_3 ?x3962))
:assumption
(let (?x3968 (ite goto_symex___guard_0_0_43 c__qurt_new__fabs__1__f_15_0_0_1 c__qurt_new__fabs__1__f_15_0_0_3))
(flet ($x3969 (= c__qurt_new__fabs__1__f_15_0_0_4 ?x3968))
(iff l782 $x3969)))
:assumption
l782
:assumption
(let (?x3968 (ite goto_symex___guard_0_0_43 c__qurt_new__fabs__1__f_15_0_0_1 c__qurt_new__fabs__1__f_15_0_0_3))
(= c__qurt_new__fabs__1__f_15_0_0_4 ?x3968))
:assumption
(flet ($x3974 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_38 c__qurt_new__fabs__1__f_15_0_0_4))
(iff l783 $x3974))
:assumption
l783
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_38 c__qurt_new__fabs__1__f_15_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3979 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_38 ?x1828))
(iff l784 $x3979)))
:assumption
(flet ($x3984 (xor l117 l784))
(iff l785 $x3984))
:assumption
(not l785)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x3979 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_38 ?x1828))
(= goto_symex___guard_0_0_44 $x3979)))
:assumption
(flet ($x3995 (= c__qurt_new__sqrt__1__flag_1_0_0_52 bv1[32]))
(iff l786 $x3995))
:assumption
l786
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_52 bv1[32])
:assumption
(flet ($x4001 (not goto_symex___guard_0_0_44))
(let (?x4002 (ite $x4001 c__qurt_new__sqrt__1__flag_1_0_0_51 c__qurt_new__sqrt__1__flag_1_0_0_52))
(flet ($x4003 (= c__qurt_new__sqrt__1__flag_1_0_0_53 ?x4002))
(iff l787 $x4003))))
:assumption
l787
:assumption
(flet ($x4001 (not goto_symex___guard_0_0_44))
(let (?x4002 (ite $x4001 c__qurt_new__sqrt__1__flag_1_0_0_51 c__qurt_new__sqrt__1__flag_1_0_0_52))
(= c__qurt_new__sqrt__1__flag_1_0_0_53 ?x4002)))
:assumption
(flet ($x4010 (= c__qurt_new__sqrt__1__x_1_0_0_54 c__qurt_new__sqrt__1__x_1_0_0_52))
(iff l788 $x4010))
:assumption
l788
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_54 c__qurt_new__sqrt__1__x_1_0_0_52)
:assumption
(flet ($x4016 (= c__qurt_new__sqrt__1__flag_1_0_0_54 c__qurt_new__sqrt__1__flag_1_0_0_51))
(iff l789 $x4016))
:assumption
l789
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_54 c__qurt_new__sqrt__1__flag_1_0_0_51)
:assumption
(flet ($x4022 (= c__qurt_new__sqrt__1__x_1_0_0_55 c__qurt_new__sqrt__1__x_1_0_0_54))
(iff l790 $x4022))
:assumption
l790
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_55 c__qurt_new__sqrt__1__x_1_0_0_54)
:assumption
(let (?x4028 (ite goto_symex___guard_0_0_42 c__qurt_new__sqrt__1__x_1_0_0_53 c__qurt_new__sqrt__1__x_1_0_0_55))
(flet ($x4029 (= c__qurt_new__sqrt__1__x_1_0_0_56 ?x4028))
(iff l791 $x4029)))
:assumption
l791
:assumption
(let (?x4028 (ite goto_symex___guard_0_0_42 c__qurt_new__sqrt__1__x_1_0_0_53 c__qurt_new__sqrt__1__x_1_0_0_55))
(= c__qurt_new__sqrt__1__x_1_0_0_56 ?x4028))
:assumption
(let (?x4034 (ite goto_symex___guard_0_0_42 c__qurt_new__sqrt__1__flag_1_0_0_53 c__qurt_new__sqrt__1__flag_1_0_0_54))
(flet ($x4035 (= c__qurt_new__sqrt__1__flag_1_0_0_55 ?x4034))
(iff l792 $x4035)))
:assumption
l792
:assumption
(let (?x4034 (ite goto_symex___guard_0_0_42 c__qurt_new__sqrt__1__flag_1_0_0_53 c__qurt_new__sqrt__1__flag_1_0_0_54))
(= c__qurt_new__sqrt__1__flag_1_0_0_55 ?x4034))
:assumption
(flet ($x4039 (= c__qurt_new__sqrt__1__flag_1_0_0_55 bv0[32]))
(iff l793 $x4039))
:assumption
(flet ($x4044 (xor l120 l793))
(iff l794 $x4044))
:assumption
(not l794)
:assumption
(flet ($x4039 (= c__qurt_new__sqrt__1__flag_1_0_0_55 bv0[32]))
(= goto_symex___guard_0_0_45 $x4039))
:assumption
(let (?x4054 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4059 (bvmul ?x1629 ?x4054))
(let (?x4060 (extract[95:32] ?x4059))
(let (?x4061 (sign_extend[32] ?x4060))
(let (?x4055 (bvmul ?x4054 ?x4054))
(let (?x4056 (extract[95:32] ?x4055))
(let (?x4057 (bvmul bv18446744073709551615[64] ?x4056))
(let (?x4058 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4057))
(let (?x4062 (concat ?x4058 bv0[32]))
(let (?x4063 (bvsdiv ?x4062 ?x4061))
(let (?x4064 (extract[63:0] ?x4063))
(flet ($x4065 (= c__qurt_new__sqrt__1__dx_1_0_0_41 ?x4064))
(iff l795 $x4065)))))))))))))))
:assumption
l795
:assumption
(let (?x4054 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4059 (bvmul ?x1629 ?x4054))
(let (?x4060 (extract[95:32] ?x4059))
(let (?x4061 (sign_extend[32] ?x4060))
(let (?x4055 (bvmul ?x4054 ?x4054))
(let (?x4056 (extract[95:32] ?x4055))
(let (?x4057 (bvmul bv18446744073709551615[64] ?x4056))
(let (?x4058 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4057))
(let (?x4062 (concat ?x4058 bv0[32]))
(let (?x4063 (bvsdiv ?x4062 ?x4061))
(let (?x4064 (extract[63:0] ?x4063))
(= c__qurt_new__sqrt__1__dx_1_0_0_41 ?x4064))))))))))))))
:assumption
(let (?x4085 (bvadd c__qurt_new__sqrt__1__x_1_0_0_56 c__qurt_new__sqrt__1__dx_1_0_0_41))
(flet ($x4086 (= c__qurt_new__sqrt__1__x_1_0_0_57 ?x4085))
(iff l796 $x4086)))
:assumption
l796
:assumption
(let (?x4085 (bvadd c__qurt_new__sqrt__1__x_1_0_0_56 c__qurt_new__sqrt__1__dx_1_0_0_41))
(= c__qurt_new__sqrt__1__x_1_0_0_57 ?x4085))
:assumption
(let (?x4091 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_57))
(let (?x4092 (bvmul ?x4091 ?x4091))
(let (?x4093 (extract[95:32] ?x4092))
(let (?x4094 (bvmul bv18446744073709551615[64] ?x4093))
(let (?x4095 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4094))
(flet ($x4096 (= c__qurt_new__sqrt__1__diff_1_0_0_41 ?x4095))
(iff l797 $x4096)))))))
:assumption
l797
:assumption
(let (?x4091 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_57))
(let (?x4092 (bvmul ?x4091 ?x4091))
(let (?x4093 (extract[95:32] ?x4092))
(let (?x4094 (bvmul bv18446744073709551615[64] ?x4093))
(let (?x4095 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4094))
(= c__qurt_new__sqrt__1__diff_1_0_0_41 ?x4095))))))
:assumption
(flet ($x4101 (= c__qurt_new__fabs__n_16_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_41))
(iff l798 $x4101))
:assumption
l798
:assumption
(= c__qurt_new__fabs__n_16_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_41)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4106 (bvsge c__qurt_new__fabs__n_16_0_0_1 ?x1542))
(iff l799 $x4106)))
:assumption
(flet ($x4113 (xor l122 l799))
(iff l800 $x4113))
:assumption
(not l800)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4106 (bvsge c__qurt_new__fabs__n_16_0_0_1 ?x1542))
(= goto_symex___guard_0_0_46 $x4106)))
:assumption
(flet ($x4124 (= c__qurt_new__fabs__1__f_16_0_0_1 c__qurt_new__fabs__n_16_0_0_1))
(iff l801 $x4124))
:assumption
l801
:assumption
(= c__qurt_new__fabs__1__f_16_0_0_1 c__qurt_new__fabs__n_16_0_0_1)
:assumption
(let (?x4130 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_16_0_0_1))
(flet ($x4131 (= c__qurt_new__fabs__1__f_16_0_0_3 ?x4130))
(iff l802 $x4131)))
:assumption
l802
:assumption
(let (?x4130 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_16_0_0_1))
(= c__qurt_new__fabs__1__f_16_0_0_3 ?x4130))
:assumption
(let (?x4136 (ite goto_symex___guard_0_0_46 c__qurt_new__fabs__1__f_16_0_0_1 c__qurt_new__fabs__1__f_16_0_0_3))
(flet ($x4137 (= c__qurt_new__fabs__1__f_16_0_0_4 ?x4136))
(iff l803 $x4137)))
:assumption
l803
:assumption
(let (?x4136 (ite goto_symex___guard_0_0_46 c__qurt_new__fabs__1__f_16_0_0_1 c__qurt_new__fabs__1__f_16_0_0_3))
(= c__qurt_new__fabs__1__f_16_0_0_4 ?x4136))
:assumption
(flet ($x4142 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_41 c__qurt_new__fabs__1__f_16_0_0_4))
(iff l804 $x4142))
:assumption
l804
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_41 c__qurt_new__fabs__1__f_16_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4147 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_41 ?x1828))
(iff l805 $x4147)))
:assumption
(flet ($x4152 (xor l125 l805))
(iff l806 $x4152))
:assumption
(not l806)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4147 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_41 ?x1828))
(= goto_symex___guard_0_0_47 $x4147)))
:assumption
(flet ($x4163 (= c__qurt_new__sqrt__1__flag_1_0_0_56 bv1[32]))
(iff l807 $x4163))
:assumption
l807
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_56 bv1[32])
:assumption
(flet ($x4169 (not goto_symex___guard_0_0_47))
(let (?x4170 (ite $x4169 c__qurt_new__sqrt__1__flag_1_0_0_55 c__qurt_new__sqrt__1__flag_1_0_0_56))
(flet ($x4171 (= c__qurt_new__sqrt__1__flag_1_0_0_57 ?x4170))
(iff l808 $x4171))))
:assumption
l808
:assumption
(flet ($x4169 (not goto_symex___guard_0_0_47))
(let (?x4170 (ite $x4169 c__qurt_new__sqrt__1__flag_1_0_0_55 c__qurt_new__sqrt__1__flag_1_0_0_56))
(= c__qurt_new__sqrt__1__flag_1_0_0_57 ?x4170)))
:assumption
(flet ($x4178 (= c__qurt_new__sqrt__1__x_1_0_0_58 c__qurt_new__sqrt__1__x_1_0_0_56))
(iff l809 $x4178))
:assumption
l809
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_58 c__qurt_new__sqrt__1__x_1_0_0_56)
:assumption
(flet ($x4184 (= c__qurt_new__sqrt__1__flag_1_0_0_58 c__qurt_new__sqrt__1__flag_1_0_0_55))
(iff l810 $x4184))
:assumption
l810
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_58 c__qurt_new__sqrt__1__flag_1_0_0_55)
:assumption
(flet ($x4190 (= c__qurt_new__sqrt__1__x_1_0_0_59 c__qurt_new__sqrt__1__x_1_0_0_58))
(iff l811 $x4190))
:assumption
l811
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_59 c__qurt_new__sqrt__1__x_1_0_0_58)
:assumption
(let (?x4196 (ite goto_symex___guard_0_0_45 c__qurt_new__sqrt__1__x_1_0_0_57 c__qurt_new__sqrt__1__x_1_0_0_59))
(flet ($x4197 (= c__qurt_new__sqrt__1__x_1_0_0_60 ?x4196))
(iff l812 $x4197)))
:assumption
l812
:assumption
(let (?x4196 (ite goto_symex___guard_0_0_45 c__qurt_new__sqrt__1__x_1_0_0_57 c__qurt_new__sqrt__1__x_1_0_0_59))
(= c__qurt_new__sqrt__1__x_1_0_0_60 ?x4196))
:assumption
(let (?x4202 (ite goto_symex___guard_0_0_45 c__qurt_new__sqrt__1__flag_1_0_0_57 c__qurt_new__sqrt__1__flag_1_0_0_58))
(flet ($x4203 (= c__qurt_new__sqrt__1__flag_1_0_0_59 ?x4202))
(iff l813 $x4203)))
:assumption
l813
:assumption
(let (?x4202 (ite goto_symex___guard_0_0_45 c__qurt_new__sqrt__1__flag_1_0_0_57 c__qurt_new__sqrt__1__flag_1_0_0_58))
(= c__qurt_new__sqrt__1__flag_1_0_0_59 ?x4202))
:assumption
(flet ($x4207 (= c__qurt_new__sqrt__1__flag_1_0_0_59 bv0[32]))
(iff l814 $x4207))
:assumption
(flet ($x4212 (xor l128 l814))
(iff l815 $x4212))
:assumption
(not l815)
:assumption
(flet ($x4207 (= c__qurt_new__sqrt__1__flag_1_0_0_59 bv0[32]))
(= goto_symex___guard_0_0_48 $x4207))
:assumption
(let (?x4222 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4227 (bvmul ?x1629 ?x4222))
(let (?x4228 (extract[95:32] ?x4227))
(let (?x4229 (sign_extend[32] ?x4228))
(let (?x4223 (bvmul ?x4222 ?x4222))
(let (?x4224 (extract[95:32] ?x4223))
(let (?x4225 (bvmul bv18446744073709551615[64] ?x4224))
(let (?x4226 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4225))
(let (?x4230 (concat ?x4226 bv0[32]))
(let (?x4231 (bvsdiv ?x4230 ?x4229))
(let (?x4232 (extract[63:0] ?x4231))
(flet ($x4233 (= c__qurt_new__sqrt__1__dx_1_0_0_44 ?x4232))
(iff l816 $x4233)))))))))))))))
:assumption
l816
:assumption
(let (?x4222 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4227 (bvmul ?x1629 ?x4222))
(let (?x4228 (extract[95:32] ?x4227))
(let (?x4229 (sign_extend[32] ?x4228))
(let (?x4223 (bvmul ?x4222 ?x4222))
(let (?x4224 (extract[95:32] ?x4223))
(let (?x4225 (bvmul bv18446744073709551615[64] ?x4224))
(let (?x4226 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4225))
(let (?x4230 (concat ?x4226 bv0[32]))
(let (?x4231 (bvsdiv ?x4230 ?x4229))
(let (?x4232 (extract[63:0] ?x4231))
(= c__qurt_new__sqrt__1__dx_1_0_0_44 ?x4232))))))))))))))
:assumption
(let (?x4253 (bvadd c__qurt_new__sqrt__1__x_1_0_0_60 c__qurt_new__sqrt__1__dx_1_0_0_44))
(flet ($x4254 (= c__qurt_new__sqrt__1__x_1_0_0_61 ?x4253))
(iff l817 $x4254)))
:assumption
l817
:assumption
(let (?x4253 (bvadd c__qurt_new__sqrt__1__x_1_0_0_60 c__qurt_new__sqrt__1__dx_1_0_0_44))
(= c__qurt_new__sqrt__1__x_1_0_0_61 ?x4253))
:assumption
(let (?x4259 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_61))
(let (?x4260 (bvmul ?x4259 ?x4259))
(let (?x4261 (extract[95:32] ?x4260))
(let (?x4262 (bvmul bv18446744073709551615[64] ?x4261))
(let (?x4263 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4262))
(flet ($x4264 (= c__qurt_new__sqrt__1__diff_1_0_0_44 ?x4263))
(iff l818 $x4264)))))))
:assumption
l818
:assumption
(let (?x4259 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_61))
(let (?x4260 (bvmul ?x4259 ?x4259))
(let (?x4261 (extract[95:32] ?x4260))
(let (?x4262 (bvmul bv18446744073709551615[64] ?x4261))
(let (?x4263 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4262))
(= c__qurt_new__sqrt__1__diff_1_0_0_44 ?x4263))))))
:assumption
(flet ($x4269 (= c__qurt_new__fabs__n_17_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_44))
(iff l819 $x4269))
:assumption
l819
:assumption
(= c__qurt_new__fabs__n_17_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_44)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4274 (bvsge c__qurt_new__fabs__n_17_0_0_1 ?x1542))
(iff l820 $x4274)))
:assumption
(flet ($x4281 (xor l130 l820))
(iff l821 $x4281))
:assumption
(not l821)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4274 (bvsge c__qurt_new__fabs__n_17_0_0_1 ?x1542))
(= goto_symex___guard_0_0_49 $x4274)))
:assumption
(flet ($x4292 (= c__qurt_new__fabs__1__f_17_0_0_1 c__qurt_new__fabs__n_17_0_0_1))
(iff l822 $x4292))
:assumption
l822
:assumption
(= c__qurt_new__fabs__1__f_17_0_0_1 c__qurt_new__fabs__n_17_0_0_1)
:assumption
(let (?x4298 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_17_0_0_1))
(flet ($x4299 (= c__qurt_new__fabs__1__f_17_0_0_3 ?x4298))
(iff l823 $x4299)))
:assumption
l823
:assumption
(let (?x4298 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_17_0_0_1))
(= c__qurt_new__fabs__1__f_17_0_0_3 ?x4298))
:assumption
(let (?x4304 (ite goto_symex___guard_0_0_49 c__qurt_new__fabs__1__f_17_0_0_1 c__qurt_new__fabs__1__f_17_0_0_3))
(flet ($x4305 (= c__qurt_new__fabs__1__f_17_0_0_4 ?x4304))
(iff l824 $x4305)))
:assumption
l824
:assumption
(let (?x4304 (ite goto_symex___guard_0_0_49 c__qurt_new__fabs__1__f_17_0_0_1 c__qurt_new__fabs__1__f_17_0_0_3))
(= c__qurt_new__fabs__1__f_17_0_0_4 ?x4304))
:assumption
(flet ($x4310 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_44 c__qurt_new__fabs__1__f_17_0_0_4))
(iff l825 $x4310))
:assumption
l825
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_44 c__qurt_new__fabs__1__f_17_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4315 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_44 ?x1828))
(iff l826 $x4315)))
:assumption
(flet ($x4320 (xor l133 l826))
(iff l827 $x4320))
:assumption
(not l827)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4315 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_44 ?x1828))
(= goto_symex___guard_0_0_50 $x4315)))
:assumption
(flet ($x4331 (= c__qurt_new__sqrt__1__flag_1_0_0_60 bv1[32]))
(iff l828 $x4331))
:assumption
l828
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_60 bv1[32])
:assumption
(flet ($x4337 (not goto_symex___guard_0_0_50))
(let (?x4338 (ite $x4337 c__qurt_new__sqrt__1__flag_1_0_0_59 c__qurt_new__sqrt__1__flag_1_0_0_60))
(flet ($x4339 (= c__qurt_new__sqrt__1__flag_1_0_0_61 ?x4338))
(iff l829 $x4339))))
:assumption
l829
:assumption
(flet ($x4337 (not goto_symex___guard_0_0_50))
(let (?x4338 (ite $x4337 c__qurt_new__sqrt__1__flag_1_0_0_59 c__qurt_new__sqrt__1__flag_1_0_0_60))
(= c__qurt_new__sqrt__1__flag_1_0_0_61 ?x4338)))
:assumption
(flet ($x4346 (= c__qurt_new__sqrt__1__x_1_0_0_62 c__qurt_new__sqrt__1__x_1_0_0_60))
(iff l830 $x4346))
:assumption
l830
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_62 c__qurt_new__sqrt__1__x_1_0_0_60)
:assumption
(flet ($x4352 (= c__qurt_new__sqrt__1__flag_1_0_0_62 c__qurt_new__sqrt__1__flag_1_0_0_59))
(iff l831 $x4352))
:assumption
l831
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_62 c__qurt_new__sqrt__1__flag_1_0_0_59)
:assumption
(flet ($x4358 (= c__qurt_new__sqrt__1__x_1_0_0_63 c__qurt_new__sqrt__1__x_1_0_0_62))
(iff l832 $x4358))
:assumption
l832
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_63 c__qurt_new__sqrt__1__x_1_0_0_62)
:assumption
(let (?x4364 (ite goto_symex___guard_0_0_48 c__qurt_new__sqrt__1__x_1_0_0_61 c__qurt_new__sqrt__1__x_1_0_0_63))
(flet ($x4365 (= c__qurt_new__sqrt__1__x_1_0_0_64 ?x4364))
(iff l833 $x4365)))
:assumption
l833
:assumption
(let (?x4364 (ite goto_symex___guard_0_0_48 c__qurt_new__sqrt__1__x_1_0_0_61 c__qurt_new__sqrt__1__x_1_0_0_63))
(= c__qurt_new__sqrt__1__x_1_0_0_64 ?x4364))
:assumption
(let (?x4370 (ite goto_symex___guard_0_0_48 c__qurt_new__sqrt__1__flag_1_0_0_61 c__qurt_new__sqrt__1__flag_1_0_0_62))
(flet ($x4371 (= c__qurt_new__sqrt__1__flag_1_0_0_63 ?x4370))
(iff l834 $x4371)))
:assumption
l834
:assumption
(let (?x4370 (ite goto_symex___guard_0_0_48 c__qurt_new__sqrt__1__flag_1_0_0_61 c__qurt_new__sqrt__1__flag_1_0_0_62))
(= c__qurt_new__sqrt__1__flag_1_0_0_63 ?x4370))
:assumption
(flet ($x4375 (= c__qurt_new__sqrt__1__flag_1_0_0_63 bv0[32]))
(iff l835 $x4375))
:assumption
(flet ($x4380 (xor l136 l835))
(iff l836 $x4380))
:assumption
(not l836)
:assumption
(flet ($x4375 (= c__qurt_new__sqrt__1__flag_1_0_0_63 bv0[32]))
(= goto_symex___guard_0_0_51 $x4375))
:assumption
(let (?x4390 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4395 (bvmul ?x1629 ?x4390))
(let (?x4396 (extract[95:32] ?x4395))
(let (?x4397 (sign_extend[32] ?x4396))
(let (?x4391 (bvmul ?x4390 ?x4390))
(let (?x4392 (extract[95:32] ?x4391))
(let (?x4393 (bvmul bv18446744073709551615[64] ?x4392))
(let (?x4394 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4393))
(let (?x4398 (concat ?x4394 bv0[32]))
(let (?x4399 (bvsdiv ?x4398 ?x4397))
(let (?x4400 (extract[63:0] ?x4399))
(flet ($x4401 (= c__qurt_new__sqrt__1__dx_1_0_0_47 ?x4400))
(iff l837 $x4401)))))))))))))))
:assumption
l837
:assumption
(let (?x4390 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4395 (bvmul ?x1629 ?x4390))
(let (?x4396 (extract[95:32] ?x4395))
(let (?x4397 (sign_extend[32] ?x4396))
(let (?x4391 (bvmul ?x4390 ?x4390))
(let (?x4392 (extract[95:32] ?x4391))
(let (?x4393 (bvmul bv18446744073709551615[64] ?x4392))
(let (?x4394 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4393))
(let (?x4398 (concat ?x4394 bv0[32]))
(let (?x4399 (bvsdiv ?x4398 ?x4397))
(let (?x4400 (extract[63:0] ?x4399))
(= c__qurt_new__sqrt__1__dx_1_0_0_47 ?x4400))))))))))))))
:assumption
(let (?x4421 (bvadd c__qurt_new__sqrt__1__x_1_0_0_64 c__qurt_new__sqrt__1__dx_1_0_0_47))
(flet ($x4422 (= c__qurt_new__sqrt__1__x_1_0_0_65 ?x4421))
(iff l838 $x4422)))
:assumption
l838
:assumption
(let (?x4421 (bvadd c__qurt_new__sqrt__1__x_1_0_0_64 c__qurt_new__sqrt__1__dx_1_0_0_47))
(= c__qurt_new__sqrt__1__x_1_0_0_65 ?x4421))
:assumption
(let (?x4427 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_65))
(let (?x4428 (bvmul ?x4427 ?x4427))
(let (?x4429 (extract[95:32] ?x4428))
(let (?x4430 (bvmul bv18446744073709551615[64] ?x4429))
(let (?x4431 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4430))
(flet ($x4432 (= c__qurt_new__sqrt__1__diff_1_0_0_47 ?x4431))
(iff l839 $x4432)))))))
:assumption
l839
:assumption
(let (?x4427 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_65))
(let (?x4428 (bvmul ?x4427 ?x4427))
(let (?x4429 (extract[95:32] ?x4428))
(let (?x4430 (bvmul bv18446744073709551615[64] ?x4429))
(let (?x4431 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4430))
(= c__qurt_new__sqrt__1__diff_1_0_0_47 ?x4431))))))
:assumption
(flet ($x4437 (= c__qurt_new__fabs__n_18_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_47))
(iff l840 $x4437))
:assumption
l840
:assumption
(= c__qurt_new__fabs__n_18_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_47)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4442 (bvsge c__qurt_new__fabs__n_18_0_0_1 ?x1542))
(iff l841 $x4442)))
:assumption
(flet ($x4449 (xor l138 l841))
(iff l842 $x4449))
:assumption
(not l842)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4442 (bvsge c__qurt_new__fabs__n_18_0_0_1 ?x1542))
(= goto_symex___guard_0_0_52 $x4442)))
:assumption
(flet ($x4460 (= c__qurt_new__fabs__1__f_18_0_0_1 c__qurt_new__fabs__n_18_0_0_1))
(iff l843 $x4460))
:assumption
l843
:assumption
(= c__qurt_new__fabs__1__f_18_0_0_1 c__qurt_new__fabs__n_18_0_0_1)
:assumption
(let (?x4466 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_18_0_0_1))
(flet ($x4467 (= c__qurt_new__fabs__1__f_18_0_0_3 ?x4466))
(iff l844 $x4467)))
:assumption
l844
:assumption
(let (?x4466 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_18_0_0_1))
(= c__qurt_new__fabs__1__f_18_0_0_3 ?x4466))
:assumption
(let (?x4472 (ite goto_symex___guard_0_0_52 c__qurt_new__fabs__1__f_18_0_0_1 c__qurt_new__fabs__1__f_18_0_0_3))
(flet ($x4473 (= c__qurt_new__fabs__1__f_18_0_0_4 ?x4472))
(iff l845 $x4473)))
:assumption
l845
:assumption
(let (?x4472 (ite goto_symex___guard_0_0_52 c__qurt_new__fabs__1__f_18_0_0_1 c__qurt_new__fabs__1__f_18_0_0_3))
(= c__qurt_new__fabs__1__f_18_0_0_4 ?x4472))
:assumption
(flet ($x4478 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_47 c__qurt_new__fabs__1__f_18_0_0_4))
(iff l846 $x4478))
:assumption
l846
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_47 c__qurt_new__fabs__1__f_18_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4483 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_47 ?x1828))
(iff l847 $x4483)))
:assumption
(flet ($x4488 (xor l141 l847))
(iff l848 $x4488))
:assumption
(not l848)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4483 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_47 ?x1828))
(= goto_symex___guard_0_0_53 $x4483)))
:assumption
(flet ($x4499 (= c__qurt_new__sqrt__1__flag_1_0_0_64 bv1[32]))
(iff l849 $x4499))
:assumption
l849
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_64 bv1[32])
:assumption
(flet ($x4505 (not goto_symex___guard_0_0_53))
(let (?x4506 (ite $x4505 c__qurt_new__sqrt__1__flag_1_0_0_63 c__qurt_new__sqrt__1__flag_1_0_0_64))
(flet ($x4507 (= c__qurt_new__sqrt__1__flag_1_0_0_65 ?x4506))
(iff l850 $x4507))))
:assumption
l850
:assumption
(flet ($x4505 (not goto_symex___guard_0_0_53))
(let (?x4506 (ite $x4505 c__qurt_new__sqrt__1__flag_1_0_0_63 c__qurt_new__sqrt__1__flag_1_0_0_64))
(= c__qurt_new__sqrt__1__flag_1_0_0_65 ?x4506)))
:assumption
(flet ($x4514 (= c__qurt_new__sqrt__1__x_1_0_0_66 c__qurt_new__sqrt__1__x_1_0_0_64))
(iff l851 $x4514))
:assumption
l851
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_66 c__qurt_new__sqrt__1__x_1_0_0_64)
:assumption
(flet ($x4520 (= c__qurt_new__sqrt__1__flag_1_0_0_66 c__qurt_new__sqrt__1__flag_1_0_0_63))
(iff l852 $x4520))
:assumption
l852
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_66 c__qurt_new__sqrt__1__flag_1_0_0_63)
:assumption
(flet ($x4526 (= c__qurt_new__sqrt__1__x_1_0_0_67 c__qurt_new__sqrt__1__x_1_0_0_66))
(iff l853 $x4526))
:assumption
l853
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_67 c__qurt_new__sqrt__1__x_1_0_0_66)
:assumption
(let (?x4532 (ite goto_symex___guard_0_0_51 c__qurt_new__sqrt__1__x_1_0_0_65 c__qurt_new__sqrt__1__x_1_0_0_67))
(flet ($x4533 (= c__qurt_new__sqrt__1__x_1_0_0_68 ?x4532))
(iff l854 $x4533)))
:assumption
l854
:assumption
(let (?x4532 (ite goto_symex___guard_0_0_51 c__qurt_new__sqrt__1__x_1_0_0_65 c__qurt_new__sqrt__1__x_1_0_0_67))
(= c__qurt_new__sqrt__1__x_1_0_0_68 ?x4532))
:assumption
(let (?x4538 (ite goto_symex___guard_0_0_51 c__qurt_new__sqrt__1__flag_1_0_0_65 c__qurt_new__sqrt__1__flag_1_0_0_66))
(flet ($x4539 (= c__qurt_new__sqrt__1__flag_1_0_0_67 ?x4538))
(iff l855 $x4539)))
:assumption
l855
:assumption
(let (?x4538 (ite goto_symex___guard_0_0_51 c__qurt_new__sqrt__1__flag_1_0_0_65 c__qurt_new__sqrt__1__flag_1_0_0_66))
(= c__qurt_new__sqrt__1__flag_1_0_0_67 ?x4538))
:assumption
(flet ($x4543 (= c__qurt_new__sqrt__1__flag_1_0_0_67 bv0[32]))
(iff l856 $x4543))
:assumption
(flet ($x4548 (xor l144 l856))
(iff l857 $x4548))
:assumption
(not l857)
:assumption
(flet ($x4543 (= c__qurt_new__sqrt__1__flag_1_0_0_67 bv0[32]))
(= goto_symex___guard_0_0_54 $x4543))
:assumption
(let (?x4558 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4563 (bvmul ?x1629 ?x4558))
(let (?x4564 (extract[95:32] ?x4563))
(let (?x4565 (sign_extend[32] ?x4564))
(let (?x4559 (bvmul ?x4558 ?x4558))
(let (?x4560 (extract[95:32] ?x4559))
(let (?x4561 (bvmul bv18446744073709551615[64] ?x4560))
(let (?x4562 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4561))
(let (?x4566 (concat ?x4562 bv0[32]))
(let (?x4567 (bvsdiv ?x4566 ?x4565))
(let (?x4568 (extract[63:0] ?x4567))
(flet ($x4569 (= c__qurt_new__sqrt__1__dx_1_0_0_50 ?x4568))
(iff l858 $x4569)))))))))))))))
:assumption
l858
:assumption
(let (?x4558 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4563 (bvmul ?x1629 ?x4558))
(let (?x4564 (extract[95:32] ?x4563))
(let (?x4565 (sign_extend[32] ?x4564))
(let (?x4559 (bvmul ?x4558 ?x4558))
(let (?x4560 (extract[95:32] ?x4559))
(let (?x4561 (bvmul bv18446744073709551615[64] ?x4560))
(let (?x4562 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4561))
(let (?x4566 (concat ?x4562 bv0[32]))
(let (?x4567 (bvsdiv ?x4566 ?x4565))
(let (?x4568 (extract[63:0] ?x4567))
(= c__qurt_new__sqrt__1__dx_1_0_0_50 ?x4568))))))))))))))
:assumption
(let (?x4589 (bvadd c__qurt_new__sqrt__1__x_1_0_0_68 c__qurt_new__sqrt__1__dx_1_0_0_50))
(flet ($x4590 (= c__qurt_new__sqrt__1__x_1_0_0_69 ?x4589))
(iff l859 $x4590)))
:assumption
l859
:assumption
(let (?x4589 (bvadd c__qurt_new__sqrt__1__x_1_0_0_68 c__qurt_new__sqrt__1__dx_1_0_0_50))
(= c__qurt_new__sqrt__1__x_1_0_0_69 ?x4589))
:assumption
(let (?x4595 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_69))
(let (?x4596 (bvmul ?x4595 ?x4595))
(let (?x4597 (extract[95:32] ?x4596))
(let (?x4598 (bvmul bv18446744073709551615[64] ?x4597))
(let (?x4599 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4598))
(flet ($x4600 (= c__qurt_new__sqrt__1__diff_1_0_0_50 ?x4599))
(iff l860 $x4600)))))))
:assumption
l860
:assumption
(let (?x4595 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_69))
(let (?x4596 (bvmul ?x4595 ?x4595))
(let (?x4597 (extract[95:32] ?x4596))
(let (?x4598 (bvmul bv18446744073709551615[64] ?x4597))
(let (?x4599 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4598))
(= c__qurt_new__sqrt__1__diff_1_0_0_50 ?x4599))))))
:assumption
(flet ($x4605 (= c__qurt_new__fabs__n_19_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_50))
(iff l861 $x4605))
:assumption
l861
:assumption
(= c__qurt_new__fabs__n_19_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_50)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4610 (bvsge c__qurt_new__fabs__n_19_0_0_1 ?x1542))
(iff l862 $x4610)))
:assumption
(flet ($x4617 (xor l146 l862))
(iff l863 $x4617))
:assumption
(not l863)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4610 (bvsge c__qurt_new__fabs__n_19_0_0_1 ?x1542))
(= goto_symex___guard_0_0_55 $x4610)))
:assumption
(flet ($x4628 (= c__qurt_new__fabs__1__f_19_0_0_1 c__qurt_new__fabs__n_19_0_0_1))
(iff l864 $x4628))
:assumption
l864
:assumption
(= c__qurt_new__fabs__1__f_19_0_0_1 c__qurt_new__fabs__n_19_0_0_1)
:assumption
(let (?x4634 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_19_0_0_1))
(flet ($x4635 (= c__qurt_new__fabs__1__f_19_0_0_3 ?x4634))
(iff l865 $x4635)))
:assumption
l865
:assumption
(let (?x4634 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_19_0_0_1))
(= c__qurt_new__fabs__1__f_19_0_0_3 ?x4634))
:assumption
(let (?x4640 (ite goto_symex___guard_0_0_55 c__qurt_new__fabs__1__f_19_0_0_1 c__qurt_new__fabs__1__f_19_0_0_3))
(flet ($x4641 (= c__qurt_new__fabs__1__f_19_0_0_4 ?x4640))
(iff l866 $x4641)))
:assumption
l866
:assumption
(let (?x4640 (ite goto_symex___guard_0_0_55 c__qurt_new__fabs__1__f_19_0_0_1 c__qurt_new__fabs__1__f_19_0_0_3))
(= c__qurt_new__fabs__1__f_19_0_0_4 ?x4640))
:assumption
(flet ($x4646 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_50 c__qurt_new__fabs__1__f_19_0_0_4))
(iff l867 $x4646))
:assumption
l867
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_50 c__qurt_new__fabs__1__f_19_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4651 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_50 ?x1828))
(iff l868 $x4651)))
:assumption
(flet ($x4656 (xor l149 l868))
(iff l869 $x4656))
:assumption
(not l869)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4651 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_50 ?x1828))
(= goto_symex___guard_0_0_56 $x4651)))
:assumption
(flet ($x4667 (= c__qurt_new__sqrt__1__flag_1_0_0_68 bv1[32]))
(iff l870 $x4667))
:assumption
l870
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_68 bv1[32])
:assumption
(flet ($x4673 (not goto_symex___guard_0_0_56))
(let (?x4674 (ite $x4673 c__qurt_new__sqrt__1__flag_1_0_0_67 c__qurt_new__sqrt__1__flag_1_0_0_68))
(flet ($x4675 (= c__qurt_new__sqrt__1__flag_1_0_0_69 ?x4674))
(iff l871 $x4675))))
:assumption
l871
:assumption
(flet ($x4673 (not goto_symex___guard_0_0_56))
(let (?x4674 (ite $x4673 c__qurt_new__sqrt__1__flag_1_0_0_67 c__qurt_new__sqrt__1__flag_1_0_0_68))
(= c__qurt_new__sqrt__1__flag_1_0_0_69 ?x4674)))
:assumption
(flet ($x4682 (= c__qurt_new__sqrt__1__x_1_0_0_70 c__qurt_new__sqrt__1__x_1_0_0_68))
(iff l872 $x4682))
:assumption
l872
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_70 c__qurt_new__sqrt__1__x_1_0_0_68)
:assumption
(flet ($x4688 (= c__qurt_new__sqrt__1__flag_1_0_0_70 c__qurt_new__sqrt__1__flag_1_0_0_67))
(iff l873 $x4688))
:assumption
l873
:assumption
(= c__qurt_new__sqrt__1__flag_1_0_0_70 c__qurt_new__sqrt__1__flag_1_0_0_67)
:assumption
(flet ($x4694 (= c__qurt_new__sqrt__1__x_1_0_0_71 c__qurt_new__sqrt__1__x_1_0_0_70))
(iff l874 $x4694))
:assumption
l874
:assumption
(= c__qurt_new__sqrt__1__x_1_0_0_71 c__qurt_new__sqrt__1__x_1_0_0_70)
:assumption
(let (?x4700 (ite goto_symex___guard_0_0_54 c__qurt_new__sqrt__1__x_1_0_0_69 c__qurt_new__sqrt__1__x_1_0_0_71))
(flet ($x4701 (= c__qurt_new__sqrt__1__x_1_0_0_72 ?x4700))
(iff l875 $x4701)))
:assumption
l875
:assumption
(let (?x4700 (ite goto_symex___guard_0_0_54 c__qurt_new__sqrt__1__x_1_0_0_69 c__qurt_new__sqrt__1__x_1_0_0_71))
(= c__qurt_new__sqrt__1__x_1_0_0_72 ?x4700))
:assumption
(let (?x4706 (ite goto_symex___guard_0_0_54 c__qurt_new__sqrt__1__flag_1_0_0_69 c__qurt_new__sqrt__1__flag_1_0_0_70))
(flet ($x4707 (= c__qurt_new__sqrt__1__flag_1_0_0_71 ?x4706))
(iff l876 $x4707)))
:assumption
l876
:assumption
(let (?x4706 (ite goto_symex___guard_0_0_54 c__qurt_new__sqrt__1__flag_1_0_0_69 c__qurt_new__sqrt__1__flag_1_0_0_70))
(= c__qurt_new__sqrt__1__flag_1_0_0_71 ?x4706))
:assumption
(flet ($x4711 (= c__qurt_new__sqrt__1__flag_1_0_0_71 bv0[32]))
(iff l877 $x4711))
:assumption
(flet ($x4716 (xor l152 l877))
(iff l878 $x4716))
:assumption
(not l878)
:assumption
(flet ($x4711 (= c__qurt_new__sqrt__1__flag_1_0_0_71 bv0[32]))
(= goto_symex___guard_0_0_57 $x4711))
:assumption
(let (?x4727 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4732 (bvmul ?x1629 ?x4727))
(let (?x4733 (extract[95:32] ?x4732))
(let (?x4734 (sign_extend[32] ?x4733))
(let (?x4728 (bvmul ?x4727 ?x4727))
(let (?x4729 (extract[95:32] ?x4728))
(let (?x4730 (bvmul bv18446744073709551615[64] ?x4729))
(let (?x4731 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4730))
(let (?x4735 (concat ?x4731 bv0[32]))
(let (?x4736 (bvsdiv ?x4735 ?x4734))
(let (?x4737 (extract[63:0] ?x4736))
(flet ($x4738 (= c__qurt_new__sqrt__1__dx_1_0_0_53 ?x4737))
(iff l879 $x4738)))))))))))))))
:assumption
l879
:assumption
(let (?x4727 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4732 (bvmul ?x1629 ?x4727))
(let (?x4733 (extract[95:32] ?x4732))
(let (?x4734 (sign_extend[32] ?x4733))
(let (?x4728 (bvmul ?x4727 ?x4727))
(let (?x4729 (extract[95:32] ?x4728))
(let (?x4730 (bvmul bv18446744073709551615[64] ?x4729))
(let (?x4731 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4730))
(let (?x4735 (concat ?x4731 bv0[32]))
(let (?x4736 (bvsdiv ?x4735 ?x4734))
(let (?x4737 (extract[63:0] ?x4736))
(= c__qurt_new__sqrt__1__dx_1_0_0_53 ?x4737))))))))))))))
:assumption
(let (?x4758 (bvadd c__qurt_new__sqrt__1__x_1_0_0_72 c__qurt_new__sqrt__1__dx_1_0_0_53))
(flet ($x4759 (= c__qurt_new__sqrt__1__x_1_0_0_73 ?x4758))
(iff l880 $x4759)))
:assumption
l880
:assumption
(let (?x4758 (bvadd c__qurt_new__sqrt__1__x_1_0_0_72 c__qurt_new__sqrt__1__dx_1_0_0_53))
(= c__qurt_new__sqrt__1__x_1_0_0_73 ?x4758))
:assumption
(let (?x4764 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_73))
(let (?x4765 (bvmul ?x4764 ?x4764))
(let (?x4766 (extract[95:32] ?x4765))
(let (?x4767 (bvmul bv18446744073709551615[64] ?x4766))
(let (?x4768 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4767))
(flet ($x4769 (= c__qurt_new__sqrt__1__diff_1_0_0_53 ?x4768))
(iff l881 $x4769)))))))
:assumption
l881
:assumption
(let (?x4764 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_73))
(let (?x4765 (bvmul ?x4764 ?x4764))
(let (?x4766 (extract[95:32] ?x4765))
(let (?x4767 (bvmul bv18446744073709551615[64] ?x4766))
(let (?x4768 (bvadd c__qurt_new__sqrt__val_1_0_0_1 ?x4767))
(= c__qurt_new__sqrt__1__diff_1_0_0_53 ?x4768))))))
:assumption
(flet ($x4774 (= c__qurt_new__fabs__n_20_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_53))
(iff l882 $x4774))
:assumption
l882
:assumption
(= c__qurt_new__fabs__n_20_0_0_1 c__qurt_new__sqrt__1__diff_1_0_0_53)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4779 (bvsge c__qurt_new__fabs__n_20_0_0_1 ?x1542))
(iff l883 $x4779)))
:assumption
(flet ($x4786 (xor l154 l883))
(iff l884 $x4786))
:assumption
(not l884)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4779 (bvsge c__qurt_new__fabs__n_20_0_0_1 ?x1542))
(= goto_symex___guard_0_0_58 $x4779)))
:assumption
(flet ($x4797 (= c__qurt_new__fabs__1__f_20_0_0_1 c__qurt_new__fabs__n_20_0_0_1))
(iff l885 $x4797))
:assumption
l885
:assumption
(= c__qurt_new__fabs__1__f_20_0_0_1 c__qurt_new__fabs__n_20_0_0_1)
:assumption
(let (?x4803 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_20_0_0_1))
(flet ($x4804 (= c__qurt_new__fabs__1__f_20_0_0_3 ?x4803))
(iff l886 $x4804)))
:assumption
l886
:assumption
(let (?x4803 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_20_0_0_1))
(= c__qurt_new__fabs__1__f_20_0_0_3 ?x4803))
:assumption
(let (?x4809 (ite goto_symex___guard_0_0_58 c__qurt_new__fabs__1__f_20_0_0_1 c__qurt_new__fabs__1__f_20_0_0_3))
(flet ($x4810 (= c__qurt_new__fabs__1__f_20_0_0_4 ?x4809))
(iff l887 $x4810)))
:assumption
l887
:assumption
(let (?x4809 (ite goto_symex___guard_0_0_58 c__qurt_new__fabs__1__f_20_0_0_1 c__qurt_new__fabs__1__f_20_0_0_3))
(= c__qurt_new__fabs__1__f_20_0_0_4 ?x4809))
:assumption
(flet ($x4815 (= c__sqrt___tmp__return_value_fabs_2_1_0_0_53 c__qurt_new__fabs__1__f_20_0_0_4))
(iff l888 $x4815))
:assumption
l888
:assumption
(= c__sqrt___tmp__return_value_fabs_2_1_0_0_53 c__qurt_new__fabs__1__f_20_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4820 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_53 ?x1828))
(iff l890 $x4820)))
:assumption
(flet ($x4826 (xor l889 l890))
(iff l891 $x4826))
:assumption
(not l891)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x4820 (bvsle c__sqrt___tmp__return_value_fabs_2_1_0_0_53 ?x1828))
(= goto_symex___guard_0_0_59 $x4820)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4836 (bvsgt c__qurt_new__qurt__1__d_1_0_0_1 ?x1542))
(iff l892 $x4836)))
:assumption
(flet ($x4844 (xor l157 l892))
(iff l893 $x4844))
:assumption
(not l893)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4836 (bvsgt c__qurt_new__qurt__1__d_1_0_0_1 ?x1542))
(= goto_symex___guard_0_0_60 $x4836)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4854 (= c__qurt_new__qurt__1__d_1_0_0_1 ?x1542))
(iff l894 $x4854)))
:assumption
(flet ($x4859 (xor l160 l894))
(iff l895 $x4859))
:assumption
(not l895)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4854 (= c__qurt_new__qurt__1__d_1_0_0_1 ?x1542))
(= goto_symex___guard_0_0_61 $x4854)))
:assumption
(let (?x4870 (store c__a_0_4 bv0[32] nondet_symex__nondet3))
(flet ($x4871 (= c__a_0_5 ?x4870))
(iff l896 $x4871)))
:assumption
l896
:assumption
(let (?x4870 (store c__a_0_4 bv0[32] nondet_symex__nondet3))
(= c__a_0_5 ?x4870))
:assumption
(let (?x4877 (store c__a_0_5 bv1[32] nondet_symex__nondet4))
(flet ($x4878 (= c__a_0_6 ?x4877))
(iff l897 $x4878)))
:assumption
l897
:assumption
(let (?x4877 (store c__a_0_5 bv1[32] nondet_symex__nondet4))
(= c__a_0_6 ?x4877))
:assumption
(let (?x4884 (store c__a_0_6 bv2[32] nondet_symex__nondet5))
(flet ($x4885 (= c__a_0_7 ?x4884))
(iff l898 $x4885)))
:assumption
l898
:assumption
(let (?x4884 (store c__a_0_6 bv2[32] nondet_symex__nondet5))
(= c__a_0_7 ?x4884))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4889 (select c__a_0_7 bv0[32]))
(flet ($x4890 (= ?x4889 ?x1542))
(iff l899 $x4890))))
:assumption
(flet ($x4895 (xor l163 l899))
(iff l900 $x4895))
:assumption
(not l900)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4889 (select c__a_0_7 bv0[32]))
(flet ($x4890 (= ?x4889 ?x1542))
(= goto_symex___guard_0_0_62 $x4890))))
:assumption
(let (?x4913 (select c__a_0_7 bv2[32]))
(let (?x4914 (sign_extend[32] ?x4913))
(let (?x4889 (select c__a_0_7 bv0[32]))
(let (?x4909 (sign_extend[32] ?x4889))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x4910 (bvmul ?x1601 ?x4909))
(let (?x4911 (extract[95:32] ?x4910))
(let (?x4912 (sign_extend[32] ?x4911))
(let (?x4915 (bvmul ?x4912 ?x4914))
(let (?x4916 (extract[95:32] ?x4915))
(let (?x4917 (bvmul bv18446744073709551615[64] ?x4916))
(let (?x4905 (select c__a_0_7 bv1[32]))
(let (?x4906 (sign_extend[32] ?x4905))
(let (?x4907 (bvmul ?x4906 ?x4906))
(let (?x4908 (extract[95:32] ?x4907))
(let (?x4918 (bvadd ?x4908 ?x4917))
(flet ($x4919 (= c__qurt_new__qurt__1__d_2_0_0_1 ?x4918))
(iff l901 $x4919)))))))))))))))))))
:assumption
l901
:assumption
(let (?x4913 (select c__a_0_7 bv2[32]))
(let (?x4914 (sign_extend[32] ?x4913))
(let (?x4889 (select c__a_0_7 bv0[32]))
(let (?x4909 (sign_extend[32] ?x4889))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x4910 (bvmul ?x1601 ?x4909))
(let (?x4911 (extract[95:32] ?x4910))
(let (?x4912 (sign_extend[32] ?x4911))
(let (?x4915 (bvmul ?x4912 ?x4914))
(let (?x4916 (extract[95:32] ?x4915))
(let (?x4917 (bvmul bv18446744073709551615[64] ?x4916))
(let (?x4905 (select c__a_0_7 bv1[32]))
(let (?x4906 (sign_extend[32] ?x4905))
(let (?x4907 (bvmul ?x4906 ?x4906))
(let (?x4908 (extract[95:32] ?x4907))
(let (?x4918 (bvadd ?x4908 ?x4917))
(= c__qurt_new__qurt__1__d_2_0_0_1 ?x4918))))))))))))))))))
:assumption
(let (?x4889 (select c__a_0_7 bv0[32]))
(let (?x4909 (sign_extend[32] ?x4889))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4932 (bvmul ?x1629 ?x4909))
(let (?x4933 (extract[95:32] ?x4932))
(flet ($x4934 (= c__qurt_new__qurt__1__w1_2_0_0_1 ?x4933))
(iff l902 $x4934))))))))
:assumption
l902
:assumption
(let (?x4889 (select c__a_0_7 bv0[32]))
(let (?x4909 (sign_extend[32] ?x4889))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4932 (bvmul ?x1629 ?x4909))
(let (?x4933 (extract[95:32] ?x4932))
(= c__qurt_new__qurt__1__w1_2_0_0_1 ?x4933)))))))
:assumption
(flet ($x4942 (= c__qurt_new__fabs__n_21_0_0_1 c__qurt_new__qurt__1__d_2_0_0_1))
(iff l903 $x4942))
:assumption
l903
:assumption
(= c__qurt_new__fabs__n_21_0_0_1 c__qurt_new__qurt__1__d_2_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4947 (bvsge c__qurt_new__fabs__n_21_0_0_1 ?x1542))
(iff l904 $x4947)))
:assumption
(flet ($x4954 (xor l166 l904))
(iff l905 $x4954))
:assumption
(not l905)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x4947 (bvsge c__qurt_new__fabs__n_21_0_0_1 ?x1542))
(= goto_symex___guard_0_0_63 $x4947)))
:assumption
(flet ($x4965 (= c__qurt_new__fabs__1__f_21_0_0_1 c__qurt_new__fabs__n_21_0_0_1))
(iff l906 $x4965))
:assumption
l906
:assumption
(= c__qurt_new__fabs__1__f_21_0_0_1 c__qurt_new__fabs__n_21_0_0_1)
:assumption
(let (?x4971 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_21_0_0_1))
(flet ($x4972 (= c__qurt_new__fabs__1__f_21_0_0_3 ?x4971))
(iff l907 $x4972)))
:assumption
l907
:assumption
(let (?x4971 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_21_0_0_1))
(= c__qurt_new__fabs__1__f_21_0_0_3 ?x4971))
:assumption
(let (?x4977 (ite goto_symex___guard_0_0_63 c__qurt_new__fabs__1__f_21_0_0_1 c__qurt_new__fabs__1__f_21_0_0_3))
(flet ($x4978 (= c__qurt_new__fabs__1__f_21_0_0_4 ?x4977))
(iff l908 $x4978)))
:assumption
l908
:assumption
(let (?x4977 (ite goto_symex___guard_0_0_63 c__qurt_new__fabs__1__f_21_0_0_1 c__qurt_new__fabs__1__f_21_0_0_3))
(= c__qurt_new__fabs__1__f_21_0_0_4 ?x4977))
:assumption
(flet ($x4983 (= c__qurt___tmp__return_value_fabs_1_2_0_0_1 c__qurt_new__fabs__1__f_21_0_0_4))
(iff l909 $x4983))
:assumption
l909
:assumption
(= c__qurt___tmp__return_value_fabs_1_2_0_0_1 c__qurt_new__fabs__1__f_21_0_0_4)
:assumption
(flet ($x4989 (= c__qurt_new__sqrt__val_2_0_0_1 c__qurt___tmp__return_value_fabs_1_2_0_0_1))
(iff l910 $x4989))
:assumption
l910
:assumption
(= c__qurt_new__sqrt__val_2_0_0_1 c__qurt___tmp__return_value_fabs_1_2_0_0_1)
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x4995 (concat c__qurt_new__sqrt__val_2_0_0_1 bv0[32]))
(let (?x4996 (bvsdiv ?x4995 ?x1697))
(let (?x4997 (extract[63:0] ?x4996))
(flet ($x4998 (= c__qurt_new__sqrt__1__x_2_0_0_1 ?x4997))
(iff l911 $x4998)))))))
:assumption
l911
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x4995 (concat c__qurt_new__sqrt__val_2_0_0_1 bv0[32]))
(let (?x4996 (bvsdiv ?x4995 ?x1697))
(let (?x4997 (extract[63:0] ?x4996))
(= c__qurt_new__sqrt__1__x_2_0_0_1 ?x4997))))))
:assumption
(flet ($x5006 (= c__qurt_new__sqrt__1__flag_2_0_0_1 bv0[32]))
(iff l912 $x5006))
:assumption
l912
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_1 bv0[32])
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5011 (= c__qurt_new__sqrt__val_2_0_0_1 ?x1542))
(iff l913 $x5011)))
:assumption
(flet ($x5016 (xor l169 l913))
(iff l914 $x5016))
:assumption
(not l914)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5011 (= c__qurt_new__sqrt__val_2_0_0_1 ?x1542))
(= goto_symex___guard_0_0_64 $x5011)))
:assumption
(flet ($x5026 (= c__qurt_new__sqrt__1__x_2_0_0_3 c__qurt_new__sqrt__1__x_2_0_0_1))
(iff l915 $x5026))
:assumption
l915
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_3 c__qurt_new__sqrt__1__x_2_0_0_1)
:assumption
(let (?x5032 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5037 (bvmul ?x1629 ?x5032))
(let (?x5038 (extract[95:32] ?x5037))
(let (?x5039 (sign_extend[32] ?x5038))
(let (?x5033 (bvmul ?x5032 ?x5032))
(let (?x5034 (extract[95:32] ?x5033))
(let (?x5035 (bvmul bv18446744073709551615[64] ?x5034))
(let (?x5036 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5035))
(let (?x5040 (concat ?x5036 bv0[32]))
(let (?x5041 (bvsdiv ?x5040 ?x5039))
(let (?x5042 (extract[63:0] ?x5041))
(flet ($x5043 (= c__qurt_new__sqrt__1__dx_2_0_0_1 ?x5042))
(iff l916 $x5043)))))))))))))))
:assumption
l916
:assumption
(let (?x5032 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5037 (bvmul ?x1629 ?x5032))
(let (?x5038 (extract[95:32] ?x5037))
(let (?x5039 (sign_extend[32] ?x5038))
(let (?x5033 (bvmul ?x5032 ?x5032))
(let (?x5034 (extract[95:32] ?x5033))
(let (?x5035 (bvmul bv18446744073709551615[64] ?x5034))
(let (?x5036 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5035))
(let (?x5040 (concat ?x5036 bv0[32]))
(let (?x5041 (bvsdiv ?x5040 ?x5039))
(let (?x5042 (extract[63:0] ?x5041))
(= c__qurt_new__sqrt__1__dx_2_0_0_1 ?x5042))))))))))))))
:assumption
(let (?x5063 (bvadd c__qurt_new__sqrt__1__x_2_0_0_3 c__qurt_new__sqrt__1__dx_2_0_0_1))
(flet ($x5064 (= c__qurt_new__sqrt__1__x_2_0_0_4 ?x5063))
(iff l917 $x5064)))
:assumption
l917
:assumption
(let (?x5063 (bvadd c__qurt_new__sqrt__1__x_2_0_0_3 c__qurt_new__sqrt__1__dx_2_0_0_1))
(= c__qurt_new__sqrt__1__x_2_0_0_4 ?x5063))
:assumption
(let (?x5069 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_4))
(let (?x5070 (bvmul ?x5069 ?x5069))
(let (?x5071 (extract[95:32] ?x5070))
(let (?x5072 (bvmul bv18446744073709551615[64] ?x5071))
(let (?x5073 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5072))
(flet ($x5074 (= c__qurt_new__sqrt__1__diff_2_0_0_1 ?x5073))
(iff l918 $x5074)))))))
:assumption
l918
:assumption
(let (?x5069 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_4))
(let (?x5070 (bvmul ?x5069 ?x5069))
(let (?x5071 (extract[95:32] ?x5070))
(let (?x5072 (bvmul bv18446744073709551615[64] ?x5071))
(let (?x5073 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5072))
(= c__qurt_new__sqrt__1__diff_2_0_0_1 ?x5073))))))
:assumption
(flet ($x5079 (= c__qurt_new__fabs__n_22_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_1))
(iff l919 $x5079))
:assumption
l919
:assumption
(= c__qurt_new__fabs__n_22_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5084 (bvsge c__qurt_new__fabs__n_22_0_0_1 ?x1542))
(iff l920 $x5084)))
:assumption
(flet ($x5091 (xor l172 l920))
(iff l921 $x5091))
:assumption
(not l921)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5084 (bvsge c__qurt_new__fabs__n_22_0_0_1 ?x1542))
(= goto_symex___guard_0_0_65 $x5084)))
:assumption
(flet ($x5102 (= c__qurt_new__fabs__1__f_22_0_0_1 c__qurt_new__fabs__n_22_0_0_1))
(iff l922 $x5102))
:assumption
l922
:assumption
(= c__qurt_new__fabs__1__f_22_0_0_1 c__qurt_new__fabs__n_22_0_0_1)
:assumption
(let (?x5108 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_22_0_0_1))
(flet ($x5109 (= c__qurt_new__fabs__1__f_22_0_0_3 ?x5108))
(iff l923 $x5109)))
:assumption
l923
:assumption
(let (?x5108 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_22_0_0_1))
(= c__qurt_new__fabs__1__f_22_0_0_3 ?x5108))
:assumption
(let (?x5114 (ite goto_symex___guard_0_0_65 c__qurt_new__fabs__1__f_22_0_0_1 c__qurt_new__fabs__1__f_22_0_0_3))
(flet ($x5115 (= c__qurt_new__fabs__1__f_22_0_0_4 ?x5114))
(iff l924 $x5115)))
:assumption
l924
:assumption
(let (?x5114 (ite goto_symex___guard_0_0_65 c__qurt_new__fabs__1__f_22_0_0_1 c__qurt_new__fabs__1__f_22_0_0_3))
(= c__qurt_new__fabs__1__f_22_0_0_4 ?x5114))
:assumption
(flet ($x5120 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_1 c__qurt_new__fabs__1__f_22_0_0_4))
(iff l925 $x5120))
:assumption
l925
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_1 c__qurt_new__fabs__1__f_22_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5125 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_1 ?x1828))
(iff l926 $x5125)))
:assumption
(flet ($x5130 (xor l175 l926))
(iff l927 $x5130))
:assumption
(not l927)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5125 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_1 ?x1828))
(= goto_symex___guard_0_0_66 $x5125)))
:assumption
(flet ($x5141 (= c__qurt_new__sqrt__1__flag_2_0_0_2 bv1[32]))
(iff l928 $x5141))
:assumption
l928
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_2 bv1[32])
:assumption
(flet ($x5147 (not goto_symex___guard_0_0_66))
(let (?x5148 (ite $x5147 c__qurt_new__sqrt__1__flag_2_0_0_1 c__qurt_new__sqrt__1__flag_2_0_0_2))
(flet ($x5149 (= c__qurt_new__sqrt__1__flag_2_0_0_3 ?x5148))
(iff l929 $x5149))))
:assumption
l929
:assumption
(flet ($x5147 (not goto_symex___guard_0_0_66))
(let (?x5148 (ite $x5147 c__qurt_new__sqrt__1__flag_2_0_0_1 c__qurt_new__sqrt__1__flag_2_0_0_2))
(= c__qurt_new__sqrt__1__flag_2_0_0_3 ?x5148)))
:assumption
(flet ($x5155 (= c__qurt_new__sqrt__1__flag_2_0_0_3 bv0[32]))
(iff l930 $x5155))
:assumption
(flet ($x5160 (xor l177 l930))
(iff l931 $x5160))
:assumption
(not l931)
:assumption
(flet ($x5155 (= c__qurt_new__sqrt__1__flag_2_0_0_3 bv0[32]))
(= goto_symex___guard_0_0_67 $x5155))
:assumption
(let (?x5069 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5170 (bvmul ?x1629 ?x5069))
(let (?x5171 (extract[95:32] ?x5170))
(let (?x5172 (sign_extend[32] ?x5171))
(let (?x5070 (bvmul ?x5069 ?x5069))
(let (?x5071 (extract[95:32] ?x5070))
(let (?x5072 (bvmul bv18446744073709551615[64] ?x5071))
(let (?x5073 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5072))
(let (?x5173 (concat ?x5073 bv0[32]))
(let (?x5174 (bvsdiv ?x5173 ?x5172))
(let (?x5175 (extract[63:0] ?x5174))
(flet ($x5176 (= c__qurt_new__sqrt__1__dx_2_0_0_2 ?x5175))
(iff l932 $x5176)))))))))))))))
:assumption
l932
:assumption
(let (?x5069 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5170 (bvmul ?x1629 ?x5069))
(let (?x5171 (extract[95:32] ?x5170))
(let (?x5172 (sign_extend[32] ?x5171))
(let (?x5070 (bvmul ?x5069 ?x5069))
(let (?x5071 (extract[95:32] ?x5070))
(let (?x5072 (bvmul bv18446744073709551615[64] ?x5071))
(let (?x5073 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5072))
(let (?x5173 (concat ?x5073 bv0[32]))
(let (?x5174 (bvsdiv ?x5173 ?x5172))
(let (?x5175 (extract[63:0] ?x5174))
(= c__qurt_new__sqrt__1__dx_2_0_0_2 ?x5175))))))))))))))
:assumption
(let (?x5196 (bvadd c__qurt_new__sqrt__1__x_2_0_0_4 c__qurt_new__sqrt__1__dx_2_0_0_2))
(flet ($x5197 (= c__qurt_new__sqrt__1__x_2_0_0_5 ?x5196))
(iff l933 $x5197)))
:assumption
l933
:assumption
(let (?x5196 (bvadd c__qurt_new__sqrt__1__x_2_0_0_4 c__qurt_new__sqrt__1__dx_2_0_0_2))
(= c__qurt_new__sqrt__1__x_2_0_0_5 ?x5196))
:assumption
(let (?x5202 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_5))
(let (?x5203 (bvmul ?x5202 ?x5202))
(let (?x5204 (extract[95:32] ?x5203))
(let (?x5205 (bvmul bv18446744073709551615[64] ?x5204))
(let (?x5206 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5205))
(flet ($x5207 (= c__qurt_new__sqrt__1__diff_2_0_0_2 ?x5206))
(iff l934 $x5207)))))))
:assumption
l934
:assumption
(let (?x5202 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_5))
(let (?x5203 (bvmul ?x5202 ?x5202))
(let (?x5204 (extract[95:32] ?x5203))
(let (?x5205 (bvmul bv18446744073709551615[64] ?x5204))
(let (?x5206 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5205))
(= c__qurt_new__sqrt__1__diff_2_0_0_2 ?x5206))))))
:assumption
(flet ($x5212 (= c__qurt_new__fabs__n_23_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_2))
(iff l935 $x5212))
:assumption
l935
:assumption
(= c__qurt_new__fabs__n_23_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_2)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5217 (bvsge c__qurt_new__fabs__n_23_0_0_1 ?x1542))
(iff l936 $x5217)))
:assumption
(flet ($x5224 (xor l179 l936))
(iff l937 $x5224))
:assumption
(not l937)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5217 (bvsge c__qurt_new__fabs__n_23_0_0_1 ?x1542))
(= goto_symex___guard_0_0_68 $x5217)))
:assumption
(flet ($x5235 (= c__qurt_new__fabs__1__f_23_0_0_1 c__qurt_new__fabs__n_23_0_0_1))
(iff l938 $x5235))
:assumption
l938
:assumption
(= c__qurt_new__fabs__1__f_23_0_0_1 c__qurt_new__fabs__n_23_0_0_1)
:assumption
(let (?x5241 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_23_0_0_1))
(flet ($x5242 (= c__qurt_new__fabs__1__f_23_0_0_3 ?x5241))
(iff l939 $x5242)))
:assumption
l939
:assumption
(let (?x5241 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_23_0_0_1))
(= c__qurt_new__fabs__1__f_23_0_0_3 ?x5241))
:assumption
(let (?x5247 (ite goto_symex___guard_0_0_68 c__qurt_new__fabs__1__f_23_0_0_1 c__qurt_new__fabs__1__f_23_0_0_3))
(flet ($x5248 (= c__qurt_new__fabs__1__f_23_0_0_4 ?x5247))
(iff l940 $x5248)))
:assumption
l940
:assumption
(let (?x5247 (ite goto_symex___guard_0_0_68 c__qurt_new__fabs__1__f_23_0_0_1 c__qurt_new__fabs__1__f_23_0_0_3))
(= c__qurt_new__fabs__1__f_23_0_0_4 ?x5247))
:assumption
(flet ($x5253 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_2 c__qurt_new__fabs__1__f_23_0_0_4))
(iff l941 $x5253))
:assumption
l941
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_2 c__qurt_new__fabs__1__f_23_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5258 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_2 ?x1828))
(iff l942 $x5258)))
:assumption
(flet ($x5263 (xor l182 l942))
(iff l943 $x5263))
:assumption
(not l943)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5258 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_2 ?x1828))
(= goto_symex___guard_0_0_69 $x5258)))
:assumption
(flet ($x5274 (= c__qurt_new__sqrt__1__flag_2_0_0_4 bv1[32]))
(iff l944 $x5274))
:assumption
l944
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_4 bv1[32])
:assumption
(flet ($x5280 (not goto_symex___guard_0_0_69))
(let (?x5281 (ite $x5280 c__qurt_new__sqrt__1__flag_2_0_0_3 c__qurt_new__sqrt__1__flag_2_0_0_4))
(flet ($x5282 (= c__qurt_new__sqrt__1__flag_2_0_0_5 ?x5281))
(iff l945 $x5282))))
:assumption
l945
:assumption
(flet ($x5280 (not goto_symex___guard_0_0_69))
(let (?x5281 (ite $x5280 c__qurt_new__sqrt__1__flag_2_0_0_3 c__qurt_new__sqrt__1__flag_2_0_0_4))
(= c__qurt_new__sqrt__1__flag_2_0_0_5 ?x5281)))
:assumption
(flet ($x5289 (= c__qurt_new__sqrt__1__x_2_0_0_6 c__qurt_new__sqrt__1__x_2_0_0_4))
(iff l946 $x5289))
:assumption
l946
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_6 c__qurt_new__sqrt__1__x_2_0_0_4)
:assumption
(flet ($x5295 (= c__qurt_new__sqrt__1__flag_2_0_0_6 c__qurt_new__sqrt__1__flag_2_0_0_3))
(iff l947 $x5295))
:assumption
l947
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_6 c__qurt_new__sqrt__1__flag_2_0_0_3)
:assumption
(flet ($x5301 (= c__qurt_new__sqrt__1__x_2_0_0_7 c__qurt_new__sqrt__1__x_2_0_0_6))
(iff l948 $x5301))
:assumption
l948
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_7 c__qurt_new__sqrt__1__x_2_0_0_6)
:assumption
(let (?x5307 (ite goto_symex___guard_0_0_67 c__qurt_new__sqrt__1__x_2_0_0_5 c__qurt_new__sqrt__1__x_2_0_0_7))
(flet ($x5308 (= c__qurt_new__sqrt__1__x_2_0_0_8 ?x5307))
(iff l949 $x5308)))
:assumption
l949
:assumption
(let (?x5307 (ite goto_symex___guard_0_0_67 c__qurt_new__sqrt__1__x_2_0_0_5 c__qurt_new__sqrt__1__x_2_0_0_7))
(= c__qurt_new__sqrt__1__x_2_0_0_8 ?x5307))
:assumption
(let (?x5313 (ite goto_symex___guard_0_0_67 c__qurt_new__sqrt__1__flag_2_0_0_5 c__qurt_new__sqrt__1__flag_2_0_0_6))
(flet ($x5314 (= c__qurt_new__sqrt__1__flag_2_0_0_7 ?x5313))
(iff l950 $x5314)))
:assumption
l950
:assumption
(let (?x5313 (ite goto_symex___guard_0_0_67 c__qurt_new__sqrt__1__flag_2_0_0_5 c__qurt_new__sqrt__1__flag_2_0_0_6))
(= c__qurt_new__sqrt__1__flag_2_0_0_7 ?x5313))
:assumption
(flet ($x5318 (= c__qurt_new__sqrt__1__flag_2_0_0_7 bv0[32]))
(iff l951 $x5318))
:assumption
(flet ($x5323 (xor l185 l951))
(iff l952 $x5323))
:assumption
(not l952)
:assumption
(flet ($x5318 (= c__qurt_new__sqrt__1__flag_2_0_0_7 bv0[32]))
(= goto_symex___guard_0_0_70 $x5318))
:assumption
(let (?x5333 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5338 (bvmul ?x1629 ?x5333))
(let (?x5339 (extract[95:32] ?x5338))
(let (?x5340 (sign_extend[32] ?x5339))
(let (?x5334 (bvmul ?x5333 ?x5333))
(let (?x5335 (extract[95:32] ?x5334))
(let (?x5336 (bvmul bv18446744073709551615[64] ?x5335))
(let (?x5337 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5336))
(let (?x5341 (concat ?x5337 bv0[32]))
(let (?x5342 (bvsdiv ?x5341 ?x5340))
(let (?x5343 (extract[63:0] ?x5342))
(flet ($x5344 (= c__qurt_new__sqrt__1__dx_2_0_0_5 ?x5343))
(iff l953 $x5344)))))))))))))))
:assumption
l953
:assumption
(let (?x5333 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5338 (bvmul ?x1629 ?x5333))
(let (?x5339 (extract[95:32] ?x5338))
(let (?x5340 (sign_extend[32] ?x5339))
(let (?x5334 (bvmul ?x5333 ?x5333))
(let (?x5335 (extract[95:32] ?x5334))
(let (?x5336 (bvmul bv18446744073709551615[64] ?x5335))
(let (?x5337 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5336))
(let (?x5341 (concat ?x5337 bv0[32]))
(let (?x5342 (bvsdiv ?x5341 ?x5340))
(let (?x5343 (extract[63:0] ?x5342))
(= c__qurt_new__sqrt__1__dx_2_0_0_5 ?x5343))))))))))))))
:assumption
(let (?x5364 (bvadd c__qurt_new__sqrt__1__x_2_0_0_8 c__qurt_new__sqrt__1__dx_2_0_0_5))
(flet ($x5365 (= c__qurt_new__sqrt__1__x_2_0_0_9 ?x5364))
(iff l954 $x5365)))
:assumption
l954
:assumption
(let (?x5364 (bvadd c__qurt_new__sqrt__1__x_2_0_0_8 c__qurt_new__sqrt__1__dx_2_0_0_5))
(= c__qurt_new__sqrt__1__x_2_0_0_9 ?x5364))
:assumption
(let (?x5370 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_9))
(let (?x5371 (bvmul ?x5370 ?x5370))
(let (?x5372 (extract[95:32] ?x5371))
(let (?x5373 (bvmul bv18446744073709551615[64] ?x5372))
(let (?x5374 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5373))
(flet ($x5375 (= c__qurt_new__sqrt__1__diff_2_0_0_5 ?x5374))
(iff l955 $x5375)))))))
:assumption
l955
:assumption
(let (?x5370 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_9))
(let (?x5371 (bvmul ?x5370 ?x5370))
(let (?x5372 (extract[95:32] ?x5371))
(let (?x5373 (bvmul bv18446744073709551615[64] ?x5372))
(let (?x5374 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5373))
(= c__qurt_new__sqrt__1__diff_2_0_0_5 ?x5374))))))
:assumption
(flet ($x5380 (= c__qurt_new__fabs__n_24_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_5))
(iff l956 $x5380))
:assumption
l956
:assumption
(= c__qurt_new__fabs__n_24_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_5)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5385 (bvsge c__qurt_new__fabs__n_24_0_0_1 ?x1542))
(iff l957 $x5385)))
:assumption
(flet ($x5392 (xor l187 l957))
(iff l958 $x5392))
:assumption
(not l958)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5385 (bvsge c__qurt_new__fabs__n_24_0_0_1 ?x1542))
(= goto_symex___guard_0_0_71 $x5385)))
:assumption
(flet ($x5403 (= c__qurt_new__fabs__1__f_24_0_0_1 c__qurt_new__fabs__n_24_0_0_1))
(iff l959 $x5403))
:assumption
l959
:assumption
(= c__qurt_new__fabs__1__f_24_0_0_1 c__qurt_new__fabs__n_24_0_0_1)
:assumption
(let (?x5409 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_24_0_0_1))
(flet ($x5410 (= c__qurt_new__fabs__1__f_24_0_0_3 ?x5409))
(iff l960 $x5410)))
:assumption
l960
:assumption
(let (?x5409 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_24_0_0_1))
(= c__qurt_new__fabs__1__f_24_0_0_3 ?x5409))
:assumption
(let (?x5415 (ite goto_symex___guard_0_0_71 c__qurt_new__fabs__1__f_24_0_0_1 c__qurt_new__fabs__1__f_24_0_0_3))
(flet ($x5416 (= c__qurt_new__fabs__1__f_24_0_0_4 ?x5415))
(iff l961 $x5416)))
:assumption
l961
:assumption
(let (?x5415 (ite goto_symex___guard_0_0_71 c__qurt_new__fabs__1__f_24_0_0_1 c__qurt_new__fabs__1__f_24_0_0_3))
(= c__qurt_new__fabs__1__f_24_0_0_4 ?x5415))
:assumption
(flet ($x5421 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_5 c__qurt_new__fabs__1__f_24_0_0_4))
(iff l962 $x5421))
:assumption
l962
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_5 c__qurt_new__fabs__1__f_24_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5426 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_5 ?x1828))
(iff l963 $x5426)))
:assumption
(flet ($x5431 (xor l190 l963))
(iff l964 $x5431))
:assumption
(not l964)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5426 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_5 ?x1828))
(= goto_symex___guard_0_0_72 $x5426)))
:assumption
(flet ($x5442 (= c__qurt_new__sqrt__1__flag_2_0_0_8 bv1[32]))
(iff l965 $x5442))
:assumption
l965
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_8 bv1[32])
:assumption
(flet ($x5448 (not goto_symex___guard_0_0_72))
(let (?x5449 (ite $x5448 c__qurt_new__sqrt__1__flag_2_0_0_7 c__qurt_new__sqrt__1__flag_2_0_0_8))
(flet ($x5450 (= c__qurt_new__sqrt__1__flag_2_0_0_9 ?x5449))
(iff l966 $x5450))))
:assumption
l966
:assumption
(flet ($x5448 (not goto_symex___guard_0_0_72))
(let (?x5449 (ite $x5448 c__qurt_new__sqrt__1__flag_2_0_0_7 c__qurt_new__sqrt__1__flag_2_0_0_8))
(= c__qurt_new__sqrt__1__flag_2_0_0_9 ?x5449)))
:assumption
(flet ($x5457 (= c__qurt_new__sqrt__1__x_2_0_0_10 c__qurt_new__sqrt__1__x_2_0_0_8))
(iff l967 $x5457))
:assumption
l967
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_10 c__qurt_new__sqrt__1__x_2_0_0_8)
:assumption
(flet ($x5463 (= c__qurt_new__sqrt__1__flag_2_0_0_10 c__qurt_new__sqrt__1__flag_2_0_0_7))
(iff l968 $x5463))
:assumption
l968
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_10 c__qurt_new__sqrt__1__flag_2_0_0_7)
:assumption
(flet ($x5469 (= c__qurt_new__sqrt__1__x_2_0_0_11 c__qurt_new__sqrt__1__x_2_0_0_10))
(iff l969 $x5469))
:assumption
l969
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_11 c__qurt_new__sqrt__1__x_2_0_0_10)
:assumption
(let (?x5475 (ite goto_symex___guard_0_0_70 c__qurt_new__sqrt__1__x_2_0_0_9 c__qurt_new__sqrt__1__x_2_0_0_11))
(flet ($x5476 (= c__qurt_new__sqrt__1__x_2_0_0_12 ?x5475))
(iff l970 $x5476)))
:assumption
l970
:assumption
(let (?x5475 (ite goto_symex___guard_0_0_70 c__qurt_new__sqrt__1__x_2_0_0_9 c__qurt_new__sqrt__1__x_2_0_0_11))
(= c__qurt_new__sqrt__1__x_2_0_0_12 ?x5475))
:assumption
(let (?x5481 (ite goto_symex___guard_0_0_70 c__qurt_new__sqrt__1__flag_2_0_0_9 c__qurt_new__sqrt__1__flag_2_0_0_10))
(flet ($x5482 (= c__qurt_new__sqrt__1__flag_2_0_0_11 ?x5481))
(iff l971 $x5482)))
:assumption
l971
:assumption
(let (?x5481 (ite goto_symex___guard_0_0_70 c__qurt_new__sqrt__1__flag_2_0_0_9 c__qurt_new__sqrt__1__flag_2_0_0_10))
(= c__qurt_new__sqrt__1__flag_2_0_0_11 ?x5481))
:assumption
(flet ($x5486 (= c__qurt_new__sqrt__1__flag_2_0_0_11 bv0[32]))
(iff l972 $x5486))
:assumption
(flet ($x5491 (xor l193 l972))
(iff l973 $x5491))
:assumption
(not l973)
:assumption
(flet ($x5486 (= c__qurt_new__sqrt__1__flag_2_0_0_11 bv0[32]))
(= goto_symex___guard_0_0_73 $x5486))
:assumption
(let (?x5501 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5506 (bvmul ?x1629 ?x5501))
(let (?x5507 (extract[95:32] ?x5506))
(let (?x5508 (sign_extend[32] ?x5507))
(let (?x5502 (bvmul ?x5501 ?x5501))
(let (?x5503 (extract[95:32] ?x5502))
(let (?x5504 (bvmul bv18446744073709551615[64] ?x5503))
(let (?x5505 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5504))
(let (?x5509 (concat ?x5505 bv0[32]))
(let (?x5510 (bvsdiv ?x5509 ?x5508))
(let (?x5511 (extract[63:0] ?x5510))
(flet ($x5512 (= c__qurt_new__sqrt__1__dx_2_0_0_8 ?x5511))
(iff l974 $x5512)))))))))))))))
:assumption
l974
:assumption
(let (?x5501 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5506 (bvmul ?x1629 ?x5501))
(let (?x5507 (extract[95:32] ?x5506))
(let (?x5508 (sign_extend[32] ?x5507))
(let (?x5502 (bvmul ?x5501 ?x5501))
(let (?x5503 (extract[95:32] ?x5502))
(let (?x5504 (bvmul bv18446744073709551615[64] ?x5503))
(let (?x5505 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5504))
(let (?x5509 (concat ?x5505 bv0[32]))
(let (?x5510 (bvsdiv ?x5509 ?x5508))
(let (?x5511 (extract[63:0] ?x5510))
(= c__qurt_new__sqrt__1__dx_2_0_0_8 ?x5511))))))))))))))
:assumption
(let (?x5532 (bvadd c__qurt_new__sqrt__1__x_2_0_0_12 c__qurt_new__sqrt__1__dx_2_0_0_8))
(flet ($x5533 (= c__qurt_new__sqrt__1__x_2_0_0_13 ?x5532))
(iff l975 $x5533)))
:assumption
l975
:assumption
(let (?x5532 (bvadd c__qurt_new__sqrt__1__x_2_0_0_12 c__qurt_new__sqrt__1__dx_2_0_0_8))
(= c__qurt_new__sqrt__1__x_2_0_0_13 ?x5532))
:assumption
(let (?x5538 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_13))
(let (?x5539 (bvmul ?x5538 ?x5538))
(let (?x5540 (extract[95:32] ?x5539))
(let (?x5541 (bvmul bv18446744073709551615[64] ?x5540))
(let (?x5542 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5541))
(flet ($x5543 (= c__qurt_new__sqrt__1__diff_2_0_0_8 ?x5542))
(iff l976 $x5543)))))))
:assumption
l976
:assumption
(let (?x5538 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_13))
(let (?x5539 (bvmul ?x5538 ?x5538))
(let (?x5540 (extract[95:32] ?x5539))
(let (?x5541 (bvmul bv18446744073709551615[64] ?x5540))
(let (?x5542 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5541))
(= c__qurt_new__sqrt__1__diff_2_0_0_8 ?x5542))))))
:assumption
(flet ($x5548 (= c__qurt_new__fabs__n_25_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_8))
(iff l977 $x5548))
:assumption
l977
:assumption
(= c__qurt_new__fabs__n_25_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_8)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5553 (bvsge c__qurt_new__fabs__n_25_0_0_1 ?x1542))
(iff l978 $x5553)))
:assumption
(flet ($x5560 (xor l195 l978))
(iff l979 $x5560))
:assumption
(not l979)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5553 (bvsge c__qurt_new__fabs__n_25_0_0_1 ?x1542))
(= goto_symex___guard_0_0_74 $x5553)))
:assumption
(flet ($x5571 (= c__qurt_new__fabs__1__f_25_0_0_1 c__qurt_new__fabs__n_25_0_0_1))
(iff l980 $x5571))
:assumption
l980
:assumption
(= c__qurt_new__fabs__1__f_25_0_0_1 c__qurt_new__fabs__n_25_0_0_1)
:assumption
(let (?x5577 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_25_0_0_1))
(flet ($x5578 (= c__qurt_new__fabs__1__f_25_0_0_3 ?x5577))
(iff l981 $x5578)))
:assumption
l981
:assumption
(let (?x5577 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_25_0_0_1))
(= c__qurt_new__fabs__1__f_25_0_0_3 ?x5577))
:assumption
(let (?x5583 (ite goto_symex___guard_0_0_74 c__qurt_new__fabs__1__f_25_0_0_1 c__qurt_new__fabs__1__f_25_0_0_3))
(flet ($x5584 (= c__qurt_new__fabs__1__f_25_0_0_4 ?x5583))
(iff l982 $x5584)))
:assumption
l982
:assumption
(let (?x5583 (ite goto_symex___guard_0_0_74 c__qurt_new__fabs__1__f_25_0_0_1 c__qurt_new__fabs__1__f_25_0_0_3))
(= c__qurt_new__fabs__1__f_25_0_0_4 ?x5583))
:assumption
(flet ($x5589 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_8 c__qurt_new__fabs__1__f_25_0_0_4))
(iff l983 $x5589))
:assumption
l983
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_8 c__qurt_new__fabs__1__f_25_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5594 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_8 ?x1828))
(iff l984 $x5594)))
:assumption
(flet ($x5599 (xor l198 l984))
(iff l985 $x5599))
:assumption
(not l985)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5594 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_8 ?x1828))
(= goto_symex___guard_0_0_75 $x5594)))
:assumption
(flet ($x5610 (= c__qurt_new__sqrt__1__flag_2_0_0_12 bv1[32]))
(iff l986 $x5610))
:assumption
l986
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_12 bv1[32])
:assumption
(flet ($x5616 (not goto_symex___guard_0_0_75))
(let (?x5617 (ite $x5616 c__qurt_new__sqrt__1__flag_2_0_0_11 c__qurt_new__sqrt__1__flag_2_0_0_12))
(flet ($x5618 (= c__qurt_new__sqrt__1__flag_2_0_0_13 ?x5617))
(iff l987 $x5618))))
:assumption
l987
:assumption
(flet ($x5616 (not goto_symex___guard_0_0_75))
(let (?x5617 (ite $x5616 c__qurt_new__sqrt__1__flag_2_0_0_11 c__qurt_new__sqrt__1__flag_2_0_0_12))
(= c__qurt_new__sqrt__1__flag_2_0_0_13 ?x5617)))
:assumption
(flet ($x5625 (= c__qurt_new__sqrt__1__x_2_0_0_14 c__qurt_new__sqrt__1__x_2_0_0_12))
(iff l988 $x5625))
:assumption
l988
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_14 c__qurt_new__sqrt__1__x_2_0_0_12)
:assumption
(flet ($x5631 (= c__qurt_new__sqrt__1__flag_2_0_0_14 c__qurt_new__sqrt__1__flag_2_0_0_11))
(iff l989 $x5631))
:assumption
l989
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_14 c__qurt_new__sqrt__1__flag_2_0_0_11)
:assumption
(flet ($x5637 (= c__qurt_new__sqrt__1__x_2_0_0_15 c__qurt_new__sqrt__1__x_2_0_0_14))
(iff l990 $x5637))
:assumption
l990
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_15 c__qurt_new__sqrt__1__x_2_0_0_14)
:assumption
(let (?x5643 (ite goto_symex___guard_0_0_73 c__qurt_new__sqrt__1__x_2_0_0_13 c__qurt_new__sqrt__1__x_2_0_0_15))
(flet ($x5644 (= c__qurt_new__sqrt__1__x_2_0_0_16 ?x5643))
(iff l991 $x5644)))
:assumption
l991
:assumption
(let (?x5643 (ite goto_symex___guard_0_0_73 c__qurt_new__sqrt__1__x_2_0_0_13 c__qurt_new__sqrt__1__x_2_0_0_15))
(= c__qurt_new__sqrt__1__x_2_0_0_16 ?x5643))
:assumption
(let (?x5649 (ite goto_symex___guard_0_0_73 c__qurt_new__sqrt__1__flag_2_0_0_13 c__qurt_new__sqrt__1__flag_2_0_0_14))
(flet ($x5650 (= c__qurt_new__sqrt__1__flag_2_0_0_15 ?x5649))
(iff l992 $x5650)))
:assumption
l992
:assumption
(let (?x5649 (ite goto_symex___guard_0_0_73 c__qurt_new__sqrt__1__flag_2_0_0_13 c__qurt_new__sqrt__1__flag_2_0_0_14))
(= c__qurt_new__sqrt__1__flag_2_0_0_15 ?x5649))
:assumption
(flet ($x5654 (= c__qurt_new__sqrt__1__flag_2_0_0_15 bv0[32]))
(iff l993 $x5654))
:assumption
(flet ($x5659 (xor l201 l993))
(iff l994 $x5659))
:assumption
(not l994)
:assumption
(flet ($x5654 (= c__qurt_new__sqrt__1__flag_2_0_0_15 bv0[32]))
(= goto_symex___guard_0_0_76 $x5654))
:assumption
(let (?x5669 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5674 (bvmul ?x1629 ?x5669))
(let (?x5675 (extract[95:32] ?x5674))
(let (?x5676 (sign_extend[32] ?x5675))
(let (?x5670 (bvmul ?x5669 ?x5669))
(let (?x5671 (extract[95:32] ?x5670))
(let (?x5672 (bvmul bv18446744073709551615[64] ?x5671))
(let (?x5673 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5672))
(let (?x5677 (concat ?x5673 bv0[32]))
(let (?x5678 (bvsdiv ?x5677 ?x5676))
(let (?x5679 (extract[63:0] ?x5678))
(flet ($x5680 (= c__qurt_new__sqrt__1__dx_2_0_0_11 ?x5679))
(iff l995 $x5680)))))))))))))))
:assumption
l995
:assumption
(let (?x5669 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5674 (bvmul ?x1629 ?x5669))
(let (?x5675 (extract[95:32] ?x5674))
(let (?x5676 (sign_extend[32] ?x5675))
(let (?x5670 (bvmul ?x5669 ?x5669))
(let (?x5671 (extract[95:32] ?x5670))
(let (?x5672 (bvmul bv18446744073709551615[64] ?x5671))
(let (?x5673 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5672))
(let (?x5677 (concat ?x5673 bv0[32]))
(let (?x5678 (bvsdiv ?x5677 ?x5676))
(let (?x5679 (extract[63:0] ?x5678))
(= c__qurt_new__sqrt__1__dx_2_0_0_11 ?x5679))))))))))))))
:assumption
(let (?x5700 (bvadd c__qurt_new__sqrt__1__x_2_0_0_16 c__qurt_new__sqrt__1__dx_2_0_0_11))
(flet ($x5701 (= c__qurt_new__sqrt__1__x_2_0_0_17 ?x5700))
(iff l996 $x5701)))
:assumption
l996
:assumption
(let (?x5700 (bvadd c__qurt_new__sqrt__1__x_2_0_0_16 c__qurt_new__sqrt__1__dx_2_0_0_11))
(= c__qurt_new__sqrt__1__x_2_0_0_17 ?x5700))
:assumption
(let (?x5706 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_17))
(let (?x5707 (bvmul ?x5706 ?x5706))
(let (?x5708 (extract[95:32] ?x5707))
(let (?x5709 (bvmul bv18446744073709551615[64] ?x5708))
(let (?x5710 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5709))
(flet ($x5711 (= c__qurt_new__sqrt__1__diff_2_0_0_11 ?x5710))
(iff l997 $x5711)))))))
:assumption
l997
:assumption
(let (?x5706 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_17))
(let (?x5707 (bvmul ?x5706 ?x5706))
(let (?x5708 (extract[95:32] ?x5707))
(let (?x5709 (bvmul bv18446744073709551615[64] ?x5708))
(let (?x5710 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5709))
(= c__qurt_new__sqrt__1__diff_2_0_0_11 ?x5710))))))
:assumption
(flet ($x5716 (= c__qurt_new__fabs__n_26_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_11))
(iff l998 $x5716))
:assumption
l998
:assumption
(= c__qurt_new__fabs__n_26_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_11)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5721 (bvsge c__qurt_new__fabs__n_26_0_0_1 ?x1542))
(iff l999 $x5721)))
:assumption
(flet ($x5728 (xor l203 l999))
(iff l1000 $x5728))
:assumption
(not l1000)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5721 (bvsge c__qurt_new__fabs__n_26_0_0_1 ?x1542))
(= goto_symex___guard_0_0_77 $x5721)))
:assumption
(flet ($x5739 (= c__qurt_new__fabs__1__f_26_0_0_1 c__qurt_new__fabs__n_26_0_0_1))
(iff l1001 $x5739))
:assumption
l1001
:assumption
(= c__qurt_new__fabs__1__f_26_0_0_1 c__qurt_new__fabs__n_26_0_0_1)
:assumption
(let (?x5745 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_26_0_0_1))
(flet ($x5746 (= c__qurt_new__fabs__1__f_26_0_0_3 ?x5745))
(iff l1002 $x5746)))
:assumption
l1002
:assumption
(let (?x5745 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_26_0_0_1))
(= c__qurt_new__fabs__1__f_26_0_0_3 ?x5745))
:assumption
(let (?x5751 (ite goto_symex___guard_0_0_77 c__qurt_new__fabs__1__f_26_0_0_1 c__qurt_new__fabs__1__f_26_0_0_3))
(flet ($x5752 (= c__qurt_new__fabs__1__f_26_0_0_4 ?x5751))
(iff l1003 $x5752)))
:assumption
l1003
:assumption
(let (?x5751 (ite goto_symex___guard_0_0_77 c__qurt_new__fabs__1__f_26_0_0_1 c__qurt_new__fabs__1__f_26_0_0_3))
(= c__qurt_new__fabs__1__f_26_0_0_4 ?x5751))
:assumption
(flet ($x5757 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_11 c__qurt_new__fabs__1__f_26_0_0_4))
(iff l1004 $x5757))
:assumption
l1004
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_11 c__qurt_new__fabs__1__f_26_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5762 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_11 ?x1828))
(iff l1005 $x5762)))
:assumption
(flet ($x5767 (xor l206 l1005))
(iff l1006 $x5767))
:assumption
(not l1006)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5762 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_11 ?x1828))
(= goto_symex___guard_0_0_78 $x5762)))
:assumption
(flet ($x5778 (= c__qurt_new__sqrt__1__flag_2_0_0_16 bv1[32]))
(iff l1007 $x5778))
:assumption
l1007
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_16 bv1[32])
:assumption
(flet ($x5784 (not goto_symex___guard_0_0_78))
(let (?x5785 (ite $x5784 c__qurt_new__sqrt__1__flag_2_0_0_15 c__qurt_new__sqrt__1__flag_2_0_0_16))
(flet ($x5786 (= c__qurt_new__sqrt__1__flag_2_0_0_17 ?x5785))
(iff l1008 $x5786))))
:assumption
l1008
:assumption
(flet ($x5784 (not goto_symex___guard_0_0_78))
(let (?x5785 (ite $x5784 c__qurt_new__sqrt__1__flag_2_0_0_15 c__qurt_new__sqrt__1__flag_2_0_0_16))
(= c__qurt_new__sqrt__1__flag_2_0_0_17 ?x5785)))
:assumption
(flet ($x5793 (= c__qurt_new__sqrt__1__x_2_0_0_18 c__qurt_new__sqrt__1__x_2_0_0_16))
(iff l1009 $x5793))
:assumption
l1009
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_18 c__qurt_new__sqrt__1__x_2_0_0_16)
:assumption
(flet ($x5799 (= c__qurt_new__sqrt__1__flag_2_0_0_18 c__qurt_new__sqrt__1__flag_2_0_0_15))
(iff l1010 $x5799))
:assumption
l1010
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_18 c__qurt_new__sqrt__1__flag_2_0_0_15)
:assumption
(flet ($x5805 (= c__qurt_new__sqrt__1__x_2_0_0_19 c__qurt_new__sqrt__1__x_2_0_0_18))
(iff l1011 $x5805))
:assumption
l1011
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_19 c__qurt_new__sqrt__1__x_2_0_0_18)
:assumption
(let (?x5811 (ite goto_symex___guard_0_0_76 c__qurt_new__sqrt__1__x_2_0_0_17 c__qurt_new__sqrt__1__x_2_0_0_19))
(flet ($x5812 (= c__qurt_new__sqrt__1__x_2_0_0_20 ?x5811))
(iff l1012 $x5812)))
:assumption
l1012
:assumption
(let (?x5811 (ite goto_symex___guard_0_0_76 c__qurt_new__sqrt__1__x_2_0_0_17 c__qurt_new__sqrt__1__x_2_0_0_19))
(= c__qurt_new__sqrt__1__x_2_0_0_20 ?x5811))
:assumption
(let (?x5817 (ite goto_symex___guard_0_0_76 c__qurt_new__sqrt__1__flag_2_0_0_17 c__qurt_new__sqrt__1__flag_2_0_0_18))
(flet ($x5818 (= c__qurt_new__sqrt__1__flag_2_0_0_19 ?x5817))
(iff l1013 $x5818)))
:assumption
l1013
:assumption
(let (?x5817 (ite goto_symex___guard_0_0_76 c__qurt_new__sqrt__1__flag_2_0_0_17 c__qurt_new__sqrt__1__flag_2_0_0_18))
(= c__qurt_new__sqrt__1__flag_2_0_0_19 ?x5817))
:assumption
(flet ($x5822 (= c__qurt_new__sqrt__1__flag_2_0_0_19 bv0[32]))
(iff l1014 $x5822))
:assumption
(flet ($x5827 (xor l209 l1014))
(iff l1015 $x5827))
:assumption
(not l1015)
:assumption
(flet ($x5822 (= c__qurt_new__sqrt__1__flag_2_0_0_19 bv0[32]))
(= goto_symex___guard_0_0_79 $x5822))
:assumption
(let (?x5837 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5842 (bvmul ?x1629 ?x5837))
(let (?x5843 (extract[95:32] ?x5842))
(let (?x5844 (sign_extend[32] ?x5843))
(let (?x5838 (bvmul ?x5837 ?x5837))
(let (?x5839 (extract[95:32] ?x5838))
(let (?x5840 (bvmul bv18446744073709551615[64] ?x5839))
(let (?x5841 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5840))
(let (?x5845 (concat ?x5841 bv0[32]))
(let (?x5846 (bvsdiv ?x5845 ?x5844))
(let (?x5847 (extract[63:0] ?x5846))
(flet ($x5848 (= c__qurt_new__sqrt__1__dx_2_0_0_14 ?x5847))
(iff l1016 $x5848)))))))))))))))
:assumption
l1016
:assumption
(let (?x5837 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5842 (bvmul ?x1629 ?x5837))
(let (?x5843 (extract[95:32] ?x5842))
(let (?x5844 (sign_extend[32] ?x5843))
(let (?x5838 (bvmul ?x5837 ?x5837))
(let (?x5839 (extract[95:32] ?x5838))
(let (?x5840 (bvmul bv18446744073709551615[64] ?x5839))
(let (?x5841 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5840))
(let (?x5845 (concat ?x5841 bv0[32]))
(let (?x5846 (bvsdiv ?x5845 ?x5844))
(let (?x5847 (extract[63:0] ?x5846))
(= c__qurt_new__sqrt__1__dx_2_0_0_14 ?x5847))))))))))))))
:assumption
(let (?x5868 (bvadd c__qurt_new__sqrt__1__x_2_0_0_20 c__qurt_new__sqrt__1__dx_2_0_0_14))
(flet ($x5869 (= c__qurt_new__sqrt__1__x_2_0_0_21 ?x5868))
(iff l1017 $x5869)))
:assumption
l1017
:assumption
(let (?x5868 (bvadd c__qurt_new__sqrt__1__x_2_0_0_20 c__qurt_new__sqrt__1__dx_2_0_0_14))
(= c__qurt_new__sqrt__1__x_2_0_0_21 ?x5868))
:assumption
(let (?x5874 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_21))
(let (?x5875 (bvmul ?x5874 ?x5874))
(let (?x5876 (extract[95:32] ?x5875))
(let (?x5877 (bvmul bv18446744073709551615[64] ?x5876))
(let (?x5878 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5877))
(flet ($x5879 (= c__qurt_new__sqrt__1__diff_2_0_0_14 ?x5878))
(iff l1018 $x5879)))))))
:assumption
l1018
:assumption
(let (?x5874 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_21))
(let (?x5875 (bvmul ?x5874 ?x5874))
(let (?x5876 (extract[95:32] ?x5875))
(let (?x5877 (bvmul bv18446744073709551615[64] ?x5876))
(let (?x5878 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x5877))
(= c__qurt_new__sqrt__1__diff_2_0_0_14 ?x5878))))))
:assumption
(flet ($x5884 (= c__qurt_new__fabs__n_27_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_14))
(iff l1019 $x5884))
:assumption
l1019
:assumption
(= c__qurt_new__fabs__n_27_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_14)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5889 (bvsge c__qurt_new__fabs__n_27_0_0_1 ?x1542))
(iff l1020 $x5889)))
:assumption
(flet ($x5896 (xor l211 l1020))
(iff l1021 $x5896))
:assumption
(not l1021)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x5889 (bvsge c__qurt_new__fabs__n_27_0_0_1 ?x1542))
(= goto_symex___guard_0_0_80 $x5889)))
:assumption
(flet ($x5907 (= c__qurt_new__fabs__1__f_27_0_0_1 c__qurt_new__fabs__n_27_0_0_1))
(iff l1022 $x5907))
:assumption
l1022
:assumption
(= c__qurt_new__fabs__1__f_27_0_0_1 c__qurt_new__fabs__n_27_0_0_1)
:assumption
(let (?x5913 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_27_0_0_1))
(flet ($x5914 (= c__qurt_new__fabs__1__f_27_0_0_3 ?x5913))
(iff l1023 $x5914)))
:assumption
l1023
:assumption
(let (?x5913 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_27_0_0_1))
(= c__qurt_new__fabs__1__f_27_0_0_3 ?x5913))
:assumption
(let (?x5919 (ite goto_symex___guard_0_0_80 c__qurt_new__fabs__1__f_27_0_0_1 c__qurt_new__fabs__1__f_27_0_0_3))
(flet ($x5920 (= c__qurt_new__fabs__1__f_27_0_0_4 ?x5919))
(iff l1024 $x5920)))
:assumption
l1024
:assumption
(let (?x5919 (ite goto_symex___guard_0_0_80 c__qurt_new__fabs__1__f_27_0_0_1 c__qurt_new__fabs__1__f_27_0_0_3))
(= c__qurt_new__fabs__1__f_27_0_0_4 ?x5919))
:assumption
(flet ($x5925 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_14 c__qurt_new__fabs__1__f_27_0_0_4))
(iff l1025 $x5925))
:assumption
l1025
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_14 c__qurt_new__fabs__1__f_27_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5930 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_14 ?x1828))
(iff l1026 $x5930)))
:assumption
(flet ($x5935 (xor l214 l1026))
(iff l1027 $x5935))
:assumption
(not l1027)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x5930 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_14 ?x1828))
(= goto_symex___guard_0_0_81 $x5930)))
:assumption
(flet ($x5946 (= c__qurt_new__sqrt__1__flag_2_0_0_20 bv1[32]))
(iff l1028 $x5946))
:assumption
l1028
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_20 bv1[32])
:assumption
(flet ($x5952 (not goto_symex___guard_0_0_81))
(let (?x5953 (ite $x5952 c__qurt_new__sqrt__1__flag_2_0_0_19 c__qurt_new__sqrt__1__flag_2_0_0_20))
(flet ($x5954 (= c__qurt_new__sqrt__1__flag_2_0_0_21 ?x5953))
(iff l1029 $x5954))))
:assumption
l1029
:assumption
(flet ($x5952 (not goto_symex___guard_0_0_81))
(let (?x5953 (ite $x5952 c__qurt_new__sqrt__1__flag_2_0_0_19 c__qurt_new__sqrt__1__flag_2_0_0_20))
(= c__qurt_new__sqrt__1__flag_2_0_0_21 ?x5953)))
:assumption
(flet ($x5961 (= c__qurt_new__sqrt__1__x_2_0_0_22 c__qurt_new__sqrt__1__x_2_0_0_20))
(iff l1030 $x5961))
:assumption
l1030
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_22 c__qurt_new__sqrt__1__x_2_0_0_20)
:assumption
(flet ($x5967 (= c__qurt_new__sqrt__1__flag_2_0_0_22 c__qurt_new__sqrt__1__flag_2_0_0_19))
(iff l1031 $x5967))
:assumption
l1031
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_22 c__qurt_new__sqrt__1__flag_2_0_0_19)
:assumption
(flet ($x5973 (= c__qurt_new__sqrt__1__x_2_0_0_23 c__qurt_new__sqrt__1__x_2_0_0_22))
(iff l1032 $x5973))
:assumption
l1032
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_23 c__qurt_new__sqrt__1__x_2_0_0_22)
:assumption
(let (?x5979 (ite goto_symex___guard_0_0_79 c__qurt_new__sqrt__1__x_2_0_0_21 c__qurt_new__sqrt__1__x_2_0_0_23))
(flet ($x5980 (= c__qurt_new__sqrt__1__x_2_0_0_24 ?x5979))
(iff l1033 $x5980)))
:assumption
l1033
:assumption
(let (?x5979 (ite goto_symex___guard_0_0_79 c__qurt_new__sqrt__1__x_2_0_0_21 c__qurt_new__sqrt__1__x_2_0_0_23))
(= c__qurt_new__sqrt__1__x_2_0_0_24 ?x5979))
:assumption
(let (?x5985 (ite goto_symex___guard_0_0_79 c__qurt_new__sqrt__1__flag_2_0_0_21 c__qurt_new__sqrt__1__flag_2_0_0_22))
(flet ($x5986 (= c__qurt_new__sqrt__1__flag_2_0_0_23 ?x5985))
(iff l1034 $x5986)))
:assumption
l1034
:assumption
(let (?x5985 (ite goto_symex___guard_0_0_79 c__qurt_new__sqrt__1__flag_2_0_0_21 c__qurt_new__sqrt__1__flag_2_0_0_22))
(= c__qurt_new__sqrt__1__flag_2_0_0_23 ?x5985))
:assumption
(flet ($x5990 (= c__qurt_new__sqrt__1__flag_2_0_0_23 bv0[32]))
(iff l1035 $x5990))
:assumption
(flet ($x5995 (xor l217 l1035))
(iff l1036 $x5995))
:assumption
(not l1036)
:assumption
(flet ($x5990 (= c__qurt_new__sqrt__1__flag_2_0_0_23 bv0[32]))
(= goto_symex___guard_0_0_82 $x5990))
:assumption
(let (?x6005 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6010 (bvmul ?x1629 ?x6005))
(let (?x6011 (extract[95:32] ?x6010))
(let (?x6012 (sign_extend[32] ?x6011))
(let (?x6006 (bvmul ?x6005 ?x6005))
(let (?x6007 (extract[95:32] ?x6006))
(let (?x6008 (bvmul bv18446744073709551615[64] ?x6007))
(let (?x6009 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6008))
(let (?x6013 (concat ?x6009 bv0[32]))
(let (?x6014 (bvsdiv ?x6013 ?x6012))
(let (?x6015 (extract[63:0] ?x6014))
(flet ($x6016 (= c__qurt_new__sqrt__1__dx_2_0_0_17 ?x6015))
(iff l1037 $x6016)))))))))))))))
:assumption
l1037
:assumption
(let (?x6005 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6010 (bvmul ?x1629 ?x6005))
(let (?x6011 (extract[95:32] ?x6010))
(let (?x6012 (sign_extend[32] ?x6011))
(let (?x6006 (bvmul ?x6005 ?x6005))
(let (?x6007 (extract[95:32] ?x6006))
(let (?x6008 (bvmul bv18446744073709551615[64] ?x6007))
(let (?x6009 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6008))
(let (?x6013 (concat ?x6009 bv0[32]))
(let (?x6014 (bvsdiv ?x6013 ?x6012))
(let (?x6015 (extract[63:0] ?x6014))
(= c__qurt_new__sqrt__1__dx_2_0_0_17 ?x6015))))))))))))))
:assumption
(let (?x6036 (bvadd c__qurt_new__sqrt__1__x_2_0_0_24 c__qurt_new__sqrt__1__dx_2_0_0_17))
(flet ($x6037 (= c__qurt_new__sqrt__1__x_2_0_0_25 ?x6036))
(iff l1038 $x6037)))
:assumption
l1038
:assumption
(let (?x6036 (bvadd c__qurt_new__sqrt__1__x_2_0_0_24 c__qurt_new__sqrt__1__dx_2_0_0_17))
(= c__qurt_new__sqrt__1__x_2_0_0_25 ?x6036))
:assumption
(let (?x6042 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_25))
(let (?x6043 (bvmul ?x6042 ?x6042))
(let (?x6044 (extract[95:32] ?x6043))
(let (?x6045 (bvmul bv18446744073709551615[64] ?x6044))
(let (?x6046 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6045))
(flet ($x6047 (= c__qurt_new__sqrt__1__diff_2_0_0_17 ?x6046))
(iff l1039 $x6047)))))))
:assumption
l1039
:assumption
(let (?x6042 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_25))
(let (?x6043 (bvmul ?x6042 ?x6042))
(let (?x6044 (extract[95:32] ?x6043))
(let (?x6045 (bvmul bv18446744073709551615[64] ?x6044))
(let (?x6046 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6045))
(= c__qurt_new__sqrt__1__diff_2_0_0_17 ?x6046))))))
:assumption
(flet ($x6052 (= c__qurt_new__fabs__n_28_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_17))
(iff l1040 $x6052))
:assumption
l1040
:assumption
(= c__qurt_new__fabs__n_28_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_17)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6057 (bvsge c__qurt_new__fabs__n_28_0_0_1 ?x1542))
(iff l1041 $x6057)))
:assumption
(flet ($x6064 (xor l219 l1041))
(iff l1042 $x6064))
:assumption
(not l1042)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6057 (bvsge c__qurt_new__fabs__n_28_0_0_1 ?x1542))
(= goto_symex___guard_0_0_83 $x6057)))
:assumption
(flet ($x6075 (= c__qurt_new__fabs__1__f_28_0_0_1 c__qurt_new__fabs__n_28_0_0_1))
(iff l1043 $x6075))
:assumption
l1043
:assumption
(= c__qurt_new__fabs__1__f_28_0_0_1 c__qurt_new__fabs__n_28_0_0_1)
:assumption
(let (?x6081 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_28_0_0_1))
(flet ($x6082 (= c__qurt_new__fabs__1__f_28_0_0_3 ?x6081))
(iff l1044 $x6082)))
:assumption
l1044
:assumption
(let (?x6081 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_28_0_0_1))
(= c__qurt_new__fabs__1__f_28_0_0_3 ?x6081))
:assumption
(let (?x6087 (ite goto_symex___guard_0_0_83 c__qurt_new__fabs__1__f_28_0_0_1 c__qurt_new__fabs__1__f_28_0_0_3))
(flet ($x6088 (= c__qurt_new__fabs__1__f_28_0_0_4 ?x6087))
(iff l1045 $x6088)))
:assumption
l1045
:assumption
(let (?x6087 (ite goto_symex___guard_0_0_83 c__qurt_new__fabs__1__f_28_0_0_1 c__qurt_new__fabs__1__f_28_0_0_3))
(= c__qurt_new__fabs__1__f_28_0_0_4 ?x6087))
:assumption
(flet ($x6093 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_17 c__qurt_new__fabs__1__f_28_0_0_4))
(iff l1046 $x6093))
:assumption
l1046
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_17 c__qurt_new__fabs__1__f_28_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6098 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_17 ?x1828))
(iff l1047 $x6098)))
:assumption
(flet ($x6103 (xor l222 l1047))
(iff l1048 $x6103))
:assumption
(not l1048)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6098 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_17 ?x1828))
(= goto_symex___guard_0_0_84 $x6098)))
:assumption
(flet ($x6114 (= c__qurt_new__sqrt__1__flag_2_0_0_24 bv1[32]))
(iff l1049 $x6114))
:assumption
l1049
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_24 bv1[32])
:assumption
(flet ($x6120 (not goto_symex___guard_0_0_84))
(let (?x6121 (ite $x6120 c__qurt_new__sqrt__1__flag_2_0_0_23 c__qurt_new__sqrt__1__flag_2_0_0_24))
(flet ($x6122 (= c__qurt_new__sqrt__1__flag_2_0_0_25 ?x6121))
(iff l1050 $x6122))))
:assumption
l1050
:assumption
(flet ($x6120 (not goto_symex___guard_0_0_84))
(let (?x6121 (ite $x6120 c__qurt_new__sqrt__1__flag_2_0_0_23 c__qurt_new__sqrt__1__flag_2_0_0_24))
(= c__qurt_new__sqrt__1__flag_2_0_0_25 ?x6121)))
:assumption
(flet ($x6129 (= c__qurt_new__sqrt__1__x_2_0_0_26 c__qurt_new__sqrt__1__x_2_0_0_24))
(iff l1051 $x6129))
:assumption
l1051
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_26 c__qurt_new__sqrt__1__x_2_0_0_24)
:assumption
(flet ($x6135 (= c__qurt_new__sqrt__1__flag_2_0_0_26 c__qurt_new__sqrt__1__flag_2_0_0_23))
(iff l1052 $x6135))
:assumption
l1052
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_26 c__qurt_new__sqrt__1__flag_2_0_0_23)
:assumption
(flet ($x6141 (= c__qurt_new__sqrt__1__x_2_0_0_27 c__qurt_new__sqrt__1__x_2_0_0_26))
(iff l1053 $x6141))
:assumption
l1053
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_27 c__qurt_new__sqrt__1__x_2_0_0_26)
:assumption
(let (?x6147 (ite goto_symex___guard_0_0_82 c__qurt_new__sqrt__1__x_2_0_0_25 c__qurt_new__sqrt__1__x_2_0_0_27))
(flet ($x6148 (= c__qurt_new__sqrt__1__x_2_0_0_28 ?x6147))
(iff l1054 $x6148)))
:assumption
l1054
:assumption
(let (?x6147 (ite goto_symex___guard_0_0_82 c__qurt_new__sqrt__1__x_2_0_0_25 c__qurt_new__sqrt__1__x_2_0_0_27))
(= c__qurt_new__sqrt__1__x_2_0_0_28 ?x6147))
:assumption
(let (?x6153 (ite goto_symex___guard_0_0_82 c__qurt_new__sqrt__1__flag_2_0_0_25 c__qurt_new__sqrt__1__flag_2_0_0_26))
(flet ($x6154 (= c__qurt_new__sqrt__1__flag_2_0_0_27 ?x6153))
(iff l1055 $x6154)))
:assumption
l1055
:assumption
(let (?x6153 (ite goto_symex___guard_0_0_82 c__qurt_new__sqrt__1__flag_2_0_0_25 c__qurt_new__sqrt__1__flag_2_0_0_26))
(= c__qurt_new__sqrt__1__flag_2_0_0_27 ?x6153))
:assumption
(flet ($x6158 (= c__qurt_new__sqrt__1__flag_2_0_0_27 bv0[32]))
(iff l1056 $x6158))
:assumption
(flet ($x6163 (xor l225 l1056))
(iff l1057 $x6163))
:assumption
(not l1057)
:assumption
(flet ($x6158 (= c__qurt_new__sqrt__1__flag_2_0_0_27 bv0[32]))
(= goto_symex___guard_0_0_85 $x6158))
:assumption
(let (?x6173 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6178 (bvmul ?x1629 ?x6173))
(let (?x6179 (extract[95:32] ?x6178))
(let (?x6180 (sign_extend[32] ?x6179))
(let (?x6174 (bvmul ?x6173 ?x6173))
(let (?x6175 (extract[95:32] ?x6174))
(let (?x6176 (bvmul bv18446744073709551615[64] ?x6175))
(let (?x6177 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6176))
(let (?x6181 (concat ?x6177 bv0[32]))
(let (?x6182 (bvsdiv ?x6181 ?x6180))
(let (?x6183 (extract[63:0] ?x6182))
(flet ($x6184 (= c__qurt_new__sqrt__1__dx_2_0_0_20 ?x6183))
(iff l1058 $x6184)))))))))))))))
:assumption
l1058
:assumption
(let (?x6173 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6178 (bvmul ?x1629 ?x6173))
(let (?x6179 (extract[95:32] ?x6178))
(let (?x6180 (sign_extend[32] ?x6179))
(let (?x6174 (bvmul ?x6173 ?x6173))
(let (?x6175 (extract[95:32] ?x6174))
(let (?x6176 (bvmul bv18446744073709551615[64] ?x6175))
(let (?x6177 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6176))
(let (?x6181 (concat ?x6177 bv0[32]))
(let (?x6182 (bvsdiv ?x6181 ?x6180))
(let (?x6183 (extract[63:0] ?x6182))
(= c__qurt_new__sqrt__1__dx_2_0_0_20 ?x6183))))))))))))))
:assumption
(let (?x6204 (bvadd c__qurt_new__sqrt__1__x_2_0_0_28 c__qurt_new__sqrt__1__dx_2_0_0_20))
(flet ($x6205 (= c__qurt_new__sqrt__1__x_2_0_0_29 ?x6204))
(iff l1059 $x6205)))
:assumption
l1059
:assumption
(let (?x6204 (bvadd c__qurt_new__sqrt__1__x_2_0_0_28 c__qurt_new__sqrt__1__dx_2_0_0_20))
(= c__qurt_new__sqrt__1__x_2_0_0_29 ?x6204))
:assumption
(let (?x6210 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_29))
(let (?x6211 (bvmul ?x6210 ?x6210))
(let (?x6212 (extract[95:32] ?x6211))
(let (?x6213 (bvmul bv18446744073709551615[64] ?x6212))
(let (?x6214 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6213))
(flet ($x6215 (= c__qurt_new__sqrt__1__diff_2_0_0_20 ?x6214))
(iff l1060 $x6215)))))))
:assumption
l1060
:assumption
(let (?x6210 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_29))
(let (?x6211 (bvmul ?x6210 ?x6210))
(let (?x6212 (extract[95:32] ?x6211))
(let (?x6213 (bvmul bv18446744073709551615[64] ?x6212))
(let (?x6214 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6213))
(= c__qurt_new__sqrt__1__diff_2_0_0_20 ?x6214))))))
:assumption
(flet ($x6220 (= c__qurt_new__fabs__n_29_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_20))
(iff l1061 $x6220))
:assumption
l1061
:assumption
(= c__qurt_new__fabs__n_29_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_20)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6225 (bvsge c__qurt_new__fabs__n_29_0_0_1 ?x1542))
(iff l1062 $x6225)))
:assumption
(flet ($x6232 (xor l227 l1062))
(iff l1063 $x6232))
:assumption
(not l1063)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6225 (bvsge c__qurt_new__fabs__n_29_0_0_1 ?x1542))
(= goto_symex___guard_0_0_86 $x6225)))
:assumption
(flet ($x6243 (= c__qurt_new__fabs__1__f_29_0_0_1 c__qurt_new__fabs__n_29_0_0_1))
(iff l1064 $x6243))
:assumption
l1064
:assumption
(= c__qurt_new__fabs__1__f_29_0_0_1 c__qurt_new__fabs__n_29_0_0_1)
:assumption
(let (?x6249 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_29_0_0_1))
(flet ($x6250 (= c__qurt_new__fabs__1__f_29_0_0_3 ?x6249))
(iff l1065 $x6250)))
:assumption
l1065
:assumption
(let (?x6249 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_29_0_0_1))
(= c__qurt_new__fabs__1__f_29_0_0_3 ?x6249))
:assumption
(let (?x6255 (ite goto_symex___guard_0_0_86 c__qurt_new__fabs__1__f_29_0_0_1 c__qurt_new__fabs__1__f_29_0_0_3))
(flet ($x6256 (= c__qurt_new__fabs__1__f_29_0_0_4 ?x6255))
(iff l1066 $x6256)))
:assumption
l1066
:assumption
(let (?x6255 (ite goto_symex___guard_0_0_86 c__qurt_new__fabs__1__f_29_0_0_1 c__qurt_new__fabs__1__f_29_0_0_3))
(= c__qurt_new__fabs__1__f_29_0_0_4 ?x6255))
:assumption
(flet ($x6261 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_20 c__qurt_new__fabs__1__f_29_0_0_4))
(iff l1067 $x6261))
:assumption
l1067
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_20 c__qurt_new__fabs__1__f_29_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6266 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_20 ?x1828))
(iff l1068 $x6266)))
:assumption
(flet ($x6271 (xor l230 l1068))
(iff l1069 $x6271))
:assumption
(not l1069)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6266 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_20 ?x1828))
(= goto_symex___guard_0_0_87 $x6266)))
:assumption
(flet ($x6282 (= c__qurt_new__sqrt__1__flag_2_0_0_28 bv1[32]))
(iff l1070 $x6282))
:assumption
l1070
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_28 bv1[32])
:assumption
(flet ($x6288 (not goto_symex___guard_0_0_87))
(let (?x6289 (ite $x6288 c__qurt_new__sqrt__1__flag_2_0_0_27 c__qurt_new__sqrt__1__flag_2_0_0_28))
(flet ($x6290 (= c__qurt_new__sqrt__1__flag_2_0_0_29 ?x6289))
(iff l1071 $x6290))))
:assumption
l1071
:assumption
(flet ($x6288 (not goto_symex___guard_0_0_87))
(let (?x6289 (ite $x6288 c__qurt_new__sqrt__1__flag_2_0_0_27 c__qurt_new__sqrt__1__flag_2_0_0_28))
(= c__qurt_new__sqrt__1__flag_2_0_0_29 ?x6289)))
:assumption
(flet ($x6297 (= c__qurt_new__sqrt__1__x_2_0_0_30 c__qurt_new__sqrt__1__x_2_0_0_28))
(iff l1072 $x6297))
:assumption
l1072
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_30 c__qurt_new__sqrt__1__x_2_0_0_28)
:assumption
(flet ($x6303 (= c__qurt_new__sqrt__1__flag_2_0_0_30 c__qurt_new__sqrt__1__flag_2_0_0_27))
(iff l1073 $x6303))
:assumption
l1073
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_30 c__qurt_new__sqrt__1__flag_2_0_0_27)
:assumption
(flet ($x6309 (= c__qurt_new__sqrt__1__x_2_0_0_31 c__qurt_new__sqrt__1__x_2_0_0_30))
(iff l1074 $x6309))
:assumption
l1074
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_31 c__qurt_new__sqrt__1__x_2_0_0_30)
:assumption
(let (?x6315 (ite goto_symex___guard_0_0_85 c__qurt_new__sqrt__1__x_2_0_0_29 c__qurt_new__sqrt__1__x_2_0_0_31))
(flet ($x6316 (= c__qurt_new__sqrt__1__x_2_0_0_32 ?x6315))
(iff l1075 $x6316)))
:assumption
l1075
:assumption
(let (?x6315 (ite goto_symex___guard_0_0_85 c__qurt_new__sqrt__1__x_2_0_0_29 c__qurt_new__sqrt__1__x_2_0_0_31))
(= c__qurt_new__sqrt__1__x_2_0_0_32 ?x6315))
:assumption
(let (?x6321 (ite goto_symex___guard_0_0_85 c__qurt_new__sqrt__1__flag_2_0_0_29 c__qurt_new__sqrt__1__flag_2_0_0_30))
(flet ($x6322 (= c__qurt_new__sqrt__1__flag_2_0_0_31 ?x6321))
(iff l1076 $x6322)))
:assumption
l1076
:assumption
(let (?x6321 (ite goto_symex___guard_0_0_85 c__qurt_new__sqrt__1__flag_2_0_0_29 c__qurt_new__sqrt__1__flag_2_0_0_30))
(= c__qurt_new__sqrt__1__flag_2_0_0_31 ?x6321))
:assumption
(flet ($x6326 (= c__qurt_new__sqrt__1__flag_2_0_0_31 bv0[32]))
(iff l1077 $x6326))
:assumption
(flet ($x6331 (xor l233 l1077))
(iff l1078 $x6331))
:assumption
(not l1078)
:assumption
(flet ($x6326 (= c__qurt_new__sqrt__1__flag_2_0_0_31 bv0[32]))
(= goto_symex___guard_0_0_88 $x6326))
:assumption
(let (?x6341 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6346 (bvmul ?x1629 ?x6341))
(let (?x6347 (extract[95:32] ?x6346))
(let (?x6348 (sign_extend[32] ?x6347))
(let (?x6342 (bvmul ?x6341 ?x6341))
(let (?x6343 (extract[95:32] ?x6342))
(let (?x6344 (bvmul bv18446744073709551615[64] ?x6343))
(let (?x6345 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6344))
(let (?x6349 (concat ?x6345 bv0[32]))
(let (?x6350 (bvsdiv ?x6349 ?x6348))
(let (?x6351 (extract[63:0] ?x6350))
(flet ($x6352 (= c__qurt_new__sqrt__1__dx_2_0_0_23 ?x6351))
(iff l1079 $x6352)))))))))))))))
:assumption
l1079
:assumption
(let (?x6341 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6346 (bvmul ?x1629 ?x6341))
(let (?x6347 (extract[95:32] ?x6346))
(let (?x6348 (sign_extend[32] ?x6347))
(let (?x6342 (bvmul ?x6341 ?x6341))
(let (?x6343 (extract[95:32] ?x6342))
(let (?x6344 (bvmul bv18446744073709551615[64] ?x6343))
(let (?x6345 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6344))
(let (?x6349 (concat ?x6345 bv0[32]))
(let (?x6350 (bvsdiv ?x6349 ?x6348))
(let (?x6351 (extract[63:0] ?x6350))
(= c__qurt_new__sqrt__1__dx_2_0_0_23 ?x6351))))))))))))))
:assumption
(let (?x6372 (bvadd c__qurt_new__sqrt__1__x_2_0_0_32 c__qurt_new__sqrt__1__dx_2_0_0_23))
(flet ($x6373 (= c__qurt_new__sqrt__1__x_2_0_0_33 ?x6372))
(iff l1080 $x6373)))
:assumption
l1080
:assumption
(let (?x6372 (bvadd c__qurt_new__sqrt__1__x_2_0_0_32 c__qurt_new__sqrt__1__dx_2_0_0_23))
(= c__qurt_new__sqrt__1__x_2_0_0_33 ?x6372))
:assumption
(let (?x6378 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_33))
(let (?x6379 (bvmul ?x6378 ?x6378))
(let (?x6380 (extract[95:32] ?x6379))
(let (?x6381 (bvmul bv18446744073709551615[64] ?x6380))
(let (?x6382 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6381))
(flet ($x6383 (= c__qurt_new__sqrt__1__diff_2_0_0_23 ?x6382))
(iff l1081 $x6383)))))))
:assumption
l1081
:assumption
(let (?x6378 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_33))
(let (?x6379 (bvmul ?x6378 ?x6378))
(let (?x6380 (extract[95:32] ?x6379))
(let (?x6381 (bvmul bv18446744073709551615[64] ?x6380))
(let (?x6382 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6381))
(= c__qurt_new__sqrt__1__diff_2_0_0_23 ?x6382))))))
:assumption
(flet ($x6388 (= c__qurt_new__fabs__n_30_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_23))
(iff l1082 $x6388))
:assumption
l1082
:assumption
(= c__qurt_new__fabs__n_30_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_23)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6393 (bvsge c__qurt_new__fabs__n_30_0_0_1 ?x1542))
(iff l1083 $x6393)))
:assumption
(flet ($x6400 (xor l235 l1083))
(iff l1084 $x6400))
:assumption
(not l1084)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6393 (bvsge c__qurt_new__fabs__n_30_0_0_1 ?x1542))
(= goto_symex___guard_0_0_89 $x6393)))
:assumption
(flet ($x6411 (= c__qurt_new__fabs__1__f_30_0_0_1 c__qurt_new__fabs__n_30_0_0_1))
(iff l1085 $x6411))
:assumption
l1085
:assumption
(= c__qurt_new__fabs__1__f_30_0_0_1 c__qurt_new__fabs__n_30_0_0_1)
:assumption
(let (?x6417 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_30_0_0_1))
(flet ($x6418 (= c__qurt_new__fabs__1__f_30_0_0_3 ?x6417))
(iff l1086 $x6418)))
:assumption
l1086
:assumption
(let (?x6417 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_30_0_0_1))
(= c__qurt_new__fabs__1__f_30_0_0_3 ?x6417))
:assumption
(let (?x6423 (ite goto_symex___guard_0_0_89 c__qurt_new__fabs__1__f_30_0_0_1 c__qurt_new__fabs__1__f_30_0_0_3))
(flet ($x6424 (= c__qurt_new__fabs__1__f_30_0_0_4 ?x6423))
(iff l1087 $x6424)))
:assumption
l1087
:assumption
(let (?x6423 (ite goto_symex___guard_0_0_89 c__qurt_new__fabs__1__f_30_0_0_1 c__qurt_new__fabs__1__f_30_0_0_3))
(= c__qurt_new__fabs__1__f_30_0_0_4 ?x6423))
:assumption
(flet ($x6429 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_23 c__qurt_new__fabs__1__f_30_0_0_4))
(iff l1088 $x6429))
:assumption
l1088
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_23 c__qurt_new__fabs__1__f_30_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6434 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_23 ?x1828))
(iff l1089 $x6434)))
:assumption
(flet ($x6439 (xor l238 l1089))
(iff l1090 $x6439))
:assumption
(not l1090)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6434 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_23 ?x1828))
(= goto_symex___guard_0_0_90 $x6434)))
:assumption
(flet ($x6450 (= c__qurt_new__sqrt__1__flag_2_0_0_32 bv1[32]))
(iff l1091 $x6450))
:assumption
l1091
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_32 bv1[32])
:assumption
(flet ($x6456 (not goto_symex___guard_0_0_90))
(let (?x6457 (ite $x6456 c__qurt_new__sqrt__1__flag_2_0_0_31 c__qurt_new__sqrt__1__flag_2_0_0_32))
(flet ($x6458 (= c__qurt_new__sqrt__1__flag_2_0_0_33 ?x6457))
(iff l1092 $x6458))))
:assumption
l1092
:assumption
(flet ($x6456 (not goto_symex___guard_0_0_90))
(let (?x6457 (ite $x6456 c__qurt_new__sqrt__1__flag_2_0_0_31 c__qurt_new__sqrt__1__flag_2_0_0_32))
(= c__qurt_new__sqrt__1__flag_2_0_0_33 ?x6457)))
:assumption
(flet ($x6465 (= c__qurt_new__sqrt__1__x_2_0_0_34 c__qurt_new__sqrt__1__x_2_0_0_32))
(iff l1093 $x6465))
:assumption
l1093
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_34 c__qurt_new__sqrt__1__x_2_0_0_32)
:assumption
(flet ($x6471 (= c__qurt_new__sqrt__1__flag_2_0_0_34 c__qurt_new__sqrt__1__flag_2_0_0_31))
(iff l1094 $x6471))
:assumption
l1094
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_34 c__qurt_new__sqrt__1__flag_2_0_0_31)
:assumption
(flet ($x6477 (= c__qurt_new__sqrt__1__x_2_0_0_35 c__qurt_new__sqrt__1__x_2_0_0_34))
(iff l1095 $x6477))
:assumption
l1095
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_35 c__qurt_new__sqrt__1__x_2_0_0_34)
:assumption
(let (?x6483 (ite goto_symex___guard_0_0_88 c__qurt_new__sqrt__1__x_2_0_0_33 c__qurt_new__sqrt__1__x_2_0_0_35))
(flet ($x6484 (= c__qurt_new__sqrt__1__x_2_0_0_36 ?x6483))
(iff l1096 $x6484)))
:assumption
l1096
:assumption
(let (?x6483 (ite goto_symex___guard_0_0_88 c__qurt_new__sqrt__1__x_2_0_0_33 c__qurt_new__sqrt__1__x_2_0_0_35))
(= c__qurt_new__sqrt__1__x_2_0_0_36 ?x6483))
:assumption
(let (?x6489 (ite goto_symex___guard_0_0_88 c__qurt_new__sqrt__1__flag_2_0_0_33 c__qurt_new__sqrt__1__flag_2_0_0_34))
(flet ($x6490 (= c__qurt_new__sqrt__1__flag_2_0_0_35 ?x6489))
(iff l1097 $x6490)))
:assumption
l1097
:assumption
(let (?x6489 (ite goto_symex___guard_0_0_88 c__qurt_new__sqrt__1__flag_2_0_0_33 c__qurt_new__sqrt__1__flag_2_0_0_34))
(= c__qurt_new__sqrt__1__flag_2_0_0_35 ?x6489))
:assumption
(flet ($x6494 (= c__qurt_new__sqrt__1__flag_2_0_0_35 bv0[32]))
(iff l1098 $x6494))
:assumption
(flet ($x6499 (xor l241 l1098))
(iff l1099 $x6499))
:assumption
(not l1099)
:assumption
(flet ($x6494 (= c__qurt_new__sqrt__1__flag_2_0_0_35 bv0[32]))
(= goto_symex___guard_0_0_91 $x6494))
:assumption
(let (?x6509 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6514 (bvmul ?x1629 ?x6509))
(let (?x6515 (extract[95:32] ?x6514))
(let (?x6516 (sign_extend[32] ?x6515))
(let (?x6510 (bvmul ?x6509 ?x6509))
(let (?x6511 (extract[95:32] ?x6510))
(let (?x6512 (bvmul bv18446744073709551615[64] ?x6511))
(let (?x6513 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6512))
(let (?x6517 (concat ?x6513 bv0[32]))
(let (?x6518 (bvsdiv ?x6517 ?x6516))
(let (?x6519 (extract[63:0] ?x6518))
(flet ($x6520 (= c__qurt_new__sqrt__1__dx_2_0_0_26 ?x6519))
(iff l1100 $x6520)))))))))))))))
:assumption
l1100
:assumption
(let (?x6509 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6514 (bvmul ?x1629 ?x6509))
(let (?x6515 (extract[95:32] ?x6514))
(let (?x6516 (sign_extend[32] ?x6515))
(let (?x6510 (bvmul ?x6509 ?x6509))
(let (?x6511 (extract[95:32] ?x6510))
(let (?x6512 (bvmul bv18446744073709551615[64] ?x6511))
(let (?x6513 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6512))
(let (?x6517 (concat ?x6513 bv0[32]))
(let (?x6518 (bvsdiv ?x6517 ?x6516))
(let (?x6519 (extract[63:0] ?x6518))
(= c__qurt_new__sqrt__1__dx_2_0_0_26 ?x6519))))))))))))))
:assumption
(let (?x6540 (bvadd c__qurt_new__sqrt__1__x_2_0_0_36 c__qurt_new__sqrt__1__dx_2_0_0_26))
(flet ($x6541 (= c__qurt_new__sqrt__1__x_2_0_0_37 ?x6540))
(iff l1101 $x6541)))
:assumption
l1101
:assumption
(let (?x6540 (bvadd c__qurt_new__sqrt__1__x_2_0_0_36 c__qurt_new__sqrt__1__dx_2_0_0_26))
(= c__qurt_new__sqrt__1__x_2_0_0_37 ?x6540))
:assumption
(let (?x6546 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_37))
(let (?x6547 (bvmul ?x6546 ?x6546))
(let (?x6548 (extract[95:32] ?x6547))
(let (?x6549 (bvmul bv18446744073709551615[64] ?x6548))
(let (?x6550 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6549))
(flet ($x6551 (= c__qurt_new__sqrt__1__diff_2_0_0_26 ?x6550))
(iff l1102 $x6551)))))))
:assumption
l1102
:assumption
(let (?x6546 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_37))
(let (?x6547 (bvmul ?x6546 ?x6546))
(let (?x6548 (extract[95:32] ?x6547))
(let (?x6549 (bvmul bv18446744073709551615[64] ?x6548))
(let (?x6550 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6549))
(= c__qurt_new__sqrt__1__diff_2_0_0_26 ?x6550))))))
:assumption
(flet ($x6556 (= c__qurt_new__fabs__n_31_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_26))
(iff l1103 $x6556))
:assumption
l1103
:assumption
(= c__qurt_new__fabs__n_31_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_26)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6561 (bvsge c__qurt_new__fabs__n_31_0_0_1 ?x1542))
(iff l1104 $x6561)))
:assumption
(flet ($x6568 (xor l243 l1104))
(iff l1105 $x6568))
:assumption
(not l1105)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6561 (bvsge c__qurt_new__fabs__n_31_0_0_1 ?x1542))
(= goto_symex___guard_0_0_92 $x6561)))
:assumption
(flet ($x6579 (= c__qurt_new__fabs__1__f_31_0_0_1 c__qurt_new__fabs__n_31_0_0_1))
(iff l1106 $x6579))
:assumption
l1106
:assumption
(= c__qurt_new__fabs__1__f_31_0_0_1 c__qurt_new__fabs__n_31_0_0_1)
:assumption
(let (?x6585 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_31_0_0_1))
(flet ($x6586 (= c__qurt_new__fabs__1__f_31_0_0_3 ?x6585))
(iff l1107 $x6586)))
:assumption
l1107
:assumption
(let (?x6585 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_31_0_0_1))
(= c__qurt_new__fabs__1__f_31_0_0_3 ?x6585))
:assumption
(let (?x6591 (ite goto_symex___guard_0_0_92 c__qurt_new__fabs__1__f_31_0_0_1 c__qurt_new__fabs__1__f_31_0_0_3))
(flet ($x6592 (= c__qurt_new__fabs__1__f_31_0_0_4 ?x6591))
(iff l1108 $x6592)))
:assumption
l1108
:assumption
(let (?x6591 (ite goto_symex___guard_0_0_92 c__qurt_new__fabs__1__f_31_0_0_1 c__qurt_new__fabs__1__f_31_0_0_3))
(= c__qurt_new__fabs__1__f_31_0_0_4 ?x6591))
:assumption
(flet ($x6597 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_26 c__qurt_new__fabs__1__f_31_0_0_4))
(iff l1109 $x6597))
:assumption
l1109
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_26 c__qurt_new__fabs__1__f_31_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6602 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_26 ?x1828))
(iff l1110 $x6602)))
:assumption
(flet ($x6607 (xor l246 l1110))
(iff l1111 $x6607))
:assumption
(not l1111)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6602 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_26 ?x1828))
(= goto_symex___guard_0_0_93 $x6602)))
:assumption
(flet ($x6618 (= c__qurt_new__sqrt__1__flag_2_0_0_36 bv1[32]))
(iff l1112 $x6618))
:assumption
l1112
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_36 bv1[32])
:assumption
(flet ($x6624 (not goto_symex___guard_0_0_93))
(let (?x6625 (ite $x6624 c__qurt_new__sqrt__1__flag_2_0_0_35 c__qurt_new__sqrt__1__flag_2_0_0_36))
(flet ($x6626 (= c__qurt_new__sqrt__1__flag_2_0_0_37 ?x6625))
(iff l1113 $x6626))))
:assumption
l1113
:assumption
(flet ($x6624 (not goto_symex___guard_0_0_93))
(let (?x6625 (ite $x6624 c__qurt_new__sqrt__1__flag_2_0_0_35 c__qurt_new__sqrt__1__flag_2_0_0_36))
(= c__qurt_new__sqrt__1__flag_2_0_0_37 ?x6625)))
:assumption
(flet ($x6633 (= c__qurt_new__sqrt__1__x_2_0_0_38 c__qurt_new__sqrt__1__x_2_0_0_36))
(iff l1114 $x6633))
:assumption
l1114
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_38 c__qurt_new__sqrt__1__x_2_0_0_36)
:assumption
(flet ($x6639 (= c__qurt_new__sqrt__1__flag_2_0_0_38 c__qurt_new__sqrt__1__flag_2_0_0_35))
(iff l1115 $x6639))
:assumption
l1115
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_38 c__qurt_new__sqrt__1__flag_2_0_0_35)
:assumption
(flet ($x6645 (= c__qurt_new__sqrt__1__x_2_0_0_39 c__qurt_new__sqrt__1__x_2_0_0_38))
(iff l1116 $x6645))
:assumption
l1116
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_39 c__qurt_new__sqrt__1__x_2_0_0_38)
:assumption
(let (?x6651 (ite goto_symex___guard_0_0_91 c__qurt_new__sqrt__1__x_2_0_0_37 c__qurt_new__sqrt__1__x_2_0_0_39))
(flet ($x6652 (= c__qurt_new__sqrt__1__x_2_0_0_40 ?x6651))
(iff l1117 $x6652)))
:assumption
l1117
:assumption
(let (?x6651 (ite goto_symex___guard_0_0_91 c__qurt_new__sqrt__1__x_2_0_0_37 c__qurt_new__sqrt__1__x_2_0_0_39))
(= c__qurt_new__sqrt__1__x_2_0_0_40 ?x6651))
:assumption
(let (?x6657 (ite goto_symex___guard_0_0_91 c__qurt_new__sqrt__1__flag_2_0_0_37 c__qurt_new__sqrt__1__flag_2_0_0_38))
(flet ($x6658 (= c__qurt_new__sqrt__1__flag_2_0_0_39 ?x6657))
(iff l1118 $x6658)))
:assumption
l1118
:assumption
(let (?x6657 (ite goto_symex___guard_0_0_91 c__qurt_new__sqrt__1__flag_2_0_0_37 c__qurt_new__sqrt__1__flag_2_0_0_38))
(= c__qurt_new__sqrt__1__flag_2_0_0_39 ?x6657))
:assumption
(flet ($x6662 (= c__qurt_new__sqrt__1__flag_2_0_0_39 bv0[32]))
(iff l1119 $x6662))
:assumption
(flet ($x6667 (xor l249 l1119))
(iff l1120 $x6667))
:assumption
(not l1120)
:assumption
(flet ($x6662 (= c__qurt_new__sqrt__1__flag_2_0_0_39 bv0[32]))
(= goto_symex___guard_0_0_94 $x6662))
:assumption
(let (?x6677 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6682 (bvmul ?x1629 ?x6677))
(let (?x6683 (extract[95:32] ?x6682))
(let (?x6684 (sign_extend[32] ?x6683))
(let (?x6678 (bvmul ?x6677 ?x6677))
(let (?x6679 (extract[95:32] ?x6678))
(let (?x6680 (bvmul bv18446744073709551615[64] ?x6679))
(let (?x6681 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6680))
(let (?x6685 (concat ?x6681 bv0[32]))
(let (?x6686 (bvsdiv ?x6685 ?x6684))
(let (?x6687 (extract[63:0] ?x6686))
(flet ($x6688 (= c__qurt_new__sqrt__1__dx_2_0_0_29 ?x6687))
(iff l1121 $x6688)))))))))))))))
:assumption
l1121
:assumption
(let (?x6677 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6682 (bvmul ?x1629 ?x6677))
(let (?x6683 (extract[95:32] ?x6682))
(let (?x6684 (sign_extend[32] ?x6683))
(let (?x6678 (bvmul ?x6677 ?x6677))
(let (?x6679 (extract[95:32] ?x6678))
(let (?x6680 (bvmul bv18446744073709551615[64] ?x6679))
(let (?x6681 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6680))
(let (?x6685 (concat ?x6681 bv0[32]))
(let (?x6686 (bvsdiv ?x6685 ?x6684))
(let (?x6687 (extract[63:0] ?x6686))
(= c__qurt_new__sqrt__1__dx_2_0_0_29 ?x6687))))))))))))))
:assumption
(let (?x6708 (bvadd c__qurt_new__sqrt__1__x_2_0_0_40 c__qurt_new__sqrt__1__dx_2_0_0_29))
(flet ($x6709 (= c__qurt_new__sqrt__1__x_2_0_0_41 ?x6708))
(iff l1122 $x6709)))
:assumption
l1122
:assumption
(let (?x6708 (bvadd c__qurt_new__sqrt__1__x_2_0_0_40 c__qurt_new__sqrt__1__dx_2_0_0_29))
(= c__qurt_new__sqrt__1__x_2_0_0_41 ?x6708))
:assumption
(let (?x6714 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_41))
(let (?x6715 (bvmul ?x6714 ?x6714))
(let (?x6716 (extract[95:32] ?x6715))
(let (?x6717 (bvmul bv18446744073709551615[64] ?x6716))
(let (?x6718 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6717))
(flet ($x6719 (= c__qurt_new__sqrt__1__diff_2_0_0_29 ?x6718))
(iff l1123 $x6719)))))))
:assumption
l1123
:assumption
(let (?x6714 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_41))
(let (?x6715 (bvmul ?x6714 ?x6714))
(let (?x6716 (extract[95:32] ?x6715))
(let (?x6717 (bvmul bv18446744073709551615[64] ?x6716))
(let (?x6718 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6717))
(= c__qurt_new__sqrt__1__diff_2_0_0_29 ?x6718))))))
:assumption
(flet ($x6724 (= c__qurt_new__fabs__n_32_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_29))
(iff l1124 $x6724))
:assumption
l1124
:assumption
(= c__qurt_new__fabs__n_32_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_29)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6729 (bvsge c__qurt_new__fabs__n_32_0_0_1 ?x1542))
(iff l1125 $x6729)))
:assumption
(flet ($x6736 (xor l251 l1125))
(iff l1126 $x6736))
:assumption
(not l1126)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6729 (bvsge c__qurt_new__fabs__n_32_0_0_1 ?x1542))
(= goto_symex___guard_0_0_95 $x6729)))
:assumption
(flet ($x6747 (= c__qurt_new__fabs__1__f_32_0_0_1 c__qurt_new__fabs__n_32_0_0_1))
(iff l1127 $x6747))
:assumption
l1127
:assumption
(= c__qurt_new__fabs__1__f_32_0_0_1 c__qurt_new__fabs__n_32_0_0_1)
:assumption
(let (?x6753 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_32_0_0_1))
(flet ($x6754 (= c__qurt_new__fabs__1__f_32_0_0_3 ?x6753))
(iff l1128 $x6754)))
:assumption
l1128
:assumption
(let (?x6753 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_32_0_0_1))
(= c__qurt_new__fabs__1__f_32_0_0_3 ?x6753))
:assumption
(let (?x6759 (ite goto_symex___guard_0_0_95 c__qurt_new__fabs__1__f_32_0_0_1 c__qurt_new__fabs__1__f_32_0_0_3))
(flet ($x6760 (= c__qurt_new__fabs__1__f_32_0_0_4 ?x6759))
(iff l1129 $x6760)))
:assumption
l1129
:assumption
(let (?x6759 (ite goto_symex___guard_0_0_95 c__qurt_new__fabs__1__f_32_0_0_1 c__qurt_new__fabs__1__f_32_0_0_3))
(= c__qurt_new__fabs__1__f_32_0_0_4 ?x6759))
:assumption
(flet ($x6765 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_29 c__qurt_new__fabs__1__f_32_0_0_4))
(iff l1130 $x6765))
:assumption
l1130
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_29 c__qurt_new__fabs__1__f_32_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6770 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_29 ?x1828))
(iff l1131 $x6770)))
:assumption
(flet ($x6775 (xor l254 l1131))
(iff l1132 $x6775))
:assumption
(not l1132)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6770 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_29 ?x1828))
(= goto_symex___guard_0_0_96 $x6770)))
:assumption
(flet ($x6786 (= c__qurt_new__sqrt__1__flag_2_0_0_40 bv1[32]))
(iff l1133 $x6786))
:assumption
l1133
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_40 bv1[32])
:assumption
(flet ($x6792 (not goto_symex___guard_0_0_96))
(let (?x6793 (ite $x6792 c__qurt_new__sqrt__1__flag_2_0_0_39 c__qurt_new__sqrt__1__flag_2_0_0_40))
(flet ($x6794 (= c__qurt_new__sqrt__1__flag_2_0_0_41 ?x6793))
(iff l1134 $x6794))))
:assumption
l1134
:assumption
(flet ($x6792 (not goto_symex___guard_0_0_96))
(let (?x6793 (ite $x6792 c__qurt_new__sqrt__1__flag_2_0_0_39 c__qurt_new__sqrt__1__flag_2_0_0_40))
(= c__qurt_new__sqrt__1__flag_2_0_0_41 ?x6793)))
:assumption
(flet ($x6801 (= c__qurt_new__sqrt__1__x_2_0_0_42 c__qurt_new__sqrt__1__x_2_0_0_40))
(iff l1135 $x6801))
:assumption
l1135
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_42 c__qurt_new__sqrt__1__x_2_0_0_40)
:assumption
(flet ($x6807 (= c__qurt_new__sqrt__1__flag_2_0_0_42 c__qurt_new__sqrt__1__flag_2_0_0_39))
(iff l1136 $x6807))
:assumption
l1136
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_42 c__qurt_new__sqrt__1__flag_2_0_0_39)
:assumption
(flet ($x6813 (= c__qurt_new__sqrt__1__x_2_0_0_43 c__qurt_new__sqrt__1__x_2_0_0_42))
(iff l1137 $x6813))
:assumption
l1137
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_43 c__qurt_new__sqrt__1__x_2_0_0_42)
:assumption
(let (?x6819 (ite goto_symex___guard_0_0_94 c__qurt_new__sqrt__1__x_2_0_0_41 c__qurt_new__sqrt__1__x_2_0_0_43))
(flet ($x6820 (= c__qurt_new__sqrt__1__x_2_0_0_44 ?x6819))
(iff l1138 $x6820)))
:assumption
l1138
:assumption
(let (?x6819 (ite goto_symex___guard_0_0_94 c__qurt_new__sqrt__1__x_2_0_0_41 c__qurt_new__sqrt__1__x_2_0_0_43))
(= c__qurt_new__sqrt__1__x_2_0_0_44 ?x6819))
:assumption
(let (?x6825 (ite goto_symex___guard_0_0_94 c__qurt_new__sqrt__1__flag_2_0_0_41 c__qurt_new__sqrt__1__flag_2_0_0_42))
(flet ($x6826 (= c__qurt_new__sqrt__1__flag_2_0_0_43 ?x6825))
(iff l1139 $x6826)))
:assumption
l1139
:assumption
(let (?x6825 (ite goto_symex___guard_0_0_94 c__qurt_new__sqrt__1__flag_2_0_0_41 c__qurt_new__sqrt__1__flag_2_0_0_42))
(= c__qurt_new__sqrt__1__flag_2_0_0_43 ?x6825))
:assumption
(flet ($x6830 (= c__qurt_new__sqrt__1__flag_2_0_0_43 bv0[32]))
(iff l1140 $x6830))
:assumption
(flet ($x6835 (xor l257 l1140))
(iff l1141 $x6835))
:assumption
(not l1141)
:assumption
(flet ($x6830 (= c__qurt_new__sqrt__1__flag_2_0_0_43 bv0[32]))
(= goto_symex___guard_0_0_97 $x6830))
:assumption
(let (?x6845 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6850 (bvmul ?x1629 ?x6845))
(let (?x6851 (extract[95:32] ?x6850))
(let (?x6852 (sign_extend[32] ?x6851))
(let (?x6846 (bvmul ?x6845 ?x6845))
(let (?x6847 (extract[95:32] ?x6846))
(let (?x6848 (bvmul bv18446744073709551615[64] ?x6847))
(let (?x6849 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6848))
(let (?x6853 (concat ?x6849 bv0[32]))
(let (?x6854 (bvsdiv ?x6853 ?x6852))
(let (?x6855 (extract[63:0] ?x6854))
(flet ($x6856 (= c__qurt_new__sqrt__1__dx_2_0_0_32 ?x6855))
(iff l1142 $x6856)))))))))))))))
:assumption
l1142
:assumption
(let (?x6845 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6850 (bvmul ?x1629 ?x6845))
(let (?x6851 (extract[95:32] ?x6850))
(let (?x6852 (sign_extend[32] ?x6851))
(let (?x6846 (bvmul ?x6845 ?x6845))
(let (?x6847 (extract[95:32] ?x6846))
(let (?x6848 (bvmul bv18446744073709551615[64] ?x6847))
(let (?x6849 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6848))
(let (?x6853 (concat ?x6849 bv0[32]))
(let (?x6854 (bvsdiv ?x6853 ?x6852))
(let (?x6855 (extract[63:0] ?x6854))
(= c__qurt_new__sqrt__1__dx_2_0_0_32 ?x6855))))))))))))))
:assumption
(let (?x6876 (bvadd c__qurt_new__sqrt__1__x_2_0_0_44 c__qurt_new__sqrt__1__dx_2_0_0_32))
(flet ($x6877 (= c__qurt_new__sqrt__1__x_2_0_0_45 ?x6876))
(iff l1143 $x6877)))
:assumption
l1143
:assumption
(let (?x6876 (bvadd c__qurt_new__sqrt__1__x_2_0_0_44 c__qurt_new__sqrt__1__dx_2_0_0_32))
(= c__qurt_new__sqrt__1__x_2_0_0_45 ?x6876))
:assumption
(let (?x6882 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_45))
(let (?x6883 (bvmul ?x6882 ?x6882))
(let (?x6884 (extract[95:32] ?x6883))
(let (?x6885 (bvmul bv18446744073709551615[64] ?x6884))
(let (?x6886 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6885))
(flet ($x6887 (= c__qurt_new__sqrt__1__diff_2_0_0_32 ?x6886))
(iff l1144 $x6887)))))))
:assumption
l1144
:assumption
(let (?x6882 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_45))
(let (?x6883 (bvmul ?x6882 ?x6882))
(let (?x6884 (extract[95:32] ?x6883))
(let (?x6885 (bvmul bv18446744073709551615[64] ?x6884))
(let (?x6886 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x6885))
(= c__qurt_new__sqrt__1__diff_2_0_0_32 ?x6886))))))
:assumption
(flet ($x6892 (= c__qurt_new__fabs__n_33_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_32))
(iff l1145 $x6892))
:assumption
l1145
:assumption
(= c__qurt_new__fabs__n_33_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_32)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6897 (bvsge c__qurt_new__fabs__n_33_0_0_1 ?x1542))
(iff l1146 $x6897)))
:assumption
(flet ($x6904 (xor l259 l1146))
(iff l1147 $x6904))
:assumption
(not l1147)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x6897 (bvsge c__qurt_new__fabs__n_33_0_0_1 ?x1542))
(= goto_symex___guard_0_0_98 $x6897)))
:assumption
(flet ($x6915 (= c__qurt_new__fabs__1__f_33_0_0_1 c__qurt_new__fabs__n_33_0_0_1))
(iff l1148 $x6915))
:assumption
l1148
:assumption
(= c__qurt_new__fabs__1__f_33_0_0_1 c__qurt_new__fabs__n_33_0_0_1)
:assumption
(let (?x6921 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_33_0_0_1))
(flet ($x6922 (= c__qurt_new__fabs__1__f_33_0_0_3 ?x6921))
(iff l1149 $x6922)))
:assumption
l1149
:assumption
(let (?x6921 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_33_0_0_1))
(= c__qurt_new__fabs__1__f_33_0_0_3 ?x6921))
:assumption
(let (?x6927 (ite goto_symex___guard_0_0_98 c__qurt_new__fabs__1__f_33_0_0_1 c__qurt_new__fabs__1__f_33_0_0_3))
(flet ($x6928 (= c__qurt_new__fabs__1__f_33_0_0_4 ?x6927))
(iff l1150 $x6928)))
:assumption
l1150
:assumption
(let (?x6927 (ite goto_symex___guard_0_0_98 c__qurt_new__fabs__1__f_33_0_0_1 c__qurt_new__fabs__1__f_33_0_0_3))
(= c__qurt_new__fabs__1__f_33_0_0_4 ?x6927))
:assumption
(flet ($x6933 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_32 c__qurt_new__fabs__1__f_33_0_0_4))
(iff l1151 $x6933))
:assumption
l1151
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_32 c__qurt_new__fabs__1__f_33_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6938 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_32 ?x1828))
(iff l1152 $x6938)))
:assumption
(flet ($x6943 (xor l262 l1152))
(iff l1153 $x6943))
:assumption
(not l1153)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x6938 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_32 ?x1828))
(= goto_symex___guard_0_0_99 $x6938)))
:assumption
(flet ($x6954 (= c__qurt_new__sqrt__1__flag_2_0_0_44 bv1[32]))
(iff l1154 $x6954))
:assumption
l1154
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_44 bv1[32])
:assumption
(flet ($x6960 (not goto_symex___guard_0_0_99))
(let (?x6961 (ite $x6960 c__qurt_new__sqrt__1__flag_2_0_0_43 c__qurt_new__sqrt__1__flag_2_0_0_44))
(flet ($x6962 (= c__qurt_new__sqrt__1__flag_2_0_0_45 ?x6961))
(iff l1155 $x6962))))
:assumption
l1155
:assumption
(flet ($x6960 (not goto_symex___guard_0_0_99))
(let (?x6961 (ite $x6960 c__qurt_new__sqrt__1__flag_2_0_0_43 c__qurt_new__sqrt__1__flag_2_0_0_44))
(= c__qurt_new__sqrt__1__flag_2_0_0_45 ?x6961)))
:assumption
(flet ($x6969 (= c__qurt_new__sqrt__1__x_2_0_0_46 c__qurt_new__sqrt__1__x_2_0_0_44))
(iff l1156 $x6969))
:assumption
l1156
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_46 c__qurt_new__sqrt__1__x_2_0_0_44)
:assumption
(flet ($x6975 (= c__qurt_new__sqrt__1__flag_2_0_0_46 c__qurt_new__sqrt__1__flag_2_0_0_43))
(iff l1157 $x6975))
:assumption
l1157
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_46 c__qurt_new__sqrt__1__flag_2_0_0_43)
:assumption
(flet ($x6981 (= c__qurt_new__sqrt__1__x_2_0_0_47 c__qurt_new__sqrt__1__x_2_0_0_46))
(iff l1158 $x6981))
:assumption
l1158
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_47 c__qurt_new__sqrt__1__x_2_0_0_46)
:assumption
(let (?x6987 (ite goto_symex___guard_0_0_97 c__qurt_new__sqrt__1__x_2_0_0_45 c__qurt_new__sqrt__1__x_2_0_0_47))
(flet ($x6988 (= c__qurt_new__sqrt__1__x_2_0_0_48 ?x6987))
(iff l1159 $x6988)))
:assumption
l1159
:assumption
(let (?x6987 (ite goto_symex___guard_0_0_97 c__qurt_new__sqrt__1__x_2_0_0_45 c__qurt_new__sqrt__1__x_2_0_0_47))
(= c__qurt_new__sqrt__1__x_2_0_0_48 ?x6987))
:assumption
(let (?x6993 (ite goto_symex___guard_0_0_97 c__qurt_new__sqrt__1__flag_2_0_0_45 c__qurt_new__sqrt__1__flag_2_0_0_46))
(flet ($x6994 (= c__qurt_new__sqrt__1__flag_2_0_0_47 ?x6993))
(iff l1160 $x6994)))
:assumption
l1160
:assumption
(let (?x6993 (ite goto_symex___guard_0_0_97 c__qurt_new__sqrt__1__flag_2_0_0_45 c__qurt_new__sqrt__1__flag_2_0_0_46))
(= c__qurt_new__sqrt__1__flag_2_0_0_47 ?x6993))
:assumption
(flet ($x6998 (= c__qurt_new__sqrt__1__flag_2_0_0_47 bv0[32]))
(iff l1161 $x6998))
:assumption
(flet ($x7003 (xor l265 l1161))
(iff l1162 $x7003))
:assumption
(not l1162)
:assumption
(flet ($x6998 (= c__qurt_new__sqrt__1__flag_2_0_0_47 bv0[32]))
(= goto_symex___guard_0_0_100 $x6998))
:assumption
(let (?x7013 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7018 (bvmul ?x1629 ?x7013))
(let (?x7019 (extract[95:32] ?x7018))
(let (?x7020 (sign_extend[32] ?x7019))
(let (?x7014 (bvmul ?x7013 ?x7013))
(let (?x7015 (extract[95:32] ?x7014))
(let (?x7016 (bvmul bv18446744073709551615[64] ?x7015))
(let (?x7017 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7016))
(let (?x7021 (concat ?x7017 bv0[32]))
(let (?x7022 (bvsdiv ?x7021 ?x7020))
(let (?x7023 (extract[63:0] ?x7022))
(flet ($x7024 (= c__qurt_new__sqrt__1__dx_2_0_0_35 ?x7023))
(iff l1163 $x7024)))))))))))))))
:assumption
l1163
:assumption
(let (?x7013 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7018 (bvmul ?x1629 ?x7013))
(let (?x7019 (extract[95:32] ?x7018))
(let (?x7020 (sign_extend[32] ?x7019))
(let (?x7014 (bvmul ?x7013 ?x7013))
(let (?x7015 (extract[95:32] ?x7014))
(let (?x7016 (bvmul bv18446744073709551615[64] ?x7015))
(let (?x7017 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7016))
(let (?x7021 (concat ?x7017 bv0[32]))
(let (?x7022 (bvsdiv ?x7021 ?x7020))
(let (?x7023 (extract[63:0] ?x7022))
(= c__qurt_new__sqrt__1__dx_2_0_0_35 ?x7023))))))))))))))
:assumption
(let (?x7044 (bvadd c__qurt_new__sqrt__1__x_2_0_0_48 c__qurt_new__sqrt__1__dx_2_0_0_35))
(flet ($x7045 (= c__qurt_new__sqrt__1__x_2_0_0_49 ?x7044))
(iff l1164 $x7045)))
:assumption
l1164
:assumption
(let (?x7044 (bvadd c__qurt_new__sqrt__1__x_2_0_0_48 c__qurt_new__sqrt__1__dx_2_0_0_35))
(= c__qurt_new__sqrt__1__x_2_0_0_49 ?x7044))
:assumption
(let (?x7050 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_49))
(let (?x7051 (bvmul ?x7050 ?x7050))
(let (?x7052 (extract[95:32] ?x7051))
(let (?x7053 (bvmul bv18446744073709551615[64] ?x7052))
(let (?x7054 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7053))
(flet ($x7055 (= c__qurt_new__sqrt__1__diff_2_0_0_35 ?x7054))
(iff l1165 $x7055)))))))
:assumption
l1165
:assumption
(let (?x7050 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_49))
(let (?x7051 (bvmul ?x7050 ?x7050))
(let (?x7052 (extract[95:32] ?x7051))
(let (?x7053 (bvmul bv18446744073709551615[64] ?x7052))
(let (?x7054 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7053))
(= c__qurt_new__sqrt__1__diff_2_0_0_35 ?x7054))))))
:assumption
(flet ($x7060 (= c__qurt_new__fabs__n_34_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_35))
(iff l1166 $x7060))
:assumption
l1166
:assumption
(= c__qurt_new__fabs__n_34_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_35)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7065 (bvsge c__qurt_new__fabs__n_34_0_0_1 ?x1542))
(iff l1167 $x7065)))
:assumption
(flet ($x7072 (xor l267 l1167))
(iff l1168 $x7072))
:assumption
(not l1168)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7065 (bvsge c__qurt_new__fabs__n_34_0_0_1 ?x1542))
(= goto_symex___guard_0_0_101 $x7065)))
:assumption
(flet ($x7083 (= c__qurt_new__fabs__1__f_34_0_0_1 c__qurt_new__fabs__n_34_0_0_1))
(iff l1169 $x7083))
:assumption
l1169
:assumption
(= c__qurt_new__fabs__1__f_34_0_0_1 c__qurt_new__fabs__n_34_0_0_1)
:assumption
(let (?x7089 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_34_0_0_1))
(flet ($x7090 (= c__qurt_new__fabs__1__f_34_0_0_3 ?x7089))
(iff l1170 $x7090)))
:assumption
l1170
:assumption
(let (?x7089 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_34_0_0_1))
(= c__qurt_new__fabs__1__f_34_0_0_3 ?x7089))
:assumption
(let (?x7095 (ite goto_symex___guard_0_0_101 c__qurt_new__fabs__1__f_34_0_0_1 c__qurt_new__fabs__1__f_34_0_0_3))
(flet ($x7096 (= c__qurt_new__fabs__1__f_34_0_0_4 ?x7095))
(iff l1171 $x7096)))
:assumption
l1171
:assumption
(let (?x7095 (ite goto_symex___guard_0_0_101 c__qurt_new__fabs__1__f_34_0_0_1 c__qurt_new__fabs__1__f_34_0_0_3))
(= c__qurt_new__fabs__1__f_34_0_0_4 ?x7095))
:assumption
(flet ($x7101 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_35 c__qurt_new__fabs__1__f_34_0_0_4))
(iff l1172 $x7101))
:assumption
l1172
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_35 c__qurt_new__fabs__1__f_34_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7106 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_35 ?x1828))
(iff l1173 $x7106)))
:assumption
(flet ($x7111 (xor l270 l1173))
(iff l1174 $x7111))
:assumption
(not l1174)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7106 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_35 ?x1828))
(= goto_symex___guard_0_0_102 $x7106)))
:assumption
(flet ($x7122 (= c__qurt_new__sqrt__1__flag_2_0_0_48 bv1[32]))
(iff l1175 $x7122))
:assumption
l1175
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_48 bv1[32])
:assumption
(flet ($x7128 (not goto_symex___guard_0_0_102))
(let (?x7129 (ite $x7128 c__qurt_new__sqrt__1__flag_2_0_0_47 c__qurt_new__sqrt__1__flag_2_0_0_48))
(flet ($x7130 (= c__qurt_new__sqrt__1__flag_2_0_0_49 ?x7129))
(iff l1176 $x7130))))
:assumption
l1176
:assumption
(flet ($x7128 (not goto_symex___guard_0_0_102))
(let (?x7129 (ite $x7128 c__qurt_new__sqrt__1__flag_2_0_0_47 c__qurt_new__sqrt__1__flag_2_0_0_48))
(= c__qurt_new__sqrt__1__flag_2_0_0_49 ?x7129)))
:assumption
(flet ($x7137 (= c__qurt_new__sqrt__1__x_2_0_0_50 c__qurt_new__sqrt__1__x_2_0_0_48))
(iff l1177 $x7137))
:assumption
l1177
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_50 c__qurt_new__sqrt__1__x_2_0_0_48)
:assumption
(flet ($x7143 (= c__qurt_new__sqrt__1__flag_2_0_0_50 c__qurt_new__sqrt__1__flag_2_0_0_47))
(iff l1178 $x7143))
:assumption
l1178
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_50 c__qurt_new__sqrt__1__flag_2_0_0_47)
:assumption
(flet ($x7149 (= c__qurt_new__sqrt__1__x_2_0_0_51 c__qurt_new__sqrt__1__x_2_0_0_50))
(iff l1179 $x7149))
:assumption
l1179
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_51 c__qurt_new__sqrt__1__x_2_0_0_50)
:assumption
(let (?x7155 (ite goto_symex___guard_0_0_100 c__qurt_new__sqrt__1__x_2_0_0_49 c__qurt_new__sqrt__1__x_2_0_0_51))
(flet ($x7156 (= c__qurt_new__sqrt__1__x_2_0_0_52 ?x7155))
(iff l1180 $x7156)))
:assumption
l1180
:assumption
(let (?x7155 (ite goto_symex___guard_0_0_100 c__qurt_new__sqrt__1__x_2_0_0_49 c__qurt_new__sqrt__1__x_2_0_0_51))
(= c__qurt_new__sqrt__1__x_2_0_0_52 ?x7155))
:assumption
(let (?x7161 (ite goto_symex___guard_0_0_100 c__qurt_new__sqrt__1__flag_2_0_0_49 c__qurt_new__sqrt__1__flag_2_0_0_50))
(flet ($x7162 (= c__qurt_new__sqrt__1__flag_2_0_0_51 ?x7161))
(iff l1181 $x7162)))
:assumption
l1181
:assumption
(let (?x7161 (ite goto_symex___guard_0_0_100 c__qurt_new__sqrt__1__flag_2_0_0_49 c__qurt_new__sqrt__1__flag_2_0_0_50))
(= c__qurt_new__sqrt__1__flag_2_0_0_51 ?x7161))
:assumption
(flet ($x7166 (= c__qurt_new__sqrt__1__flag_2_0_0_51 bv0[32]))
(iff l1182 $x7166))
:assumption
(flet ($x7171 (xor l273 l1182))
(iff l1183 $x7171))
:assumption
(not l1183)
:assumption
(flet ($x7166 (= c__qurt_new__sqrt__1__flag_2_0_0_51 bv0[32]))
(= goto_symex___guard_0_0_103 $x7166))
:assumption
(let (?x7181 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7186 (bvmul ?x1629 ?x7181))
(let (?x7187 (extract[95:32] ?x7186))
(let (?x7188 (sign_extend[32] ?x7187))
(let (?x7182 (bvmul ?x7181 ?x7181))
(let (?x7183 (extract[95:32] ?x7182))
(let (?x7184 (bvmul bv18446744073709551615[64] ?x7183))
(let (?x7185 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7184))
(let (?x7189 (concat ?x7185 bv0[32]))
(let (?x7190 (bvsdiv ?x7189 ?x7188))
(let (?x7191 (extract[63:0] ?x7190))
(flet ($x7192 (= c__qurt_new__sqrt__1__dx_2_0_0_38 ?x7191))
(iff l1184 $x7192)))))))))))))))
:assumption
l1184
:assumption
(let (?x7181 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7186 (bvmul ?x1629 ?x7181))
(let (?x7187 (extract[95:32] ?x7186))
(let (?x7188 (sign_extend[32] ?x7187))
(let (?x7182 (bvmul ?x7181 ?x7181))
(let (?x7183 (extract[95:32] ?x7182))
(let (?x7184 (bvmul bv18446744073709551615[64] ?x7183))
(let (?x7185 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7184))
(let (?x7189 (concat ?x7185 bv0[32]))
(let (?x7190 (bvsdiv ?x7189 ?x7188))
(let (?x7191 (extract[63:0] ?x7190))
(= c__qurt_new__sqrt__1__dx_2_0_0_38 ?x7191))))))))))))))
:assumption
(let (?x7212 (bvadd c__qurt_new__sqrt__1__x_2_0_0_52 c__qurt_new__sqrt__1__dx_2_0_0_38))
(flet ($x7213 (= c__qurt_new__sqrt__1__x_2_0_0_53 ?x7212))
(iff l1185 $x7213)))
:assumption
l1185
:assumption
(let (?x7212 (bvadd c__qurt_new__sqrt__1__x_2_0_0_52 c__qurt_new__sqrt__1__dx_2_0_0_38))
(= c__qurt_new__sqrt__1__x_2_0_0_53 ?x7212))
:assumption
(let (?x7218 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_53))
(let (?x7219 (bvmul ?x7218 ?x7218))
(let (?x7220 (extract[95:32] ?x7219))
(let (?x7221 (bvmul bv18446744073709551615[64] ?x7220))
(let (?x7222 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7221))
(flet ($x7223 (= c__qurt_new__sqrt__1__diff_2_0_0_38 ?x7222))
(iff l1186 $x7223)))))))
:assumption
l1186
:assumption
(let (?x7218 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_53))
(let (?x7219 (bvmul ?x7218 ?x7218))
(let (?x7220 (extract[95:32] ?x7219))
(let (?x7221 (bvmul bv18446744073709551615[64] ?x7220))
(let (?x7222 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7221))
(= c__qurt_new__sqrt__1__diff_2_0_0_38 ?x7222))))))
:assumption
(flet ($x7228 (= c__qurt_new__fabs__n_35_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_38))
(iff l1187 $x7228))
:assumption
l1187
:assumption
(= c__qurt_new__fabs__n_35_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_38)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7233 (bvsge c__qurt_new__fabs__n_35_0_0_1 ?x1542))
(iff l1188 $x7233)))
:assumption
(flet ($x7240 (xor l275 l1188))
(iff l1189 $x7240))
:assumption
(not l1189)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7233 (bvsge c__qurt_new__fabs__n_35_0_0_1 ?x1542))
(= goto_symex___guard_0_0_104 $x7233)))
:assumption
(flet ($x7251 (= c__qurt_new__fabs__1__f_35_0_0_1 c__qurt_new__fabs__n_35_0_0_1))
(iff l1190 $x7251))
:assumption
l1190
:assumption
(= c__qurt_new__fabs__1__f_35_0_0_1 c__qurt_new__fabs__n_35_0_0_1)
:assumption
(let (?x7257 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_35_0_0_1))
(flet ($x7258 (= c__qurt_new__fabs__1__f_35_0_0_3 ?x7257))
(iff l1191 $x7258)))
:assumption
l1191
:assumption
(let (?x7257 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_35_0_0_1))
(= c__qurt_new__fabs__1__f_35_0_0_3 ?x7257))
:assumption
(let (?x7263 (ite goto_symex___guard_0_0_104 c__qurt_new__fabs__1__f_35_0_0_1 c__qurt_new__fabs__1__f_35_0_0_3))
(flet ($x7264 (= c__qurt_new__fabs__1__f_35_0_0_4 ?x7263))
(iff l1192 $x7264)))
:assumption
l1192
:assumption
(let (?x7263 (ite goto_symex___guard_0_0_104 c__qurt_new__fabs__1__f_35_0_0_1 c__qurt_new__fabs__1__f_35_0_0_3))
(= c__qurt_new__fabs__1__f_35_0_0_4 ?x7263))
:assumption
(flet ($x7269 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_38 c__qurt_new__fabs__1__f_35_0_0_4))
(iff l1193 $x7269))
:assumption
l1193
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_38 c__qurt_new__fabs__1__f_35_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7274 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_38 ?x1828))
(iff l1194 $x7274)))
:assumption
(flet ($x7279 (xor l278 l1194))
(iff l1195 $x7279))
:assumption
(not l1195)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7274 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_38 ?x1828))
(= goto_symex___guard_0_0_105 $x7274)))
:assumption
(flet ($x7290 (= c__qurt_new__sqrt__1__flag_2_0_0_52 bv1[32]))
(iff l1196 $x7290))
:assumption
l1196
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_52 bv1[32])
:assumption
(flet ($x7296 (not goto_symex___guard_0_0_105))
(let (?x7297 (ite $x7296 c__qurt_new__sqrt__1__flag_2_0_0_51 c__qurt_new__sqrt__1__flag_2_0_0_52))
(flet ($x7298 (= c__qurt_new__sqrt__1__flag_2_0_0_53 ?x7297))
(iff l1197 $x7298))))
:assumption
l1197
:assumption
(flet ($x7296 (not goto_symex___guard_0_0_105))
(let (?x7297 (ite $x7296 c__qurt_new__sqrt__1__flag_2_0_0_51 c__qurt_new__sqrt__1__flag_2_0_0_52))
(= c__qurt_new__sqrt__1__flag_2_0_0_53 ?x7297)))
:assumption
(flet ($x7305 (= c__qurt_new__sqrt__1__x_2_0_0_54 c__qurt_new__sqrt__1__x_2_0_0_52))
(iff l1198 $x7305))
:assumption
l1198
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_54 c__qurt_new__sqrt__1__x_2_0_0_52)
:assumption
(flet ($x7311 (= c__qurt_new__sqrt__1__flag_2_0_0_54 c__qurt_new__sqrt__1__flag_2_0_0_51))
(iff l1199 $x7311))
:assumption
l1199
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_54 c__qurt_new__sqrt__1__flag_2_0_0_51)
:assumption
(flet ($x7317 (= c__qurt_new__sqrt__1__x_2_0_0_55 c__qurt_new__sqrt__1__x_2_0_0_54))
(iff l1200 $x7317))
:assumption
l1200
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_55 c__qurt_new__sqrt__1__x_2_0_0_54)
:assumption
(let (?x7323 (ite goto_symex___guard_0_0_103 c__qurt_new__sqrt__1__x_2_0_0_53 c__qurt_new__sqrt__1__x_2_0_0_55))
(flet ($x7324 (= c__qurt_new__sqrt__1__x_2_0_0_56 ?x7323))
(iff l1201 $x7324)))
:assumption
l1201
:assumption
(let (?x7323 (ite goto_symex___guard_0_0_103 c__qurt_new__sqrt__1__x_2_0_0_53 c__qurt_new__sqrt__1__x_2_0_0_55))
(= c__qurt_new__sqrt__1__x_2_0_0_56 ?x7323))
:assumption
(let (?x7329 (ite goto_symex___guard_0_0_103 c__qurt_new__sqrt__1__flag_2_0_0_53 c__qurt_new__sqrt__1__flag_2_0_0_54))
(flet ($x7330 (= c__qurt_new__sqrt__1__flag_2_0_0_55 ?x7329))
(iff l1202 $x7330)))
:assumption
l1202
:assumption
(let (?x7329 (ite goto_symex___guard_0_0_103 c__qurt_new__sqrt__1__flag_2_0_0_53 c__qurt_new__sqrt__1__flag_2_0_0_54))
(= c__qurt_new__sqrt__1__flag_2_0_0_55 ?x7329))
:assumption
(flet ($x7334 (= c__qurt_new__sqrt__1__flag_2_0_0_55 bv0[32]))
(iff l1203 $x7334))
:assumption
(flet ($x7339 (xor l281 l1203))
(iff l1204 $x7339))
:assumption
(not l1204)
:assumption
(flet ($x7334 (= c__qurt_new__sqrt__1__flag_2_0_0_55 bv0[32]))
(= goto_symex___guard_0_0_106 $x7334))
:assumption
(let (?x7349 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7354 (bvmul ?x1629 ?x7349))
(let (?x7355 (extract[95:32] ?x7354))
(let (?x7356 (sign_extend[32] ?x7355))
(let (?x7350 (bvmul ?x7349 ?x7349))
(let (?x7351 (extract[95:32] ?x7350))
(let (?x7352 (bvmul bv18446744073709551615[64] ?x7351))
(let (?x7353 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7352))
(let (?x7357 (concat ?x7353 bv0[32]))
(let (?x7358 (bvsdiv ?x7357 ?x7356))
(let (?x7359 (extract[63:0] ?x7358))
(flet ($x7360 (= c__qurt_new__sqrt__1__dx_2_0_0_41 ?x7359))
(iff l1205 $x7360)))))))))))))))
:assumption
l1205
:assumption
(let (?x7349 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7354 (bvmul ?x1629 ?x7349))
(let (?x7355 (extract[95:32] ?x7354))
(let (?x7356 (sign_extend[32] ?x7355))
(let (?x7350 (bvmul ?x7349 ?x7349))
(let (?x7351 (extract[95:32] ?x7350))
(let (?x7352 (bvmul bv18446744073709551615[64] ?x7351))
(let (?x7353 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7352))
(let (?x7357 (concat ?x7353 bv0[32]))
(let (?x7358 (bvsdiv ?x7357 ?x7356))
(let (?x7359 (extract[63:0] ?x7358))
(= c__qurt_new__sqrt__1__dx_2_0_0_41 ?x7359))))))))))))))
:assumption
(let (?x7380 (bvadd c__qurt_new__sqrt__1__x_2_0_0_56 c__qurt_new__sqrt__1__dx_2_0_0_41))
(flet ($x7381 (= c__qurt_new__sqrt__1__x_2_0_0_57 ?x7380))
(iff l1206 $x7381)))
:assumption
l1206
:assumption
(let (?x7380 (bvadd c__qurt_new__sqrt__1__x_2_0_0_56 c__qurt_new__sqrt__1__dx_2_0_0_41))
(= c__qurt_new__sqrt__1__x_2_0_0_57 ?x7380))
:assumption
(let (?x7386 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_57))
(let (?x7387 (bvmul ?x7386 ?x7386))
(let (?x7388 (extract[95:32] ?x7387))
(let (?x7389 (bvmul bv18446744073709551615[64] ?x7388))
(let (?x7390 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7389))
(flet ($x7391 (= c__qurt_new__sqrt__1__diff_2_0_0_41 ?x7390))
(iff l1207 $x7391)))))))
:assumption
l1207
:assumption
(let (?x7386 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_57))
(let (?x7387 (bvmul ?x7386 ?x7386))
(let (?x7388 (extract[95:32] ?x7387))
(let (?x7389 (bvmul bv18446744073709551615[64] ?x7388))
(let (?x7390 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7389))
(= c__qurt_new__sqrt__1__diff_2_0_0_41 ?x7390))))))
:assumption
(flet ($x7396 (= c__qurt_new__fabs__n_36_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_41))
(iff l1208 $x7396))
:assumption
l1208
:assumption
(= c__qurt_new__fabs__n_36_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_41)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7401 (bvsge c__qurt_new__fabs__n_36_0_0_1 ?x1542))
(iff l1209 $x7401)))
:assumption
(flet ($x7408 (xor l283 l1209))
(iff l1210 $x7408))
:assumption
(not l1210)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7401 (bvsge c__qurt_new__fabs__n_36_0_0_1 ?x1542))
(= goto_symex___guard_0_0_107 $x7401)))
:assumption
(flet ($x7419 (= c__qurt_new__fabs__1__f_36_0_0_1 c__qurt_new__fabs__n_36_0_0_1))
(iff l1211 $x7419))
:assumption
l1211
:assumption
(= c__qurt_new__fabs__1__f_36_0_0_1 c__qurt_new__fabs__n_36_0_0_1)
:assumption
(let (?x7425 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_36_0_0_1))
(flet ($x7426 (= c__qurt_new__fabs__1__f_36_0_0_3 ?x7425))
(iff l1212 $x7426)))
:assumption
l1212
:assumption
(let (?x7425 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_36_0_0_1))
(= c__qurt_new__fabs__1__f_36_0_0_3 ?x7425))
:assumption
(let (?x7431 (ite goto_symex___guard_0_0_107 c__qurt_new__fabs__1__f_36_0_0_1 c__qurt_new__fabs__1__f_36_0_0_3))
(flet ($x7432 (= c__qurt_new__fabs__1__f_36_0_0_4 ?x7431))
(iff l1213 $x7432)))
:assumption
l1213
:assumption
(let (?x7431 (ite goto_symex___guard_0_0_107 c__qurt_new__fabs__1__f_36_0_0_1 c__qurt_new__fabs__1__f_36_0_0_3))
(= c__qurt_new__fabs__1__f_36_0_0_4 ?x7431))
:assumption
(flet ($x7437 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_41 c__qurt_new__fabs__1__f_36_0_0_4))
(iff l1214 $x7437))
:assumption
l1214
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_41 c__qurt_new__fabs__1__f_36_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7442 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_41 ?x1828))
(iff l1215 $x7442)))
:assumption
(flet ($x7447 (xor l286 l1215))
(iff l1216 $x7447))
:assumption
(not l1216)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7442 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_41 ?x1828))
(= goto_symex___guard_0_0_108 $x7442)))
:assumption
(flet ($x7458 (= c__qurt_new__sqrt__1__flag_2_0_0_56 bv1[32]))
(iff l1217 $x7458))
:assumption
l1217
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_56 bv1[32])
:assumption
(flet ($x7464 (not goto_symex___guard_0_0_108))
(let (?x7465 (ite $x7464 c__qurt_new__sqrt__1__flag_2_0_0_55 c__qurt_new__sqrt__1__flag_2_0_0_56))
(flet ($x7466 (= c__qurt_new__sqrt__1__flag_2_0_0_57 ?x7465))
(iff l1218 $x7466))))
:assumption
l1218
:assumption
(flet ($x7464 (not goto_symex___guard_0_0_108))
(let (?x7465 (ite $x7464 c__qurt_new__sqrt__1__flag_2_0_0_55 c__qurt_new__sqrt__1__flag_2_0_0_56))
(= c__qurt_new__sqrt__1__flag_2_0_0_57 ?x7465)))
:assumption
(flet ($x7473 (= c__qurt_new__sqrt__1__x_2_0_0_58 c__qurt_new__sqrt__1__x_2_0_0_56))
(iff l1219 $x7473))
:assumption
l1219
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_58 c__qurt_new__sqrt__1__x_2_0_0_56)
:assumption
(flet ($x7479 (= c__qurt_new__sqrt__1__flag_2_0_0_58 c__qurt_new__sqrt__1__flag_2_0_0_55))
(iff l1220 $x7479))
:assumption
l1220
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_58 c__qurt_new__sqrt__1__flag_2_0_0_55)
:assumption
(flet ($x7485 (= c__qurt_new__sqrt__1__x_2_0_0_59 c__qurt_new__sqrt__1__x_2_0_0_58))
(iff l1221 $x7485))
:assumption
l1221
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_59 c__qurt_new__sqrt__1__x_2_0_0_58)
:assumption
(let (?x7491 (ite goto_symex___guard_0_0_106 c__qurt_new__sqrt__1__x_2_0_0_57 c__qurt_new__sqrt__1__x_2_0_0_59))
(flet ($x7492 (= c__qurt_new__sqrt__1__x_2_0_0_60 ?x7491))
(iff l1222 $x7492)))
:assumption
l1222
:assumption
(let (?x7491 (ite goto_symex___guard_0_0_106 c__qurt_new__sqrt__1__x_2_0_0_57 c__qurt_new__sqrt__1__x_2_0_0_59))
(= c__qurt_new__sqrt__1__x_2_0_0_60 ?x7491))
:assumption
(let (?x7497 (ite goto_symex___guard_0_0_106 c__qurt_new__sqrt__1__flag_2_0_0_57 c__qurt_new__sqrt__1__flag_2_0_0_58))
(flet ($x7498 (= c__qurt_new__sqrt__1__flag_2_0_0_59 ?x7497))
(iff l1223 $x7498)))
:assumption
l1223
:assumption
(let (?x7497 (ite goto_symex___guard_0_0_106 c__qurt_new__sqrt__1__flag_2_0_0_57 c__qurt_new__sqrt__1__flag_2_0_0_58))
(= c__qurt_new__sqrt__1__flag_2_0_0_59 ?x7497))
:assumption
(flet ($x7502 (= c__qurt_new__sqrt__1__flag_2_0_0_59 bv0[32]))
(iff l1224 $x7502))
:assumption
(flet ($x7507 (xor l289 l1224))
(iff l1225 $x7507))
:assumption
(not l1225)
:assumption
(flet ($x7502 (= c__qurt_new__sqrt__1__flag_2_0_0_59 bv0[32]))
(= goto_symex___guard_0_0_109 $x7502))
:assumption
(let (?x7517 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7522 (bvmul ?x1629 ?x7517))
(let (?x7523 (extract[95:32] ?x7522))
(let (?x7524 (sign_extend[32] ?x7523))
(let (?x7518 (bvmul ?x7517 ?x7517))
(let (?x7519 (extract[95:32] ?x7518))
(let (?x7520 (bvmul bv18446744073709551615[64] ?x7519))
(let (?x7521 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7520))
(let (?x7525 (concat ?x7521 bv0[32]))
(let (?x7526 (bvsdiv ?x7525 ?x7524))
(let (?x7527 (extract[63:0] ?x7526))
(flet ($x7528 (= c__qurt_new__sqrt__1__dx_2_0_0_44 ?x7527))
(iff l1226 $x7528)))))))))))))))
:assumption
l1226
:assumption
(let (?x7517 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7522 (bvmul ?x1629 ?x7517))
(let (?x7523 (extract[95:32] ?x7522))
(let (?x7524 (sign_extend[32] ?x7523))
(let (?x7518 (bvmul ?x7517 ?x7517))
(let (?x7519 (extract[95:32] ?x7518))
(let (?x7520 (bvmul bv18446744073709551615[64] ?x7519))
(let (?x7521 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7520))
(let (?x7525 (concat ?x7521 bv0[32]))
(let (?x7526 (bvsdiv ?x7525 ?x7524))
(let (?x7527 (extract[63:0] ?x7526))
(= c__qurt_new__sqrt__1__dx_2_0_0_44 ?x7527))))))))))))))
:assumption
(let (?x7548 (bvadd c__qurt_new__sqrt__1__x_2_0_0_60 c__qurt_new__sqrt__1__dx_2_0_0_44))
(flet ($x7549 (= c__qurt_new__sqrt__1__x_2_0_0_61 ?x7548))
(iff l1227 $x7549)))
:assumption
l1227
:assumption
(let (?x7548 (bvadd c__qurt_new__sqrt__1__x_2_0_0_60 c__qurt_new__sqrt__1__dx_2_0_0_44))
(= c__qurt_new__sqrt__1__x_2_0_0_61 ?x7548))
:assumption
(let (?x7554 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_61))
(let (?x7555 (bvmul ?x7554 ?x7554))
(let (?x7556 (extract[95:32] ?x7555))
(let (?x7557 (bvmul bv18446744073709551615[64] ?x7556))
(let (?x7558 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7557))
(flet ($x7559 (= c__qurt_new__sqrt__1__diff_2_0_0_44 ?x7558))
(iff l1228 $x7559)))))))
:assumption
l1228
:assumption
(let (?x7554 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_61))
(let (?x7555 (bvmul ?x7554 ?x7554))
(let (?x7556 (extract[95:32] ?x7555))
(let (?x7557 (bvmul bv18446744073709551615[64] ?x7556))
(let (?x7558 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7557))
(= c__qurt_new__sqrt__1__diff_2_0_0_44 ?x7558))))))
:assumption
(flet ($x7564 (= c__qurt_new__fabs__n_37_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_44))
(iff l1229 $x7564))
:assumption
l1229
:assumption
(= c__qurt_new__fabs__n_37_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_44)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7569 (bvsge c__qurt_new__fabs__n_37_0_0_1 ?x1542))
(iff l1230 $x7569)))
:assumption
(flet ($x7576 (xor l291 l1230))
(iff l1231 $x7576))
:assumption
(not l1231)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7569 (bvsge c__qurt_new__fabs__n_37_0_0_1 ?x1542))
(= goto_symex___guard_0_0_110 $x7569)))
:assumption
(flet ($x7587 (= c__qurt_new__fabs__1__f_37_0_0_1 c__qurt_new__fabs__n_37_0_0_1))
(iff l1232 $x7587))
:assumption
l1232
:assumption
(= c__qurt_new__fabs__1__f_37_0_0_1 c__qurt_new__fabs__n_37_0_0_1)
:assumption
(let (?x7593 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_37_0_0_1))
(flet ($x7594 (= c__qurt_new__fabs__1__f_37_0_0_3 ?x7593))
(iff l1233 $x7594)))
:assumption
l1233
:assumption
(let (?x7593 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_37_0_0_1))
(= c__qurt_new__fabs__1__f_37_0_0_3 ?x7593))
:assumption
(let (?x7599 (ite goto_symex___guard_0_0_110 c__qurt_new__fabs__1__f_37_0_0_1 c__qurt_new__fabs__1__f_37_0_0_3))
(flet ($x7600 (= c__qurt_new__fabs__1__f_37_0_0_4 ?x7599))
(iff l1234 $x7600)))
:assumption
l1234
:assumption
(let (?x7599 (ite goto_symex___guard_0_0_110 c__qurt_new__fabs__1__f_37_0_0_1 c__qurt_new__fabs__1__f_37_0_0_3))
(= c__qurt_new__fabs__1__f_37_0_0_4 ?x7599))
:assumption
(flet ($x7605 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_44 c__qurt_new__fabs__1__f_37_0_0_4))
(iff l1235 $x7605))
:assumption
l1235
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_44 c__qurt_new__fabs__1__f_37_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7610 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_44 ?x1828))
(iff l1236 $x7610)))
:assumption
(flet ($x7615 (xor l294 l1236))
(iff l1237 $x7615))
:assumption
(not l1237)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7610 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_44 ?x1828))
(= goto_symex___guard_0_0_111 $x7610)))
:assumption
(flet ($x7626 (= c__qurt_new__sqrt__1__flag_2_0_0_60 bv1[32]))
(iff l1238 $x7626))
:assumption
l1238
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_60 bv1[32])
:assumption
(flet ($x7632 (not goto_symex___guard_0_0_111))
(let (?x7633 (ite $x7632 c__qurt_new__sqrt__1__flag_2_0_0_59 c__qurt_new__sqrt__1__flag_2_0_0_60))
(flet ($x7634 (= c__qurt_new__sqrt__1__flag_2_0_0_61 ?x7633))
(iff l1239 $x7634))))
:assumption
l1239
:assumption
(flet ($x7632 (not goto_symex___guard_0_0_111))
(let (?x7633 (ite $x7632 c__qurt_new__sqrt__1__flag_2_0_0_59 c__qurt_new__sqrt__1__flag_2_0_0_60))
(= c__qurt_new__sqrt__1__flag_2_0_0_61 ?x7633)))
:assumption
(flet ($x7641 (= c__qurt_new__sqrt__1__x_2_0_0_62 c__qurt_new__sqrt__1__x_2_0_0_60))
(iff l1240 $x7641))
:assumption
l1240
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_62 c__qurt_new__sqrt__1__x_2_0_0_60)
:assumption
(flet ($x7647 (= c__qurt_new__sqrt__1__flag_2_0_0_62 c__qurt_new__sqrt__1__flag_2_0_0_59))
(iff l1241 $x7647))
:assumption
l1241
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_62 c__qurt_new__sqrt__1__flag_2_0_0_59)
:assumption
(flet ($x7653 (= c__qurt_new__sqrt__1__x_2_0_0_63 c__qurt_new__sqrt__1__x_2_0_0_62))
(iff l1242 $x7653))
:assumption
l1242
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_63 c__qurt_new__sqrt__1__x_2_0_0_62)
:assumption
(let (?x7659 (ite goto_symex___guard_0_0_109 c__qurt_new__sqrt__1__x_2_0_0_61 c__qurt_new__sqrt__1__x_2_0_0_63))
(flet ($x7660 (= c__qurt_new__sqrt__1__x_2_0_0_64 ?x7659))
(iff l1243 $x7660)))
:assumption
l1243
:assumption
(let (?x7659 (ite goto_symex___guard_0_0_109 c__qurt_new__sqrt__1__x_2_0_0_61 c__qurt_new__sqrt__1__x_2_0_0_63))
(= c__qurt_new__sqrt__1__x_2_0_0_64 ?x7659))
:assumption
(let (?x7665 (ite goto_symex___guard_0_0_109 c__qurt_new__sqrt__1__flag_2_0_0_61 c__qurt_new__sqrt__1__flag_2_0_0_62))
(flet ($x7666 (= c__qurt_new__sqrt__1__flag_2_0_0_63 ?x7665))
(iff l1244 $x7666)))
:assumption
l1244
:assumption
(let (?x7665 (ite goto_symex___guard_0_0_109 c__qurt_new__sqrt__1__flag_2_0_0_61 c__qurt_new__sqrt__1__flag_2_0_0_62))
(= c__qurt_new__sqrt__1__flag_2_0_0_63 ?x7665))
:assumption
(flet ($x7670 (= c__qurt_new__sqrt__1__flag_2_0_0_63 bv0[32]))
(iff l1245 $x7670))
:assumption
(flet ($x7675 (xor l297 l1245))
(iff l1246 $x7675))
:assumption
(not l1246)
:assumption
(flet ($x7670 (= c__qurt_new__sqrt__1__flag_2_0_0_63 bv0[32]))
(= goto_symex___guard_0_0_112 $x7670))
:assumption
(let (?x7685 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7690 (bvmul ?x1629 ?x7685))
(let (?x7691 (extract[95:32] ?x7690))
(let (?x7692 (sign_extend[32] ?x7691))
(let (?x7686 (bvmul ?x7685 ?x7685))
(let (?x7687 (extract[95:32] ?x7686))
(let (?x7688 (bvmul bv18446744073709551615[64] ?x7687))
(let (?x7689 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7688))
(let (?x7693 (concat ?x7689 bv0[32]))
(let (?x7694 (bvsdiv ?x7693 ?x7692))
(let (?x7695 (extract[63:0] ?x7694))
(flet ($x7696 (= c__qurt_new__sqrt__1__dx_2_0_0_47 ?x7695))
(iff l1247 $x7696)))))))))))))))
:assumption
l1247
:assumption
(let (?x7685 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7690 (bvmul ?x1629 ?x7685))
(let (?x7691 (extract[95:32] ?x7690))
(let (?x7692 (sign_extend[32] ?x7691))
(let (?x7686 (bvmul ?x7685 ?x7685))
(let (?x7687 (extract[95:32] ?x7686))
(let (?x7688 (bvmul bv18446744073709551615[64] ?x7687))
(let (?x7689 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7688))
(let (?x7693 (concat ?x7689 bv0[32]))
(let (?x7694 (bvsdiv ?x7693 ?x7692))
(let (?x7695 (extract[63:0] ?x7694))
(= c__qurt_new__sqrt__1__dx_2_0_0_47 ?x7695))))))))))))))
:assumption
(let (?x7716 (bvadd c__qurt_new__sqrt__1__x_2_0_0_64 c__qurt_new__sqrt__1__dx_2_0_0_47))
(flet ($x7717 (= c__qurt_new__sqrt__1__x_2_0_0_65 ?x7716))
(iff l1248 $x7717)))
:assumption
l1248
:assumption
(let (?x7716 (bvadd c__qurt_new__sqrt__1__x_2_0_0_64 c__qurt_new__sqrt__1__dx_2_0_0_47))
(= c__qurt_new__sqrt__1__x_2_0_0_65 ?x7716))
:assumption
(let (?x7722 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_65))
(let (?x7723 (bvmul ?x7722 ?x7722))
(let (?x7724 (extract[95:32] ?x7723))
(let (?x7725 (bvmul bv18446744073709551615[64] ?x7724))
(let (?x7726 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7725))
(flet ($x7727 (= c__qurt_new__sqrt__1__diff_2_0_0_47 ?x7726))
(iff l1249 $x7727)))))))
:assumption
l1249
:assumption
(let (?x7722 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_65))
(let (?x7723 (bvmul ?x7722 ?x7722))
(let (?x7724 (extract[95:32] ?x7723))
(let (?x7725 (bvmul bv18446744073709551615[64] ?x7724))
(let (?x7726 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7725))
(= c__qurt_new__sqrt__1__diff_2_0_0_47 ?x7726))))))
:assumption
(flet ($x7732 (= c__qurt_new__fabs__n_38_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_47))
(iff l1250 $x7732))
:assumption
l1250
:assumption
(= c__qurt_new__fabs__n_38_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_47)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7737 (bvsge c__qurt_new__fabs__n_38_0_0_1 ?x1542))
(iff l1251 $x7737)))
:assumption
(flet ($x7744 (xor l299 l1251))
(iff l1252 $x7744))
:assumption
(not l1252)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7737 (bvsge c__qurt_new__fabs__n_38_0_0_1 ?x1542))
(= goto_symex___guard_0_0_113 $x7737)))
:assumption
(flet ($x7755 (= c__qurt_new__fabs__1__f_38_0_0_1 c__qurt_new__fabs__n_38_0_0_1))
(iff l1253 $x7755))
:assumption
l1253
:assumption
(= c__qurt_new__fabs__1__f_38_0_0_1 c__qurt_new__fabs__n_38_0_0_1)
:assumption
(let (?x7761 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_38_0_0_1))
(flet ($x7762 (= c__qurt_new__fabs__1__f_38_0_0_3 ?x7761))
(iff l1254 $x7762)))
:assumption
l1254
:assumption
(let (?x7761 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_38_0_0_1))
(= c__qurt_new__fabs__1__f_38_0_0_3 ?x7761))
:assumption
(let (?x7767 (ite goto_symex___guard_0_0_113 c__qurt_new__fabs__1__f_38_0_0_1 c__qurt_new__fabs__1__f_38_0_0_3))
(flet ($x7768 (= c__qurt_new__fabs__1__f_38_0_0_4 ?x7767))
(iff l1255 $x7768)))
:assumption
l1255
:assumption
(let (?x7767 (ite goto_symex___guard_0_0_113 c__qurt_new__fabs__1__f_38_0_0_1 c__qurt_new__fabs__1__f_38_0_0_3))
(= c__qurt_new__fabs__1__f_38_0_0_4 ?x7767))
:assumption
(flet ($x7773 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_47 c__qurt_new__fabs__1__f_38_0_0_4))
(iff l1256 $x7773))
:assumption
l1256
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_47 c__qurt_new__fabs__1__f_38_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7778 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_47 ?x1828))
(iff l1257 $x7778)))
:assumption
(flet ($x7783 (xor l302 l1257))
(iff l1258 $x7783))
:assumption
(not l1258)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7778 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_47 ?x1828))
(= goto_symex___guard_0_0_114 $x7778)))
:assumption
(flet ($x7794 (= c__qurt_new__sqrt__1__flag_2_0_0_64 bv1[32]))
(iff l1259 $x7794))
:assumption
l1259
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_64 bv1[32])
:assumption
(flet ($x7800 (not goto_symex___guard_0_0_114))
(let (?x7801 (ite $x7800 c__qurt_new__sqrt__1__flag_2_0_0_63 c__qurt_new__sqrt__1__flag_2_0_0_64))
(flet ($x7802 (= c__qurt_new__sqrt__1__flag_2_0_0_65 ?x7801))
(iff l1260 $x7802))))
:assumption
l1260
:assumption
(flet ($x7800 (not goto_symex___guard_0_0_114))
(let (?x7801 (ite $x7800 c__qurt_new__sqrt__1__flag_2_0_0_63 c__qurt_new__sqrt__1__flag_2_0_0_64))
(= c__qurt_new__sqrt__1__flag_2_0_0_65 ?x7801)))
:assumption
(flet ($x7809 (= c__qurt_new__sqrt__1__x_2_0_0_66 c__qurt_new__sqrt__1__x_2_0_0_64))
(iff l1261 $x7809))
:assumption
l1261
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_66 c__qurt_new__sqrt__1__x_2_0_0_64)
:assumption
(flet ($x7815 (= c__qurt_new__sqrt__1__flag_2_0_0_66 c__qurt_new__sqrt__1__flag_2_0_0_63))
(iff l1262 $x7815))
:assumption
l1262
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_66 c__qurt_new__sqrt__1__flag_2_0_0_63)
:assumption
(flet ($x7821 (= c__qurt_new__sqrt__1__x_2_0_0_67 c__qurt_new__sqrt__1__x_2_0_0_66))
(iff l1263 $x7821))
:assumption
l1263
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_67 c__qurt_new__sqrt__1__x_2_0_0_66)
:assumption
(let (?x7827 (ite goto_symex___guard_0_0_112 c__qurt_new__sqrt__1__x_2_0_0_65 c__qurt_new__sqrt__1__x_2_0_0_67))
(flet ($x7828 (= c__qurt_new__sqrt__1__x_2_0_0_68 ?x7827))
(iff l1264 $x7828)))
:assumption
l1264
:assumption
(let (?x7827 (ite goto_symex___guard_0_0_112 c__qurt_new__sqrt__1__x_2_0_0_65 c__qurt_new__sqrt__1__x_2_0_0_67))
(= c__qurt_new__sqrt__1__x_2_0_0_68 ?x7827))
:assumption
(let (?x7833 (ite goto_symex___guard_0_0_112 c__qurt_new__sqrt__1__flag_2_0_0_65 c__qurt_new__sqrt__1__flag_2_0_0_66))
(flet ($x7834 (= c__qurt_new__sqrt__1__flag_2_0_0_67 ?x7833))
(iff l1265 $x7834)))
:assumption
l1265
:assumption
(let (?x7833 (ite goto_symex___guard_0_0_112 c__qurt_new__sqrt__1__flag_2_0_0_65 c__qurt_new__sqrt__1__flag_2_0_0_66))
(= c__qurt_new__sqrt__1__flag_2_0_0_67 ?x7833))
:assumption
(flet ($x7838 (= c__qurt_new__sqrt__1__flag_2_0_0_67 bv0[32]))
(iff l1266 $x7838))
:assumption
(flet ($x7843 (xor l305 l1266))
(iff l1267 $x7843))
:assumption
(not l1267)
:assumption
(flet ($x7838 (= c__qurt_new__sqrt__1__flag_2_0_0_67 bv0[32]))
(= goto_symex___guard_0_0_115 $x7838))
:assumption
(let (?x7853 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7858 (bvmul ?x1629 ?x7853))
(let (?x7859 (extract[95:32] ?x7858))
(let (?x7860 (sign_extend[32] ?x7859))
(let (?x7854 (bvmul ?x7853 ?x7853))
(let (?x7855 (extract[95:32] ?x7854))
(let (?x7856 (bvmul bv18446744073709551615[64] ?x7855))
(let (?x7857 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7856))
(let (?x7861 (concat ?x7857 bv0[32]))
(let (?x7862 (bvsdiv ?x7861 ?x7860))
(let (?x7863 (extract[63:0] ?x7862))
(flet ($x7864 (= c__qurt_new__sqrt__1__dx_2_0_0_50 ?x7863))
(iff l1268 $x7864)))))))))))))))
:assumption
l1268
:assumption
(let (?x7853 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7858 (bvmul ?x1629 ?x7853))
(let (?x7859 (extract[95:32] ?x7858))
(let (?x7860 (sign_extend[32] ?x7859))
(let (?x7854 (bvmul ?x7853 ?x7853))
(let (?x7855 (extract[95:32] ?x7854))
(let (?x7856 (bvmul bv18446744073709551615[64] ?x7855))
(let (?x7857 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7856))
(let (?x7861 (concat ?x7857 bv0[32]))
(let (?x7862 (bvsdiv ?x7861 ?x7860))
(let (?x7863 (extract[63:0] ?x7862))
(= c__qurt_new__sqrt__1__dx_2_0_0_50 ?x7863))))))))))))))
:assumption
(let (?x7884 (bvadd c__qurt_new__sqrt__1__x_2_0_0_68 c__qurt_new__sqrt__1__dx_2_0_0_50))
(flet ($x7885 (= c__qurt_new__sqrt__1__x_2_0_0_69 ?x7884))
(iff l1269 $x7885)))
:assumption
l1269
:assumption
(let (?x7884 (bvadd c__qurt_new__sqrt__1__x_2_0_0_68 c__qurt_new__sqrt__1__dx_2_0_0_50))
(= c__qurt_new__sqrt__1__x_2_0_0_69 ?x7884))
:assumption
(let (?x7890 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_69))
(let (?x7891 (bvmul ?x7890 ?x7890))
(let (?x7892 (extract[95:32] ?x7891))
(let (?x7893 (bvmul bv18446744073709551615[64] ?x7892))
(let (?x7894 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7893))
(flet ($x7895 (= c__qurt_new__sqrt__1__diff_2_0_0_50 ?x7894))
(iff l1270 $x7895)))))))
:assumption
l1270
:assumption
(let (?x7890 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_69))
(let (?x7891 (bvmul ?x7890 ?x7890))
(let (?x7892 (extract[95:32] ?x7891))
(let (?x7893 (bvmul bv18446744073709551615[64] ?x7892))
(let (?x7894 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x7893))
(= c__qurt_new__sqrt__1__diff_2_0_0_50 ?x7894))))))
:assumption
(flet ($x7900 (= c__qurt_new__fabs__n_39_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_50))
(iff l1271 $x7900))
:assumption
l1271
:assumption
(= c__qurt_new__fabs__n_39_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_50)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7905 (bvsge c__qurt_new__fabs__n_39_0_0_1 ?x1542))
(iff l1272 $x7905)))
:assumption
(flet ($x7912 (xor l307 l1272))
(iff l1273 $x7912))
:assumption
(not l1273)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x7905 (bvsge c__qurt_new__fabs__n_39_0_0_1 ?x1542))
(= goto_symex___guard_0_0_116 $x7905)))
:assumption
(flet ($x7923 (= c__qurt_new__fabs__1__f_39_0_0_1 c__qurt_new__fabs__n_39_0_0_1))
(iff l1274 $x7923))
:assumption
l1274
:assumption
(= c__qurt_new__fabs__1__f_39_0_0_1 c__qurt_new__fabs__n_39_0_0_1)
:assumption
(let (?x7929 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_39_0_0_1))
(flet ($x7930 (= c__qurt_new__fabs__1__f_39_0_0_3 ?x7929))
(iff l1275 $x7930)))
:assumption
l1275
:assumption
(let (?x7929 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_39_0_0_1))
(= c__qurt_new__fabs__1__f_39_0_0_3 ?x7929))
:assumption
(let (?x7935 (ite goto_symex___guard_0_0_116 c__qurt_new__fabs__1__f_39_0_0_1 c__qurt_new__fabs__1__f_39_0_0_3))
(flet ($x7936 (= c__qurt_new__fabs__1__f_39_0_0_4 ?x7935))
(iff l1276 $x7936)))
:assumption
l1276
:assumption
(let (?x7935 (ite goto_symex___guard_0_0_116 c__qurt_new__fabs__1__f_39_0_0_1 c__qurt_new__fabs__1__f_39_0_0_3))
(= c__qurt_new__fabs__1__f_39_0_0_4 ?x7935))
:assumption
(flet ($x7941 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_50 c__qurt_new__fabs__1__f_39_0_0_4))
(iff l1277 $x7941))
:assumption
l1277
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_50 c__qurt_new__fabs__1__f_39_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7946 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_50 ?x1828))
(iff l1278 $x7946)))
:assumption
(flet ($x7951 (xor l310 l1278))
(iff l1279 $x7951))
:assumption
(not l1279)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x7946 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_50 ?x1828))
(= goto_symex___guard_0_0_117 $x7946)))
:assumption
(flet ($x7962 (= c__qurt_new__sqrt__1__flag_2_0_0_68 bv1[32]))
(iff l1280 $x7962))
:assumption
l1280
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_68 bv1[32])
:assumption
(flet ($x7968 (not goto_symex___guard_0_0_117))
(let (?x7969 (ite $x7968 c__qurt_new__sqrt__1__flag_2_0_0_67 c__qurt_new__sqrt__1__flag_2_0_0_68))
(flet ($x7970 (= c__qurt_new__sqrt__1__flag_2_0_0_69 ?x7969))
(iff l1281 $x7970))))
:assumption
l1281
:assumption
(flet ($x7968 (not goto_symex___guard_0_0_117))
(let (?x7969 (ite $x7968 c__qurt_new__sqrt__1__flag_2_0_0_67 c__qurt_new__sqrt__1__flag_2_0_0_68))
(= c__qurt_new__sqrt__1__flag_2_0_0_69 ?x7969)))
:assumption
(flet ($x7977 (= c__qurt_new__sqrt__1__x_2_0_0_70 c__qurt_new__sqrt__1__x_2_0_0_68))
(iff l1282 $x7977))
:assumption
l1282
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_70 c__qurt_new__sqrt__1__x_2_0_0_68)
:assumption
(flet ($x7983 (= c__qurt_new__sqrt__1__flag_2_0_0_70 c__qurt_new__sqrt__1__flag_2_0_0_67))
(iff l1283 $x7983))
:assumption
l1283
:assumption
(= c__qurt_new__sqrt__1__flag_2_0_0_70 c__qurt_new__sqrt__1__flag_2_0_0_67)
:assumption
(flet ($x7989 (= c__qurt_new__sqrt__1__x_2_0_0_71 c__qurt_new__sqrt__1__x_2_0_0_70))
(iff l1284 $x7989))
:assumption
l1284
:assumption
(= c__qurt_new__sqrt__1__x_2_0_0_71 c__qurt_new__sqrt__1__x_2_0_0_70)
:assumption
(let (?x7995 (ite goto_symex___guard_0_0_115 c__qurt_new__sqrt__1__x_2_0_0_69 c__qurt_new__sqrt__1__x_2_0_0_71))
(flet ($x7996 (= c__qurt_new__sqrt__1__x_2_0_0_72 ?x7995))
(iff l1285 $x7996)))
:assumption
l1285
:assumption
(let (?x7995 (ite goto_symex___guard_0_0_115 c__qurt_new__sqrt__1__x_2_0_0_69 c__qurt_new__sqrt__1__x_2_0_0_71))
(= c__qurt_new__sqrt__1__x_2_0_0_72 ?x7995))
:assumption
(let (?x8001 (ite goto_symex___guard_0_0_115 c__qurt_new__sqrt__1__flag_2_0_0_69 c__qurt_new__sqrt__1__flag_2_0_0_70))
(flet ($x8002 (= c__qurt_new__sqrt__1__flag_2_0_0_71 ?x8001))
(iff l1286 $x8002)))
:assumption
l1286
:assumption
(let (?x8001 (ite goto_symex___guard_0_0_115 c__qurt_new__sqrt__1__flag_2_0_0_69 c__qurt_new__sqrt__1__flag_2_0_0_70))
(= c__qurt_new__sqrt__1__flag_2_0_0_71 ?x8001))
:assumption
(flet ($x8006 (= c__qurt_new__sqrt__1__flag_2_0_0_71 bv0[32]))
(iff l1287 $x8006))
:assumption
(flet ($x8011 (xor l313 l1287))
(iff l1288 $x8011))
:assumption
(not l1288)
:assumption
(flet ($x8006 (= c__qurt_new__sqrt__1__flag_2_0_0_71 bv0[32]))
(= goto_symex___guard_0_0_118 $x8006))
:assumption
(let (?x8022 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8027 (bvmul ?x1629 ?x8022))
(let (?x8028 (extract[95:32] ?x8027))
(let (?x8029 (sign_extend[32] ?x8028))
(let (?x8023 (bvmul ?x8022 ?x8022))
(let (?x8024 (extract[95:32] ?x8023))
(let (?x8025 (bvmul bv18446744073709551615[64] ?x8024))
(let (?x8026 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x8025))
(let (?x8030 (concat ?x8026 bv0[32]))
(let (?x8031 (bvsdiv ?x8030 ?x8029))
(let (?x8032 (extract[63:0] ?x8031))
(flet ($x8033 (= c__qurt_new__sqrt__1__dx_2_0_0_53 ?x8032))
(iff l1289 $x8033)))))))))))))))
:assumption
l1289
:assumption
(let (?x8022 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8027 (bvmul ?x1629 ?x8022))
(let (?x8028 (extract[95:32] ?x8027))
(let (?x8029 (sign_extend[32] ?x8028))
(let (?x8023 (bvmul ?x8022 ?x8022))
(let (?x8024 (extract[95:32] ?x8023))
(let (?x8025 (bvmul bv18446744073709551615[64] ?x8024))
(let (?x8026 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x8025))
(let (?x8030 (concat ?x8026 bv0[32]))
(let (?x8031 (bvsdiv ?x8030 ?x8029))
(let (?x8032 (extract[63:0] ?x8031))
(= c__qurt_new__sqrt__1__dx_2_0_0_53 ?x8032))))))))))))))
:assumption
(let (?x8053 (bvadd c__qurt_new__sqrt__1__x_2_0_0_72 c__qurt_new__sqrt__1__dx_2_0_0_53))
(flet ($x8054 (= c__qurt_new__sqrt__1__x_2_0_0_73 ?x8053))
(iff l1290 $x8054)))
:assumption
l1290
:assumption
(let (?x8053 (bvadd c__qurt_new__sqrt__1__x_2_0_0_72 c__qurt_new__sqrt__1__dx_2_0_0_53))
(= c__qurt_new__sqrt__1__x_2_0_0_73 ?x8053))
:assumption
(let (?x8059 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_73))
(let (?x8060 (bvmul ?x8059 ?x8059))
(let (?x8061 (extract[95:32] ?x8060))
(let (?x8062 (bvmul bv18446744073709551615[64] ?x8061))
(let (?x8063 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x8062))
(flet ($x8064 (= c__qurt_new__sqrt__1__diff_2_0_0_53 ?x8063))
(iff l1291 $x8064)))))))
:assumption
l1291
:assumption
(let (?x8059 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_73))
(let (?x8060 (bvmul ?x8059 ?x8059))
(let (?x8061 (extract[95:32] ?x8060))
(let (?x8062 (bvmul bv18446744073709551615[64] ?x8061))
(let (?x8063 (bvadd c__qurt_new__sqrt__val_2_0_0_1 ?x8062))
(= c__qurt_new__sqrt__1__diff_2_0_0_53 ?x8063))))))
:assumption
(flet ($x8069 (= c__qurt_new__fabs__n_40_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_53))
(iff l1292 $x8069))
:assumption
l1292
:assumption
(= c__qurt_new__fabs__n_40_0_0_1 c__qurt_new__sqrt__1__diff_2_0_0_53)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8074 (bvsge c__qurt_new__fabs__n_40_0_0_1 ?x1542))
(iff l1293 $x8074)))
:assumption
(flet ($x8081 (xor l315 l1293))
(iff l1294 $x8081))
:assumption
(not l1294)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8074 (bvsge c__qurt_new__fabs__n_40_0_0_1 ?x1542))
(= goto_symex___guard_0_0_119 $x8074)))
:assumption
(flet ($x8092 (= c__qurt_new__fabs__1__f_40_0_0_1 c__qurt_new__fabs__n_40_0_0_1))
(iff l1295 $x8092))
:assumption
l1295
:assumption
(= c__qurt_new__fabs__1__f_40_0_0_1 c__qurt_new__fabs__n_40_0_0_1)
:assumption
(let (?x8098 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_40_0_0_1))
(flet ($x8099 (= c__qurt_new__fabs__1__f_40_0_0_3 ?x8098))
(iff l1296 $x8099)))
:assumption
l1296
:assumption
(let (?x8098 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_40_0_0_1))
(= c__qurt_new__fabs__1__f_40_0_0_3 ?x8098))
:assumption
(let (?x8104 (ite goto_symex___guard_0_0_119 c__qurt_new__fabs__1__f_40_0_0_1 c__qurt_new__fabs__1__f_40_0_0_3))
(flet ($x8105 (= c__qurt_new__fabs__1__f_40_0_0_4 ?x8104))
(iff l1297 $x8105)))
:assumption
l1297
:assumption
(let (?x8104 (ite goto_symex___guard_0_0_119 c__qurt_new__fabs__1__f_40_0_0_1 c__qurt_new__fabs__1__f_40_0_0_3))
(= c__qurt_new__fabs__1__f_40_0_0_4 ?x8104))
:assumption
(flet ($x8110 (= c__sqrt___tmp__return_value_fabs_2_2_0_0_53 c__qurt_new__fabs__1__f_40_0_0_4))
(iff l1298 $x8110))
:assumption
l1298
:assumption
(= c__sqrt___tmp__return_value_fabs_2_2_0_0_53 c__qurt_new__fabs__1__f_40_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8115 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_53 ?x1828))
(iff l1300 $x8115)))
:assumption
(flet ($x8121 (xor l1299 l1300))
(iff l1301 $x8121))
:assumption
(not l1301)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8115 (bvsle c__sqrt___tmp__return_value_fabs_2_2_0_0_53 ?x1828))
(= goto_symex___guard_0_0_120 $x8115)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8131 (bvsgt c__qurt_new__qurt__1__d_2_0_0_1 ?x1542))
(iff l1302 $x8131)))
:assumption
(flet ($x8139 (xor l318 l1302))
(iff l1303 $x8139))
:assumption
(not l1303)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8131 (bvsgt c__qurt_new__qurt__1__d_2_0_0_1 ?x1542))
(= goto_symex___guard_0_0_121 $x8131)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8149 (= c__qurt_new__qurt__1__d_2_0_0_1 ?x1542))
(iff l1304 $x8149)))
:assumption
(flet ($x8154 (xor l321 l1304))
(iff l1305 $x8154))
:assumption
(not l1305)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8149 (= c__qurt_new__qurt__1__d_2_0_0_1 ?x1542))
(= goto_symex___guard_0_0_122 $x8149)))
:assumption
(let (?x8165 (store c__a_0_7 bv0[32] nondet_symex__nondet6))
(flet ($x8166 (= c__a_0_8 ?x8165))
(iff l1306 $x8166)))
:assumption
l1306
:assumption
(let (?x8165 (store c__a_0_7 bv0[32] nondet_symex__nondet6))
(= c__a_0_8 ?x8165))
:assumption
(let (?x8172 (store c__a_0_8 bv1[32] nondet_symex__nondet7))
(flet ($x8173 (= c__a_0_9 ?x8172))
(iff l1307 $x8173)))
:assumption
l1307
:assumption
(let (?x8172 (store c__a_0_8 bv1[32] nondet_symex__nondet7))
(= c__a_0_9 ?x8172))
:assumption
(let (?x8179 (store c__a_0_9 bv2[32] nondet_symex__nondet8))
(flet ($x8180 (= c__a_0_10 ?x8179))
(iff l1308 $x8180)))
:assumption
l1308
:assumption
(let (?x8179 (store c__a_0_9 bv2[32] nondet_symex__nondet8))
(= c__a_0_10 ?x8179))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8184 (select c__a_0_10 bv0[32]))
(flet ($x8185 (= ?x8184 ?x1542))
(iff l1309 $x8185))))
:assumption
(flet ($x8190 (xor l324 l1309))
(iff l1310 $x8190))
:assumption
(not l1310)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8184 (select c__a_0_10 bv0[32]))
(flet ($x8185 (= ?x8184 ?x1542))
(= goto_symex___guard_0_0_123 $x8185))))
:assumption
(let (?x8208 (select c__a_0_10 bv2[32]))
(let (?x8209 (sign_extend[32] ?x8208))
(let (?x8184 (select c__a_0_10 bv0[32]))
(let (?x8204 (sign_extend[32] ?x8184))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x8205 (bvmul ?x1601 ?x8204))
(let (?x8206 (extract[95:32] ?x8205))
(let (?x8207 (sign_extend[32] ?x8206))
(let (?x8210 (bvmul ?x8207 ?x8209))
(let (?x8211 (extract[95:32] ?x8210))
(let (?x8212 (bvmul bv18446744073709551615[64] ?x8211))
(let (?x8200 (select c__a_0_10 bv1[32]))
(let (?x8201 (sign_extend[32] ?x8200))
(let (?x8202 (bvmul ?x8201 ?x8201))
(let (?x8203 (extract[95:32] ?x8202))
(let (?x8213 (bvadd ?x8203 ?x8212))
(flet ($x8214 (= c__qurt_new__qurt__1__d_3_0_0_1 ?x8213))
(iff l1311 $x8214)))))))))))))))))))
:assumption
l1311
:assumption
(let (?x8208 (select c__a_0_10 bv2[32]))
(let (?x8209 (sign_extend[32] ?x8208))
(let (?x8184 (select c__a_0_10 bv0[32]))
(let (?x8204 (sign_extend[32] ?x8184))
(let (?x1600 (concat bv4[32] bv0[32]))
(let (?x1601 (sign_extend[32] ?x1600))
(let (?x8205 (bvmul ?x1601 ?x8204))
(let (?x8206 (extract[95:32] ?x8205))
(let (?x8207 (sign_extend[32] ?x8206))
(let (?x8210 (bvmul ?x8207 ?x8209))
(let (?x8211 (extract[95:32] ?x8210))
(let (?x8212 (bvmul bv18446744073709551615[64] ?x8211))
(let (?x8200 (select c__a_0_10 bv1[32]))
(let (?x8201 (sign_extend[32] ?x8200))
(let (?x8202 (bvmul ?x8201 ?x8201))
(let (?x8203 (extract[95:32] ?x8202))
(let (?x8213 (bvadd ?x8203 ?x8212))
(= c__qurt_new__qurt__1__d_3_0_0_1 ?x8213))))))))))))))))))
:assumption
(let (?x8184 (select c__a_0_10 bv0[32]))
(let (?x8204 (sign_extend[32] ?x8184))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8227 (bvmul ?x1629 ?x8204))
(let (?x8228 (extract[95:32] ?x8227))
(flet ($x8229 (= c__qurt_new__qurt__1__w1_3_0_0_1 ?x8228))
(iff l1312 $x8229))))))))
:assumption
l1312
:assumption
(let (?x8184 (select c__a_0_10 bv0[32]))
(let (?x8204 (sign_extend[32] ?x8184))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8227 (bvmul ?x1629 ?x8204))
(let (?x8228 (extract[95:32] ?x8227))
(= c__qurt_new__qurt__1__w1_3_0_0_1 ?x8228)))))))
:assumption
(flet ($x8237 (= c__qurt_new__fabs__n_41_0_0_1 c__qurt_new__qurt__1__d_3_0_0_1))
(iff l1313 $x8237))
:assumption
l1313
:assumption
(= c__qurt_new__fabs__n_41_0_0_1 c__qurt_new__qurt__1__d_3_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8242 (bvsge c__qurt_new__fabs__n_41_0_0_1 ?x1542))
(iff l1314 $x8242)))
:assumption
(flet ($x8249 (xor l327 l1314))
(iff l1315 $x8249))
:assumption
(not l1315)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8242 (bvsge c__qurt_new__fabs__n_41_0_0_1 ?x1542))
(= goto_symex___guard_0_0_124 $x8242)))
:assumption
(flet ($x8260 (= c__qurt_new__fabs__1__f_41_0_0_1 c__qurt_new__fabs__n_41_0_0_1))
(iff l1316 $x8260))
:assumption
l1316
:assumption
(= c__qurt_new__fabs__1__f_41_0_0_1 c__qurt_new__fabs__n_41_0_0_1)
:assumption
(let (?x8266 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_41_0_0_1))
(flet ($x8267 (= c__qurt_new__fabs__1__f_41_0_0_3 ?x8266))
(iff l1317 $x8267)))
:assumption
l1317
:assumption
(let (?x8266 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_41_0_0_1))
(= c__qurt_new__fabs__1__f_41_0_0_3 ?x8266))
:assumption
(let (?x8272 (ite goto_symex___guard_0_0_124 c__qurt_new__fabs__1__f_41_0_0_1 c__qurt_new__fabs__1__f_41_0_0_3))
(flet ($x8273 (= c__qurt_new__fabs__1__f_41_0_0_4 ?x8272))
(iff l1318 $x8273)))
:assumption
l1318
:assumption
(let (?x8272 (ite goto_symex___guard_0_0_124 c__qurt_new__fabs__1__f_41_0_0_1 c__qurt_new__fabs__1__f_41_0_0_3))
(= c__qurt_new__fabs__1__f_41_0_0_4 ?x8272))
:assumption
(flet ($x8278 (= c__qurt___tmp__return_value_fabs_1_3_0_0_1 c__qurt_new__fabs__1__f_41_0_0_4))
(iff l1319 $x8278))
:assumption
l1319
:assumption
(= c__qurt___tmp__return_value_fabs_1_3_0_0_1 c__qurt_new__fabs__1__f_41_0_0_4)
:assumption
(flet ($x8284 (= c__qurt_new__sqrt__val_3_0_0_1 c__qurt___tmp__return_value_fabs_1_3_0_0_1))
(iff l1320 $x8284))
:assumption
l1320
:assumption
(= c__qurt_new__sqrt__val_3_0_0_1 c__qurt___tmp__return_value_fabs_1_3_0_0_1)
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x8290 (concat c__qurt_new__sqrt__val_3_0_0_1 bv0[32]))
(let (?x8291 (bvsdiv ?x8290 ?x1697))
(let (?x8292 (extract[63:0] ?x8291))
(flet ($x8293 (= c__qurt_new__sqrt__1__x_3_0_0_1 ?x8292))
(iff l1321 $x8293)))))))
:assumption
l1321
:assumption
(let (?x1696 (concat bv10[32] bv0[32]))
(let (?x1697 (sign_extend[32] ?x1696))
(let (?x8290 (concat c__qurt_new__sqrt__val_3_0_0_1 bv0[32]))
(let (?x8291 (bvsdiv ?x8290 ?x1697))
(let (?x8292 (extract[63:0] ?x8291))
(= c__qurt_new__sqrt__1__x_3_0_0_1 ?x8292))))))
:assumption
(flet ($x8301 (= c__qurt_new__sqrt__1__flag_3_0_0_1 bv0[32]))
(iff l1322 $x8301))
:assumption
l1322
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_1 bv0[32])
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8306 (= c__qurt_new__sqrt__val_3_0_0_1 ?x1542))
(iff l1323 $x8306)))
:assumption
(flet ($x8311 (xor l330 l1323))
(iff l1324 $x8311))
:assumption
(not l1324)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8306 (= c__qurt_new__sqrt__val_3_0_0_1 ?x1542))
(= goto_symex___guard_0_0_125 $x8306)))
:assumption
(flet ($x8321 (= c__qurt_new__sqrt__1__x_3_0_0_3 c__qurt_new__sqrt__1__x_3_0_0_1))
(iff l1325 $x8321))
:assumption
l1325
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_3 c__qurt_new__sqrt__1__x_3_0_0_1)
:assumption
(let (?x8327 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8332 (bvmul ?x1629 ?x8327))
(let (?x8333 (extract[95:32] ?x8332))
(let (?x8334 (sign_extend[32] ?x8333))
(let (?x8328 (bvmul ?x8327 ?x8327))
(let (?x8329 (extract[95:32] ?x8328))
(let (?x8330 (bvmul bv18446744073709551615[64] ?x8329))
(let (?x8331 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8330))
(let (?x8335 (concat ?x8331 bv0[32]))
(let (?x8336 (bvsdiv ?x8335 ?x8334))
(let (?x8337 (extract[63:0] ?x8336))
(flet ($x8338 (= c__qurt_new__sqrt__1__dx_3_0_0_1 ?x8337))
(iff l1326 $x8338)))))))))))))))
:assumption
l1326
:assumption
(let (?x8327 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8332 (bvmul ?x1629 ?x8327))
(let (?x8333 (extract[95:32] ?x8332))
(let (?x8334 (sign_extend[32] ?x8333))
(let (?x8328 (bvmul ?x8327 ?x8327))
(let (?x8329 (extract[95:32] ?x8328))
(let (?x8330 (bvmul bv18446744073709551615[64] ?x8329))
(let (?x8331 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8330))
(let (?x8335 (concat ?x8331 bv0[32]))
(let (?x8336 (bvsdiv ?x8335 ?x8334))
(let (?x8337 (extract[63:0] ?x8336))
(= c__qurt_new__sqrt__1__dx_3_0_0_1 ?x8337))))))))))))))
:assumption
(let (?x8358 (bvadd c__qurt_new__sqrt__1__x_3_0_0_3 c__qurt_new__sqrt__1__dx_3_0_0_1))
(flet ($x8359 (= c__qurt_new__sqrt__1__x_3_0_0_4 ?x8358))
(iff l1327 $x8359)))
:assumption
l1327
:assumption
(let (?x8358 (bvadd c__qurt_new__sqrt__1__x_3_0_0_3 c__qurt_new__sqrt__1__dx_3_0_0_1))
(= c__qurt_new__sqrt__1__x_3_0_0_4 ?x8358))
:assumption
(let (?x8364 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_4))
(let (?x8365 (bvmul ?x8364 ?x8364))
(let (?x8366 (extract[95:32] ?x8365))
(let (?x8367 (bvmul bv18446744073709551615[64] ?x8366))
(let (?x8368 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8367))
(flet ($x8369 (= c__qurt_new__sqrt__1__diff_3_0_0_1 ?x8368))
(iff l1328 $x8369)))))))
:assumption
l1328
:assumption
(let (?x8364 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_4))
(let (?x8365 (bvmul ?x8364 ?x8364))
(let (?x8366 (extract[95:32] ?x8365))
(let (?x8367 (bvmul bv18446744073709551615[64] ?x8366))
(let (?x8368 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8367))
(= c__qurt_new__sqrt__1__diff_3_0_0_1 ?x8368))))))
:assumption
(flet ($x8374 (= c__qurt_new__fabs__n_42_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_1))
(iff l1329 $x8374))
:assumption
l1329
:assumption
(= c__qurt_new__fabs__n_42_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_1)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8379 (bvsge c__qurt_new__fabs__n_42_0_0_1 ?x1542))
(iff l1330 $x8379)))
:assumption
(flet ($x8386 (xor l333 l1330))
(iff l1331 $x8386))
:assumption
(not l1331)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8379 (bvsge c__qurt_new__fabs__n_42_0_0_1 ?x1542))
(= goto_symex___guard_0_0_126 $x8379)))
:assumption
(flet ($x8397 (= c__qurt_new__fabs__1__f_42_0_0_1 c__qurt_new__fabs__n_42_0_0_1))
(iff l1332 $x8397))
:assumption
l1332
:assumption
(= c__qurt_new__fabs__1__f_42_0_0_1 c__qurt_new__fabs__n_42_0_0_1)
:assumption
(let (?x8403 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_42_0_0_1))
(flet ($x8404 (= c__qurt_new__fabs__1__f_42_0_0_3 ?x8403))
(iff l1333 $x8404)))
:assumption
l1333
:assumption
(let (?x8403 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_42_0_0_1))
(= c__qurt_new__fabs__1__f_42_0_0_3 ?x8403))
:assumption
(let (?x8409 (ite goto_symex___guard_0_0_126 c__qurt_new__fabs__1__f_42_0_0_1 c__qurt_new__fabs__1__f_42_0_0_3))
(flet ($x8410 (= c__qurt_new__fabs__1__f_42_0_0_4 ?x8409))
(iff l1334 $x8410)))
:assumption
l1334
:assumption
(let (?x8409 (ite goto_symex___guard_0_0_126 c__qurt_new__fabs__1__f_42_0_0_1 c__qurt_new__fabs__1__f_42_0_0_3))
(= c__qurt_new__fabs__1__f_42_0_0_4 ?x8409))
:assumption
(flet ($x8415 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_1 c__qurt_new__fabs__1__f_42_0_0_4))
(iff l1335 $x8415))
:assumption
l1335
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_1 c__qurt_new__fabs__1__f_42_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8420 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_1 ?x1828))
(iff l1336 $x8420)))
:assumption
(flet ($x8425 (xor l336 l1336))
(iff l1337 $x8425))
:assumption
(not l1337)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8420 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_1 ?x1828))
(= goto_symex___guard_0_0_127 $x8420)))
:assumption
(flet ($x8436 (= c__qurt_new__sqrt__1__flag_3_0_0_2 bv1[32]))
(iff l1338 $x8436))
:assumption
l1338
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_2 bv1[32])
:assumption
(flet ($x8442 (not goto_symex___guard_0_0_127))
(let (?x8443 (ite $x8442 c__qurt_new__sqrt__1__flag_3_0_0_1 c__qurt_new__sqrt__1__flag_3_0_0_2))
(flet ($x8444 (= c__qurt_new__sqrt__1__flag_3_0_0_3 ?x8443))
(iff l1339 $x8444))))
:assumption
l1339
:assumption
(flet ($x8442 (not goto_symex___guard_0_0_127))
(let (?x8443 (ite $x8442 c__qurt_new__sqrt__1__flag_3_0_0_1 c__qurt_new__sqrt__1__flag_3_0_0_2))
(= c__qurt_new__sqrt__1__flag_3_0_0_3 ?x8443)))
:assumption
(flet ($x8450 (= c__qurt_new__sqrt__1__flag_3_0_0_3 bv0[32]))
(iff l1340 $x8450))
:assumption
(flet ($x8455 (xor l338 l1340))
(iff l1341 $x8455))
:assumption
(not l1341)
:assumption
(flet ($x8450 (= c__qurt_new__sqrt__1__flag_3_0_0_3 bv0[32]))
(= goto_symex___guard_0_0_128 $x8450))
:assumption
(let (?x8364 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8465 (bvmul ?x1629 ?x8364))
(let (?x8466 (extract[95:32] ?x8465))
(let (?x8467 (sign_extend[32] ?x8466))
(let (?x8365 (bvmul ?x8364 ?x8364))
(let (?x8366 (extract[95:32] ?x8365))
(let (?x8367 (bvmul bv18446744073709551615[64] ?x8366))
(let (?x8368 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8367))
(let (?x8468 (concat ?x8368 bv0[32]))
(let (?x8469 (bvsdiv ?x8468 ?x8467))
(let (?x8470 (extract[63:0] ?x8469))
(flet ($x8471 (= c__qurt_new__sqrt__1__dx_3_0_0_2 ?x8470))
(iff l1342 $x8471)))))))))))))))
:assumption
l1342
:assumption
(let (?x8364 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8465 (bvmul ?x1629 ?x8364))
(let (?x8466 (extract[95:32] ?x8465))
(let (?x8467 (sign_extend[32] ?x8466))
(let (?x8365 (bvmul ?x8364 ?x8364))
(let (?x8366 (extract[95:32] ?x8365))
(let (?x8367 (bvmul bv18446744073709551615[64] ?x8366))
(let (?x8368 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8367))
(let (?x8468 (concat ?x8368 bv0[32]))
(let (?x8469 (bvsdiv ?x8468 ?x8467))
(let (?x8470 (extract[63:0] ?x8469))
(= c__qurt_new__sqrt__1__dx_3_0_0_2 ?x8470))))))))))))))
:assumption
(let (?x8491 (bvadd c__qurt_new__sqrt__1__x_3_0_0_4 c__qurt_new__sqrt__1__dx_3_0_0_2))
(flet ($x8492 (= c__qurt_new__sqrt__1__x_3_0_0_5 ?x8491))
(iff l1343 $x8492)))
:assumption
l1343
:assumption
(let (?x8491 (bvadd c__qurt_new__sqrt__1__x_3_0_0_4 c__qurt_new__sqrt__1__dx_3_0_0_2))
(= c__qurt_new__sqrt__1__x_3_0_0_5 ?x8491))
:assumption
(let (?x8497 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_5))
(let (?x8498 (bvmul ?x8497 ?x8497))
(let (?x8499 (extract[95:32] ?x8498))
(let (?x8500 (bvmul bv18446744073709551615[64] ?x8499))
(let (?x8501 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8500))
(flet ($x8502 (= c__qurt_new__sqrt__1__diff_3_0_0_2 ?x8501))
(iff l1344 $x8502)))))))
:assumption
l1344
:assumption
(let (?x8497 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_5))
(let (?x8498 (bvmul ?x8497 ?x8497))
(let (?x8499 (extract[95:32] ?x8498))
(let (?x8500 (bvmul bv18446744073709551615[64] ?x8499))
(let (?x8501 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8500))
(= c__qurt_new__sqrt__1__diff_3_0_0_2 ?x8501))))))
:assumption
(flet ($x8507 (= c__qurt_new__fabs__n_43_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_2))
(iff l1345 $x8507))
:assumption
l1345
:assumption
(= c__qurt_new__fabs__n_43_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_2)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8512 (bvsge c__qurt_new__fabs__n_43_0_0_1 ?x1542))
(iff l1346 $x8512)))
:assumption
(flet ($x8519 (xor l340 l1346))
(iff l1347 $x8519))
:assumption
(not l1347)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8512 (bvsge c__qurt_new__fabs__n_43_0_0_1 ?x1542))
(= goto_symex___guard_0_0_129 $x8512)))
:assumption
(flet ($x8530 (= c__qurt_new__fabs__1__f_43_0_0_1 c__qurt_new__fabs__n_43_0_0_1))
(iff l1348 $x8530))
:assumption
l1348
:assumption
(= c__qurt_new__fabs__1__f_43_0_0_1 c__qurt_new__fabs__n_43_0_0_1)
:assumption
(let (?x8536 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_43_0_0_1))
(flet ($x8537 (= c__qurt_new__fabs__1__f_43_0_0_3 ?x8536))
(iff l1349 $x8537)))
:assumption
l1349
:assumption
(let (?x8536 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_43_0_0_1))
(= c__qurt_new__fabs__1__f_43_0_0_3 ?x8536))
:assumption
(let (?x8542 (ite goto_symex___guard_0_0_129 c__qurt_new__fabs__1__f_43_0_0_1 c__qurt_new__fabs__1__f_43_0_0_3))
(flet ($x8543 (= c__qurt_new__fabs__1__f_43_0_0_4 ?x8542))
(iff l1350 $x8543)))
:assumption
l1350
:assumption
(let (?x8542 (ite goto_symex___guard_0_0_129 c__qurt_new__fabs__1__f_43_0_0_1 c__qurt_new__fabs__1__f_43_0_0_3))
(= c__qurt_new__fabs__1__f_43_0_0_4 ?x8542))
:assumption
(flet ($x8548 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_2 c__qurt_new__fabs__1__f_43_0_0_4))
(iff l1351 $x8548))
:assumption
l1351
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_2 c__qurt_new__fabs__1__f_43_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8553 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_2 ?x1828))
(iff l1352 $x8553)))
:assumption
(flet ($x8558 (xor l343 l1352))
(iff l1353 $x8558))
:assumption
(not l1353)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8553 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_2 ?x1828))
(= goto_symex___guard_0_0_130 $x8553)))
:assumption
(flet ($x8569 (= c__qurt_new__sqrt__1__flag_3_0_0_4 bv1[32]))
(iff l1354 $x8569))
:assumption
l1354
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_4 bv1[32])
:assumption
(flet ($x8575 (not goto_symex___guard_0_0_130))
(let (?x8576 (ite $x8575 c__qurt_new__sqrt__1__flag_3_0_0_3 c__qurt_new__sqrt__1__flag_3_0_0_4))
(flet ($x8577 (= c__qurt_new__sqrt__1__flag_3_0_0_5 ?x8576))
(iff l1355 $x8577))))
:assumption
l1355
:assumption
(flet ($x8575 (not goto_symex___guard_0_0_130))
(let (?x8576 (ite $x8575 c__qurt_new__sqrt__1__flag_3_0_0_3 c__qurt_new__sqrt__1__flag_3_0_0_4))
(= c__qurt_new__sqrt__1__flag_3_0_0_5 ?x8576)))
:assumption
(flet ($x8584 (= c__qurt_new__sqrt__1__x_3_0_0_6 c__qurt_new__sqrt__1__x_3_0_0_4))
(iff l1356 $x8584))
:assumption
l1356
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_6 c__qurt_new__sqrt__1__x_3_0_0_4)
:assumption
(flet ($x8590 (= c__qurt_new__sqrt__1__flag_3_0_0_6 c__qurt_new__sqrt__1__flag_3_0_0_3))
(iff l1357 $x8590))
:assumption
l1357
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_6 c__qurt_new__sqrt__1__flag_3_0_0_3)
:assumption
(flet ($x8596 (= c__qurt_new__sqrt__1__x_3_0_0_7 c__qurt_new__sqrt__1__x_3_0_0_6))
(iff l1358 $x8596))
:assumption
l1358
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_7 c__qurt_new__sqrt__1__x_3_0_0_6)
:assumption
(let (?x8602 (ite goto_symex___guard_0_0_128 c__qurt_new__sqrt__1__x_3_0_0_5 c__qurt_new__sqrt__1__x_3_0_0_7))
(flet ($x8603 (= c__qurt_new__sqrt__1__x_3_0_0_8 ?x8602))
(iff l1359 $x8603)))
:assumption
l1359
:assumption
(let (?x8602 (ite goto_symex___guard_0_0_128 c__qurt_new__sqrt__1__x_3_0_0_5 c__qurt_new__sqrt__1__x_3_0_0_7))
(= c__qurt_new__sqrt__1__x_3_0_0_8 ?x8602))
:assumption
(let (?x8608 (ite goto_symex___guard_0_0_128 c__qurt_new__sqrt__1__flag_3_0_0_5 c__qurt_new__sqrt__1__flag_3_0_0_6))
(flet ($x8609 (= c__qurt_new__sqrt__1__flag_3_0_0_7 ?x8608))
(iff l1360 $x8609)))
:assumption
l1360
:assumption
(let (?x8608 (ite goto_symex___guard_0_0_128 c__qurt_new__sqrt__1__flag_3_0_0_5 c__qurt_new__sqrt__1__flag_3_0_0_6))
(= c__qurt_new__sqrt__1__flag_3_0_0_7 ?x8608))
:assumption
(flet ($x8613 (= c__qurt_new__sqrt__1__flag_3_0_0_7 bv0[32]))
(iff l1361 $x8613))
:assumption
(flet ($x8618 (xor l346 l1361))
(iff l1362 $x8618))
:assumption
(not l1362)
:assumption
(flet ($x8613 (= c__qurt_new__sqrt__1__flag_3_0_0_7 bv0[32]))
(= goto_symex___guard_0_0_131 $x8613))
:assumption
(let (?x8628 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8633 (bvmul ?x1629 ?x8628))
(let (?x8634 (extract[95:32] ?x8633))
(let (?x8635 (sign_extend[32] ?x8634))
(let (?x8629 (bvmul ?x8628 ?x8628))
(let (?x8630 (extract[95:32] ?x8629))
(let (?x8631 (bvmul bv18446744073709551615[64] ?x8630))
(let (?x8632 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8631))
(let (?x8636 (concat ?x8632 bv0[32]))
(let (?x8637 (bvsdiv ?x8636 ?x8635))
(let (?x8638 (extract[63:0] ?x8637))
(flet ($x8639 (= c__qurt_new__sqrt__1__dx_3_0_0_5 ?x8638))
(iff l1363 $x8639)))))))))))))))
:assumption
l1363
:assumption
(let (?x8628 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8633 (bvmul ?x1629 ?x8628))
(let (?x8634 (extract[95:32] ?x8633))
(let (?x8635 (sign_extend[32] ?x8634))
(let (?x8629 (bvmul ?x8628 ?x8628))
(let (?x8630 (extract[95:32] ?x8629))
(let (?x8631 (bvmul bv18446744073709551615[64] ?x8630))
(let (?x8632 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8631))
(let (?x8636 (concat ?x8632 bv0[32]))
(let (?x8637 (bvsdiv ?x8636 ?x8635))
(let (?x8638 (extract[63:0] ?x8637))
(= c__qurt_new__sqrt__1__dx_3_0_0_5 ?x8638))))))))))))))
:assumption
(let (?x8659 (bvadd c__qurt_new__sqrt__1__x_3_0_0_8 c__qurt_new__sqrt__1__dx_3_0_0_5))
(flet ($x8660 (= c__qurt_new__sqrt__1__x_3_0_0_9 ?x8659))
(iff l1364 $x8660)))
:assumption
l1364
:assumption
(let (?x8659 (bvadd c__qurt_new__sqrt__1__x_3_0_0_8 c__qurt_new__sqrt__1__dx_3_0_0_5))
(= c__qurt_new__sqrt__1__x_3_0_0_9 ?x8659))
:assumption
(let (?x8665 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_9))
(let (?x8666 (bvmul ?x8665 ?x8665))
(let (?x8667 (extract[95:32] ?x8666))
(let (?x8668 (bvmul bv18446744073709551615[64] ?x8667))
(let (?x8669 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8668))
(flet ($x8670 (= c__qurt_new__sqrt__1__diff_3_0_0_5 ?x8669))
(iff l1365 $x8670)))))))
:assumption
l1365
:assumption
(let (?x8665 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_9))
(let (?x8666 (bvmul ?x8665 ?x8665))
(let (?x8667 (extract[95:32] ?x8666))
(let (?x8668 (bvmul bv18446744073709551615[64] ?x8667))
(let (?x8669 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8668))
(= c__qurt_new__sqrt__1__diff_3_0_0_5 ?x8669))))))
:assumption
(flet ($x8675 (= c__qurt_new__fabs__n_44_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_5))
(iff l1366 $x8675))
:assumption
l1366
:assumption
(= c__qurt_new__fabs__n_44_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_5)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8680 (bvsge c__qurt_new__fabs__n_44_0_0_1 ?x1542))
(iff l1367 $x8680)))
:assumption
(flet ($x8687 (xor l348 l1367))
(iff l1368 $x8687))
:assumption
(not l1368)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8680 (bvsge c__qurt_new__fabs__n_44_0_0_1 ?x1542))
(= goto_symex___guard_0_0_132 $x8680)))
:assumption
(flet ($x8698 (= c__qurt_new__fabs__1__f_44_0_0_1 c__qurt_new__fabs__n_44_0_0_1))
(iff l1369 $x8698))
:assumption
l1369
:assumption
(= c__qurt_new__fabs__1__f_44_0_0_1 c__qurt_new__fabs__n_44_0_0_1)
:assumption
(let (?x8704 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_44_0_0_1))
(flet ($x8705 (= c__qurt_new__fabs__1__f_44_0_0_3 ?x8704))
(iff l1370 $x8705)))
:assumption
l1370
:assumption
(let (?x8704 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_44_0_0_1))
(= c__qurt_new__fabs__1__f_44_0_0_3 ?x8704))
:assumption
(let (?x8710 (ite goto_symex___guard_0_0_132 c__qurt_new__fabs__1__f_44_0_0_1 c__qurt_new__fabs__1__f_44_0_0_3))
(flet ($x8711 (= c__qurt_new__fabs__1__f_44_0_0_4 ?x8710))
(iff l1371 $x8711)))
:assumption
l1371
:assumption
(let (?x8710 (ite goto_symex___guard_0_0_132 c__qurt_new__fabs__1__f_44_0_0_1 c__qurt_new__fabs__1__f_44_0_0_3))
(= c__qurt_new__fabs__1__f_44_0_0_4 ?x8710))
:assumption
(flet ($x8716 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_5 c__qurt_new__fabs__1__f_44_0_0_4))
(iff l1372 $x8716))
:assumption
l1372
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_5 c__qurt_new__fabs__1__f_44_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8721 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_5 ?x1828))
(iff l1373 $x8721)))
:assumption
(flet ($x8726 (xor l351 l1373))
(iff l1374 $x8726))
:assumption
(not l1374)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8721 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_5 ?x1828))
(= goto_symex___guard_0_0_133 $x8721)))
:assumption
(flet ($x8737 (= c__qurt_new__sqrt__1__flag_3_0_0_8 bv1[32]))
(iff l1375 $x8737))
:assumption
l1375
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_8 bv1[32])
:assumption
(flet ($x8743 (not goto_symex___guard_0_0_133))
(let (?x8744 (ite $x8743 c__qurt_new__sqrt__1__flag_3_0_0_7 c__qurt_new__sqrt__1__flag_3_0_0_8))
(flet ($x8745 (= c__qurt_new__sqrt__1__flag_3_0_0_9 ?x8744))
(iff l1376 $x8745))))
:assumption
l1376
:assumption
(flet ($x8743 (not goto_symex___guard_0_0_133))
(let (?x8744 (ite $x8743 c__qurt_new__sqrt__1__flag_3_0_0_7 c__qurt_new__sqrt__1__flag_3_0_0_8))
(= c__qurt_new__sqrt__1__flag_3_0_0_9 ?x8744)))
:assumption
(flet ($x8752 (= c__qurt_new__sqrt__1__x_3_0_0_10 c__qurt_new__sqrt__1__x_3_0_0_8))
(iff l1377 $x8752))
:assumption
l1377
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_10 c__qurt_new__sqrt__1__x_3_0_0_8)
:assumption
(flet ($x8758 (= c__qurt_new__sqrt__1__flag_3_0_0_10 c__qurt_new__sqrt__1__flag_3_0_0_7))
(iff l1378 $x8758))
:assumption
l1378
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_10 c__qurt_new__sqrt__1__flag_3_0_0_7)
:assumption
(flet ($x8764 (= c__qurt_new__sqrt__1__x_3_0_0_11 c__qurt_new__sqrt__1__x_3_0_0_10))
(iff l1379 $x8764))
:assumption
l1379
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_11 c__qurt_new__sqrt__1__x_3_0_0_10)
:assumption
(let (?x8770 (ite goto_symex___guard_0_0_131 c__qurt_new__sqrt__1__x_3_0_0_9 c__qurt_new__sqrt__1__x_3_0_0_11))
(flet ($x8771 (= c__qurt_new__sqrt__1__x_3_0_0_12 ?x8770))
(iff l1380 $x8771)))
:assumption
l1380
:assumption
(let (?x8770 (ite goto_symex___guard_0_0_131 c__qurt_new__sqrt__1__x_3_0_0_9 c__qurt_new__sqrt__1__x_3_0_0_11))
(= c__qurt_new__sqrt__1__x_3_0_0_12 ?x8770))
:assumption
(let (?x8776 (ite goto_symex___guard_0_0_131 c__qurt_new__sqrt__1__flag_3_0_0_9 c__qurt_new__sqrt__1__flag_3_0_0_10))
(flet ($x8777 (= c__qurt_new__sqrt__1__flag_3_0_0_11 ?x8776))
(iff l1381 $x8777)))
:assumption
l1381
:assumption
(let (?x8776 (ite goto_symex___guard_0_0_131 c__qurt_new__sqrt__1__flag_3_0_0_9 c__qurt_new__sqrt__1__flag_3_0_0_10))
(= c__qurt_new__sqrt__1__flag_3_0_0_11 ?x8776))
:assumption
(flet ($x8781 (= c__qurt_new__sqrt__1__flag_3_0_0_11 bv0[32]))
(iff l1382 $x8781))
:assumption
(flet ($x8786 (xor l354 l1382))
(iff l1383 $x8786))
:assumption
(not l1383)
:assumption
(flet ($x8781 (= c__qurt_new__sqrt__1__flag_3_0_0_11 bv0[32]))
(= goto_symex___guard_0_0_134 $x8781))
:assumption
(let (?x8796 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8801 (bvmul ?x1629 ?x8796))
(let (?x8802 (extract[95:32] ?x8801))
(let (?x8803 (sign_extend[32] ?x8802))
(let (?x8797 (bvmul ?x8796 ?x8796))
(let (?x8798 (extract[95:32] ?x8797))
(let (?x8799 (bvmul bv18446744073709551615[64] ?x8798))
(let (?x8800 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8799))
(let (?x8804 (concat ?x8800 bv0[32]))
(let (?x8805 (bvsdiv ?x8804 ?x8803))
(let (?x8806 (extract[63:0] ?x8805))
(flet ($x8807 (= c__qurt_new__sqrt__1__dx_3_0_0_8 ?x8806))
(iff l1384 $x8807)))))))))))))))
:assumption
l1384
:assumption
(let (?x8796 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8801 (bvmul ?x1629 ?x8796))
(let (?x8802 (extract[95:32] ?x8801))
(let (?x8803 (sign_extend[32] ?x8802))
(let (?x8797 (bvmul ?x8796 ?x8796))
(let (?x8798 (extract[95:32] ?x8797))
(let (?x8799 (bvmul bv18446744073709551615[64] ?x8798))
(let (?x8800 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8799))
(let (?x8804 (concat ?x8800 bv0[32]))
(let (?x8805 (bvsdiv ?x8804 ?x8803))
(let (?x8806 (extract[63:0] ?x8805))
(= c__qurt_new__sqrt__1__dx_3_0_0_8 ?x8806))))))))))))))
:assumption
(let (?x8827 (bvadd c__qurt_new__sqrt__1__x_3_0_0_12 c__qurt_new__sqrt__1__dx_3_0_0_8))
(flet ($x8828 (= c__qurt_new__sqrt__1__x_3_0_0_13 ?x8827))
(iff l1385 $x8828)))
:assumption
l1385
:assumption
(let (?x8827 (bvadd c__qurt_new__sqrt__1__x_3_0_0_12 c__qurt_new__sqrt__1__dx_3_0_0_8))
(= c__qurt_new__sqrt__1__x_3_0_0_13 ?x8827))
:assumption
(let (?x8833 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_13))
(let (?x8834 (bvmul ?x8833 ?x8833))
(let (?x8835 (extract[95:32] ?x8834))
(let (?x8836 (bvmul bv18446744073709551615[64] ?x8835))
(let (?x8837 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8836))
(flet ($x8838 (= c__qurt_new__sqrt__1__diff_3_0_0_8 ?x8837))
(iff l1386 $x8838)))))))
:assumption
l1386
:assumption
(let (?x8833 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_13))
(let (?x8834 (bvmul ?x8833 ?x8833))
(let (?x8835 (extract[95:32] ?x8834))
(let (?x8836 (bvmul bv18446744073709551615[64] ?x8835))
(let (?x8837 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8836))
(= c__qurt_new__sqrt__1__diff_3_0_0_8 ?x8837))))))
:assumption
(flet ($x8843 (= c__qurt_new__fabs__n_45_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_8))
(iff l1387 $x8843))
:assumption
l1387
:assumption
(= c__qurt_new__fabs__n_45_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_8)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8848 (bvsge c__qurt_new__fabs__n_45_0_0_1 ?x1542))
(iff l1388 $x8848)))
:assumption
(flet ($x8855 (xor l356 l1388))
(iff l1389 $x8855))
:assumption
(not l1389)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x8848 (bvsge c__qurt_new__fabs__n_45_0_0_1 ?x1542))
(= goto_symex___guard_0_0_135 $x8848)))
:assumption
(flet ($x8866 (= c__qurt_new__fabs__1__f_45_0_0_1 c__qurt_new__fabs__n_45_0_0_1))
(iff l1390 $x8866))
:assumption
l1390
:assumption
(= c__qurt_new__fabs__1__f_45_0_0_1 c__qurt_new__fabs__n_45_0_0_1)
:assumption
(let (?x8872 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_45_0_0_1))
(flet ($x8873 (= c__qurt_new__fabs__1__f_45_0_0_3 ?x8872))
(iff l1391 $x8873)))
:assumption
l1391
:assumption
(let (?x8872 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_45_0_0_1))
(= c__qurt_new__fabs__1__f_45_0_0_3 ?x8872))
:assumption
(let (?x8878 (ite goto_symex___guard_0_0_135 c__qurt_new__fabs__1__f_45_0_0_1 c__qurt_new__fabs__1__f_45_0_0_3))
(flet ($x8879 (= c__qurt_new__fabs__1__f_45_0_0_4 ?x8878))
(iff l1392 $x8879)))
:assumption
l1392
:assumption
(let (?x8878 (ite goto_symex___guard_0_0_135 c__qurt_new__fabs__1__f_45_0_0_1 c__qurt_new__fabs__1__f_45_0_0_3))
(= c__qurt_new__fabs__1__f_45_0_0_4 ?x8878))
:assumption
(flet ($x8884 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_8 c__qurt_new__fabs__1__f_45_0_0_4))
(iff l1393 $x8884))
:assumption
l1393
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_8 c__qurt_new__fabs__1__f_45_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8889 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_8 ?x1828))
(iff l1394 $x8889)))
:assumption
(flet ($x8894 (xor l359 l1394))
(iff l1395 $x8894))
:assumption
(not l1395)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x8889 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_8 ?x1828))
(= goto_symex___guard_0_0_136 $x8889)))
:assumption
(flet ($x8905 (= c__qurt_new__sqrt__1__flag_3_0_0_12 bv1[32]))
(iff l1396 $x8905))
:assumption
l1396
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_12 bv1[32])
:assumption
(flet ($x8911 (not goto_symex___guard_0_0_136))
(let (?x8912 (ite $x8911 c__qurt_new__sqrt__1__flag_3_0_0_11 c__qurt_new__sqrt__1__flag_3_0_0_12))
(flet ($x8913 (= c__qurt_new__sqrt__1__flag_3_0_0_13 ?x8912))
(iff l1397 $x8913))))
:assumption
l1397
:assumption
(flet ($x8911 (not goto_symex___guard_0_0_136))
(let (?x8912 (ite $x8911 c__qurt_new__sqrt__1__flag_3_0_0_11 c__qurt_new__sqrt__1__flag_3_0_0_12))
(= c__qurt_new__sqrt__1__flag_3_0_0_13 ?x8912)))
:assumption
(flet ($x8920 (= c__qurt_new__sqrt__1__x_3_0_0_14 c__qurt_new__sqrt__1__x_3_0_0_12))
(iff l1398 $x8920))
:assumption
l1398
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_14 c__qurt_new__sqrt__1__x_3_0_0_12)
:assumption
(flet ($x8926 (= c__qurt_new__sqrt__1__flag_3_0_0_14 c__qurt_new__sqrt__1__flag_3_0_0_11))
(iff l1399 $x8926))
:assumption
l1399
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_14 c__qurt_new__sqrt__1__flag_3_0_0_11)
:assumption
(flet ($x8932 (= c__qurt_new__sqrt__1__x_3_0_0_15 c__qurt_new__sqrt__1__x_3_0_0_14))
(iff l1400 $x8932))
:assumption
l1400
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_15 c__qurt_new__sqrt__1__x_3_0_0_14)
:assumption
(let (?x8938 (ite goto_symex___guard_0_0_134 c__qurt_new__sqrt__1__x_3_0_0_13 c__qurt_new__sqrt__1__x_3_0_0_15))
(flet ($x8939 (= c__qurt_new__sqrt__1__x_3_0_0_16 ?x8938))
(iff l1401 $x8939)))
:assumption
l1401
:assumption
(let (?x8938 (ite goto_symex___guard_0_0_134 c__qurt_new__sqrt__1__x_3_0_0_13 c__qurt_new__sqrt__1__x_3_0_0_15))
(= c__qurt_new__sqrt__1__x_3_0_0_16 ?x8938))
:assumption
(let (?x8944 (ite goto_symex___guard_0_0_134 c__qurt_new__sqrt__1__flag_3_0_0_13 c__qurt_new__sqrt__1__flag_3_0_0_14))
(flet ($x8945 (= c__qurt_new__sqrt__1__flag_3_0_0_15 ?x8944))
(iff l1402 $x8945)))
:assumption
l1402
:assumption
(let (?x8944 (ite goto_symex___guard_0_0_134 c__qurt_new__sqrt__1__flag_3_0_0_13 c__qurt_new__sqrt__1__flag_3_0_0_14))
(= c__qurt_new__sqrt__1__flag_3_0_0_15 ?x8944))
:assumption
(flet ($x8949 (= c__qurt_new__sqrt__1__flag_3_0_0_15 bv0[32]))
(iff l1403 $x8949))
:assumption
(flet ($x8954 (xor l362 l1403))
(iff l1404 $x8954))
:assumption
(not l1404)
:assumption
(flet ($x8949 (= c__qurt_new__sqrt__1__flag_3_0_0_15 bv0[32]))
(= goto_symex___guard_0_0_137 $x8949))
:assumption
(let (?x8964 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8969 (bvmul ?x1629 ?x8964))
(let (?x8970 (extract[95:32] ?x8969))
(let (?x8971 (sign_extend[32] ?x8970))
(let (?x8965 (bvmul ?x8964 ?x8964))
(let (?x8966 (extract[95:32] ?x8965))
(let (?x8967 (bvmul bv18446744073709551615[64] ?x8966))
(let (?x8968 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8967))
(let (?x8972 (concat ?x8968 bv0[32]))
(let (?x8973 (bvsdiv ?x8972 ?x8971))
(let (?x8974 (extract[63:0] ?x8973))
(flet ($x8975 (= c__qurt_new__sqrt__1__dx_3_0_0_11 ?x8974))
(iff l1405 $x8975)))))))))))))))
:assumption
l1405
:assumption
(let (?x8964 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8969 (bvmul ?x1629 ?x8964))
(let (?x8970 (extract[95:32] ?x8969))
(let (?x8971 (sign_extend[32] ?x8970))
(let (?x8965 (bvmul ?x8964 ?x8964))
(let (?x8966 (extract[95:32] ?x8965))
(let (?x8967 (bvmul bv18446744073709551615[64] ?x8966))
(let (?x8968 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x8967))
(let (?x8972 (concat ?x8968 bv0[32]))
(let (?x8973 (bvsdiv ?x8972 ?x8971))
(let (?x8974 (extract[63:0] ?x8973))
(= c__qurt_new__sqrt__1__dx_3_0_0_11 ?x8974))))))))))))))
:assumption
(let (?x8995 (bvadd c__qurt_new__sqrt__1__x_3_0_0_16 c__qurt_new__sqrt__1__dx_3_0_0_11))
(flet ($x8996 (= c__qurt_new__sqrt__1__x_3_0_0_17 ?x8995))
(iff l1406 $x8996)))
:assumption
l1406
:assumption
(let (?x8995 (bvadd c__qurt_new__sqrt__1__x_3_0_0_16 c__qurt_new__sqrt__1__dx_3_0_0_11))
(= c__qurt_new__sqrt__1__x_3_0_0_17 ?x8995))
:assumption
(let (?x9001 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_17))
(let (?x9002 (bvmul ?x9001 ?x9001))
(let (?x9003 (extract[95:32] ?x9002))
(let (?x9004 (bvmul bv18446744073709551615[64] ?x9003))
(let (?x9005 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9004))
(flet ($x9006 (= c__qurt_new__sqrt__1__diff_3_0_0_11 ?x9005))
(iff l1407 $x9006)))))))
:assumption
l1407
:assumption
(let (?x9001 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_17))
(let (?x9002 (bvmul ?x9001 ?x9001))
(let (?x9003 (extract[95:32] ?x9002))
(let (?x9004 (bvmul bv18446744073709551615[64] ?x9003))
(let (?x9005 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9004))
(= c__qurt_new__sqrt__1__diff_3_0_0_11 ?x9005))))))
:assumption
(flet ($x9011 (= c__qurt_new__fabs__n_46_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_11))
(iff l1408 $x9011))
:assumption
l1408
:assumption
(= c__qurt_new__fabs__n_46_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_11)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9016 (bvsge c__qurt_new__fabs__n_46_0_0_1 ?x1542))
(iff l1409 $x9016)))
:assumption
(flet ($x9023 (xor l364 l1409))
(iff l1410 $x9023))
:assumption
(not l1410)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9016 (bvsge c__qurt_new__fabs__n_46_0_0_1 ?x1542))
(= goto_symex___guard_0_0_138 $x9016)))
:assumption
(flet ($x9034 (= c__qurt_new__fabs__1__f_46_0_0_1 c__qurt_new__fabs__n_46_0_0_1))
(iff l1411 $x9034))
:assumption
l1411
:assumption
(= c__qurt_new__fabs__1__f_46_0_0_1 c__qurt_new__fabs__n_46_0_0_1)
:assumption
(let (?x9040 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_46_0_0_1))
(flet ($x9041 (= c__qurt_new__fabs__1__f_46_0_0_3 ?x9040))
(iff l1412 $x9041)))
:assumption
l1412
:assumption
(let (?x9040 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_46_0_0_1))
(= c__qurt_new__fabs__1__f_46_0_0_3 ?x9040))
:assumption
(let (?x9046 (ite goto_symex___guard_0_0_138 c__qurt_new__fabs__1__f_46_0_0_1 c__qurt_new__fabs__1__f_46_0_0_3))
(flet ($x9047 (= c__qurt_new__fabs__1__f_46_0_0_4 ?x9046))
(iff l1413 $x9047)))
:assumption
l1413
:assumption
(let (?x9046 (ite goto_symex___guard_0_0_138 c__qurt_new__fabs__1__f_46_0_0_1 c__qurt_new__fabs__1__f_46_0_0_3))
(= c__qurt_new__fabs__1__f_46_0_0_4 ?x9046))
:assumption
(flet ($x9052 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_11 c__qurt_new__fabs__1__f_46_0_0_4))
(iff l1414 $x9052))
:assumption
l1414
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_11 c__qurt_new__fabs__1__f_46_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9057 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_11 ?x1828))
(iff l1415 $x9057)))
:assumption
(flet ($x9062 (xor l367 l1415))
(iff l1416 $x9062))
:assumption
(not l1416)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9057 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_11 ?x1828))
(= goto_symex___guard_0_0_139 $x9057)))
:assumption
(flet ($x9073 (= c__qurt_new__sqrt__1__flag_3_0_0_16 bv1[32]))
(iff l1417 $x9073))
:assumption
l1417
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_16 bv1[32])
:assumption
(flet ($x9079 (not goto_symex___guard_0_0_139))
(let (?x9080 (ite $x9079 c__qurt_new__sqrt__1__flag_3_0_0_15 c__qurt_new__sqrt__1__flag_3_0_0_16))
(flet ($x9081 (= c__qurt_new__sqrt__1__flag_3_0_0_17 ?x9080))
(iff l1418 $x9081))))
:assumption
l1418
:assumption
(flet ($x9079 (not goto_symex___guard_0_0_139))
(let (?x9080 (ite $x9079 c__qurt_new__sqrt__1__flag_3_0_0_15 c__qurt_new__sqrt__1__flag_3_0_0_16))
(= c__qurt_new__sqrt__1__flag_3_0_0_17 ?x9080)))
:assumption
(flet ($x9088 (= c__qurt_new__sqrt__1__x_3_0_0_18 c__qurt_new__sqrt__1__x_3_0_0_16))
(iff l1419 $x9088))
:assumption
l1419
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_18 c__qurt_new__sqrt__1__x_3_0_0_16)
:assumption
(flet ($x9094 (= c__qurt_new__sqrt__1__flag_3_0_0_18 c__qurt_new__sqrt__1__flag_3_0_0_15))
(iff l1420 $x9094))
:assumption
l1420
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_18 c__qurt_new__sqrt__1__flag_3_0_0_15)
:assumption
(flet ($x9100 (= c__qurt_new__sqrt__1__x_3_0_0_19 c__qurt_new__sqrt__1__x_3_0_0_18))
(iff l1421 $x9100))
:assumption
l1421
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_19 c__qurt_new__sqrt__1__x_3_0_0_18)
:assumption
(let (?x9106 (ite goto_symex___guard_0_0_137 c__qurt_new__sqrt__1__x_3_0_0_17 c__qurt_new__sqrt__1__x_3_0_0_19))
(flet ($x9107 (= c__qurt_new__sqrt__1__x_3_0_0_20 ?x9106))
(iff l1422 $x9107)))
:assumption
l1422
:assumption
(let (?x9106 (ite goto_symex___guard_0_0_137 c__qurt_new__sqrt__1__x_3_0_0_17 c__qurt_new__sqrt__1__x_3_0_0_19))
(= c__qurt_new__sqrt__1__x_3_0_0_20 ?x9106))
:assumption
(let (?x9112 (ite goto_symex___guard_0_0_137 c__qurt_new__sqrt__1__flag_3_0_0_17 c__qurt_new__sqrt__1__flag_3_0_0_18))
(flet ($x9113 (= c__qurt_new__sqrt__1__flag_3_0_0_19 ?x9112))
(iff l1423 $x9113)))
:assumption
l1423
:assumption
(let (?x9112 (ite goto_symex___guard_0_0_137 c__qurt_new__sqrt__1__flag_3_0_0_17 c__qurt_new__sqrt__1__flag_3_0_0_18))
(= c__qurt_new__sqrt__1__flag_3_0_0_19 ?x9112))
:assumption
(flet ($x9117 (= c__qurt_new__sqrt__1__flag_3_0_0_19 bv0[32]))
(iff l1424 $x9117))
:assumption
(flet ($x9122 (xor l370 l1424))
(iff l1425 $x9122))
:assumption
(not l1425)
:assumption
(flet ($x9117 (= c__qurt_new__sqrt__1__flag_3_0_0_19 bv0[32]))
(= goto_symex___guard_0_0_140 $x9117))
:assumption
(let (?x9132 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9137 (bvmul ?x1629 ?x9132))
(let (?x9138 (extract[95:32] ?x9137))
(let (?x9139 (sign_extend[32] ?x9138))
(let (?x9133 (bvmul ?x9132 ?x9132))
(let (?x9134 (extract[95:32] ?x9133))
(let (?x9135 (bvmul bv18446744073709551615[64] ?x9134))
(let (?x9136 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9135))
(let (?x9140 (concat ?x9136 bv0[32]))
(let (?x9141 (bvsdiv ?x9140 ?x9139))
(let (?x9142 (extract[63:0] ?x9141))
(flet ($x9143 (= c__qurt_new__sqrt__1__dx_3_0_0_14 ?x9142))
(iff l1426 $x9143)))))))))))))))
:assumption
l1426
:assumption
(let (?x9132 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9137 (bvmul ?x1629 ?x9132))
(let (?x9138 (extract[95:32] ?x9137))
(let (?x9139 (sign_extend[32] ?x9138))
(let (?x9133 (bvmul ?x9132 ?x9132))
(let (?x9134 (extract[95:32] ?x9133))
(let (?x9135 (bvmul bv18446744073709551615[64] ?x9134))
(let (?x9136 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9135))
(let (?x9140 (concat ?x9136 bv0[32]))
(let (?x9141 (bvsdiv ?x9140 ?x9139))
(let (?x9142 (extract[63:0] ?x9141))
(= c__qurt_new__sqrt__1__dx_3_0_0_14 ?x9142))))))))))))))
:assumption
(let (?x9163 (bvadd c__qurt_new__sqrt__1__x_3_0_0_20 c__qurt_new__sqrt__1__dx_3_0_0_14))
(flet ($x9164 (= c__qurt_new__sqrt__1__x_3_0_0_21 ?x9163))
(iff l1427 $x9164)))
:assumption
l1427
:assumption
(let (?x9163 (bvadd c__qurt_new__sqrt__1__x_3_0_0_20 c__qurt_new__sqrt__1__dx_3_0_0_14))
(= c__qurt_new__sqrt__1__x_3_0_0_21 ?x9163))
:assumption
(let (?x9169 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_21))
(let (?x9170 (bvmul ?x9169 ?x9169))
(let (?x9171 (extract[95:32] ?x9170))
(let (?x9172 (bvmul bv18446744073709551615[64] ?x9171))
(let (?x9173 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9172))
(flet ($x9174 (= c__qurt_new__sqrt__1__diff_3_0_0_14 ?x9173))
(iff l1428 $x9174)))))))
:assumption
l1428
:assumption
(let (?x9169 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_21))
(let (?x9170 (bvmul ?x9169 ?x9169))
(let (?x9171 (extract[95:32] ?x9170))
(let (?x9172 (bvmul bv18446744073709551615[64] ?x9171))
(let (?x9173 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9172))
(= c__qurt_new__sqrt__1__diff_3_0_0_14 ?x9173))))))
:assumption
(flet ($x9179 (= c__qurt_new__fabs__n_47_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_14))
(iff l1429 $x9179))
:assumption
l1429
:assumption
(= c__qurt_new__fabs__n_47_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_14)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9184 (bvsge c__qurt_new__fabs__n_47_0_0_1 ?x1542))
(iff l1430 $x9184)))
:assumption
(flet ($x9191 (xor l372 l1430))
(iff l1431 $x9191))
:assumption
(not l1431)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9184 (bvsge c__qurt_new__fabs__n_47_0_0_1 ?x1542))
(= goto_symex___guard_0_0_141 $x9184)))
:assumption
(flet ($x9202 (= c__qurt_new__fabs__1__f_47_0_0_1 c__qurt_new__fabs__n_47_0_0_1))
(iff l1432 $x9202))
:assumption
l1432
:assumption
(= c__qurt_new__fabs__1__f_47_0_0_1 c__qurt_new__fabs__n_47_0_0_1)
:assumption
(let (?x9208 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_47_0_0_1))
(flet ($x9209 (= c__qurt_new__fabs__1__f_47_0_0_3 ?x9208))
(iff l1433 $x9209)))
:assumption
l1433
:assumption
(let (?x9208 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_47_0_0_1))
(= c__qurt_new__fabs__1__f_47_0_0_3 ?x9208))
:assumption
(let (?x9214 (ite goto_symex___guard_0_0_141 c__qurt_new__fabs__1__f_47_0_0_1 c__qurt_new__fabs__1__f_47_0_0_3))
(flet ($x9215 (= c__qurt_new__fabs__1__f_47_0_0_4 ?x9214))
(iff l1434 $x9215)))
:assumption
l1434
:assumption
(let (?x9214 (ite goto_symex___guard_0_0_141 c__qurt_new__fabs__1__f_47_0_0_1 c__qurt_new__fabs__1__f_47_0_0_3))
(= c__qurt_new__fabs__1__f_47_0_0_4 ?x9214))
:assumption
(flet ($x9220 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_14 c__qurt_new__fabs__1__f_47_0_0_4))
(iff l1435 $x9220))
:assumption
l1435
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_14 c__qurt_new__fabs__1__f_47_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9225 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_14 ?x1828))
(iff l1436 $x9225)))
:assumption
(flet ($x9230 (xor l375 l1436))
(iff l1437 $x9230))
:assumption
(not l1437)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9225 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_14 ?x1828))
(= goto_symex___guard_0_0_142 $x9225)))
:assumption
(flet ($x9241 (= c__qurt_new__sqrt__1__flag_3_0_0_20 bv1[32]))
(iff l1438 $x9241))
:assumption
l1438
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_20 bv1[32])
:assumption
(flet ($x9247 (not goto_symex___guard_0_0_142))
(let (?x9248 (ite $x9247 c__qurt_new__sqrt__1__flag_3_0_0_19 c__qurt_new__sqrt__1__flag_3_0_0_20))
(flet ($x9249 (= c__qurt_new__sqrt__1__flag_3_0_0_21 ?x9248))
(iff l1439 $x9249))))
:assumption
l1439
:assumption
(flet ($x9247 (not goto_symex___guard_0_0_142))
(let (?x9248 (ite $x9247 c__qurt_new__sqrt__1__flag_3_0_0_19 c__qurt_new__sqrt__1__flag_3_0_0_20))
(= c__qurt_new__sqrt__1__flag_3_0_0_21 ?x9248)))
:assumption
(flet ($x9256 (= c__qurt_new__sqrt__1__x_3_0_0_22 c__qurt_new__sqrt__1__x_3_0_0_20))
(iff l1440 $x9256))
:assumption
l1440
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_22 c__qurt_new__sqrt__1__x_3_0_0_20)
:assumption
(flet ($x9262 (= c__qurt_new__sqrt__1__flag_3_0_0_22 c__qurt_new__sqrt__1__flag_3_0_0_19))
(iff l1441 $x9262))
:assumption
l1441
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_22 c__qurt_new__sqrt__1__flag_3_0_0_19)
:assumption
(flet ($x9268 (= c__qurt_new__sqrt__1__x_3_0_0_23 c__qurt_new__sqrt__1__x_3_0_0_22))
(iff l1442 $x9268))
:assumption
l1442
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_23 c__qurt_new__sqrt__1__x_3_0_0_22)
:assumption
(let (?x9274 (ite goto_symex___guard_0_0_140 c__qurt_new__sqrt__1__x_3_0_0_21 c__qurt_new__sqrt__1__x_3_0_0_23))
(flet ($x9275 (= c__qurt_new__sqrt__1__x_3_0_0_24 ?x9274))
(iff l1443 $x9275)))
:assumption
l1443
:assumption
(let (?x9274 (ite goto_symex___guard_0_0_140 c__qurt_new__sqrt__1__x_3_0_0_21 c__qurt_new__sqrt__1__x_3_0_0_23))
(= c__qurt_new__sqrt__1__x_3_0_0_24 ?x9274))
:assumption
(let (?x9280 (ite goto_symex___guard_0_0_140 c__qurt_new__sqrt__1__flag_3_0_0_21 c__qurt_new__sqrt__1__flag_3_0_0_22))
(flet ($x9281 (= c__qurt_new__sqrt__1__flag_3_0_0_23 ?x9280))
(iff l1444 $x9281)))
:assumption
l1444
:assumption
(let (?x9280 (ite goto_symex___guard_0_0_140 c__qurt_new__sqrt__1__flag_3_0_0_21 c__qurt_new__sqrt__1__flag_3_0_0_22))
(= c__qurt_new__sqrt__1__flag_3_0_0_23 ?x9280))
:assumption
(flet ($x9285 (= c__qurt_new__sqrt__1__flag_3_0_0_23 bv0[32]))
(iff l1445 $x9285))
:assumption
(flet ($x9290 (xor l378 l1445))
(iff l1446 $x9290))
:assumption
(not l1446)
:assumption
(flet ($x9285 (= c__qurt_new__sqrt__1__flag_3_0_0_23 bv0[32]))
(= goto_symex___guard_0_0_143 $x9285))
:assumption
(let (?x9300 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9305 (bvmul ?x1629 ?x9300))
(let (?x9306 (extract[95:32] ?x9305))
(let (?x9307 (sign_extend[32] ?x9306))
(let (?x9301 (bvmul ?x9300 ?x9300))
(let (?x9302 (extract[95:32] ?x9301))
(let (?x9303 (bvmul bv18446744073709551615[64] ?x9302))
(let (?x9304 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9303))
(let (?x9308 (concat ?x9304 bv0[32]))
(let (?x9309 (bvsdiv ?x9308 ?x9307))
(let (?x9310 (extract[63:0] ?x9309))
(flet ($x9311 (= c__qurt_new__sqrt__1__dx_3_0_0_17 ?x9310))
(iff l1447 $x9311)))))))))))))))
:assumption
l1447
:assumption
(let (?x9300 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9305 (bvmul ?x1629 ?x9300))
(let (?x9306 (extract[95:32] ?x9305))
(let (?x9307 (sign_extend[32] ?x9306))
(let (?x9301 (bvmul ?x9300 ?x9300))
(let (?x9302 (extract[95:32] ?x9301))
(let (?x9303 (bvmul bv18446744073709551615[64] ?x9302))
(let (?x9304 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9303))
(let (?x9308 (concat ?x9304 bv0[32]))
(let (?x9309 (bvsdiv ?x9308 ?x9307))
(let (?x9310 (extract[63:0] ?x9309))
(= c__qurt_new__sqrt__1__dx_3_0_0_17 ?x9310))))))))))))))
:assumption
(let (?x9331 (bvadd c__qurt_new__sqrt__1__x_3_0_0_24 c__qurt_new__sqrt__1__dx_3_0_0_17))
(flet ($x9332 (= c__qurt_new__sqrt__1__x_3_0_0_25 ?x9331))
(iff l1448 $x9332)))
:assumption
l1448
:assumption
(let (?x9331 (bvadd c__qurt_new__sqrt__1__x_3_0_0_24 c__qurt_new__sqrt__1__dx_3_0_0_17))
(= c__qurt_new__sqrt__1__x_3_0_0_25 ?x9331))
:assumption
(let (?x9337 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_25))
(let (?x9338 (bvmul ?x9337 ?x9337))
(let (?x9339 (extract[95:32] ?x9338))
(let (?x9340 (bvmul bv18446744073709551615[64] ?x9339))
(let (?x9341 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9340))
(flet ($x9342 (= c__qurt_new__sqrt__1__diff_3_0_0_17 ?x9341))
(iff l1449 $x9342)))))))
:assumption
l1449
:assumption
(let (?x9337 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_25))
(let (?x9338 (bvmul ?x9337 ?x9337))
(let (?x9339 (extract[95:32] ?x9338))
(let (?x9340 (bvmul bv18446744073709551615[64] ?x9339))
(let (?x9341 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9340))
(= c__qurt_new__sqrt__1__diff_3_0_0_17 ?x9341))))))
:assumption
(flet ($x9347 (= c__qurt_new__fabs__n_48_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_17))
(iff l1450 $x9347))
:assumption
l1450
:assumption
(= c__qurt_new__fabs__n_48_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_17)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9352 (bvsge c__qurt_new__fabs__n_48_0_0_1 ?x1542))
(iff l1451 $x9352)))
:assumption
(flet ($x9359 (xor l380 l1451))
(iff l1452 $x9359))
:assumption
(not l1452)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9352 (bvsge c__qurt_new__fabs__n_48_0_0_1 ?x1542))
(= goto_symex___guard_0_0_144 $x9352)))
:assumption
(flet ($x9370 (= c__qurt_new__fabs__1__f_48_0_0_1 c__qurt_new__fabs__n_48_0_0_1))
(iff l1453 $x9370))
:assumption
l1453
:assumption
(= c__qurt_new__fabs__1__f_48_0_0_1 c__qurt_new__fabs__n_48_0_0_1)
:assumption
(let (?x9376 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_48_0_0_1))
(flet ($x9377 (= c__qurt_new__fabs__1__f_48_0_0_3 ?x9376))
(iff l1454 $x9377)))
:assumption
l1454
:assumption
(let (?x9376 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_48_0_0_1))
(= c__qurt_new__fabs__1__f_48_0_0_3 ?x9376))
:assumption
(let (?x9382 (ite goto_symex___guard_0_0_144 c__qurt_new__fabs__1__f_48_0_0_1 c__qurt_new__fabs__1__f_48_0_0_3))
(flet ($x9383 (= c__qurt_new__fabs__1__f_48_0_0_4 ?x9382))
(iff l1455 $x9383)))
:assumption
l1455
:assumption
(let (?x9382 (ite goto_symex___guard_0_0_144 c__qurt_new__fabs__1__f_48_0_0_1 c__qurt_new__fabs__1__f_48_0_0_3))
(= c__qurt_new__fabs__1__f_48_0_0_4 ?x9382))
:assumption
(flet ($x9388 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_17 c__qurt_new__fabs__1__f_48_0_0_4))
(iff l1456 $x9388))
:assumption
l1456
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_17 c__qurt_new__fabs__1__f_48_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9393 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_17 ?x1828))
(iff l1457 $x9393)))
:assumption
(flet ($x9398 (xor l383 l1457))
(iff l1458 $x9398))
:assumption
(not l1458)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9393 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_17 ?x1828))
(= goto_symex___guard_0_0_145 $x9393)))
:assumption
(flet ($x9409 (= c__qurt_new__sqrt__1__flag_3_0_0_24 bv1[32]))
(iff l1459 $x9409))
:assumption
l1459
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_24 bv1[32])
:assumption
(flet ($x9415 (not goto_symex___guard_0_0_145))
(let (?x9416 (ite $x9415 c__qurt_new__sqrt__1__flag_3_0_0_23 c__qurt_new__sqrt__1__flag_3_0_0_24))
(flet ($x9417 (= c__qurt_new__sqrt__1__flag_3_0_0_25 ?x9416))
(iff l1460 $x9417))))
:assumption
l1460
:assumption
(flet ($x9415 (not goto_symex___guard_0_0_145))
(let (?x9416 (ite $x9415 c__qurt_new__sqrt__1__flag_3_0_0_23 c__qurt_new__sqrt__1__flag_3_0_0_24))
(= c__qurt_new__sqrt__1__flag_3_0_0_25 ?x9416)))
:assumption
(flet ($x9424 (= c__qurt_new__sqrt__1__x_3_0_0_26 c__qurt_new__sqrt__1__x_3_0_0_24))
(iff l1461 $x9424))
:assumption
l1461
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_26 c__qurt_new__sqrt__1__x_3_0_0_24)
:assumption
(flet ($x9430 (= c__qurt_new__sqrt__1__flag_3_0_0_26 c__qurt_new__sqrt__1__flag_3_0_0_23))
(iff l1462 $x9430))
:assumption
l1462
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_26 c__qurt_new__sqrt__1__flag_3_0_0_23)
:assumption
(flet ($x9436 (= c__qurt_new__sqrt__1__x_3_0_0_27 c__qurt_new__sqrt__1__x_3_0_0_26))
(iff l1463 $x9436))
:assumption
l1463
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_27 c__qurt_new__sqrt__1__x_3_0_0_26)
:assumption
(let (?x9442 (ite goto_symex___guard_0_0_143 c__qurt_new__sqrt__1__x_3_0_0_25 c__qurt_new__sqrt__1__x_3_0_0_27))
(flet ($x9443 (= c__qurt_new__sqrt__1__x_3_0_0_28 ?x9442))
(iff l1464 $x9443)))
:assumption
l1464
:assumption
(let (?x9442 (ite goto_symex___guard_0_0_143 c__qurt_new__sqrt__1__x_3_0_0_25 c__qurt_new__sqrt__1__x_3_0_0_27))
(= c__qurt_new__sqrt__1__x_3_0_0_28 ?x9442))
:assumption
(let (?x9448 (ite goto_symex___guard_0_0_143 c__qurt_new__sqrt__1__flag_3_0_0_25 c__qurt_new__sqrt__1__flag_3_0_0_26))
(flet ($x9449 (= c__qurt_new__sqrt__1__flag_3_0_0_27 ?x9448))
(iff l1465 $x9449)))
:assumption
l1465
:assumption
(let (?x9448 (ite goto_symex___guard_0_0_143 c__qurt_new__sqrt__1__flag_3_0_0_25 c__qurt_new__sqrt__1__flag_3_0_0_26))
(= c__qurt_new__sqrt__1__flag_3_0_0_27 ?x9448))
:assumption
(flet ($x9453 (= c__qurt_new__sqrt__1__flag_3_0_0_27 bv0[32]))
(iff l1466 $x9453))
:assumption
(flet ($x9458 (xor l386 l1466))
(iff l1467 $x9458))
:assumption
(not l1467)
:assumption
(flet ($x9453 (= c__qurt_new__sqrt__1__flag_3_0_0_27 bv0[32]))
(= goto_symex___guard_0_0_146 $x9453))
:assumption
(let (?x9468 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9473 (bvmul ?x1629 ?x9468))
(let (?x9474 (extract[95:32] ?x9473))
(let (?x9475 (sign_extend[32] ?x9474))
(let (?x9469 (bvmul ?x9468 ?x9468))
(let (?x9470 (extract[95:32] ?x9469))
(let (?x9471 (bvmul bv18446744073709551615[64] ?x9470))
(let (?x9472 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9471))
(let (?x9476 (concat ?x9472 bv0[32]))
(let (?x9477 (bvsdiv ?x9476 ?x9475))
(let (?x9478 (extract[63:0] ?x9477))
(flet ($x9479 (= c__qurt_new__sqrt__1__dx_3_0_0_20 ?x9478))
(iff l1468 $x9479)))))))))))))))
:assumption
l1468
:assumption
(let (?x9468 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9473 (bvmul ?x1629 ?x9468))
(let (?x9474 (extract[95:32] ?x9473))
(let (?x9475 (sign_extend[32] ?x9474))
(let (?x9469 (bvmul ?x9468 ?x9468))
(let (?x9470 (extract[95:32] ?x9469))
(let (?x9471 (bvmul bv18446744073709551615[64] ?x9470))
(let (?x9472 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9471))
(let (?x9476 (concat ?x9472 bv0[32]))
(let (?x9477 (bvsdiv ?x9476 ?x9475))
(let (?x9478 (extract[63:0] ?x9477))
(= c__qurt_new__sqrt__1__dx_3_0_0_20 ?x9478))))))))))))))
:assumption
(let (?x9499 (bvadd c__qurt_new__sqrt__1__x_3_0_0_28 c__qurt_new__sqrt__1__dx_3_0_0_20))
(flet ($x9500 (= c__qurt_new__sqrt__1__x_3_0_0_29 ?x9499))
(iff l1469 $x9500)))
:assumption
l1469
:assumption
(let (?x9499 (bvadd c__qurt_new__sqrt__1__x_3_0_0_28 c__qurt_new__sqrt__1__dx_3_0_0_20))
(= c__qurt_new__sqrt__1__x_3_0_0_29 ?x9499))
:assumption
(let (?x9505 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_29))
(let (?x9506 (bvmul ?x9505 ?x9505))
(let (?x9507 (extract[95:32] ?x9506))
(let (?x9508 (bvmul bv18446744073709551615[64] ?x9507))
(let (?x9509 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9508))
(flet ($x9510 (= c__qurt_new__sqrt__1__diff_3_0_0_20 ?x9509))
(iff l1470 $x9510)))))))
:assumption
l1470
:assumption
(let (?x9505 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_29))
(let (?x9506 (bvmul ?x9505 ?x9505))
(let (?x9507 (extract[95:32] ?x9506))
(let (?x9508 (bvmul bv18446744073709551615[64] ?x9507))
(let (?x9509 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9508))
(= c__qurt_new__sqrt__1__diff_3_0_0_20 ?x9509))))))
:assumption
(flet ($x9515 (= c__qurt_new__fabs__n_49_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_20))
(iff l1471 $x9515))
:assumption
l1471
:assumption
(= c__qurt_new__fabs__n_49_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_20)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9520 (bvsge c__qurt_new__fabs__n_49_0_0_1 ?x1542))
(iff l1472 $x9520)))
:assumption
(flet ($x9527 (xor l388 l1472))
(iff l1473 $x9527))
:assumption
(not l1473)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9520 (bvsge c__qurt_new__fabs__n_49_0_0_1 ?x1542))
(= goto_symex___guard_0_0_147 $x9520)))
:assumption
(flet ($x9538 (= c__qurt_new__fabs__1__f_49_0_0_1 c__qurt_new__fabs__n_49_0_0_1))
(iff l1474 $x9538))
:assumption
l1474
:assumption
(= c__qurt_new__fabs__1__f_49_0_0_1 c__qurt_new__fabs__n_49_0_0_1)
:assumption
(let (?x9544 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_49_0_0_1))
(flet ($x9545 (= c__qurt_new__fabs__1__f_49_0_0_3 ?x9544))
(iff l1475 $x9545)))
:assumption
l1475
:assumption
(let (?x9544 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_49_0_0_1))
(= c__qurt_new__fabs__1__f_49_0_0_3 ?x9544))
:assumption
(let (?x9550 (ite goto_symex___guard_0_0_147 c__qurt_new__fabs__1__f_49_0_0_1 c__qurt_new__fabs__1__f_49_0_0_3))
(flet ($x9551 (= c__qurt_new__fabs__1__f_49_0_0_4 ?x9550))
(iff l1476 $x9551)))
:assumption
l1476
:assumption
(let (?x9550 (ite goto_symex___guard_0_0_147 c__qurt_new__fabs__1__f_49_0_0_1 c__qurt_new__fabs__1__f_49_0_0_3))
(= c__qurt_new__fabs__1__f_49_0_0_4 ?x9550))
:assumption
(flet ($x9556 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_20 c__qurt_new__fabs__1__f_49_0_0_4))
(iff l1477 $x9556))
:assumption
l1477
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_20 c__qurt_new__fabs__1__f_49_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9561 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_20 ?x1828))
(iff l1478 $x9561)))
:assumption
(flet ($x9566 (xor l391 l1478))
(iff l1479 $x9566))
:assumption
(not l1479)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9561 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_20 ?x1828))
(= goto_symex___guard_0_0_148 $x9561)))
:assumption
(flet ($x9577 (= c__qurt_new__sqrt__1__flag_3_0_0_28 bv1[32]))
(iff l1480 $x9577))
:assumption
l1480
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_28 bv1[32])
:assumption
(flet ($x9583 (not goto_symex___guard_0_0_148))
(let (?x9584 (ite $x9583 c__qurt_new__sqrt__1__flag_3_0_0_27 c__qurt_new__sqrt__1__flag_3_0_0_28))
(flet ($x9585 (= c__qurt_new__sqrt__1__flag_3_0_0_29 ?x9584))
(iff l1481 $x9585))))
:assumption
l1481
:assumption
(flet ($x9583 (not goto_symex___guard_0_0_148))
(let (?x9584 (ite $x9583 c__qurt_new__sqrt__1__flag_3_0_0_27 c__qurt_new__sqrt__1__flag_3_0_0_28))
(= c__qurt_new__sqrt__1__flag_3_0_0_29 ?x9584)))
:assumption
(flet ($x9592 (= c__qurt_new__sqrt__1__x_3_0_0_30 c__qurt_new__sqrt__1__x_3_0_0_28))
(iff l1482 $x9592))
:assumption
l1482
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_30 c__qurt_new__sqrt__1__x_3_0_0_28)
:assumption
(flet ($x9598 (= c__qurt_new__sqrt__1__flag_3_0_0_30 c__qurt_new__sqrt__1__flag_3_0_0_27))
(iff l1483 $x9598))
:assumption
l1483
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_30 c__qurt_new__sqrt__1__flag_3_0_0_27)
:assumption
(flet ($x9604 (= c__qurt_new__sqrt__1__x_3_0_0_31 c__qurt_new__sqrt__1__x_3_0_0_30))
(iff l1484 $x9604))
:assumption
l1484
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_31 c__qurt_new__sqrt__1__x_3_0_0_30)
:assumption
(let (?x9610 (ite goto_symex___guard_0_0_146 c__qurt_new__sqrt__1__x_3_0_0_29 c__qurt_new__sqrt__1__x_3_0_0_31))
(flet ($x9611 (= c__qurt_new__sqrt__1__x_3_0_0_32 ?x9610))
(iff l1485 $x9611)))
:assumption
l1485
:assumption
(let (?x9610 (ite goto_symex___guard_0_0_146 c__qurt_new__sqrt__1__x_3_0_0_29 c__qurt_new__sqrt__1__x_3_0_0_31))
(= c__qurt_new__sqrt__1__x_3_0_0_32 ?x9610))
:assumption
(let (?x9616 (ite goto_symex___guard_0_0_146 c__qurt_new__sqrt__1__flag_3_0_0_29 c__qurt_new__sqrt__1__flag_3_0_0_30))
(flet ($x9617 (= c__qurt_new__sqrt__1__flag_3_0_0_31 ?x9616))
(iff l1486 $x9617)))
:assumption
l1486
:assumption
(let (?x9616 (ite goto_symex___guard_0_0_146 c__qurt_new__sqrt__1__flag_3_0_0_29 c__qurt_new__sqrt__1__flag_3_0_0_30))
(= c__qurt_new__sqrt__1__flag_3_0_0_31 ?x9616))
:assumption
(flet ($x9621 (= c__qurt_new__sqrt__1__flag_3_0_0_31 bv0[32]))
(iff l1487 $x9621))
:assumption
(flet ($x9626 (xor l394 l1487))
(iff l1488 $x9626))
:assumption
(not l1488)
:assumption
(flet ($x9621 (= c__qurt_new__sqrt__1__flag_3_0_0_31 bv0[32]))
(= goto_symex___guard_0_0_149 $x9621))
:assumption
(let (?x9636 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9641 (bvmul ?x1629 ?x9636))
(let (?x9642 (extract[95:32] ?x9641))
(let (?x9643 (sign_extend[32] ?x9642))
(let (?x9637 (bvmul ?x9636 ?x9636))
(let (?x9638 (extract[95:32] ?x9637))
(let (?x9639 (bvmul bv18446744073709551615[64] ?x9638))
(let (?x9640 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9639))
(let (?x9644 (concat ?x9640 bv0[32]))
(let (?x9645 (bvsdiv ?x9644 ?x9643))
(let (?x9646 (extract[63:0] ?x9645))
(flet ($x9647 (= c__qurt_new__sqrt__1__dx_3_0_0_23 ?x9646))
(iff l1489 $x9647)))))))))))))))
:assumption
l1489
:assumption
(let (?x9636 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9641 (bvmul ?x1629 ?x9636))
(let (?x9642 (extract[95:32] ?x9641))
(let (?x9643 (sign_extend[32] ?x9642))
(let (?x9637 (bvmul ?x9636 ?x9636))
(let (?x9638 (extract[95:32] ?x9637))
(let (?x9639 (bvmul bv18446744073709551615[64] ?x9638))
(let (?x9640 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9639))
(let (?x9644 (concat ?x9640 bv0[32]))
(let (?x9645 (bvsdiv ?x9644 ?x9643))
(let (?x9646 (extract[63:0] ?x9645))
(= c__qurt_new__sqrt__1__dx_3_0_0_23 ?x9646))))))))))))))
:assumption
(let (?x9667 (bvadd c__qurt_new__sqrt__1__x_3_0_0_32 c__qurt_new__sqrt__1__dx_3_0_0_23))
(flet ($x9668 (= c__qurt_new__sqrt__1__x_3_0_0_33 ?x9667))
(iff l1490 $x9668)))
:assumption
l1490
:assumption
(let (?x9667 (bvadd c__qurt_new__sqrt__1__x_3_0_0_32 c__qurt_new__sqrt__1__dx_3_0_0_23))
(= c__qurt_new__sqrt__1__x_3_0_0_33 ?x9667))
:assumption
(let (?x9673 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_33))
(let (?x9674 (bvmul ?x9673 ?x9673))
(let (?x9675 (extract[95:32] ?x9674))
(let (?x9676 (bvmul bv18446744073709551615[64] ?x9675))
(let (?x9677 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9676))
(flet ($x9678 (= c__qurt_new__sqrt__1__diff_3_0_0_23 ?x9677))
(iff l1491 $x9678)))))))
:assumption
l1491
:assumption
(let (?x9673 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_33))
(let (?x9674 (bvmul ?x9673 ?x9673))
(let (?x9675 (extract[95:32] ?x9674))
(let (?x9676 (bvmul bv18446744073709551615[64] ?x9675))
(let (?x9677 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9676))
(= c__qurt_new__sqrt__1__diff_3_0_0_23 ?x9677))))))
:assumption
(flet ($x9683 (= c__qurt_new__fabs__n_50_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_23))
(iff l1492 $x9683))
:assumption
l1492
:assumption
(= c__qurt_new__fabs__n_50_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_23)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9688 (bvsge c__qurt_new__fabs__n_50_0_0_1 ?x1542))
(iff l1493 $x9688)))
:assumption
(flet ($x9695 (xor l396 l1493))
(iff l1494 $x9695))
:assumption
(not l1494)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9688 (bvsge c__qurt_new__fabs__n_50_0_0_1 ?x1542))
(= goto_symex___guard_0_0_150 $x9688)))
:assumption
(flet ($x9706 (= c__qurt_new__fabs__1__f_50_0_0_1 c__qurt_new__fabs__n_50_0_0_1))
(iff l1495 $x9706))
:assumption
l1495
:assumption
(= c__qurt_new__fabs__1__f_50_0_0_1 c__qurt_new__fabs__n_50_0_0_1)
:assumption
(let (?x9712 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_50_0_0_1))
(flet ($x9713 (= c__qurt_new__fabs__1__f_50_0_0_3 ?x9712))
(iff l1496 $x9713)))
:assumption
l1496
:assumption
(let (?x9712 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_50_0_0_1))
(= c__qurt_new__fabs__1__f_50_0_0_3 ?x9712))
:assumption
(let (?x9718 (ite goto_symex___guard_0_0_150 c__qurt_new__fabs__1__f_50_0_0_1 c__qurt_new__fabs__1__f_50_0_0_3))
(flet ($x9719 (= c__qurt_new__fabs__1__f_50_0_0_4 ?x9718))
(iff l1497 $x9719)))
:assumption
l1497
:assumption
(let (?x9718 (ite goto_symex___guard_0_0_150 c__qurt_new__fabs__1__f_50_0_0_1 c__qurt_new__fabs__1__f_50_0_0_3))
(= c__qurt_new__fabs__1__f_50_0_0_4 ?x9718))
:assumption
(flet ($x9724 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_23 c__qurt_new__fabs__1__f_50_0_0_4))
(iff l1498 $x9724))
:assumption
l1498
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_23 c__qurt_new__fabs__1__f_50_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9729 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_23 ?x1828))
(iff l1499 $x9729)))
:assumption
(flet ($x9734 (xor l399 l1499))
(iff l1500 $x9734))
:assumption
(not l1500)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9729 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_23 ?x1828))
(= goto_symex___guard_0_0_151 $x9729)))
:assumption
(flet ($x9745 (= c__qurt_new__sqrt__1__flag_3_0_0_32 bv1[32]))
(iff l1501 $x9745))
:assumption
l1501
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_32 bv1[32])
:assumption
(flet ($x9751 (not goto_symex___guard_0_0_151))
(let (?x9752 (ite $x9751 c__qurt_new__sqrt__1__flag_3_0_0_31 c__qurt_new__sqrt__1__flag_3_0_0_32))
(flet ($x9753 (= c__qurt_new__sqrt__1__flag_3_0_0_33 ?x9752))
(iff l1502 $x9753))))
:assumption
l1502
:assumption
(flet ($x9751 (not goto_symex___guard_0_0_151))
(let (?x9752 (ite $x9751 c__qurt_new__sqrt__1__flag_3_0_0_31 c__qurt_new__sqrt__1__flag_3_0_0_32))
(= c__qurt_new__sqrt__1__flag_3_0_0_33 ?x9752)))
:assumption
(flet ($x9760 (= c__qurt_new__sqrt__1__x_3_0_0_34 c__qurt_new__sqrt__1__x_3_0_0_32))
(iff l1503 $x9760))
:assumption
l1503
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_34 c__qurt_new__sqrt__1__x_3_0_0_32)
:assumption
(flet ($x9766 (= c__qurt_new__sqrt__1__flag_3_0_0_34 c__qurt_new__sqrt__1__flag_3_0_0_31))
(iff l1504 $x9766))
:assumption
l1504
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_34 c__qurt_new__sqrt__1__flag_3_0_0_31)
:assumption
(flet ($x9772 (= c__qurt_new__sqrt__1__x_3_0_0_35 c__qurt_new__sqrt__1__x_3_0_0_34))
(iff l1505 $x9772))
:assumption
l1505
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_35 c__qurt_new__sqrt__1__x_3_0_0_34)
:assumption
(let (?x9778 (ite goto_symex___guard_0_0_149 c__qurt_new__sqrt__1__x_3_0_0_33 c__qurt_new__sqrt__1__x_3_0_0_35))
(flet ($x9779 (= c__qurt_new__sqrt__1__x_3_0_0_36 ?x9778))
(iff l1506 $x9779)))
:assumption
l1506
:assumption
(let (?x9778 (ite goto_symex___guard_0_0_149 c__qurt_new__sqrt__1__x_3_0_0_33 c__qurt_new__sqrt__1__x_3_0_0_35))
(= c__qurt_new__sqrt__1__x_3_0_0_36 ?x9778))
:assumption
(let (?x9784 (ite goto_symex___guard_0_0_149 c__qurt_new__sqrt__1__flag_3_0_0_33 c__qurt_new__sqrt__1__flag_3_0_0_34))
(flet ($x9785 (= c__qurt_new__sqrt__1__flag_3_0_0_35 ?x9784))
(iff l1507 $x9785)))
:assumption
l1507
:assumption
(let (?x9784 (ite goto_symex___guard_0_0_149 c__qurt_new__sqrt__1__flag_3_0_0_33 c__qurt_new__sqrt__1__flag_3_0_0_34))
(= c__qurt_new__sqrt__1__flag_3_0_0_35 ?x9784))
:assumption
(flet ($x9789 (= c__qurt_new__sqrt__1__flag_3_0_0_35 bv0[32]))
(iff l1508 $x9789))
:assumption
(flet ($x9794 (xor l402 l1508))
(iff l1509 $x9794))
:assumption
(not l1509)
:assumption
(flet ($x9789 (= c__qurt_new__sqrt__1__flag_3_0_0_35 bv0[32]))
(= goto_symex___guard_0_0_152 $x9789))
:assumption
(let (?x9804 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9809 (bvmul ?x1629 ?x9804))
(let (?x9810 (extract[95:32] ?x9809))
(let (?x9811 (sign_extend[32] ?x9810))
(let (?x9805 (bvmul ?x9804 ?x9804))
(let (?x9806 (extract[95:32] ?x9805))
(let (?x9807 (bvmul bv18446744073709551615[64] ?x9806))
(let (?x9808 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9807))
(let (?x9812 (concat ?x9808 bv0[32]))
(let (?x9813 (bvsdiv ?x9812 ?x9811))
(let (?x9814 (extract[63:0] ?x9813))
(flet ($x9815 (= c__qurt_new__sqrt__1__dx_3_0_0_26 ?x9814))
(iff l1510 $x9815)))))))))))))))
:assumption
l1510
:assumption
(let (?x9804 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9809 (bvmul ?x1629 ?x9804))
(let (?x9810 (extract[95:32] ?x9809))
(let (?x9811 (sign_extend[32] ?x9810))
(let (?x9805 (bvmul ?x9804 ?x9804))
(let (?x9806 (extract[95:32] ?x9805))
(let (?x9807 (bvmul bv18446744073709551615[64] ?x9806))
(let (?x9808 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9807))
(let (?x9812 (concat ?x9808 bv0[32]))
(let (?x9813 (bvsdiv ?x9812 ?x9811))
(let (?x9814 (extract[63:0] ?x9813))
(= c__qurt_new__sqrt__1__dx_3_0_0_26 ?x9814))))))))))))))
:assumption
(let (?x9835 (bvadd c__qurt_new__sqrt__1__x_3_0_0_36 c__qurt_new__sqrt__1__dx_3_0_0_26))
(flet ($x9836 (= c__qurt_new__sqrt__1__x_3_0_0_37 ?x9835))
(iff l1511 $x9836)))
:assumption
l1511
:assumption
(let (?x9835 (bvadd c__qurt_new__sqrt__1__x_3_0_0_36 c__qurt_new__sqrt__1__dx_3_0_0_26))
(= c__qurt_new__sqrt__1__x_3_0_0_37 ?x9835))
:assumption
(let (?x9841 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_37))
(let (?x9842 (bvmul ?x9841 ?x9841))
(let (?x9843 (extract[95:32] ?x9842))
(let (?x9844 (bvmul bv18446744073709551615[64] ?x9843))
(let (?x9845 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9844))
(flet ($x9846 (= c__qurt_new__sqrt__1__diff_3_0_0_26 ?x9845))
(iff l1512 $x9846)))))))
:assumption
l1512
:assumption
(let (?x9841 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_37))
(let (?x9842 (bvmul ?x9841 ?x9841))
(let (?x9843 (extract[95:32] ?x9842))
(let (?x9844 (bvmul bv18446744073709551615[64] ?x9843))
(let (?x9845 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9844))
(= c__qurt_new__sqrt__1__diff_3_0_0_26 ?x9845))))))
:assumption
(flet ($x9851 (= c__qurt_new__fabs__n_51_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_26))
(iff l1513 $x9851))
:assumption
l1513
:assumption
(= c__qurt_new__fabs__n_51_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_26)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9856 (bvsge c__qurt_new__fabs__n_51_0_0_1 ?x1542))
(iff l1514 $x9856)))
:assumption
(flet ($x9863 (xor l404 l1514))
(iff l1515 $x9863))
:assumption
(not l1515)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x9856 (bvsge c__qurt_new__fabs__n_51_0_0_1 ?x1542))
(= goto_symex___guard_0_0_153 $x9856)))
:assumption
(flet ($x9874 (= c__qurt_new__fabs__1__f_51_0_0_1 c__qurt_new__fabs__n_51_0_0_1))
(iff l1516 $x9874))
:assumption
l1516
:assumption
(= c__qurt_new__fabs__1__f_51_0_0_1 c__qurt_new__fabs__n_51_0_0_1)
:assumption
(let (?x9880 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_51_0_0_1))
(flet ($x9881 (= c__qurt_new__fabs__1__f_51_0_0_3 ?x9880))
(iff l1517 $x9881)))
:assumption
l1517
:assumption
(let (?x9880 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_51_0_0_1))
(= c__qurt_new__fabs__1__f_51_0_0_3 ?x9880))
:assumption
(let (?x9886 (ite goto_symex___guard_0_0_153 c__qurt_new__fabs__1__f_51_0_0_1 c__qurt_new__fabs__1__f_51_0_0_3))
(flet ($x9887 (= c__qurt_new__fabs__1__f_51_0_0_4 ?x9886))
(iff l1518 $x9887)))
:assumption
l1518
:assumption
(let (?x9886 (ite goto_symex___guard_0_0_153 c__qurt_new__fabs__1__f_51_0_0_1 c__qurt_new__fabs__1__f_51_0_0_3))
(= c__qurt_new__fabs__1__f_51_0_0_4 ?x9886))
:assumption
(flet ($x9892 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_26 c__qurt_new__fabs__1__f_51_0_0_4))
(iff l1519 $x9892))
:assumption
l1519
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_26 c__qurt_new__fabs__1__f_51_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9897 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_26 ?x1828))
(iff l1520 $x9897)))
:assumption
(flet ($x9902 (xor l407 l1520))
(iff l1521 $x9902))
:assumption
(not l1521)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x9897 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_26 ?x1828))
(= goto_symex___guard_0_0_154 $x9897)))
:assumption
(flet ($x9913 (= c__qurt_new__sqrt__1__flag_3_0_0_36 bv1[32]))
(iff l1522 $x9913))
:assumption
l1522
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_36 bv1[32])
:assumption
(flet ($x9919 (not goto_symex___guard_0_0_154))
(let (?x9920 (ite $x9919 c__qurt_new__sqrt__1__flag_3_0_0_35 c__qurt_new__sqrt__1__flag_3_0_0_36))
(flet ($x9921 (= c__qurt_new__sqrt__1__flag_3_0_0_37 ?x9920))
(iff l1523 $x9921))))
:assumption
l1523
:assumption
(flet ($x9919 (not goto_symex___guard_0_0_154))
(let (?x9920 (ite $x9919 c__qurt_new__sqrt__1__flag_3_0_0_35 c__qurt_new__sqrt__1__flag_3_0_0_36))
(= c__qurt_new__sqrt__1__flag_3_0_0_37 ?x9920)))
:assumption
(flet ($x9928 (= c__qurt_new__sqrt__1__x_3_0_0_38 c__qurt_new__sqrt__1__x_3_0_0_36))
(iff l1524 $x9928))
:assumption
l1524
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_38 c__qurt_new__sqrt__1__x_3_0_0_36)
:assumption
(flet ($x9934 (= c__qurt_new__sqrt__1__flag_3_0_0_38 c__qurt_new__sqrt__1__flag_3_0_0_35))
(iff l1525 $x9934))
:assumption
l1525
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_38 c__qurt_new__sqrt__1__flag_3_0_0_35)
:assumption
(flet ($x9940 (= c__qurt_new__sqrt__1__x_3_0_0_39 c__qurt_new__sqrt__1__x_3_0_0_38))
(iff l1526 $x9940))
:assumption
l1526
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_39 c__qurt_new__sqrt__1__x_3_0_0_38)
:assumption
(let (?x9946 (ite goto_symex___guard_0_0_152 c__qurt_new__sqrt__1__x_3_0_0_37 c__qurt_new__sqrt__1__x_3_0_0_39))
(flet ($x9947 (= c__qurt_new__sqrt__1__x_3_0_0_40 ?x9946))
(iff l1527 $x9947)))
:assumption
l1527
:assumption
(let (?x9946 (ite goto_symex___guard_0_0_152 c__qurt_new__sqrt__1__x_3_0_0_37 c__qurt_new__sqrt__1__x_3_0_0_39))
(= c__qurt_new__sqrt__1__x_3_0_0_40 ?x9946))
:assumption
(let (?x9952 (ite goto_symex___guard_0_0_152 c__qurt_new__sqrt__1__flag_3_0_0_37 c__qurt_new__sqrt__1__flag_3_0_0_38))
(flet ($x9953 (= c__qurt_new__sqrt__1__flag_3_0_0_39 ?x9952))
(iff l1528 $x9953)))
:assumption
l1528
:assumption
(let (?x9952 (ite goto_symex___guard_0_0_152 c__qurt_new__sqrt__1__flag_3_0_0_37 c__qurt_new__sqrt__1__flag_3_0_0_38))
(= c__qurt_new__sqrt__1__flag_3_0_0_39 ?x9952))
:assumption
(flet ($x9957 (= c__qurt_new__sqrt__1__flag_3_0_0_39 bv0[32]))
(iff l1529 $x9957))
:assumption
(flet ($x9962 (xor l410 l1529))
(iff l1530 $x9962))
:assumption
(not l1530)
:assumption
(flet ($x9957 (= c__qurt_new__sqrt__1__flag_3_0_0_39 bv0[32]))
(= goto_symex___guard_0_0_155 $x9957))
:assumption
(let (?x9972 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9977 (bvmul ?x1629 ?x9972))
(let (?x9978 (extract[95:32] ?x9977))
(let (?x9979 (sign_extend[32] ?x9978))
(let (?x9973 (bvmul ?x9972 ?x9972))
(let (?x9974 (extract[95:32] ?x9973))
(let (?x9975 (bvmul bv18446744073709551615[64] ?x9974))
(let (?x9976 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9975))
(let (?x9980 (concat ?x9976 bv0[32]))
(let (?x9981 (bvsdiv ?x9980 ?x9979))
(let (?x9982 (extract[63:0] ?x9981))
(flet ($x9983 (= c__qurt_new__sqrt__1__dx_3_0_0_29 ?x9982))
(iff l1531 $x9983)))))))))))))))
:assumption
l1531
:assumption
(let (?x9972 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9977 (bvmul ?x1629 ?x9972))
(let (?x9978 (extract[95:32] ?x9977))
(let (?x9979 (sign_extend[32] ?x9978))
(let (?x9973 (bvmul ?x9972 ?x9972))
(let (?x9974 (extract[95:32] ?x9973))
(let (?x9975 (bvmul bv18446744073709551615[64] ?x9974))
(let (?x9976 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x9975))
(let (?x9980 (concat ?x9976 bv0[32]))
(let (?x9981 (bvsdiv ?x9980 ?x9979))
(let (?x9982 (extract[63:0] ?x9981))
(= c__qurt_new__sqrt__1__dx_3_0_0_29 ?x9982))))))))))))))
:assumption
(let (?x10003 (bvadd c__qurt_new__sqrt__1__x_3_0_0_40 c__qurt_new__sqrt__1__dx_3_0_0_29))
(flet ($x10004 (= c__qurt_new__sqrt__1__x_3_0_0_41 ?x10003))
(iff l1532 $x10004)))
:assumption
l1532
:assumption
(let (?x10003 (bvadd c__qurt_new__sqrt__1__x_3_0_0_40 c__qurt_new__sqrt__1__dx_3_0_0_29))
(= c__qurt_new__sqrt__1__x_3_0_0_41 ?x10003))
:assumption
(let (?x10009 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_41))
(let (?x10010 (bvmul ?x10009 ?x10009))
(let (?x10011 (extract[95:32] ?x10010))
(let (?x10012 (bvmul bv18446744073709551615[64] ?x10011))
(let (?x10013 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10012))
(flet ($x10014 (= c__qurt_new__sqrt__1__diff_3_0_0_29 ?x10013))
(iff l1533 $x10014)))))))
:assumption
l1533
:assumption
(let (?x10009 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_41))
(let (?x10010 (bvmul ?x10009 ?x10009))
(let (?x10011 (extract[95:32] ?x10010))
(let (?x10012 (bvmul bv18446744073709551615[64] ?x10011))
(let (?x10013 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10012))
(= c__qurt_new__sqrt__1__diff_3_0_0_29 ?x10013))))))
:assumption
(flet ($x10019 (= c__qurt_new__fabs__n_52_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_29))
(iff l1534 $x10019))
:assumption
l1534
:assumption
(= c__qurt_new__fabs__n_52_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_29)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10024 (bvsge c__qurt_new__fabs__n_52_0_0_1 ?x1542))
(iff l1535 $x10024)))
:assumption
(flet ($x10031 (xor l412 l1535))
(iff l1536 $x10031))
:assumption
(not l1536)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10024 (bvsge c__qurt_new__fabs__n_52_0_0_1 ?x1542))
(= goto_symex___guard_0_0_156 $x10024)))
:assumption
(flet ($x10042 (= c__qurt_new__fabs__1__f_52_0_0_1 c__qurt_new__fabs__n_52_0_0_1))
(iff l1537 $x10042))
:assumption
l1537
:assumption
(= c__qurt_new__fabs__1__f_52_0_0_1 c__qurt_new__fabs__n_52_0_0_1)
:assumption
(let (?x10048 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_52_0_0_1))
(flet ($x10049 (= c__qurt_new__fabs__1__f_52_0_0_3 ?x10048))
(iff l1538 $x10049)))
:assumption
l1538
:assumption
(let (?x10048 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_52_0_0_1))
(= c__qurt_new__fabs__1__f_52_0_0_3 ?x10048))
:assumption
(let (?x10054 (ite goto_symex___guard_0_0_156 c__qurt_new__fabs__1__f_52_0_0_1 c__qurt_new__fabs__1__f_52_0_0_3))
(flet ($x10055 (= c__qurt_new__fabs__1__f_52_0_0_4 ?x10054))
(iff l1539 $x10055)))
:assumption
l1539
:assumption
(let (?x10054 (ite goto_symex___guard_0_0_156 c__qurt_new__fabs__1__f_52_0_0_1 c__qurt_new__fabs__1__f_52_0_0_3))
(= c__qurt_new__fabs__1__f_52_0_0_4 ?x10054))
:assumption
(flet ($x10060 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_29 c__qurt_new__fabs__1__f_52_0_0_4))
(iff l1540 $x10060))
:assumption
l1540
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_29 c__qurt_new__fabs__1__f_52_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10065 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_29 ?x1828))
(iff l1541 $x10065)))
:assumption
(flet ($x10070 (xor l415 l1541))
(iff l1542 $x10070))
:assumption
(not l1542)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10065 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_29 ?x1828))
(= goto_symex___guard_0_0_157 $x10065)))
:assumption
(flet ($x10081 (= c__qurt_new__sqrt__1__flag_3_0_0_40 bv1[32]))
(iff l1543 $x10081))
:assumption
l1543
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_40 bv1[32])
:assumption
(flet ($x10087 (not goto_symex___guard_0_0_157))
(let (?x10088 (ite $x10087 c__qurt_new__sqrt__1__flag_3_0_0_39 c__qurt_new__sqrt__1__flag_3_0_0_40))
(flet ($x10089 (= c__qurt_new__sqrt__1__flag_3_0_0_41 ?x10088))
(iff l1544 $x10089))))
:assumption
l1544
:assumption
(flet ($x10087 (not goto_symex___guard_0_0_157))
(let (?x10088 (ite $x10087 c__qurt_new__sqrt__1__flag_3_0_0_39 c__qurt_new__sqrt__1__flag_3_0_0_40))
(= c__qurt_new__sqrt__1__flag_3_0_0_41 ?x10088)))
:assumption
(flet ($x10096 (= c__qurt_new__sqrt__1__x_3_0_0_42 c__qurt_new__sqrt__1__x_3_0_0_40))
(iff l1545 $x10096))
:assumption
l1545
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_42 c__qurt_new__sqrt__1__x_3_0_0_40)
:assumption
(flet ($x10102 (= c__qurt_new__sqrt__1__flag_3_0_0_42 c__qurt_new__sqrt__1__flag_3_0_0_39))
(iff l1546 $x10102))
:assumption
l1546
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_42 c__qurt_new__sqrt__1__flag_3_0_0_39)
:assumption
(flet ($x10108 (= c__qurt_new__sqrt__1__x_3_0_0_43 c__qurt_new__sqrt__1__x_3_0_0_42))
(iff l1547 $x10108))
:assumption
l1547
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_43 c__qurt_new__sqrt__1__x_3_0_0_42)
:assumption
(let (?x10114 (ite goto_symex___guard_0_0_155 c__qurt_new__sqrt__1__x_3_0_0_41 c__qurt_new__sqrt__1__x_3_0_0_43))
(flet ($x10115 (= c__qurt_new__sqrt__1__x_3_0_0_44 ?x10114))
(iff l1548 $x10115)))
:assumption
l1548
:assumption
(let (?x10114 (ite goto_symex___guard_0_0_155 c__qurt_new__sqrt__1__x_3_0_0_41 c__qurt_new__sqrt__1__x_3_0_0_43))
(= c__qurt_new__sqrt__1__x_3_0_0_44 ?x10114))
:assumption
(let (?x10120 (ite goto_symex___guard_0_0_155 c__qurt_new__sqrt__1__flag_3_0_0_41 c__qurt_new__sqrt__1__flag_3_0_0_42))
(flet ($x10121 (= c__qurt_new__sqrt__1__flag_3_0_0_43 ?x10120))
(iff l1549 $x10121)))
:assumption
l1549
:assumption
(let (?x10120 (ite goto_symex___guard_0_0_155 c__qurt_new__sqrt__1__flag_3_0_0_41 c__qurt_new__sqrt__1__flag_3_0_0_42))
(= c__qurt_new__sqrt__1__flag_3_0_0_43 ?x10120))
:assumption
(flet ($x10125 (= c__qurt_new__sqrt__1__flag_3_0_0_43 bv0[32]))
(iff l1550 $x10125))
:assumption
(flet ($x10130 (xor l418 l1550))
(iff l1551 $x10130))
:assumption
(not l1551)
:assumption
(flet ($x10125 (= c__qurt_new__sqrt__1__flag_3_0_0_43 bv0[32]))
(= goto_symex___guard_0_0_158 $x10125))
:assumption
(let (?x10140 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10145 (bvmul ?x1629 ?x10140))
(let (?x10146 (extract[95:32] ?x10145))
(let (?x10147 (sign_extend[32] ?x10146))
(let (?x10141 (bvmul ?x10140 ?x10140))
(let (?x10142 (extract[95:32] ?x10141))
(let (?x10143 (bvmul bv18446744073709551615[64] ?x10142))
(let (?x10144 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10143))
(let (?x10148 (concat ?x10144 bv0[32]))
(let (?x10149 (bvsdiv ?x10148 ?x10147))
(let (?x10150 (extract[63:0] ?x10149))
(flet ($x10151 (= c__qurt_new__sqrt__1__dx_3_0_0_32 ?x10150))
(iff l1552 $x10151)))))))))))))))
:assumption
l1552
:assumption
(let (?x10140 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10145 (bvmul ?x1629 ?x10140))
(let (?x10146 (extract[95:32] ?x10145))
(let (?x10147 (sign_extend[32] ?x10146))
(let (?x10141 (bvmul ?x10140 ?x10140))
(let (?x10142 (extract[95:32] ?x10141))
(let (?x10143 (bvmul bv18446744073709551615[64] ?x10142))
(let (?x10144 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10143))
(let (?x10148 (concat ?x10144 bv0[32]))
(let (?x10149 (bvsdiv ?x10148 ?x10147))
(let (?x10150 (extract[63:0] ?x10149))
(= c__qurt_new__sqrt__1__dx_3_0_0_32 ?x10150))))))))))))))
:assumption
(let (?x10171 (bvadd c__qurt_new__sqrt__1__x_3_0_0_44 c__qurt_new__sqrt__1__dx_3_0_0_32))
(flet ($x10172 (= c__qurt_new__sqrt__1__x_3_0_0_45 ?x10171))
(iff l1553 $x10172)))
:assumption
l1553
:assumption
(let (?x10171 (bvadd c__qurt_new__sqrt__1__x_3_0_0_44 c__qurt_new__sqrt__1__dx_3_0_0_32))
(= c__qurt_new__sqrt__1__x_3_0_0_45 ?x10171))
:assumption
(let (?x10177 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_45))
(let (?x10178 (bvmul ?x10177 ?x10177))
(let (?x10179 (extract[95:32] ?x10178))
(let (?x10180 (bvmul bv18446744073709551615[64] ?x10179))
(let (?x10181 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10180))
(flet ($x10182 (= c__qurt_new__sqrt__1__diff_3_0_0_32 ?x10181))
(iff l1554 $x10182)))))))
:assumption
l1554
:assumption
(let (?x10177 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_45))
(let (?x10178 (bvmul ?x10177 ?x10177))
(let (?x10179 (extract[95:32] ?x10178))
(let (?x10180 (bvmul bv18446744073709551615[64] ?x10179))
(let (?x10181 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10180))
(= c__qurt_new__sqrt__1__diff_3_0_0_32 ?x10181))))))
:assumption
(flet ($x10187 (= c__qurt_new__fabs__n_53_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_32))
(iff l1555 $x10187))
:assumption
l1555
:assumption
(= c__qurt_new__fabs__n_53_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_32)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10192 (bvsge c__qurt_new__fabs__n_53_0_0_1 ?x1542))
(iff l1556 $x10192)))
:assumption
(flet ($x10199 (xor l420 l1556))
(iff l1557 $x10199))
:assumption
(not l1557)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10192 (bvsge c__qurt_new__fabs__n_53_0_0_1 ?x1542))
(= goto_symex___guard_0_0_159 $x10192)))
:assumption
(flet ($x10210 (= c__qurt_new__fabs__1__f_53_0_0_1 c__qurt_new__fabs__n_53_0_0_1))
(iff l1558 $x10210))
:assumption
l1558
:assumption
(= c__qurt_new__fabs__1__f_53_0_0_1 c__qurt_new__fabs__n_53_0_0_1)
:assumption
(let (?x10216 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_53_0_0_1))
(flet ($x10217 (= c__qurt_new__fabs__1__f_53_0_0_3 ?x10216))
(iff l1559 $x10217)))
:assumption
l1559
:assumption
(let (?x10216 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_53_0_0_1))
(= c__qurt_new__fabs__1__f_53_0_0_3 ?x10216))
:assumption
(let (?x10222 (ite goto_symex___guard_0_0_159 c__qurt_new__fabs__1__f_53_0_0_1 c__qurt_new__fabs__1__f_53_0_0_3))
(flet ($x10223 (= c__qurt_new__fabs__1__f_53_0_0_4 ?x10222))
(iff l1560 $x10223)))
:assumption
l1560
:assumption
(let (?x10222 (ite goto_symex___guard_0_0_159 c__qurt_new__fabs__1__f_53_0_0_1 c__qurt_new__fabs__1__f_53_0_0_3))
(= c__qurt_new__fabs__1__f_53_0_0_4 ?x10222))
:assumption
(flet ($x10228 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_32 c__qurt_new__fabs__1__f_53_0_0_4))
(iff l1561 $x10228))
:assumption
l1561
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_32 c__qurt_new__fabs__1__f_53_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10233 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_32 ?x1828))
(iff l1562 $x10233)))
:assumption
(flet ($x10238 (xor l423 l1562))
(iff l1563 $x10238))
:assumption
(not l1563)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10233 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_32 ?x1828))
(= goto_symex___guard_0_0_160 $x10233)))
:assumption
(flet ($x10249 (= c__qurt_new__sqrt__1__flag_3_0_0_44 bv1[32]))
(iff l1564 $x10249))
:assumption
l1564
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_44 bv1[32])
:assumption
(flet ($x10255 (not goto_symex___guard_0_0_160))
(let (?x10256 (ite $x10255 c__qurt_new__sqrt__1__flag_3_0_0_43 c__qurt_new__sqrt__1__flag_3_0_0_44))
(flet ($x10257 (= c__qurt_new__sqrt__1__flag_3_0_0_45 ?x10256))
(iff l1565 $x10257))))
:assumption
l1565
:assumption
(flet ($x10255 (not goto_symex___guard_0_0_160))
(let (?x10256 (ite $x10255 c__qurt_new__sqrt__1__flag_3_0_0_43 c__qurt_new__sqrt__1__flag_3_0_0_44))
(= c__qurt_new__sqrt__1__flag_3_0_0_45 ?x10256)))
:assumption
(flet ($x10264 (= c__qurt_new__sqrt__1__x_3_0_0_46 c__qurt_new__sqrt__1__x_3_0_0_44))
(iff l1566 $x10264))
:assumption
l1566
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_46 c__qurt_new__sqrt__1__x_3_0_0_44)
:assumption
(flet ($x10270 (= c__qurt_new__sqrt__1__flag_3_0_0_46 c__qurt_new__sqrt__1__flag_3_0_0_43))
(iff l1567 $x10270))
:assumption
l1567
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_46 c__qurt_new__sqrt__1__flag_3_0_0_43)
:assumption
(flet ($x10276 (= c__qurt_new__sqrt__1__x_3_0_0_47 c__qurt_new__sqrt__1__x_3_0_0_46))
(iff l1568 $x10276))
:assumption
l1568
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_47 c__qurt_new__sqrt__1__x_3_0_0_46)
:assumption
(let (?x10282 (ite goto_symex___guard_0_0_158 c__qurt_new__sqrt__1__x_3_0_0_45 c__qurt_new__sqrt__1__x_3_0_0_47))
(flet ($x10283 (= c__qurt_new__sqrt__1__x_3_0_0_48 ?x10282))
(iff l1569 $x10283)))
:assumption
l1569
:assumption
(let (?x10282 (ite goto_symex___guard_0_0_158 c__qurt_new__sqrt__1__x_3_0_0_45 c__qurt_new__sqrt__1__x_3_0_0_47))
(= c__qurt_new__sqrt__1__x_3_0_0_48 ?x10282))
:assumption
(let (?x10288 (ite goto_symex___guard_0_0_158 c__qurt_new__sqrt__1__flag_3_0_0_45 c__qurt_new__sqrt__1__flag_3_0_0_46))
(flet ($x10289 (= c__qurt_new__sqrt__1__flag_3_0_0_47 ?x10288))
(iff l1570 $x10289)))
:assumption
l1570
:assumption
(let (?x10288 (ite goto_symex___guard_0_0_158 c__qurt_new__sqrt__1__flag_3_0_0_45 c__qurt_new__sqrt__1__flag_3_0_0_46))
(= c__qurt_new__sqrt__1__flag_3_0_0_47 ?x10288))
:assumption
(flet ($x10293 (= c__qurt_new__sqrt__1__flag_3_0_0_47 bv0[32]))
(iff l1571 $x10293))
:assumption
(flet ($x10298 (xor l426 l1571))
(iff l1572 $x10298))
:assumption
(not l1572)
:assumption
(flet ($x10293 (= c__qurt_new__sqrt__1__flag_3_0_0_47 bv0[32]))
(= goto_symex___guard_0_0_161 $x10293))
:assumption
(let (?x10308 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10313 (bvmul ?x1629 ?x10308))
(let (?x10314 (extract[95:32] ?x10313))
(let (?x10315 (sign_extend[32] ?x10314))
(let (?x10309 (bvmul ?x10308 ?x10308))
(let (?x10310 (extract[95:32] ?x10309))
(let (?x10311 (bvmul bv18446744073709551615[64] ?x10310))
(let (?x10312 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10311))
(let (?x10316 (concat ?x10312 bv0[32]))
(let (?x10317 (bvsdiv ?x10316 ?x10315))
(let (?x10318 (extract[63:0] ?x10317))
(flet ($x10319 (= c__qurt_new__sqrt__1__dx_3_0_0_35 ?x10318))
(iff l1573 $x10319)))))))))))))))
:assumption
l1573
:assumption
(let (?x10308 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10313 (bvmul ?x1629 ?x10308))
(let (?x10314 (extract[95:32] ?x10313))
(let (?x10315 (sign_extend[32] ?x10314))
(let (?x10309 (bvmul ?x10308 ?x10308))
(let (?x10310 (extract[95:32] ?x10309))
(let (?x10311 (bvmul bv18446744073709551615[64] ?x10310))
(let (?x10312 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10311))
(let (?x10316 (concat ?x10312 bv0[32]))
(let (?x10317 (bvsdiv ?x10316 ?x10315))
(let (?x10318 (extract[63:0] ?x10317))
(= c__qurt_new__sqrt__1__dx_3_0_0_35 ?x10318))))))))))))))
:assumption
(let (?x10339 (bvadd c__qurt_new__sqrt__1__x_3_0_0_48 c__qurt_new__sqrt__1__dx_3_0_0_35))
(flet ($x10340 (= c__qurt_new__sqrt__1__x_3_0_0_49 ?x10339))
(iff l1574 $x10340)))
:assumption
l1574
:assumption
(let (?x10339 (bvadd c__qurt_new__sqrt__1__x_3_0_0_48 c__qurt_new__sqrt__1__dx_3_0_0_35))
(= c__qurt_new__sqrt__1__x_3_0_0_49 ?x10339))
:assumption
(let (?x10345 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_49))
(let (?x10346 (bvmul ?x10345 ?x10345))
(let (?x10347 (extract[95:32] ?x10346))
(let (?x10348 (bvmul bv18446744073709551615[64] ?x10347))
(let (?x10349 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10348))
(flet ($x10350 (= c__qurt_new__sqrt__1__diff_3_0_0_35 ?x10349))
(iff l1575 $x10350)))))))
:assumption
l1575
:assumption
(let (?x10345 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_49))
(let (?x10346 (bvmul ?x10345 ?x10345))
(let (?x10347 (extract[95:32] ?x10346))
(let (?x10348 (bvmul bv18446744073709551615[64] ?x10347))
(let (?x10349 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10348))
(= c__qurt_new__sqrt__1__diff_3_0_0_35 ?x10349))))))
:assumption
(flet ($x10355 (= c__qurt_new__fabs__n_54_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_35))
(iff l1576 $x10355))
:assumption
l1576
:assumption
(= c__qurt_new__fabs__n_54_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_35)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10360 (bvsge c__qurt_new__fabs__n_54_0_0_1 ?x1542))
(iff l1577 $x10360)))
:assumption
(flet ($x10367 (xor l428 l1577))
(iff l1578 $x10367))
:assumption
(not l1578)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10360 (bvsge c__qurt_new__fabs__n_54_0_0_1 ?x1542))
(= goto_symex___guard_0_0_162 $x10360)))
:assumption
(flet ($x10378 (= c__qurt_new__fabs__1__f_54_0_0_1 c__qurt_new__fabs__n_54_0_0_1))
(iff l1579 $x10378))
:assumption
l1579
:assumption
(= c__qurt_new__fabs__1__f_54_0_0_1 c__qurt_new__fabs__n_54_0_0_1)
:assumption
(let (?x10384 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_54_0_0_1))
(flet ($x10385 (= c__qurt_new__fabs__1__f_54_0_0_3 ?x10384))
(iff l1580 $x10385)))
:assumption
l1580
:assumption
(let (?x10384 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_54_0_0_1))
(= c__qurt_new__fabs__1__f_54_0_0_3 ?x10384))
:assumption
(let (?x10390 (ite goto_symex___guard_0_0_162 c__qurt_new__fabs__1__f_54_0_0_1 c__qurt_new__fabs__1__f_54_0_0_3))
(flet ($x10391 (= c__qurt_new__fabs__1__f_54_0_0_4 ?x10390))
(iff l1581 $x10391)))
:assumption
l1581
:assumption
(let (?x10390 (ite goto_symex___guard_0_0_162 c__qurt_new__fabs__1__f_54_0_0_1 c__qurt_new__fabs__1__f_54_0_0_3))
(= c__qurt_new__fabs__1__f_54_0_0_4 ?x10390))
:assumption
(flet ($x10396 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_35 c__qurt_new__fabs__1__f_54_0_0_4))
(iff l1582 $x10396))
:assumption
l1582
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_35 c__qurt_new__fabs__1__f_54_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10401 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_35 ?x1828))
(iff l1583 $x10401)))
:assumption
(flet ($x10406 (xor l431 l1583))
(iff l1584 $x10406))
:assumption
(not l1584)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10401 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_35 ?x1828))
(= goto_symex___guard_0_0_163 $x10401)))
:assumption
(flet ($x10417 (= c__qurt_new__sqrt__1__flag_3_0_0_48 bv1[32]))
(iff l1585 $x10417))
:assumption
l1585
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_48 bv1[32])
:assumption
(flet ($x10423 (not goto_symex___guard_0_0_163))
(let (?x10424 (ite $x10423 c__qurt_new__sqrt__1__flag_3_0_0_47 c__qurt_new__sqrt__1__flag_3_0_0_48))
(flet ($x10425 (= c__qurt_new__sqrt__1__flag_3_0_0_49 ?x10424))
(iff l1586 $x10425))))
:assumption
l1586
:assumption
(flet ($x10423 (not goto_symex___guard_0_0_163))
(let (?x10424 (ite $x10423 c__qurt_new__sqrt__1__flag_3_0_0_47 c__qurt_new__sqrt__1__flag_3_0_0_48))
(= c__qurt_new__sqrt__1__flag_3_0_0_49 ?x10424)))
:assumption
(flet ($x10432 (= c__qurt_new__sqrt__1__x_3_0_0_50 c__qurt_new__sqrt__1__x_3_0_0_48))
(iff l1587 $x10432))
:assumption
l1587
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_50 c__qurt_new__sqrt__1__x_3_0_0_48)
:assumption
(flet ($x10438 (= c__qurt_new__sqrt__1__flag_3_0_0_50 c__qurt_new__sqrt__1__flag_3_0_0_47))
(iff l1588 $x10438))
:assumption
l1588
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_50 c__qurt_new__sqrt__1__flag_3_0_0_47)
:assumption
(flet ($x10444 (= c__qurt_new__sqrt__1__x_3_0_0_51 c__qurt_new__sqrt__1__x_3_0_0_50))
(iff l1589 $x10444))
:assumption
l1589
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_51 c__qurt_new__sqrt__1__x_3_0_0_50)
:assumption
(let (?x10450 (ite goto_symex___guard_0_0_161 c__qurt_new__sqrt__1__x_3_0_0_49 c__qurt_new__sqrt__1__x_3_0_0_51))
(flet ($x10451 (= c__qurt_new__sqrt__1__x_3_0_0_52 ?x10450))
(iff l1590 $x10451)))
:assumption
l1590
:assumption
(let (?x10450 (ite goto_symex___guard_0_0_161 c__qurt_new__sqrt__1__x_3_0_0_49 c__qurt_new__sqrt__1__x_3_0_0_51))
(= c__qurt_new__sqrt__1__x_3_0_0_52 ?x10450))
:assumption
(let (?x10456 (ite goto_symex___guard_0_0_161 c__qurt_new__sqrt__1__flag_3_0_0_49 c__qurt_new__sqrt__1__flag_3_0_0_50))
(flet ($x10457 (= c__qurt_new__sqrt__1__flag_3_0_0_51 ?x10456))
(iff l1591 $x10457)))
:assumption
l1591
:assumption
(let (?x10456 (ite goto_symex___guard_0_0_161 c__qurt_new__sqrt__1__flag_3_0_0_49 c__qurt_new__sqrt__1__flag_3_0_0_50))
(= c__qurt_new__sqrt__1__flag_3_0_0_51 ?x10456))
:assumption
(flet ($x10461 (= c__qurt_new__sqrt__1__flag_3_0_0_51 bv0[32]))
(iff l1592 $x10461))
:assumption
(flet ($x10466 (xor l434 l1592))
(iff l1593 $x10466))
:assumption
(not l1593)
:assumption
(flet ($x10461 (= c__qurt_new__sqrt__1__flag_3_0_0_51 bv0[32]))
(= goto_symex___guard_0_0_164 $x10461))
:assumption
(let (?x10476 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10481 (bvmul ?x1629 ?x10476))
(let (?x10482 (extract[95:32] ?x10481))
(let (?x10483 (sign_extend[32] ?x10482))
(let (?x10477 (bvmul ?x10476 ?x10476))
(let (?x10478 (extract[95:32] ?x10477))
(let (?x10479 (bvmul bv18446744073709551615[64] ?x10478))
(let (?x10480 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10479))
(let (?x10484 (concat ?x10480 bv0[32]))
(let (?x10485 (bvsdiv ?x10484 ?x10483))
(let (?x10486 (extract[63:0] ?x10485))
(flet ($x10487 (= c__qurt_new__sqrt__1__dx_3_0_0_38 ?x10486))
(iff l1594 $x10487)))))))))))))))
:assumption
l1594
:assumption
(let (?x10476 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10481 (bvmul ?x1629 ?x10476))
(let (?x10482 (extract[95:32] ?x10481))
(let (?x10483 (sign_extend[32] ?x10482))
(let (?x10477 (bvmul ?x10476 ?x10476))
(let (?x10478 (extract[95:32] ?x10477))
(let (?x10479 (bvmul bv18446744073709551615[64] ?x10478))
(let (?x10480 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10479))
(let (?x10484 (concat ?x10480 bv0[32]))
(let (?x10485 (bvsdiv ?x10484 ?x10483))
(let (?x10486 (extract[63:0] ?x10485))
(= c__qurt_new__sqrt__1__dx_3_0_0_38 ?x10486))))))))))))))
:assumption
(let (?x10507 (bvadd c__qurt_new__sqrt__1__x_3_0_0_52 c__qurt_new__sqrt__1__dx_3_0_0_38))
(flet ($x10508 (= c__qurt_new__sqrt__1__x_3_0_0_53 ?x10507))
(iff l1595 $x10508)))
:assumption
l1595
:assumption
(let (?x10507 (bvadd c__qurt_new__sqrt__1__x_3_0_0_52 c__qurt_new__sqrt__1__dx_3_0_0_38))
(= c__qurt_new__sqrt__1__x_3_0_0_53 ?x10507))
:assumption
(let (?x10513 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_53))
(let (?x10514 (bvmul ?x10513 ?x10513))
(let (?x10515 (extract[95:32] ?x10514))
(let (?x10516 (bvmul bv18446744073709551615[64] ?x10515))
(let (?x10517 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10516))
(flet ($x10518 (= c__qurt_new__sqrt__1__diff_3_0_0_38 ?x10517))
(iff l1596 $x10518)))))))
:assumption
l1596
:assumption
(let (?x10513 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_53))
(let (?x10514 (bvmul ?x10513 ?x10513))
(let (?x10515 (extract[95:32] ?x10514))
(let (?x10516 (bvmul bv18446744073709551615[64] ?x10515))
(let (?x10517 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10516))
(= c__qurt_new__sqrt__1__diff_3_0_0_38 ?x10517))))))
:assumption
(flet ($x10523 (= c__qurt_new__fabs__n_55_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_38))
(iff l1597 $x10523))
:assumption
l1597
:assumption
(= c__qurt_new__fabs__n_55_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_38)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10528 (bvsge c__qurt_new__fabs__n_55_0_0_1 ?x1542))
(iff l1598 $x10528)))
:assumption
(flet ($x10535 (xor l436 l1598))
(iff l1599 $x10535))
:assumption
(not l1599)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10528 (bvsge c__qurt_new__fabs__n_55_0_0_1 ?x1542))
(= goto_symex___guard_0_0_165 $x10528)))
:assumption
(flet ($x10546 (= c__qurt_new__fabs__1__f_55_0_0_1 c__qurt_new__fabs__n_55_0_0_1))
(iff l1600 $x10546))
:assumption
l1600
:assumption
(= c__qurt_new__fabs__1__f_55_0_0_1 c__qurt_new__fabs__n_55_0_0_1)
:assumption
(let (?x10552 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_55_0_0_1))
(flet ($x10553 (= c__qurt_new__fabs__1__f_55_0_0_3 ?x10552))
(iff l1601 $x10553)))
:assumption
l1601
:assumption
(let (?x10552 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_55_0_0_1))
(= c__qurt_new__fabs__1__f_55_0_0_3 ?x10552))
:assumption
(let (?x10558 (ite goto_symex___guard_0_0_165 c__qurt_new__fabs__1__f_55_0_0_1 c__qurt_new__fabs__1__f_55_0_0_3))
(flet ($x10559 (= c__qurt_new__fabs__1__f_55_0_0_4 ?x10558))
(iff l1602 $x10559)))
:assumption
l1602
:assumption
(let (?x10558 (ite goto_symex___guard_0_0_165 c__qurt_new__fabs__1__f_55_0_0_1 c__qurt_new__fabs__1__f_55_0_0_3))
(= c__qurt_new__fabs__1__f_55_0_0_4 ?x10558))
:assumption
(flet ($x10564 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_38 c__qurt_new__fabs__1__f_55_0_0_4))
(iff l1603 $x10564))
:assumption
l1603
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_38 c__qurt_new__fabs__1__f_55_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10569 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_38 ?x1828))
(iff l1604 $x10569)))
:assumption
(flet ($x10574 (xor l439 l1604))
(iff l1605 $x10574))
:assumption
(not l1605)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10569 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_38 ?x1828))
(= goto_symex___guard_0_0_166 $x10569)))
:assumption
(flet ($x10585 (= c__qurt_new__sqrt__1__flag_3_0_0_52 bv1[32]))
(iff l1606 $x10585))
:assumption
l1606
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_52 bv1[32])
:assumption
(flet ($x10591 (not goto_symex___guard_0_0_166))
(let (?x10592 (ite $x10591 c__qurt_new__sqrt__1__flag_3_0_0_51 c__qurt_new__sqrt__1__flag_3_0_0_52))
(flet ($x10593 (= c__qurt_new__sqrt__1__flag_3_0_0_53 ?x10592))
(iff l1607 $x10593))))
:assumption
l1607
:assumption
(flet ($x10591 (not goto_symex___guard_0_0_166))
(let (?x10592 (ite $x10591 c__qurt_new__sqrt__1__flag_3_0_0_51 c__qurt_new__sqrt__1__flag_3_0_0_52))
(= c__qurt_new__sqrt__1__flag_3_0_0_53 ?x10592)))
:assumption
(flet ($x10600 (= c__qurt_new__sqrt__1__x_3_0_0_54 c__qurt_new__sqrt__1__x_3_0_0_52))
(iff l1608 $x10600))
:assumption
l1608
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_54 c__qurt_new__sqrt__1__x_3_0_0_52)
:assumption
(flet ($x10606 (= c__qurt_new__sqrt__1__flag_3_0_0_54 c__qurt_new__sqrt__1__flag_3_0_0_51))
(iff l1609 $x10606))
:assumption
l1609
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_54 c__qurt_new__sqrt__1__flag_3_0_0_51)
:assumption
(flet ($x10612 (= c__qurt_new__sqrt__1__x_3_0_0_55 c__qurt_new__sqrt__1__x_3_0_0_54))
(iff l1610 $x10612))
:assumption
l1610
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_55 c__qurt_new__sqrt__1__x_3_0_0_54)
:assumption
(let (?x10618 (ite goto_symex___guard_0_0_164 c__qurt_new__sqrt__1__x_3_0_0_53 c__qurt_new__sqrt__1__x_3_0_0_55))
(flet ($x10619 (= c__qurt_new__sqrt__1__x_3_0_0_56 ?x10618))
(iff l1611 $x10619)))
:assumption
l1611
:assumption
(let (?x10618 (ite goto_symex___guard_0_0_164 c__qurt_new__sqrt__1__x_3_0_0_53 c__qurt_new__sqrt__1__x_3_0_0_55))
(= c__qurt_new__sqrt__1__x_3_0_0_56 ?x10618))
:assumption
(let (?x10624 (ite goto_symex___guard_0_0_164 c__qurt_new__sqrt__1__flag_3_0_0_53 c__qurt_new__sqrt__1__flag_3_0_0_54))
(flet ($x10625 (= c__qurt_new__sqrt__1__flag_3_0_0_55 ?x10624))
(iff l1612 $x10625)))
:assumption
l1612
:assumption
(let (?x10624 (ite goto_symex___guard_0_0_164 c__qurt_new__sqrt__1__flag_3_0_0_53 c__qurt_new__sqrt__1__flag_3_0_0_54))
(= c__qurt_new__sqrt__1__flag_3_0_0_55 ?x10624))
:assumption
(flet ($x10629 (= c__qurt_new__sqrt__1__flag_3_0_0_55 bv0[32]))
(iff l1613 $x10629))
:assumption
(flet ($x10634 (xor l442 l1613))
(iff l1614 $x10634))
:assumption
(not l1614)
:assumption
(flet ($x10629 (= c__qurt_new__sqrt__1__flag_3_0_0_55 bv0[32]))
(= goto_symex___guard_0_0_167 $x10629))
:assumption
(let (?x10644 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10649 (bvmul ?x1629 ?x10644))
(let (?x10650 (extract[95:32] ?x10649))
(let (?x10651 (sign_extend[32] ?x10650))
(let (?x10645 (bvmul ?x10644 ?x10644))
(let (?x10646 (extract[95:32] ?x10645))
(let (?x10647 (bvmul bv18446744073709551615[64] ?x10646))
(let (?x10648 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10647))
(let (?x10652 (concat ?x10648 bv0[32]))
(let (?x10653 (bvsdiv ?x10652 ?x10651))
(let (?x10654 (extract[63:0] ?x10653))
(flet ($x10655 (= c__qurt_new__sqrt__1__dx_3_0_0_41 ?x10654))
(iff l1615 $x10655)))))))))))))))
:assumption
l1615
:assumption
(let (?x10644 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10649 (bvmul ?x1629 ?x10644))
(let (?x10650 (extract[95:32] ?x10649))
(let (?x10651 (sign_extend[32] ?x10650))
(let (?x10645 (bvmul ?x10644 ?x10644))
(let (?x10646 (extract[95:32] ?x10645))
(let (?x10647 (bvmul bv18446744073709551615[64] ?x10646))
(let (?x10648 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10647))
(let (?x10652 (concat ?x10648 bv0[32]))
(let (?x10653 (bvsdiv ?x10652 ?x10651))
(let (?x10654 (extract[63:0] ?x10653))
(= c__qurt_new__sqrt__1__dx_3_0_0_41 ?x10654))))))))))))))
:assumption
(let (?x10675 (bvadd c__qurt_new__sqrt__1__x_3_0_0_56 c__qurt_new__sqrt__1__dx_3_0_0_41))
(flet ($x10676 (= c__qurt_new__sqrt__1__x_3_0_0_57 ?x10675))
(iff l1616 $x10676)))
:assumption
l1616
:assumption
(let (?x10675 (bvadd c__qurt_new__sqrt__1__x_3_0_0_56 c__qurt_new__sqrt__1__dx_3_0_0_41))
(= c__qurt_new__sqrt__1__x_3_0_0_57 ?x10675))
:assumption
(let (?x10681 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_57))
(let (?x10682 (bvmul ?x10681 ?x10681))
(let (?x10683 (extract[95:32] ?x10682))
(let (?x10684 (bvmul bv18446744073709551615[64] ?x10683))
(let (?x10685 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10684))
(flet ($x10686 (= c__qurt_new__sqrt__1__diff_3_0_0_41 ?x10685))
(iff l1617 $x10686)))))))
:assumption
l1617
:assumption
(let (?x10681 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_57))
(let (?x10682 (bvmul ?x10681 ?x10681))
(let (?x10683 (extract[95:32] ?x10682))
(let (?x10684 (bvmul bv18446744073709551615[64] ?x10683))
(let (?x10685 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10684))
(= c__qurt_new__sqrt__1__diff_3_0_0_41 ?x10685))))))
:assumption
(flet ($x10691 (= c__qurt_new__fabs__n_56_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_41))
(iff l1618 $x10691))
:assumption
l1618
:assumption
(= c__qurt_new__fabs__n_56_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_41)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10696 (bvsge c__qurt_new__fabs__n_56_0_0_1 ?x1542))
(iff l1619 $x10696)))
:assumption
(flet ($x10703 (xor l444 l1619))
(iff l1620 $x10703))
:assumption
(not l1620)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10696 (bvsge c__qurt_new__fabs__n_56_0_0_1 ?x1542))
(= goto_symex___guard_0_0_168 $x10696)))
:assumption
(flet ($x10714 (= c__qurt_new__fabs__1__f_56_0_0_1 c__qurt_new__fabs__n_56_0_0_1))
(iff l1621 $x10714))
:assumption
l1621
:assumption
(= c__qurt_new__fabs__1__f_56_0_0_1 c__qurt_new__fabs__n_56_0_0_1)
:assumption
(let (?x10720 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_56_0_0_1))
(flet ($x10721 (= c__qurt_new__fabs__1__f_56_0_0_3 ?x10720))
(iff l1622 $x10721)))
:assumption
l1622
:assumption
(let (?x10720 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_56_0_0_1))
(= c__qurt_new__fabs__1__f_56_0_0_3 ?x10720))
:assumption
(let (?x10726 (ite goto_symex___guard_0_0_168 c__qurt_new__fabs__1__f_56_0_0_1 c__qurt_new__fabs__1__f_56_0_0_3))
(flet ($x10727 (= c__qurt_new__fabs__1__f_56_0_0_4 ?x10726))
(iff l1623 $x10727)))
:assumption
l1623
:assumption
(let (?x10726 (ite goto_symex___guard_0_0_168 c__qurt_new__fabs__1__f_56_0_0_1 c__qurt_new__fabs__1__f_56_0_0_3))
(= c__qurt_new__fabs__1__f_56_0_0_4 ?x10726))
:assumption
(flet ($x10732 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_41 c__qurt_new__fabs__1__f_56_0_0_4))
(iff l1624 $x10732))
:assumption
l1624
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_41 c__qurt_new__fabs__1__f_56_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10737 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_41 ?x1828))
(iff l1625 $x10737)))
:assumption
(flet ($x10742 (xor l447 l1625))
(iff l1626 $x10742))
:assumption
(not l1626)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10737 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_41 ?x1828))
(= goto_symex___guard_0_0_169 $x10737)))
:assumption
(flet ($x10753 (= c__qurt_new__sqrt__1__flag_3_0_0_56 bv1[32]))
(iff l1627 $x10753))
:assumption
l1627
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_56 bv1[32])
:assumption
(flet ($x10759 (not goto_symex___guard_0_0_169))
(let (?x10760 (ite $x10759 c__qurt_new__sqrt__1__flag_3_0_0_55 c__qurt_new__sqrt__1__flag_3_0_0_56))
(flet ($x10761 (= c__qurt_new__sqrt__1__flag_3_0_0_57 ?x10760))
(iff l1628 $x10761))))
:assumption
l1628
:assumption
(flet ($x10759 (not goto_symex___guard_0_0_169))
(let (?x10760 (ite $x10759 c__qurt_new__sqrt__1__flag_3_0_0_55 c__qurt_new__sqrt__1__flag_3_0_0_56))
(= c__qurt_new__sqrt__1__flag_3_0_0_57 ?x10760)))
:assumption
(flet ($x10768 (= c__qurt_new__sqrt__1__x_3_0_0_58 c__qurt_new__sqrt__1__x_3_0_0_56))
(iff l1629 $x10768))
:assumption
l1629
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_58 c__qurt_new__sqrt__1__x_3_0_0_56)
:assumption
(flet ($x10774 (= c__qurt_new__sqrt__1__flag_3_0_0_58 c__qurt_new__sqrt__1__flag_3_0_0_55))
(iff l1630 $x10774))
:assumption
l1630
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_58 c__qurt_new__sqrt__1__flag_3_0_0_55)
:assumption
(flet ($x10780 (= c__qurt_new__sqrt__1__x_3_0_0_59 c__qurt_new__sqrt__1__x_3_0_0_58))
(iff l1631 $x10780))
:assumption
l1631
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_59 c__qurt_new__sqrt__1__x_3_0_0_58)
:assumption
(let (?x10786 (ite goto_symex___guard_0_0_167 c__qurt_new__sqrt__1__x_3_0_0_57 c__qurt_new__sqrt__1__x_3_0_0_59))
(flet ($x10787 (= c__qurt_new__sqrt__1__x_3_0_0_60 ?x10786))
(iff l1632 $x10787)))
:assumption
l1632
:assumption
(let (?x10786 (ite goto_symex___guard_0_0_167 c__qurt_new__sqrt__1__x_3_0_0_57 c__qurt_new__sqrt__1__x_3_0_0_59))
(= c__qurt_new__sqrt__1__x_3_0_0_60 ?x10786))
:assumption
(let (?x10792 (ite goto_symex___guard_0_0_167 c__qurt_new__sqrt__1__flag_3_0_0_57 c__qurt_new__sqrt__1__flag_3_0_0_58))
(flet ($x10793 (= c__qurt_new__sqrt__1__flag_3_0_0_59 ?x10792))
(iff l1633 $x10793)))
:assumption
l1633
:assumption
(let (?x10792 (ite goto_symex___guard_0_0_167 c__qurt_new__sqrt__1__flag_3_0_0_57 c__qurt_new__sqrt__1__flag_3_0_0_58))
(= c__qurt_new__sqrt__1__flag_3_0_0_59 ?x10792))
:assumption
(flet ($x10797 (= c__qurt_new__sqrt__1__flag_3_0_0_59 bv0[32]))
(iff l1634 $x10797))
:assumption
(flet ($x10802 (xor l450 l1634))
(iff l1635 $x10802))
:assumption
(not l1635)
:assumption
(flet ($x10797 (= c__qurt_new__sqrt__1__flag_3_0_0_59 bv0[32]))
(= goto_symex___guard_0_0_170 $x10797))
:assumption
(let (?x10812 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10817 (bvmul ?x1629 ?x10812))
(let (?x10818 (extract[95:32] ?x10817))
(let (?x10819 (sign_extend[32] ?x10818))
(let (?x10813 (bvmul ?x10812 ?x10812))
(let (?x10814 (extract[95:32] ?x10813))
(let (?x10815 (bvmul bv18446744073709551615[64] ?x10814))
(let (?x10816 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10815))
(let (?x10820 (concat ?x10816 bv0[32]))
(let (?x10821 (bvsdiv ?x10820 ?x10819))
(let (?x10822 (extract[63:0] ?x10821))
(flet ($x10823 (= c__qurt_new__sqrt__1__dx_3_0_0_44 ?x10822))
(iff l1636 $x10823)))))))))))))))
:assumption
l1636
:assumption
(let (?x10812 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10817 (bvmul ?x1629 ?x10812))
(let (?x10818 (extract[95:32] ?x10817))
(let (?x10819 (sign_extend[32] ?x10818))
(let (?x10813 (bvmul ?x10812 ?x10812))
(let (?x10814 (extract[95:32] ?x10813))
(let (?x10815 (bvmul bv18446744073709551615[64] ?x10814))
(let (?x10816 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10815))
(let (?x10820 (concat ?x10816 bv0[32]))
(let (?x10821 (bvsdiv ?x10820 ?x10819))
(let (?x10822 (extract[63:0] ?x10821))
(= c__qurt_new__sqrt__1__dx_3_0_0_44 ?x10822))))))))))))))
:assumption
(let (?x10843 (bvadd c__qurt_new__sqrt__1__x_3_0_0_60 c__qurt_new__sqrt__1__dx_3_0_0_44))
(flet ($x10844 (= c__qurt_new__sqrt__1__x_3_0_0_61 ?x10843))
(iff l1637 $x10844)))
:assumption
l1637
:assumption
(let (?x10843 (bvadd c__qurt_new__sqrt__1__x_3_0_0_60 c__qurt_new__sqrt__1__dx_3_0_0_44))
(= c__qurt_new__sqrt__1__x_3_0_0_61 ?x10843))
:assumption
(let (?x10849 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_61))
(let (?x10850 (bvmul ?x10849 ?x10849))
(let (?x10851 (extract[95:32] ?x10850))
(let (?x10852 (bvmul bv18446744073709551615[64] ?x10851))
(let (?x10853 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10852))
(flet ($x10854 (= c__qurt_new__sqrt__1__diff_3_0_0_44 ?x10853))
(iff l1638 $x10854)))))))
:assumption
l1638
:assumption
(let (?x10849 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_61))
(let (?x10850 (bvmul ?x10849 ?x10849))
(let (?x10851 (extract[95:32] ?x10850))
(let (?x10852 (bvmul bv18446744073709551615[64] ?x10851))
(let (?x10853 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10852))
(= c__qurt_new__sqrt__1__diff_3_0_0_44 ?x10853))))))
:assumption
(flet ($x10859 (= c__qurt_new__fabs__n_57_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_44))
(iff l1639 $x10859))
:assumption
l1639
:assumption
(= c__qurt_new__fabs__n_57_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_44)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10864 (bvsge c__qurt_new__fabs__n_57_0_0_1 ?x1542))
(iff l1640 $x10864)))
:assumption
(flet ($x10871 (xor l452 l1640))
(iff l1641 $x10871))
:assumption
(not l1641)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x10864 (bvsge c__qurt_new__fabs__n_57_0_0_1 ?x1542))
(= goto_symex___guard_0_0_171 $x10864)))
:assumption
(flet ($x10882 (= c__qurt_new__fabs__1__f_57_0_0_1 c__qurt_new__fabs__n_57_0_0_1))
(iff l1642 $x10882))
:assumption
l1642
:assumption
(= c__qurt_new__fabs__1__f_57_0_0_1 c__qurt_new__fabs__n_57_0_0_1)
:assumption
(let (?x10888 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_57_0_0_1))
(flet ($x10889 (= c__qurt_new__fabs__1__f_57_0_0_3 ?x10888))
(iff l1643 $x10889)))
:assumption
l1643
:assumption
(let (?x10888 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_57_0_0_1))
(= c__qurt_new__fabs__1__f_57_0_0_3 ?x10888))
:assumption
(let (?x10894 (ite goto_symex___guard_0_0_171 c__qurt_new__fabs__1__f_57_0_0_1 c__qurt_new__fabs__1__f_57_0_0_3))
(flet ($x10895 (= c__qurt_new__fabs__1__f_57_0_0_4 ?x10894))
(iff l1644 $x10895)))
:assumption
l1644
:assumption
(let (?x10894 (ite goto_symex___guard_0_0_171 c__qurt_new__fabs__1__f_57_0_0_1 c__qurt_new__fabs__1__f_57_0_0_3))
(= c__qurt_new__fabs__1__f_57_0_0_4 ?x10894))
:assumption
(flet ($x10900 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_44 c__qurt_new__fabs__1__f_57_0_0_4))
(iff l1645 $x10900))
:assumption
l1645
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_44 c__qurt_new__fabs__1__f_57_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10905 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_44 ?x1828))
(iff l1646 $x10905)))
:assumption
(flet ($x10910 (xor l455 l1646))
(iff l1647 $x10910))
:assumption
(not l1647)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x10905 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_44 ?x1828))
(= goto_symex___guard_0_0_172 $x10905)))
:assumption
(flet ($x10921 (= c__qurt_new__sqrt__1__flag_3_0_0_60 bv1[32]))
(iff l1648 $x10921))
:assumption
l1648
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_60 bv1[32])
:assumption
(flet ($x10927 (not goto_symex___guard_0_0_172))
(let (?x10928 (ite $x10927 c__qurt_new__sqrt__1__flag_3_0_0_59 c__qurt_new__sqrt__1__flag_3_0_0_60))
(flet ($x10929 (= c__qurt_new__sqrt__1__flag_3_0_0_61 ?x10928))
(iff l1649 $x10929))))
:assumption
l1649
:assumption
(flet ($x10927 (not goto_symex___guard_0_0_172))
(let (?x10928 (ite $x10927 c__qurt_new__sqrt__1__flag_3_0_0_59 c__qurt_new__sqrt__1__flag_3_0_0_60))
(= c__qurt_new__sqrt__1__flag_3_0_0_61 ?x10928)))
:assumption
(flet ($x10936 (= c__qurt_new__sqrt__1__x_3_0_0_62 c__qurt_new__sqrt__1__x_3_0_0_60))
(iff l1650 $x10936))
:assumption
l1650
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_62 c__qurt_new__sqrt__1__x_3_0_0_60)
:assumption
(flet ($x10942 (= c__qurt_new__sqrt__1__flag_3_0_0_62 c__qurt_new__sqrt__1__flag_3_0_0_59))
(iff l1651 $x10942))
:assumption
l1651
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_62 c__qurt_new__sqrt__1__flag_3_0_0_59)
:assumption
(flet ($x10948 (= c__qurt_new__sqrt__1__x_3_0_0_63 c__qurt_new__sqrt__1__x_3_0_0_62))
(iff l1652 $x10948))
:assumption
l1652
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_63 c__qurt_new__sqrt__1__x_3_0_0_62)
:assumption
(let (?x10954 (ite goto_symex___guard_0_0_170 c__qurt_new__sqrt__1__x_3_0_0_61 c__qurt_new__sqrt__1__x_3_0_0_63))
(flet ($x10955 (= c__qurt_new__sqrt__1__x_3_0_0_64 ?x10954))
(iff l1653 $x10955)))
:assumption
l1653
:assumption
(let (?x10954 (ite goto_symex___guard_0_0_170 c__qurt_new__sqrt__1__x_3_0_0_61 c__qurt_new__sqrt__1__x_3_0_0_63))
(= c__qurt_new__sqrt__1__x_3_0_0_64 ?x10954))
:assumption
(let (?x10960 (ite goto_symex___guard_0_0_170 c__qurt_new__sqrt__1__flag_3_0_0_61 c__qurt_new__sqrt__1__flag_3_0_0_62))
(flet ($x10961 (= c__qurt_new__sqrt__1__flag_3_0_0_63 ?x10960))
(iff l1654 $x10961)))
:assumption
l1654
:assumption
(let (?x10960 (ite goto_symex___guard_0_0_170 c__qurt_new__sqrt__1__flag_3_0_0_61 c__qurt_new__sqrt__1__flag_3_0_0_62))
(= c__qurt_new__sqrt__1__flag_3_0_0_63 ?x10960))
:assumption
(flet ($x10965 (= c__qurt_new__sqrt__1__flag_3_0_0_63 bv0[32]))
(iff l1655 $x10965))
:assumption
(flet ($x10970 (xor l458 l1655))
(iff l1656 $x10970))
:assumption
(not l1656)
:assumption
(flet ($x10965 (= c__qurt_new__sqrt__1__flag_3_0_0_63 bv0[32]))
(= goto_symex___guard_0_0_173 $x10965))
:assumption
(let (?x10980 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10985 (bvmul ?x1629 ?x10980))
(let (?x10986 (extract[95:32] ?x10985))
(let (?x10987 (sign_extend[32] ?x10986))
(let (?x10981 (bvmul ?x10980 ?x10980))
(let (?x10982 (extract[95:32] ?x10981))
(let (?x10983 (bvmul bv18446744073709551615[64] ?x10982))
(let (?x10984 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10983))
(let (?x10988 (concat ?x10984 bv0[32]))
(let (?x10989 (bvsdiv ?x10988 ?x10987))
(let (?x10990 (extract[63:0] ?x10989))
(flet ($x10991 (= c__qurt_new__sqrt__1__dx_3_0_0_47 ?x10990))
(iff l1657 $x10991)))))))))))))))
:assumption
l1657
:assumption
(let (?x10980 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10985 (bvmul ?x1629 ?x10980))
(let (?x10986 (extract[95:32] ?x10985))
(let (?x10987 (sign_extend[32] ?x10986))
(let (?x10981 (bvmul ?x10980 ?x10980))
(let (?x10982 (extract[95:32] ?x10981))
(let (?x10983 (bvmul bv18446744073709551615[64] ?x10982))
(let (?x10984 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x10983))
(let (?x10988 (concat ?x10984 bv0[32]))
(let (?x10989 (bvsdiv ?x10988 ?x10987))
(let (?x10990 (extract[63:0] ?x10989))
(= c__qurt_new__sqrt__1__dx_3_0_0_47 ?x10990))))))))))))))
:assumption
(let (?x11011 (bvadd c__qurt_new__sqrt__1__x_3_0_0_64 c__qurt_new__sqrt__1__dx_3_0_0_47))
(flet ($x11012 (= c__qurt_new__sqrt__1__x_3_0_0_65 ?x11011))
(iff l1658 $x11012)))
:assumption
l1658
:assumption
(let (?x11011 (bvadd c__qurt_new__sqrt__1__x_3_0_0_64 c__qurt_new__sqrt__1__dx_3_0_0_47))
(= c__qurt_new__sqrt__1__x_3_0_0_65 ?x11011))
:assumption
(let (?x11017 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_65))
(let (?x11018 (bvmul ?x11017 ?x11017))
(let (?x11019 (extract[95:32] ?x11018))
(let (?x11020 (bvmul bv18446744073709551615[64] ?x11019))
(let (?x11021 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11020))
(flet ($x11022 (= c__qurt_new__sqrt__1__diff_3_0_0_47 ?x11021))
(iff l1659 $x11022)))))))
:assumption
l1659
:assumption
(let (?x11017 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_65))
(let (?x11018 (bvmul ?x11017 ?x11017))
(let (?x11019 (extract[95:32] ?x11018))
(let (?x11020 (bvmul bv18446744073709551615[64] ?x11019))
(let (?x11021 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11020))
(= c__qurt_new__sqrt__1__diff_3_0_0_47 ?x11021))))))
:assumption
(flet ($x11027 (= c__qurt_new__fabs__n_58_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_47))
(iff l1660 $x11027))
:assumption
l1660
:assumption
(= c__qurt_new__fabs__n_58_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_47)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11032 (bvsge c__qurt_new__fabs__n_58_0_0_1 ?x1542))
(iff l1661 $x11032)))
:assumption
(flet ($x11039 (xor l460 l1661))
(iff l1662 $x11039))
:assumption
(not l1662)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11032 (bvsge c__qurt_new__fabs__n_58_0_0_1 ?x1542))
(= goto_symex___guard_0_0_174 $x11032)))
:assumption
(flet ($x11050 (= c__qurt_new__fabs__1__f_58_0_0_1 c__qurt_new__fabs__n_58_0_0_1))
(iff l1663 $x11050))
:assumption
l1663
:assumption
(= c__qurt_new__fabs__1__f_58_0_0_1 c__qurt_new__fabs__n_58_0_0_1)
:assumption
(let (?x11056 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_58_0_0_1))
(flet ($x11057 (= c__qurt_new__fabs__1__f_58_0_0_3 ?x11056))
(iff l1664 $x11057)))
:assumption
l1664
:assumption
(let (?x11056 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_58_0_0_1))
(= c__qurt_new__fabs__1__f_58_0_0_3 ?x11056))
:assumption
(let (?x11062 (ite goto_symex___guard_0_0_174 c__qurt_new__fabs__1__f_58_0_0_1 c__qurt_new__fabs__1__f_58_0_0_3))
(flet ($x11063 (= c__qurt_new__fabs__1__f_58_0_0_4 ?x11062))
(iff l1665 $x11063)))
:assumption
l1665
:assumption
(let (?x11062 (ite goto_symex___guard_0_0_174 c__qurt_new__fabs__1__f_58_0_0_1 c__qurt_new__fabs__1__f_58_0_0_3))
(= c__qurt_new__fabs__1__f_58_0_0_4 ?x11062))
:assumption
(flet ($x11068 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_47 c__qurt_new__fabs__1__f_58_0_0_4))
(iff l1666 $x11068))
:assumption
l1666
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_47 c__qurt_new__fabs__1__f_58_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11073 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_47 ?x1828))
(iff l1667 $x11073)))
:assumption
(flet ($x11078 (xor l463 l1667))
(iff l1668 $x11078))
:assumption
(not l1668)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11073 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_47 ?x1828))
(= goto_symex___guard_0_0_175 $x11073)))
:assumption
(flet ($x11089 (= c__qurt_new__sqrt__1__flag_3_0_0_64 bv1[32]))
(iff l1669 $x11089))
:assumption
l1669
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_64 bv1[32])
:assumption
(flet ($x11095 (not goto_symex___guard_0_0_175))
(let (?x11096 (ite $x11095 c__qurt_new__sqrt__1__flag_3_0_0_63 c__qurt_new__sqrt__1__flag_3_0_0_64))
(flet ($x11097 (= c__qurt_new__sqrt__1__flag_3_0_0_65 ?x11096))
(iff l1670 $x11097))))
:assumption
l1670
:assumption
(flet ($x11095 (not goto_symex___guard_0_0_175))
(let (?x11096 (ite $x11095 c__qurt_new__sqrt__1__flag_3_0_0_63 c__qurt_new__sqrt__1__flag_3_0_0_64))
(= c__qurt_new__sqrt__1__flag_3_0_0_65 ?x11096)))
:assumption
(flet ($x11104 (= c__qurt_new__sqrt__1__x_3_0_0_66 c__qurt_new__sqrt__1__x_3_0_0_64))
(iff l1671 $x11104))
:assumption
l1671
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_66 c__qurt_new__sqrt__1__x_3_0_0_64)
:assumption
(flet ($x11110 (= c__qurt_new__sqrt__1__flag_3_0_0_66 c__qurt_new__sqrt__1__flag_3_0_0_63))
(iff l1672 $x11110))
:assumption
l1672
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_66 c__qurt_new__sqrt__1__flag_3_0_0_63)
:assumption
(flet ($x11116 (= c__qurt_new__sqrt__1__x_3_0_0_67 c__qurt_new__sqrt__1__x_3_0_0_66))
(iff l1673 $x11116))
:assumption
l1673
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_67 c__qurt_new__sqrt__1__x_3_0_0_66)
:assumption
(let (?x11122 (ite goto_symex___guard_0_0_173 c__qurt_new__sqrt__1__x_3_0_0_65 c__qurt_new__sqrt__1__x_3_0_0_67))
(flet ($x11123 (= c__qurt_new__sqrt__1__x_3_0_0_68 ?x11122))
(iff l1674 $x11123)))
:assumption
l1674
:assumption
(let (?x11122 (ite goto_symex___guard_0_0_173 c__qurt_new__sqrt__1__x_3_0_0_65 c__qurt_new__sqrt__1__x_3_0_0_67))
(= c__qurt_new__sqrt__1__x_3_0_0_68 ?x11122))
:assumption
(let (?x11128 (ite goto_symex___guard_0_0_173 c__qurt_new__sqrt__1__flag_3_0_0_65 c__qurt_new__sqrt__1__flag_3_0_0_66))
(flet ($x11129 (= c__qurt_new__sqrt__1__flag_3_0_0_67 ?x11128))
(iff l1675 $x11129)))
:assumption
l1675
:assumption
(let (?x11128 (ite goto_symex___guard_0_0_173 c__qurt_new__sqrt__1__flag_3_0_0_65 c__qurt_new__sqrt__1__flag_3_0_0_66))
(= c__qurt_new__sqrt__1__flag_3_0_0_67 ?x11128))
:assumption
(flet ($x11133 (= c__qurt_new__sqrt__1__flag_3_0_0_67 bv0[32]))
(iff l1676 $x11133))
:assumption
(flet ($x11138 (xor l466 l1676))
(iff l1677 $x11138))
:assumption
(not l1677)
:assumption
(flet ($x11133 (= c__qurt_new__sqrt__1__flag_3_0_0_67 bv0[32]))
(= goto_symex___guard_0_0_176 $x11133))
:assumption
(let (?x11148 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11153 (bvmul ?x1629 ?x11148))
(let (?x11154 (extract[95:32] ?x11153))
(let (?x11155 (sign_extend[32] ?x11154))
(let (?x11149 (bvmul ?x11148 ?x11148))
(let (?x11150 (extract[95:32] ?x11149))
(let (?x11151 (bvmul bv18446744073709551615[64] ?x11150))
(let (?x11152 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11151))
(let (?x11156 (concat ?x11152 bv0[32]))
(let (?x11157 (bvsdiv ?x11156 ?x11155))
(let (?x11158 (extract[63:0] ?x11157))
(flet ($x11159 (= c__qurt_new__sqrt__1__dx_3_0_0_50 ?x11158))
(iff l1678 $x11159)))))))))))))))
:assumption
l1678
:assumption
(let (?x11148 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11153 (bvmul ?x1629 ?x11148))
(let (?x11154 (extract[95:32] ?x11153))
(let (?x11155 (sign_extend[32] ?x11154))
(let (?x11149 (bvmul ?x11148 ?x11148))
(let (?x11150 (extract[95:32] ?x11149))
(let (?x11151 (bvmul bv18446744073709551615[64] ?x11150))
(let (?x11152 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11151))
(let (?x11156 (concat ?x11152 bv0[32]))
(let (?x11157 (bvsdiv ?x11156 ?x11155))
(let (?x11158 (extract[63:0] ?x11157))
(= c__qurt_new__sqrt__1__dx_3_0_0_50 ?x11158))))))))))))))
:assumption
(let (?x11179 (bvadd c__qurt_new__sqrt__1__x_3_0_0_68 c__qurt_new__sqrt__1__dx_3_0_0_50))
(flet ($x11180 (= c__qurt_new__sqrt__1__x_3_0_0_69 ?x11179))
(iff l1679 $x11180)))
:assumption
l1679
:assumption
(let (?x11179 (bvadd c__qurt_new__sqrt__1__x_3_0_0_68 c__qurt_new__sqrt__1__dx_3_0_0_50))
(= c__qurt_new__sqrt__1__x_3_0_0_69 ?x11179))
:assumption
(let (?x11185 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_69))
(let (?x11186 (bvmul ?x11185 ?x11185))
(let (?x11187 (extract[95:32] ?x11186))
(let (?x11188 (bvmul bv18446744073709551615[64] ?x11187))
(let (?x11189 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11188))
(flet ($x11190 (= c__qurt_new__sqrt__1__diff_3_0_0_50 ?x11189))
(iff l1680 $x11190)))))))
:assumption
l1680
:assumption
(let (?x11185 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_69))
(let (?x11186 (bvmul ?x11185 ?x11185))
(let (?x11187 (extract[95:32] ?x11186))
(let (?x11188 (bvmul bv18446744073709551615[64] ?x11187))
(let (?x11189 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11188))
(= c__qurt_new__sqrt__1__diff_3_0_0_50 ?x11189))))))
:assumption
(flet ($x11195 (= c__qurt_new__fabs__n_59_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_50))
(iff l1681 $x11195))
:assumption
l1681
:assumption
(= c__qurt_new__fabs__n_59_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_50)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11200 (bvsge c__qurt_new__fabs__n_59_0_0_1 ?x1542))
(iff l1682 $x11200)))
:assumption
(flet ($x11207 (xor l468 l1682))
(iff l1683 $x11207))
:assumption
(not l1683)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11200 (bvsge c__qurt_new__fabs__n_59_0_0_1 ?x1542))
(= goto_symex___guard_0_0_177 $x11200)))
:assumption
(flet ($x11218 (= c__qurt_new__fabs__1__f_59_0_0_1 c__qurt_new__fabs__n_59_0_0_1))
(iff l1684 $x11218))
:assumption
l1684
:assumption
(= c__qurt_new__fabs__1__f_59_0_0_1 c__qurt_new__fabs__n_59_0_0_1)
:assumption
(let (?x11224 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_59_0_0_1))
(flet ($x11225 (= c__qurt_new__fabs__1__f_59_0_0_3 ?x11224))
(iff l1685 $x11225)))
:assumption
l1685
:assumption
(let (?x11224 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_59_0_0_1))
(= c__qurt_new__fabs__1__f_59_0_0_3 ?x11224))
:assumption
(let (?x11230 (ite goto_symex___guard_0_0_177 c__qurt_new__fabs__1__f_59_0_0_1 c__qurt_new__fabs__1__f_59_0_0_3))
(flet ($x11231 (= c__qurt_new__fabs__1__f_59_0_0_4 ?x11230))
(iff l1686 $x11231)))
:assumption
l1686
:assumption
(let (?x11230 (ite goto_symex___guard_0_0_177 c__qurt_new__fabs__1__f_59_0_0_1 c__qurt_new__fabs__1__f_59_0_0_3))
(= c__qurt_new__fabs__1__f_59_0_0_4 ?x11230))
:assumption
(flet ($x11236 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_50 c__qurt_new__fabs__1__f_59_0_0_4))
(iff l1687 $x11236))
:assumption
l1687
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_50 c__qurt_new__fabs__1__f_59_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11241 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_50 ?x1828))
(iff l1688 $x11241)))
:assumption
(flet ($x11246 (xor l471 l1688))
(iff l1689 $x11246))
:assumption
(not l1689)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11241 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_50 ?x1828))
(= goto_symex___guard_0_0_178 $x11241)))
:assumption
(flet ($x11257 (= c__qurt_new__sqrt__1__flag_3_0_0_68 bv1[32]))
(iff l1690 $x11257))
:assumption
l1690
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_68 bv1[32])
:assumption
(flet ($x11263 (not goto_symex___guard_0_0_178))
(let (?x11264 (ite $x11263 c__qurt_new__sqrt__1__flag_3_0_0_67 c__qurt_new__sqrt__1__flag_3_0_0_68))
(flet ($x11265 (= c__qurt_new__sqrt__1__flag_3_0_0_69 ?x11264))
(iff l1691 $x11265))))
:assumption
l1691
:assumption
(flet ($x11263 (not goto_symex___guard_0_0_178))
(let (?x11264 (ite $x11263 c__qurt_new__sqrt__1__flag_3_0_0_67 c__qurt_new__sqrt__1__flag_3_0_0_68))
(= c__qurt_new__sqrt__1__flag_3_0_0_69 ?x11264)))
:assumption
(flet ($x11272 (= c__qurt_new__sqrt__1__x_3_0_0_70 c__qurt_new__sqrt__1__x_3_0_0_68))
(iff l1692 $x11272))
:assumption
l1692
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_70 c__qurt_new__sqrt__1__x_3_0_0_68)
:assumption
(flet ($x11278 (= c__qurt_new__sqrt__1__flag_3_0_0_70 c__qurt_new__sqrt__1__flag_3_0_0_67))
(iff l1693 $x11278))
:assumption
l1693
:assumption
(= c__qurt_new__sqrt__1__flag_3_0_0_70 c__qurt_new__sqrt__1__flag_3_0_0_67)
:assumption
(flet ($x11284 (= c__qurt_new__sqrt__1__x_3_0_0_71 c__qurt_new__sqrt__1__x_3_0_0_70))
(iff l1694 $x11284))
:assumption
l1694
:assumption
(= c__qurt_new__sqrt__1__x_3_0_0_71 c__qurt_new__sqrt__1__x_3_0_0_70)
:assumption
(let (?x11290 (ite goto_symex___guard_0_0_176 c__qurt_new__sqrt__1__x_3_0_0_69 c__qurt_new__sqrt__1__x_3_0_0_71))
(flet ($x11291 (= c__qurt_new__sqrt__1__x_3_0_0_72 ?x11290))
(iff l1695 $x11291)))
:assumption
l1695
:assumption
(let (?x11290 (ite goto_symex___guard_0_0_176 c__qurt_new__sqrt__1__x_3_0_0_69 c__qurt_new__sqrt__1__x_3_0_0_71))
(= c__qurt_new__sqrt__1__x_3_0_0_72 ?x11290))
:assumption
(let (?x11296 (ite goto_symex___guard_0_0_176 c__qurt_new__sqrt__1__flag_3_0_0_69 c__qurt_new__sqrt__1__flag_3_0_0_70))
(flet ($x11297 (= c__qurt_new__sqrt__1__flag_3_0_0_71 ?x11296))
(iff l1696 $x11297)))
:assumption
l1696
:assumption
(let (?x11296 (ite goto_symex___guard_0_0_176 c__qurt_new__sqrt__1__flag_3_0_0_69 c__qurt_new__sqrt__1__flag_3_0_0_70))
(= c__qurt_new__sqrt__1__flag_3_0_0_71 ?x11296))
:assumption
(flet ($x11301 (= c__qurt_new__sqrt__1__flag_3_0_0_71 bv0[32]))
(iff l1697 $x11301))
:assumption
(flet ($x11306 (xor l474 l1697))
(iff l1698 $x11306))
:assumption
(not l1698)
:assumption
(flet ($x11301 (= c__qurt_new__sqrt__1__flag_3_0_0_71 bv0[32]))
(= goto_symex___guard_0_0_179 $x11301))
:assumption
(let (?x11317 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11322 (bvmul ?x1629 ?x11317))
(let (?x11323 (extract[95:32] ?x11322))
(let (?x11324 (sign_extend[32] ?x11323))
(let (?x11318 (bvmul ?x11317 ?x11317))
(let (?x11319 (extract[95:32] ?x11318))
(let (?x11320 (bvmul bv18446744073709551615[64] ?x11319))
(let (?x11321 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11320))
(let (?x11325 (concat ?x11321 bv0[32]))
(let (?x11326 (bvsdiv ?x11325 ?x11324))
(let (?x11327 (extract[63:0] ?x11326))
(flet ($x11328 (= c__qurt_new__sqrt__1__dx_3_0_0_53 ?x11327))
(iff l1699 $x11328)))))))))))))))
:assumption
l1699
:assumption
(let (?x11317 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11322 (bvmul ?x1629 ?x11317))
(let (?x11323 (extract[95:32] ?x11322))
(let (?x11324 (sign_extend[32] ?x11323))
(let (?x11318 (bvmul ?x11317 ?x11317))
(let (?x11319 (extract[95:32] ?x11318))
(let (?x11320 (bvmul bv18446744073709551615[64] ?x11319))
(let (?x11321 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11320))
(let (?x11325 (concat ?x11321 bv0[32]))
(let (?x11326 (bvsdiv ?x11325 ?x11324))
(let (?x11327 (extract[63:0] ?x11326))
(= c__qurt_new__sqrt__1__dx_3_0_0_53 ?x11327))))))))))))))
:assumption
(let (?x11348 (bvadd c__qurt_new__sqrt__1__x_3_0_0_72 c__qurt_new__sqrt__1__dx_3_0_0_53))
(flet ($x11349 (= c__qurt_new__sqrt__1__x_3_0_0_73 ?x11348))
(iff l1700 $x11349)))
:assumption
l1700
:assumption
(let (?x11348 (bvadd c__qurt_new__sqrt__1__x_3_0_0_72 c__qurt_new__sqrt__1__dx_3_0_0_53))
(= c__qurt_new__sqrt__1__x_3_0_0_73 ?x11348))
:assumption
(let (?x11354 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_73))
(let (?x11355 (bvmul ?x11354 ?x11354))
(let (?x11356 (extract[95:32] ?x11355))
(let (?x11357 (bvmul bv18446744073709551615[64] ?x11356))
(let (?x11358 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11357))
(flet ($x11359 (= c__qurt_new__sqrt__1__diff_3_0_0_53 ?x11358))
(iff l1701 $x11359)))))))
:assumption
l1701
:assumption
(let (?x11354 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_73))
(let (?x11355 (bvmul ?x11354 ?x11354))
(let (?x11356 (extract[95:32] ?x11355))
(let (?x11357 (bvmul bv18446744073709551615[64] ?x11356))
(let (?x11358 (bvadd c__qurt_new__sqrt__val_3_0_0_1 ?x11357))
(= c__qurt_new__sqrt__1__diff_3_0_0_53 ?x11358))))))
:assumption
(flet ($x11364 (= c__qurt_new__fabs__n_60_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_53))
(iff l1702 $x11364))
:assumption
l1702
:assumption
(= c__qurt_new__fabs__n_60_0_0_1 c__qurt_new__sqrt__1__diff_3_0_0_53)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11369 (bvsge c__qurt_new__fabs__n_60_0_0_1 ?x1542))
(iff l1703 $x11369)))
:assumption
(flet ($x11376 (xor l476 l1703))
(iff l1704 $x11376))
:assumption
(not l1704)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11369 (bvsge c__qurt_new__fabs__n_60_0_0_1 ?x1542))
(= goto_symex___guard_0_0_180 $x11369)))
:assumption
(flet ($x11387 (= c__qurt_new__fabs__1__f_60_0_0_1 c__qurt_new__fabs__n_60_0_0_1))
(iff l1705 $x11387))
:assumption
l1705
:assumption
(= c__qurt_new__fabs__1__f_60_0_0_1 c__qurt_new__fabs__n_60_0_0_1)
:assumption
(let (?x11393 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_60_0_0_1))
(flet ($x11394 (= c__qurt_new__fabs__1__f_60_0_0_3 ?x11393))
(iff l1706 $x11394)))
:assumption
l1706
:assumption
(let (?x11393 (bvmul bv18446744073709551615[64] c__qurt_new__fabs__n_60_0_0_1))
(= c__qurt_new__fabs__1__f_60_0_0_3 ?x11393))
:assumption
(let (?x11399 (ite goto_symex___guard_0_0_180 c__qurt_new__fabs__1__f_60_0_0_1 c__qurt_new__fabs__1__f_60_0_0_3))
(flet ($x11400 (= c__qurt_new__fabs__1__f_60_0_0_4 ?x11399))
(iff l1707 $x11400)))
:assumption
l1707
:assumption
(let (?x11399 (ite goto_symex___guard_0_0_180 c__qurt_new__fabs__1__f_60_0_0_1 c__qurt_new__fabs__1__f_60_0_0_3))
(= c__qurt_new__fabs__1__f_60_0_0_4 ?x11399))
:assumption
(flet ($x11405 (= c__sqrt___tmp__return_value_fabs_2_3_0_0_53 c__qurt_new__fabs__1__f_60_0_0_4))
(iff l1708 $x11405))
:assumption
l1708
:assumption
(= c__sqrt___tmp__return_value_fabs_2_3_0_0_53 c__qurt_new__fabs__1__f_60_0_0_4)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11410 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_53 ?x1828))
(iff l1710 $x11410)))
:assumption
(flet ($x11416 (xor l1709 l1710))
(iff l1711 $x11416))
:assumption
(not l1711)
:assumption
(let (?x1828 (concat bv0[32] bv42949[32]))
(flet ($x11410 (bvsle c__sqrt___tmp__return_value_fabs_2_3_0_0_53 ?x1828))
(= goto_symex___guard_0_0_181 $x11410)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11426 (bvsgt c__qurt_new__qurt__1__d_3_0_0_1 ?x1542))
(iff l1712 $x11426)))
:assumption
(flet ($x11434 (xor l479 l1712))
(iff l1713 $x11434))
:assumption
(not l1713)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11426 (bvsgt c__qurt_new__qurt__1__d_3_0_0_1 ?x1542))
(= goto_symex___guard_0_0_182 $x11426)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11444 (= c__qurt_new__qurt__1__d_3_0_0_1 ?x1542))
(iff l1714 $x11444)))
:assumption
(flet ($x11449 (xor l482 l1714))
(iff l1715 $x11449))
:assumption
(not l1715)
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x11444 (= c__qurt_new__qurt__1__d_3_0_0_1 ?x1542))
(= goto_symex___guard_0_0_183 $x11444)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1737 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1742 (bvmul ?x1629 ?x1737))
(let (?x1743 (extract[95:32] ?x1742))
(flet ($x11458 (and (distinct ?x1743 ?x1542) true))
(iff l1716 $x11458))))))))
:assumption
(flet ($x11464 (not l10))
(flet ($x11465 (or $x11464 l1716))
(iff l1717 $x11465)))
:assumption
(let (?x11469 (bvadd bv1[32] bv1[32]))
(flet ($x11476 (bvslt ?x11469 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11475 (and $x11474 $x11474))
(flet ($x11477 (implies $x11475 $x11476))
(flet ($x11472 (bvslt bv0[32] ?x11469))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11471 (and $x11470 $x11470))
(flet ($x11473 (implies $x11471 $x11472))
(flet ($x11478 (and $x11473 $x11477))
(flet ($x11479 (not $x11478))
(iff l1718 $x11479))))))))))))
:assumption
(flet ($x11491 (not l1718))
(flet ($x11464 (not l10))
(flet ($x11492 (or $x11464 $x11491))
(iff l1719 $x11492))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x1771 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x1875 (bvmul ?x1629 ?x1771))
(let (?x1876 (extract[95:32] ?x1875))
(flet ($x11496 (and (distinct ?x1876 ?x1542) true))
(iff l1720 $x11496))))))))
:assumption
(flet ($x11502 (not l17))
(flet ($x11503 (or $x11502 l1720))
(iff l1721 $x11503)))
:assumption
(let (?x11507 (bvadd bv2[32] bv1[32]))
(flet ($x11512 (bvslt ?x11507 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11485 (bvslt bv2[32] bv0[32]))
(flet ($x11511 (and $x11485 $x11474))
(flet ($x11513 (implies $x11511 $x11512))
(flet ($x11509 (bvslt bv0[32] ?x11507))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11482 (bvslt bv0[32] bv2[32]))
(flet ($x11508 (and $x11482 $x11470))
(flet ($x11510 (implies $x11508 $x11509))
(flet ($x11514 (and $x11510 $x11513))
(flet ($x11515 (not $x11514))
(iff l1722 $x11515))))))))))))))
:assumption
(flet ($x11530 (not l1722))
(flet ($x11464 (not l10))
(flet ($x11531 (or $x11464 $x11530))
(iff l1723 $x11531))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2038 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2043 (bvmul ?x1629 ?x2038))
(let (?x2044 (extract[95:32] ?x2043))
(flet ($x11535 (and (distinct ?x2044 ?x1542) true))
(iff l1724 $x11535))))))))
:assumption
(flet ($x11541 (not l25))
(flet ($x11542 (or $x11541 l1724))
(iff l1725 $x11542)))
:assumption
(let (?x11546 (bvadd bv3[32] bv1[32]))
(flet ($x11551 (bvslt ?x11546 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11524 (bvslt bv3[32] bv0[32]))
(flet ($x11550 (and $x11524 $x11474))
(flet ($x11552 (implies $x11550 $x11551))
(flet ($x11548 (bvslt bv0[32] ?x11546))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11520 (bvslt bv0[32] bv3[32]))
(flet ($x11547 (and $x11520 $x11470))
(flet ($x11549 (implies $x11547 $x11548))
(flet ($x11553 (and $x11549 $x11552))
(flet ($x11554 (not $x11553))
(iff l1726 $x11554))))))))))))))
:assumption
(flet ($x11568 (not l1726))
(flet ($x11464 (not l10))
(flet ($x11569 (or $x11464 $x11568))
(iff l1727 $x11569))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2206 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2211 (bvmul ?x1629 ?x2206))
(let (?x2212 (extract[95:32] ?x2211))
(flet ($x11573 (and (distinct ?x2212 ?x1542) true))
(iff l1728 $x11573))))))))
:assumption
(flet ($x11579 (not l33))
(flet ($x11580 (or $x11579 l1728))
(iff l1729 $x11580)))
:assumption
(let (?x11584 (bvadd bv4[32] bv1[32]))
(flet ($x11589 (bvslt ?x11584 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11562 (bvslt bv4[32] bv0[32]))
(flet ($x11588 (and $x11562 $x11474))
(flet ($x11590 (implies $x11588 $x11589))
(flet ($x11586 (bvslt bv0[32] ?x11584))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11558 (bvslt bv0[32] bv4[32]))
(flet ($x11585 (and $x11558 $x11470))
(flet ($x11587 (implies $x11585 $x11586))
(flet ($x11591 (and $x11587 $x11590))
(flet ($x11592 (not $x11591))
(iff l1730 $x11592))))))))))))))
:assumption
(flet ($x11607 (not l1730))
(flet ($x11464 (not l10))
(flet ($x11608 (or $x11464 $x11607))
(iff l1731 $x11608))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2374 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2379 (bvmul ?x1629 ?x2374))
(let (?x2380 (extract[95:32] ?x2379))
(flet ($x11612 (and (distinct ?x2380 ?x1542) true))
(iff l1732 $x11612))))))))
:assumption
(flet ($x11618 (not l41))
(flet ($x11619 (or $x11618 l1732))
(iff l1733 $x11619)))
:assumption
(let (?x11623 (bvadd bv5[32] bv1[32]))
(flet ($x11628 (bvslt ?x11623 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11601 (bvslt bv5[32] bv0[32]))
(flet ($x11627 (and $x11601 $x11474))
(flet ($x11629 (implies $x11627 $x11628))
(flet ($x11625 (bvslt bv0[32] ?x11623))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11597 (bvslt bv0[32] bv5[32]))
(flet ($x11624 (and $x11597 $x11470))
(flet ($x11626 (implies $x11624 $x11625))
(flet ($x11630 (and $x11626 $x11629))
(flet ($x11631 (not $x11630))
(iff l1734 $x11631))))))))))))))
:assumption
(flet ($x11646 (not l1734))
(flet ($x11464 (not l10))
(flet ($x11647 (or $x11464 $x11646))
(iff l1735 $x11647))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2542 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2547 (bvmul ?x1629 ?x2542))
(let (?x2548 (extract[95:32] ?x2547))
(flet ($x11651 (and (distinct ?x2548 ?x1542) true))
(iff l1736 $x11651))))))))
:assumption
(flet ($x11657 (not l49))
(flet ($x11658 (or $x11657 l1736))
(iff l1737 $x11658)))
:assumption
(let (?x11662 (bvadd bv6[32] bv1[32]))
(flet ($x11667 (bvslt ?x11662 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11640 (bvslt bv6[32] bv0[32]))
(flet ($x11666 (and $x11640 $x11474))
(flet ($x11668 (implies $x11666 $x11667))
(flet ($x11664 (bvslt bv0[32] ?x11662))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11636 (bvslt bv0[32] bv6[32]))
(flet ($x11663 (and $x11636 $x11470))
(flet ($x11665 (implies $x11663 $x11664))
(flet ($x11669 (and $x11665 $x11668))
(flet ($x11670 (not $x11669))
(iff l1738 $x11670))))))))))))))
:assumption
(flet ($x11685 (not l1738))
(flet ($x11464 (not l10))
(flet ($x11686 (or $x11464 $x11685))
(iff l1739 $x11686))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2710 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2715 (bvmul ?x1629 ?x2710))
(let (?x2716 (extract[95:32] ?x2715))
(flet ($x11690 (and (distinct ?x2716 ?x1542) true))
(iff l1740 $x11690))))))))
:assumption
(flet ($x11696 (not l57))
(flet ($x11697 (or $x11696 l1740))
(iff l1741 $x11697)))
:assumption
(let (?x11701 (bvadd bv7[32] bv1[32]))
(flet ($x11706 (bvslt ?x11701 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11679 (bvslt bv7[32] bv0[32]))
(flet ($x11705 (and $x11679 $x11474))
(flet ($x11707 (implies $x11705 $x11706))
(flet ($x11703 (bvslt bv0[32] ?x11701))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11675 (bvslt bv0[32] bv7[32]))
(flet ($x11702 (and $x11675 $x11470))
(flet ($x11704 (implies $x11702 $x11703))
(flet ($x11708 (and $x11704 $x11707))
(flet ($x11709 (not $x11708))
(iff l1742 $x11709))))))))))))))
:assumption
(flet ($x11724 (not l1742))
(flet ($x11464 (not l10))
(flet ($x11725 (or $x11464 $x11724))
(iff l1743 $x11725))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x2878 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x2883 (bvmul ?x1629 ?x2878))
(let (?x2884 (extract[95:32] ?x2883))
(flet ($x11729 (and (distinct ?x2884 ?x1542) true))
(iff l1744 $x11729))))))))
:assumption
(flet ($x11735 (not l65))
(flet ($x11736 (or $x11735 l1744))
(iff l1745 $x11736)))
:assumption
(let (?x11740 (bvadd bv8[32] bv1[32]))
(flet ($x11745 (bvslt ?x11740 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11718 (bvslt bv8[32] bv0[32]))
(flet ($x11744 (and $x11718 $x11474))
(flet ($x11746 (implies $x11744 $x11745))
(flet ($x11742 (bvslt bv0[32] ?x11740))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11714 (bvslt bv0[32] bv8[32]))
(flet ($x11741 (and $x11714 $x11470))
(flet ($x11743 (implies $x11741 $x11742))
(flet ($x11747 (and $x11743 $x11746))
(flet ($x11748 (not $x11747))
(iff l1746 $x11748))))))))))))))
:assumption
(flet ($x11763 (not l1746))
(flet ($x11464 (not l10))
(flet ($x11764 (or $x11464 $x11763))
(iff l1747 $x11764))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3046 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3051 (bvmul ?x1629 ?x3046))
(let (?x3052 (extract[95:32] ?x3051))
(flet ($x11768 (and (distinct ?x3052 ?x1542) true))
(iff l1748 $x11768))))))))
:assumption
(flet ($x11774 (not l73))
(flet ($x11775 (or $x11774 l1748))
(iff l1749 $x11775)))
:assumption
(let (?x11779 (bvadd bv9[32] bv1[32]))
(flet ($x11784 (bvslt ?x11779 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11757 (bvslt bv9[32] bv0[32]))
(flet ($x11783 (and $x11757 $x11474))
(flet ($x11785 (implies $x11783 $x11784))
(flet ($x11781 (bvslt bv0[32] ?x11779))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11753 (bvslt bv0[32] bv9[32]))
(flet ($x11780 (and $x11753 $x11470))
(flet ($x11782 (implies $x11780 $x11781))
(flet ($x11786 (and $x11782 $x11785))
(flet ($x11787 (not $x11786))
(iff l1750 $x11787))))))))))))))
:assumption
(flet ($x11801 (not l1750))
(flet ($x11464 (not l10))
(flet ($x11802 (or $x11464 $x11801))
(iff l1751 $x11802))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3214 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3219 (bvmul ?x1629 ?x3214))
(let (?x3220 (extract[95:32] ?x3219))
(flet ($x11806 (and (distinct ?x3220 ?x1542) true))
(iff l1752 $x11806))))))))
:assumption
(flet ($x11812 (not l81))
(flet ($x11813 (or $x11812 l1752))
(iff l1753 $x11813)))
:assumption
(let (?x11817 (bvadd bv10[32] bv1[32]))
(flet ($x11822 (bvslt ?x11817 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11795 (bvslt bv10[32] bv0[32]))
(flet ($x11821 (and $x11795 $x11474))
(flet ($x11823 (implies $x11821 $x11822))
(flet ($x11819 (bvslt bv0[32] ?x11817))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11791 (bvslt bv0[32] bv10[32]))
(flet ($x11818 (and $x11791 $x11470))
(flet ($x11820 (implies $x11818 $x11819))
(flet ($x11824 (and $x11820 $x11823))
(flet ($x11825 (not $x11824))
(iff l1754 $x11825))))))))))))))
:assumption
(flet ($x11840 (not l1754))
(flet ($x11464 (not l10))
(flet ($x11841 (or $x11464 $x11840))
(iff l1755 $x11841))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3382 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3387 (bvmul ?x1629 ?x3382))
(let (?x3388 (extract[95:32] ?x3387))
(flet ($x11845 (and (distinct ?x3388 ?x1542) true))
(iff l1756 $x11845))))))))
:assumption
(flet ($x11851 (not l89))
(flet ($x11852 (or $x11851 l1756))
(iff l1757 $x11852)))
:assumption
(let (?x11856 (bvadd bv11[32] bv1[32]))
(flet ($x11861 (bvslt ?x11856 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11834 (bvslt bv11[32] bv0[32]))
(flet ($x11860 (and $x11834 $x11474))
(flet ($x11862 (implies $x11860 $x11861))
(flet ($x11858 (bvslt bv0[32] ?x11856))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11830 (bvslt bv0[32] bv11[32]))
(flet ($x11857 (and $x11830 $x11470))
(flet ($x11859 (implies $x11857 $x11858))
(flet ($x11863 (and $x11859 $x11862))
(flet ($x11864 (not $x11863))
(iff l1758 $x11864))))))))))))))
:assumption
(flet ($x11879 (not l1758))
(flet ($x11464 (not l10))
(flet ($x11880 (or $x11464 $x11879))
(iff l1759 $x11880))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3550 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3555 (bvmul ?x1629 ?x3550))
(let (?x3556 (extract[95:32] ?x3555))
(flet ($x11884 (and (distinct ?x3556 ?x1542) true))
(iff l1760 $x11884))))))))
:assumption
(flet ($x11890 (not l97))
(flet ($x11891 (or $x11890 l1760))
(iff l1761 $x11891)))
:assumption
(let (?x11895 (bvadd bv12[32] bv1[32]))
(flet ($x11900 (bvslt ?x11895 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11873 (bvslt bv12[32] bv0[32]))
(flet ($x11899 (and $x11873 $x11474))
(flet ($x11901 (implies $x11899 $x11900))
(flet ($x11897 (bvslt bv0[32] ?x11895))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11869 (bvslt bv0[32] bv12[32]))
(flet ($x11896 (and $x11869 $x11470))
(flet ($x11898 (implies $x11896 $x11897))
(flet ($x11902 (and $x11898 $x11901))
(flet ($x11903 (not $x11902))
(iff l1762 $x11903))))))))))))))
:assumption
(flet ($x11918 (not l1762))
(flet ($x11464 (not l10))
(flet ($x11919 (or $x11464 $x11918))
(iff l1763 $x11919))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3718 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3723 (bvmul ?x1629 ?x3718))
(let (?x3724 (extract[95:32] ?x3723))
(flet ($x11923 (and (distinct ?x3724 ?x1542) true))
(iff l1764 $x11923))))))))
:assumption
(flet ($x11929 (not l105))
(flet ($x11930 (or $x11929 l1764))
(iff l1765 $x11930)))
:assumption
(let (?x11934 (bvadd bv13[32] bv1[32]))
(flet ($x11939 (bvslt ?x11934 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11912 (bvslt bv13[32] bv0[32]))
(flet ($x11938 (and $x11912 $x11474))
(flet ($x11940 (implies $x11938 $x11939))
(flet ($x11936 (bvslt bv0[32] ?x11934))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11908 (bvslt bv0[32] bv13[32]))
(flet ($x11935 (and $x11908 $x11470))
(flet ($x11937 (implies $x11935 $x11936))
(flet ($x11941 (and $x11937 $x11940))
(flet ($x11942 (not $x11941))
(iff l1766 $x11942))))))))))))))
:assumption
(flet ($x11957 (not l1766))
(flet ($x11464 (not l10))
(flet ($x11958 (or $x11464 $x11957))
(iff l1767 $x11958))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x3886 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x3891 (bvmul ?x1629 ?x3886))
(let (?x3892 (extract[95:32] ?x3891))
(flet ($x11962 (and (distinct ?x3892 ?x1542) true))
(iff l1768 $x11962))))))))
:assumption
(flet ($x11968 (not l113))
(flet ($x11969 (or $x11968 l1768))
(iff l1769 $x11969)))
:assumption
(let (?x11973 (bvadd bv14[32] bv1[32]))
(flet ($x11978 (bvslt ?x11973 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11951 (bvslt bv14[32] bv0[32]))
(flet ($x11977 (and $x11951 $x11474))
(flet ($x11979 (implies $x11977 $x11978))
(flet ($x11975 (bvslt bv0[32] ?x11973))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11947 (bvslt bv0[32] bv14[32]))
(flet ($x11974 (and $x11947 $x11470))
(flet ($x11976 (implies $x11974 $x11975))
(flet ($x11980 (and $x11976 $x11979))
(flet ($x11981 (not $x11980))
(iff l1770 $x11981))))))))))))))
:assumption
(flet ($x11996 (not l1770))
(flet ($x11464 (not l10))
(flet ($x11997 (or $x11464 $x11996))
(iff l1771 $x11997))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4054 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4059 (bvmul ?x1629 ?x4054))
(let (?x4060 (extract[95:32] ?x4059))
(flet ($x12001 (and (distinct ?x4060 ?x1542) true))
(iff l1772 $x12001))))))))
:assumption
(flet ($x12007 (not l121))
(flet ($x12008 (or $x12007 l1772))
(iff l1773 $x12008)))
:assumption
(let (?x12012 (bvadd bv15[32] bv1[32]))
(flet ($x12017 (bvslt ?x12012 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x11990 (bvslt bv15[32] bv0[32]))
(flet ($x12016 (and $x11990 $x11474))
(flet ($x12018 (implies $x12016 $x12017))
(flet ($x12014 (bvslt bv0[32] ?x12012))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x11986 (bvslt bv0[32] bv15[32]))
(flet ($x12013 (and $x11986 $x11470))
(flet ($x12015 (implies $x12013 $x12014))
(flet ($x12019 (and $x12015 $x12018))
(flet ($x12020 (not $x12019))
(iff l1774 $x12020))))))))))))))
:assumption
(flet ($x12035 (not l1774))
(flet ($x11464 (not l10))
(flet ($x12036 (or $x11464 $x12035))
(iff l1775 $x12036))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4222 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4227 (bvmul ?x1629 ?x4222))
(let (?x4228 (extract[95:32] ?x4227))
(flet ($x12040 (and (distinct ?x4228 ?x1542) true))
(iff l1776 $x12040))))))))
:assumption
(flet ($x12046 (not l129))
(flet ($x12047 (or $x12046 l1776))
(iff l1777 $x12047)))
:assumption
(let (?x12051 (bvadd bv16[32] bv1[32]))
(flet ($x12056 (bvslt ?x12051 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x12029 (bvslt bv16[32] bv0[32]))
(flet ($x12055 (and $x12029 $x11474))
(flet ($x12057 (implies $x12055 $x12056))
(flet ($x12053 (bvslt bv0[32] ?x12051))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x12025 (bvslt bv0[32] bv16[32]))
(flet ($x12052 (and $x12025 $x11470))
(flet ($x12054 (implies $x12052 $x12053))
(flet ($x12058 (and $x12054 $x12057))
(flet ($x12059 (not $x12058))
(iff l1778 $x12059))))))))))))))
:assumption
(flet ($x12074 (not l1778))
(flet ($x11464 (not l10))
(flet ($x12075 (or $x11464 $x12074))
(iff l1779 $x12075))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4390 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4395 (bvmul ?x1629 ?x4390))
(let (?x4396 (extract[95:32] ?x4395))
(flet ($x12079 (and (distinct ?x4396 ?x1542) true))
(iff l1780 $x12079))))))))
:assumption
(flet ($x12085 (not l137))
(flet ($x12086 (or $x12085 l1780))
(iff l1781 $x12086)))
:assumption
(let (?x12090 (bvadd bv17[32] bv1[32]))
(flet ($x12095 (bvslt ?x12090 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x12068 (bvslt bv17[32] bv0[32]))
(flet ($x12094 (and $x12068 $x11474))
(flet ($x12096 (implies $x12094 $x12095))
(flet ($x12092 (bvslt bv0[32] ?x12090))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x12064 (bvslt bv0[32] bv17[32]))
(flet ($x12091 (and $x12064 $x11470))
(flet ($x12093 (implies $x12091 $x12092))
(flet ($x12097 (and $x12093 $x12096))
(flet ($x12098 (not $x12097))
(iff l1782 $x12098))))))))))))))
:assumption
(flet ($x12113 (not l1782))
(flet ($x11464 (not l10))
(flet ($x12114 (or $x11464 $x12113))
(iff l1783 $x12114))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4558 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4563 (bvmul ?x1629 ?x4558))
(let (?x4564 (extract[95:32] ?x4563))
(flet ($x12118 (and (distinct ?x4564 ?x1542) true))
(iff l1784 $x12118))))))))
:assumption
(flet ($x12124 (not l145))
(flet ($x12125 (or $x12124 l1784))
(iff l1785 $x12125)))
:assumption
(let (?x12129 (bvadd bv18[32] bv1[32]))
(flet ($x12134 (bvslt ?x12129 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x12107 (bvslt bv18[32] bv0[32]))
(flet ($x12133 (and $x12107 $x11474))
(flet ($x12135 (implies $x12133 $x12134))
(flet ($x12131 (bvslt bv0[32] ?x12129))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x12103 (bvslt bv0[32] bv18[32]))
(flet ($x12130 (and $x12103 $x11470))
(flet ($x12132 (implies $x12130 $x12131))
(flet ($x12136 (and $x12132 $x12135))
(flet ($x12137 (not $x12136))
(iff l1786 $x12137))))))))))))))
:assumption
(flet ($x12152 (not l1786))
(flet ($x11464 (not l10))
(flet ($x12153 (or $x11464 $x12152))
(iff l1787 $x12153))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x4727 (sign_extend[32] c__qurt_new__sqrt__1__x_1_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x4732 (bvmul ?x1629 ?x4727))
(let (?x4733 (extract[95:32] ?x4732))
(flet ($x12157 (and (distinct ?x4733 ?x1542) true))
(iff l1788 $x12157))))))))
:assumption
(flet ($x12163 (not l153))
(flet ($x12164 (or $x12163 l1788))
(iff l1789 $x12164)))
:assumption
(let (?x12168 (bvadd bv19[32] bv1[32]))
(flet ($x12173 (bvslt ?x12168 bv0[32]))
(flet ($x11474 (bvslt bv1[32] bv0[32]))
(flet ($x12146 (bvslt bv19[32] bv0[32]))
(flet ($x12172 (and $x12146 $x11474))
(flet ($x12174 (implies $x12172 $x12173))
(flet ($x12170 (bvslt bv0[32] ?x12168))
(flet ($x11470 (bvslt bv0[32] bv1[32]))
(flet ($x12142 (bvslt bv0[32] bv19[32]))
(flet ($x12169 (and $x12142 $x11470))
(flet ($x12171 (implies $x12169 $x12170))
(flet ($x12175 (and $x12171 $x12174))
(flet ($x12176 (not $x12175))
(iff l1790 $x12176))))))))))))))
:assumption
(flet ($x12191 (not l1790))
(flet ($x11464 (not l10))
(flet ($x12192 (or $x11464 $x12191))
(iff l1791 $x12192))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x12196 (and (distinct c__qurt_new__qurt__1__w1_1_0_0_1 ?x1542) true))
(iff l1792 $x12196)))
:assumption
(flet ($x12202 (not l158))
(flet ($x12203 (or $x12202 l1792))
(iff l1793 $x12203)))
:assumption
(flet ($x12207 (not l161))
(flet ($x12208 (or $x12207 l1792))
(iff l1794 $x12208)))
:assumption
(let (?x12213 (bvshl bv1[32] bv31[32]))
(flet ($x12214 (= bv1[32] ?x12213))
(flet ($x12215 (not $x12214))
(flet ($x12216 (not $x12215))
(iff l1795 $x12216)))))
:assumption
(flet ($x12220 (not l1795))
(flet ($x12221 (not l162))
(flet ($x12222 (or $x12221 $x12220))
(iff l1796 $x12222))))
:assumption
(flet ($x12221 (not l162))
(flet ($x12226 (or $x12221 l1792))
(iff l1797 $x12226)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5032 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5037 (bvmul ?x1629 ?x5032))
(let (?x5038 (extract[95:32] ?x5037))
(flet ($x12230 (and (distinct ?x5038 ?x1542) true))
(iff l1798 $x12230))))))))
:assumption
(flet ($x12236 (not l171))
(flet ($x12237 (or $x12236 l1798))
(iff l1799 $x12237)))
:assumption
(flet ($x11491 (not l1718))
(flet ($x12236 (not l171))
(flet ($x12241 (or $x12236 $x11491))
(iff l1800 $x12241))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5069 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5170 (bvmul ?x1629 ?x5069))
(let (?x5171 (extract[95:32] ?x5170))
(flet ($x12245 (and (distinct ?x5171 ?x1542) true))
(iff l1801 $x12245))))))))
:assumption
(flet ($x12251 (not l178))
(flet ($x12252 (or $x12251 l1801))
(iff l1802 $x12252)))
:assumption
(flet ($x11530 (not l1722))
(flet ($x12236 (not l171))
(flet ($x12256 (or $x12236 $x11530))
(iff l1803 $x12256))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5333 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5338 (bvmul ?x1629 ?x5333))
(let (?x5339 (extract[95:32] ?x5338))
(flet ($x12260 (and (distinct ?x5339 ?x1542) true))
(iff l1804 $x12260))))))))
:assumption
(flet ($x12266 (not l186))
(flet ($x12267 (or $x12266 l1804))
(iff l1805 $x12267)))
:assumption
(flet ($x11568 (not l1726))
(flet ($x12236 (not l171))
(flet ($x12271 (or $x12236 $x11568))
(iff l1806 $x12271))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5501 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5506 (bvmul ?x1629 ?x5501))
(let (?x5507 (extract[95:32] ?x5506))
(flet ($x12275 (and (distinct ?x5507 ?x1542) true))
(iff l1807 $x12275))))))))
:assumption
(flet ($x12281 (not l194))
(flet ($x12282 (or $x12281 l1807))
(iff l1808 $x12282)))
:assumption
(flet ($x11607 (not l1730))
(flet ($x12236 (not l171))
(flet ($x12286 (or $x12236 $x11607))
(iff l1809 $x12286))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5669 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5674 (bvmul ?x1629 ?x5669))
(let (?x5675 (extract[95:32] ?x5674))
(flet ($x12290 (and (distinct ?x5675 ?x1542) true))
(iff l1810 $x12290))))))))
:assumption
(flet ($x12296 (not l202))
(flet ($x12297 (or $x12296 l1810))
(iff l1811 $x12297)))
:assumption
(flet ($x11646 (not l1734))
(flet ($x12236 (not l171))
(flet ($x12301 (or $x12236 $x11646))
(iff l1812 $x12301))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x5837 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x5842 (bvmul ?x1629 ?x5837))
(let (?x5843 (extract[95:32] ?x5842))
(flet ($x12305 (and (distinct ?x5843 ?x1542) true))
(iff l1813 $x12305))))))))
:assumption
(flet ($x12311 (not l210))
(flet ($x12312 (or $x12311 l1813))
(iff l1814 $x12312)))
:assumption
(flet ($x11685 (not l1738))
(flet ($x12236 (not l171))
(flet ($x12316 (or $x12236 $x11685))
(iff l1815 $x12316))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6005 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6010 (bvmul ?x1629 ?x6005))
(let (?x6011 (extract[95:32] ?x6010))
(flet ($x12320 (and (distinct ?x6011 ?x1542) true))
(iff l1816 $x12320))))))))
:assumption
(flet ($x12326 (not l218))
(flet ($x12327 (or $x12326 l1816))
(iff l1817 $x12327)))
:assumption
(flet ($x11724 (not l1742))
(flet ($x12236 (not l171))
(flet ($x12331 (or $x12236 $x11724))
(iff l1818 $x12331))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6173 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6178 (bvmul ?x1629 ?x6173))
(let (?x6179 (extract[95:32] ?x6178))
(flet ($x12335 (and (distinct ?x6179 ?x1542) true))
(iff l1819 $x12335))))))))
:assumption
(flet ($x12341 (not l226))
(flet ($x12342 (or $x12341 l1819))
(iff l1820 $x12342)))
:assumption
(flet ($x11763 (not l1746))
(flet ($x12236 (not l171))
(flet ($x12346 (or $x12236 $x11763))
(iff l1821 $x12346))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6341 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6346 (bvmul ?x1629 ?x6341))
(let (?x6347 (extract[95:32] ?x6346))
(flet ($x12350 (and (distinct ?x6347 ?x1542) true))
(iff l1822 $x12350))))))))
:assumption
(flet ($x12356 (not l234))
(flet ($x12357 (or $x12356 l1822))
(iff l1823 $x12357)))
:assumption
(flet ($x11801 (not l1750))
(flet ($x12236 (not l171))
(flet ($x12361 (or $x12236 $x11801))
(iff l1824 $x12361))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6509 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6514 (bvmul ?x1629 ?x6509))
(let (?x6515 (extract[95:32] ?x6514))
(flet ($x12365 (and (distinct ?x6515 ?x1542) true))
(iff l1825 $x12365))))))))
:assumption
(flet ($x12371 (not l242))
(flet ($x12372 (or $x12371 l1825))
(iff l1826 $x12372)))
:assumption
(flet ($x11840 (not l1754))
(flet ($x12236 (not l171))
(flet ($x12376 (or $x12236 $x11840))
(iff l1827 $x12376))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6677 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6682 (bvmul ?x1629 ?x6677))
(let (?x6683 (extract[95:32] ?x6682))
(flet ($x12380 (and (distinct ?x6683 ?x1542) true))
(iff l1828 $x12380))))))))
:assumption
(flet ($x12386 (not l250))
(flet ($x12387 (or $x12386 l1828))
(iff l1829 $x12387)))
:assumption
(flet ($x11879 (not l1758))
(flet ($x12236 (not l171))
(flet ($x12391 (or $x12236 $x11879))
(iff l1830 $x12391))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x6845 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x6850 (bvmul ?x1629 ?x6845))
(let (?x6851 (extract[95:32] ?x6850))
(flet ($x12395 (and (distinct ?x6851 ?x1542) true))
(iff l1831 $x12395))))))))
:assumption
(flet ($x12401 (not l258))
(flet ($x12402 (or $x12401 l1831))
(iff l1832 $x12402)))
:assumption
(flet ($x11918 (not l1762))
(flet ($x12236 (not l171))
(flet ($x12406 (or $x12236 $x11918))
(iff l1833 $x12406))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7013 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7018 (bvmul ?x1629 ?x7013))
(let (?x7019 (extract[95:32] ?x7018))
(flet ($x12410 (and (distinct ?x7019 ?x1542) true))
(iff l1834 $x12410))))))))
:assumption
(flet ($x12416 (not l266))
(flet ($x12417 (or $x12416 l1834))
(iff l1835 $x12417)))
:assumption
(flet ($x11957 (not l1766))
(flet ($x12236 (not l171))
(flet ($x12421 (or $x12236 $x11957))
(iff l1836 $x12421))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7181 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7186 (bvmul ?x1629 ?x7181))
(let (?x7187 (extract[95:32] ?x7186))
(flet ($x12425 (and (distinct ?x7187 ?x1542) true))
(iff l1837 $x12425))))))))
:assumption
(flet ($x12431 (not l274))
(flet ($x12432 (or $x12431 l1837))
(iff l1838 $x12432)))
:assumption
(flet ($x11996 (not l1770))
(flet ($x12236 (not l171))
(flet ($x12436 (or $x12236 $x11996))
(iff l1839 $x12436))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7349 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7354 (bvmul ?x1629 ?x7349))
(let (?x7355 (extract[95:32] ?x7354))
(flet ($x12440 (and (distinct ?x7355 ?x1542) true))
(iff l1840 $x12440))))))))
:assumption
(flet ($x12446 (not l282))
(flet ($x12447 (or $x12446 l1840))
(iff l1841 $x12447)))
:assumption
(flet ($x12035 (not l1774))
(flet ($x12236 (not l171))
(flet ($x12451 (or $x12236 $x12035))
(iff l1842 $x12451))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7517 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7522 (bvmul ?x1629 ?x7517))
(let (?x7523 (extract[95:32] ?x7522))
(flet ($x12455 (and (distinct ?x7523 ?x1542) true))
(iff l1843 $x12455))))))))
:assumption
(flet ($x12461 (not l290))
(flet ($x12462 (or $x12461 l1843))
(iff l1844 $x12462)))
:assumption
(flet ($x12074 (not l1778))
(flet ($x12236 (not l171))
(flet ($x12466 (or $x12236 $x12074))
(iff l1845 $x12466))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7685 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7690 (bvmul ?x1629 ?x7685))
(let (?x7691 (extract[95:32] ?x7690))
(flet ($x12470 (and (distinct ?x7691 ?x1542) true))
(iff l1846 $x12470))))))))
:assumption
(flet ($x12476 (not l298))
(flet ($x12477 (or $x12476 l1846))
(iff l1847 $x12477)))
:assumption
(flet ($x12113 (not l1782))
(flet ($x12236 (not l171))
(flet ($x12481 (or $x12236 $x12113))
(iff l1848 $x12481))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x7853 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x7858 (bvmul ?x1629 ?x7853))
(let (?x7859 (extract[95:32] ?x7858))
(flet ($x12485 (and (distinct ?x7859 ?x1542) true))
(iff l1849 $x12485))))))))
:assumption
(flet ($x12491 (not l306))
(flet ($x12492 (or $x12491 l1849))
(iff l1850 $x12492)))
:assumption
(flet ($x12152 (not l1786))
(flet ($x12236 (not l171))
(flet ($x12496 (or $x12236 $x12152))
(iff l1851 $x12496))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8022 (sign_extend[32] c__qurt_new__sqrt__1__x_2_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8027 (bvmul ?x1629 ?x8022))
(let (?x8028 (extract[95:32] ?x8027))
(flet ($x12500 (and (distinct ?x8028 ?x1542) true))
(iff l1852 $x12500))))))))
:assumption
(flet ($x12506 (not l314))
(flet ($x12507 (or $x12506 l1852))
(iff l1853 $x12507)))
:assumption
(flet ($x12191 (not l1790))
(flet ($x12236 (not l171))
(flet ($x12511 (or $x12236 $x12191))
(iff l1854 $x12511))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x12515 (and (distinct c__qurt_new__qurt__1__w1_2_0_0_1 ?x1542) true))
(iff l1855 $x12515)))
:assumption
(flet ($x12521 (not l319))
(flet ($x12522 (or $x12521 l1855))
(iff l1856 $x12522)))
:assumption
(flet ($x12526 (not l322))
(flet ($x12527 (or $x12526 l1855))
(iff l1857 $x12527)))
:assumption
(flet ($x12220 (not l1795))
(flet ($x12531 (not l323))
(flet ($x12532 (or $x12531 $x12220))
(iff l1858 $x12532))))
:assumption
(flet ($x12531 (not l323))
(flet ($x12536 (or $x12531 l1855))
(iff l1859 $x12536)))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8327 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_3))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8332 (bvmul ?x1629 ?x8327))
(let (?x8333 (extract[95:32] ?x8332))
(flet ($x12540 (and (distinct ?x8333 ?x1542) true))
(iff l1860 $x12540))))))))
:assumption
(flet ($x12546 (not l332))
(flet ($x12547 (or $x12546 l1860))
(iff l1861 $x12547)))
:assumption
(flet ($x11491 (not l1718))
(flet ($x12546 (not l332))
(flet ($x12551 (or $x12546 $x11491))
(iff l1862 $x12551))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8364 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_4))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8465 (bvmul ?x1629 ?x8364))
(let (?x8466 (extract[95:32] ?x8465))
(flet ($x12555 (and (distinct ?x8466 ?x1542) true))
(iff l1863 $x12555))))))))
:assumption
(flet ($x12561 (not l339))
(flet ($x12562 (or $x12561 l1863))
(iff l1864 $x12562)))
:assumption
(flet ($x11530 (not l1722))
(flet ($x12546 (not l332))
(flet ($x12566 (or $x12546 $x11530))
(iff l1865 $x12566))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8628 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_8))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8633 (bvmul ?x1629 ?x8628))
(let (?x8634 (extract[95:32] ?x8633))
(flet ($x12570 (and (distinct ?x8634 ?x1542) true))
(iff l1866 $x12570))))))))
:assumption
(flet ($x12576 (not l347))
(flet ($x12577 (or $x12576 l1866))
(iff l1867 $x12577)))
:assumption
(flet ($x11568 (not l1726))
(flet ($x12546 (not l332))
(flet ($x12581 (or $x12546 $x11568))
(iff l1868 $x12581))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8796 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_12))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8801 (bvmul ?x1629 ?x8796))
(let (?x8802 (extract[95:32] ?x8801))
(flet ($x12585 (and (distinct ?x8802 ?x1542) true))
(iff l1869 $x12585))))))))
:assumption
(flet ($x12591 (not l355))
(flet ($x12592 (or $x12591 l1869))
(iff l1870 $x12592)))
:assumption
(flet ($x11607 (not l1730))
(flet ($x12546 (not l332))
(flet ($x12596 (or $x12546 $x11607))
(iff l1871 $x12596))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x8964 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_16))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x8969 (bvmul ?x1629 ?x8964))
(let (?x8970 (extract[95:32] ?x8969))
(flet ($x12600 (and (distinct ?x8970 ?x1542) true))
(iff l1872 $x12600))))))))
:assumption
(flet ($x12606 (not l363))
(flet ($x12607 (or $x12606 l1872))
(iff l1873 $x12607)))
:assumption
(flet ($x11646 (not l1734))
(flet ($x12546 (not l332))
(flet ($x12611 (or $x12546 $x11646))
(iff l1874 $x12611))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9132 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_20))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9137 (bvmul ?x1629 ?x9132))
(let (?x9138 (extract[95:32] ?x9137))
(flet ($x12615 (and (distinct ?x9138 ?x1542) true))
(iff l1875 $x12615))))))))
:assumption
(flet ($x12621 (not l371))
(flet ($x12622 (or $x12621 l1875))
(iff l1876 $x12622)))
:assumption
(flet ($x11685 (not l1738))
(flet ($x12546 (not l332))
(flet ($x12626 (or $x12546 $x11685))
(iff l1877 $x12626))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9300 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_24))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9305 (bvmul ?x1629 ?x9300))
(let (?x9306 (extract[95:32] ?x9305))
(flet ($x12630 (and (distinct ?x9306 ?x1542) true))
(iff l1878 $x12630))))))))
:assumption
(flet ($x12636 (not l379))
(flet ($x12637 (or $x12636 l1878))
(iff l1879 $x12637)))
:assumption
(flet ($x11724 (not l1742))
(flet ($x12546 (not l332))
(flet ($x12641 (or $x12546 $x11724))
(iff l1880 $x12641))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9468 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_28))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9473 (bvmul ?x1629 ?x9468))
(let (?x9474 (extract[95:32] ?x9473))
(flet ($x12645 (and (distinct ?x9474 ?x1542) true))
(iff l1881 $x12645))))))))
:assumption
(flet ($x12651 (not l387))
(flet ($x12652 (or $x12651 l1881))
(iff l1882 $x12652)))
:assumption
(flet ($x11763 (not l1746))
(flet ($x12546 (not l332))
(flet ($x12656 (or $x12546 $x11763))
(iff l1883 $x12656))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9636 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_32))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9641 (bvmul ?x1629 ?x9636))
(let (?x9642 (extract[95:32] ?x9641))
(flet ($x12660 (and (distinct ?x9642 ?x1542) true))
(iff l1884 $x12660))))))))
:assumption
(flet ($x12666 (not l395))
(flet ($x12667 (or $x12666 l1884))
(iff l1885 $x12667)))
:assumption
(flet ($x11801 (not l1750))
(flet ($x12546 (not l332))
(flet ($x12671 (or $x12546 $x11801))
(iff l1886 $x12671))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9804 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_36))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9809 (bvmul ?x1629 ?x9804))
(let (?x9810 (extract[95:32] ?x9809))
(flet ($x12675 (and (distinct ?x9810 ?x1542) true))
(iff l1887 $x12675))))))))
:assumption
(flet ($x12681 (not l403))
(flet ($x12682 (or $x12681 l1887))
(iff l1888 $x12682)))
:assumption
(flet ($x11840 (not l1754))
(flet ($x12546 (not l332))
(flet ($x12686 (or $x12546 $x11840))
(iff l1889 $x12686))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x9972 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_40))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x9977 (bvmul ?x1629 ?x9972))
(let (?x9978 (extract[95:32] ?x9977))
(flet ($x12690 (and (distinct ?x9978 ?x1542) true))
(iff l1890 $x12690))))))))
:assumption
(flet ($x12696 (not l411))
(flet ($x12697 (or $x12696 l1890))
(iff l1891 $x12697)))
:assumption
(flet ($x11879 (not l1758))
(flet ($x12546 (not l332))
(flet ($x12701 (or $x12546 $x11879))
(iff l1892 $x12701))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10140 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_44))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10145 (bvmul ?x1629 ?x10140))
(let (?x10146 (extract[95:32] ?x10145))
(flet ($x12705 (and (distinct ?x10146 ?x1542) true))
(iff l1893 $x12705))))))))
:assumption
(flet ($x12711 (not l419))
(flet ($x12712 (or $x12711 l1893))
(iff l1894 $x12712)))
:assumption
(flet ($x11918 (not l1762))
(flet ($x12546 (not l332))
(flet ($x12716 (or $x12546 $x11918))
(iff l1895 $x12716))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10308 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_48))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10313 (bvmul ?x1629 ?x10308))
(let (?x10314 (extract[95:32] ?x10313))
(flet ($x12720 (and (distinct ?x10314 ?x1542) true))
(iff l1896 $x12720))))))))
:assumption
(flet ($x12726 (not l427))
(flet ($x12727 (or $x12726 l1896))
(iff l1897 $x12727)))
:assumption
(flet ($x11957 (not l1766))
(flet ($x12546 (not l332))
(flet ($x12731 (or $x12546 $x11957))
(iff l1898 $x12731))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10476 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_52))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10481 (bvmul ?x1629 ?x10476))
(let (?x10482 (extract[95:32] ?x10481))
(flet ($x12735 (and (distinct ?x10482 ?x1542) true))
(iff l1899 $x12735))))))))
:assumption
(flet ($x12741 (not l435))
(flet ($x12742 (or $x12741 l1899))
(iff l1900 $x12742)))
:assumption
(flet ($x11996 (not l1770))
(flet ($x12546 (not l332))
(flet ($x12746 (or $x12546 $x11996))
(iff l1901 $x12746))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10644 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_56))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10649 (bvmul ?x1629 ?x10644))
(let (?x10650 (extract[95:32] ?x10649))
(flet ($x12750 (and (distinct ?x10650 ?x1542) true))
(iff l1902 $x12750))))))))
:assumption
(flet ($x12756 (not l443))
(flet ($x12757 (or $x12756 l1902))
(iff l1903 $x12757)))
:assumption
(flet ($x12035 (not l1774))
(flet ($x12546 (not l332))
(flet ($x12761 (or $x12546 $x12035))
(iff l1904 $x12761))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10812 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_60))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10817 (bvmul ?x1629 ?x10812))
(let (?x10818 (extract[95:32] ?x10817))
(flet ($x12765 (and (distinct ?x10818 ?x1542) true))
(iff l1905 $x12765))))))))
:assumption
(flet ($x12771 (not l451))
(flet ($x12772 (or $x12771 l1905))
(iff l1906 $x12772)))
:assumption
(flet ($x12074 (not l1778))
(flet ($x12546 (not l332))
(flet ($x12776 (or $x12546 $x12074))
(iff l1907 $x12776))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x10980 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_64))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x10985 (bvmul ?x1629 ?x10980))
(let (?x10986 (extract[95:32] ?x10985))
(flet ($x12780 (and (distinct ?x10986 ?x1542) true))
(iff l1908 $x12780))))))))
:assumption
(flet ($x12786 (not l459))
(flet ($x12787 (or $x12786 l1908))
(iff l1909 $x12787)))
:assumption
(flet ($x12113 (not l1782))
(flet ($x12546 (not l332))
(flet ($x12791 (or $x12546 $x12113))
(iff l1910 $x12791))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x11148 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_68))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11153 (bvmul ?x1629 ?x11148))
(let (?x11154 (extract[95:32] ?x11153))
(flet ($x12795 (and (distinct ?x11154 ?x1542) true))
(iff l1911 $x12795))))))))
:assumption
(flet ($x12801 (not l467))
(flet ($x12802 (or $x12801 l1911))
(iff l1912 $x12802)))
:assumption
(flet ($x12152 (not l1786))
(flet ($x12546 (not l332))
(flet ($x12806 (or $x12546 $x12152))
(iff l1913 $x12806))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(let (?x11317 (sign_extend[32] c__qurt_new__sqrt__1__x_3_0_0_72))
(let (?x1628 (concat bv2[32] bv0[32]))
(let (?x1629 (sign_extend[32] ?x1628))
(let (?x11322 (bvmul ?x1629 ?x11317))
(let (?x11323 (extract[95:32] ?x11322))
(flet ($x12810 (and (distinct ?x11323 ?x1542) true))
(iff l1914 $x12810))))))))
:assumption
(flet ($x12816 (not l475))
(flet ($x12817 (or $x12816 l1914))
(iff l1915 $x12817)))
:assumption
(flet ($x12191 (not l1790))
(flet ($x12546 (not l332))
(flet ($x12821 (or $x12546 $x12191))
(iff l1916 $x12821))))
:assumption
(let (?x1542 (concat bv0[32] bv0[32]))
(flet ($x12825 (and (distinct c__qurt_new__qurt__1__w1_3_0_0_1 ?x1542) true))
(iff l1917 $x12825)))
:assumption
(flet ($x12831 (not l480))
(flet ($x12832 (or $x12831 l1917))
(iff l1918 $x12832)))
:assumption
(flet ($x12836 (not l483))
(flet ($x12837 (or $x12836 l1917))
(iff l1919 $x12837)))
:assumption
(flet ($x12220 (not l1795))
(flet ($x12841 (not l484))
(flet ($x12842 (or $x12841 $x12220))
(iff l1920 $x12842))))
:assumption
(flet ($x12841 (not l484))
(flet ($x12846 (or $x12841 l1917))
(iff l1921 $x12846)))
:assumption
(flet ($x12975 (not l1921))
(flet ($x12974 (not l1920))
(flet ($x12973 (not l1919))
(flet ($x12972 (not l1918))
(flet ($x12971 (not l1916))
(flet ($x12970 (not l1915))
(flet ($x12969 (not l1913))
(flet ($x12968 (not l1912))
(flet ($x12967 (not l1910))
(flet ($x12966 (not l1909))
(flet ($x12965 (not l1907))
(flet ($x12964 (not l1906))
(flet ($x12963 (not l1904))
(flet ($x12962 (not l1903))
(flet ($x12961 (not l1901))
(flet ($x12960 (not l1900))
(flet ($x12959 (not l1898))
(flet ($x12958 (not l1897))
(flet ($x12957 (not l1895))
(flet ($x12956 (not l1894))
(flet ($x12955 (not l1892))
(flet ($x12954 (not l1891))
(flet ($x12953 (not l1889))
(flet ($x12952 (not l1888))
(flet ($x12951 (not l1886))
(flet ($x12950 (not l1885))
(flet ($x12949 (not l1883))
(flet ($x12948 (not l1882))
(flet ($x12947 (not l1880))
(flet ($x12946 (not l1879))
(flet ($x12945 (not l1877))
(flet ($x12944 (not l1876))
(flet ($x12943 (not l1874))
(flet ($x12942 (not l1873))
(flet ($x12941 (not l1871))
(flet ($x12940 (not l1870))
(flet ($x12939 (not l1868))
(flet ($x12938 (not l1867))
(flet ($x12937 (not l1865))
(flet ($x12936 (not l1864))
(flet ($x12935 (not l1862))
(flet ($x12934 (not l1861))
(flet ($x12933 (not l1859))
(flet ($x12932 (not l1858))
(flet ($x12931 (not l1857))
(flet ($x12930 (not l1856))
(flet ($x12929 (not l1854))
(flet ($x12928 (not l1853))
(flet ($x12927 (not l1851))
(flet ($x12926 (not l1850))
(flet ($x12925 (not l1848))
(flet ($x12924 (not l1847))
(flet ($x12923 (not l1845))
(flet ($x12922 (not l1844))
(flet ($x12921 (not l1842))
(flet ($x12920 (not l1841))
(flet ($x12919 (not l1839))
(flet ($x12918 (not l1838))
(flet ($x12917 (not l1836))
(flet ($x12916 (not l1835))
(flet ($x12915 (not l1833))
(flet ($x12914 (not l1832))
(flet ($x12913 (not l1830))
(flet ($x12912 (not l1829))
(flet ($x12911 (not l1827))
(flet ($x12910 (not l1826))
(flet ($x12909 (not l1824))
(flet ($x12908 (not l1823))
(flet ($x12907 (not l1821))
(flet ($x12906 (not l1820))
(flet ($x12905 (not l1818))
(flet ($x12904 (not l1817))
(flet ($x12903 (not l1815))
(flet ($x12902 (not l1814))
(flet ($x12901 (not l1812))
(flet ($x12900 (not l1811))
(flet ($x12899 (not l1809))
(flet ($x12898 (not l1808))
(flet ($x12897 (not l1806))
(flet ($x12896 (not l1805))
(flet ($x12895 (not l1803))
(flet ($x12894 (not l1802))
(flet ($x12893 (not l1800))
(flet ($x12892 (not l1799))
(flet ($x12891 (not l1797))
(flet ($x12890 (not l1796))
(flet ($x12889 (not l1794))
(flet ($x12888 (not l1793))
(flet ($x12887 (not l1791))
(flet ($x12886 (not l1789))
(flet ($x12885 (not l1787))
(flet ($x12884 (not l1785))
(flet ($x12883 (not l1783))
(flet ($x12882 (not l1781))
(flet ($x12881 (not l1779))
(flet ($x12880 (not l1777))
(flet ($x12879 (not l1775))
(flet ($x12878 (not l1773))
(flet ($x12877 (not l1771))
(flet ($x12876 (not l1769))
(flet ($x12875 (not l1767))
(flet ($x12874 (not l1765))
(flet ($x12873 (not l1763))
(flet ($x12872 (not l1761))
(flet ($x12871 (not l1759))
(flet ($x12870 (not l1757))
(flet ($x12869 (not l1755))
(flet ($x12868 (not l1753))
(flet ($x12867 (not l1751))
(flet ($x12866 (not l1749))
(flet ($x12865 (not l1747))
(flet ($x12864 (not l1745))
(flet ($x12863 (not l1743))
(flet ($x12862 (not l1741))
(flet ($x12861 (not l1739))
(flet ($x12860 (not l1737))
(flet ($x12859 (not l1735))
(flet ($x12858 (not l1733))
(flet ($x12857 (not l1731))
(flet ($x12856 (not l1729))
(flet ($x12855 (not l1727))
(flet ($x12854 (not l1725))
(flet ($x12853 (not l1723))
(flet ($x12852 (not l1721))
(flet ($x12851 (not l1719))
(flet ($x12850 (not l1717))
(or $x12850 $x12851 $x12852 $x12853 $x12854 $x12855 $x12856 $x12857 $x12858 $x12859 $x12860 $x12861 $x12862 $x12863 $x12864 $x12865 $x12866 $x12867 $x12868 $x12869 $x12870 $x12871 $x12872 $x12873 $x12874 $x12875 $x12876 $x12877 $x12878 $x12879 $x12880 $x12881 $x12882 $x12883 $x12884 $x12885 $x12886 $x12887 $x12888 $x12889 $x12890 $x12891 $x12892 $x12893 $x12894 $x12895 $x12896 $x12897 $x12898 $x12899 $x12900 $x12901 $x12902 $x12903 $x12904 $x12905 $x12906 $x12907 $x12908 $x12909 $x12910 $x12911 $x12912 $x12913 $x12914 $x12915 $x12916 $x12917 $x12918 $x12919 $x12920 $x12921 $x12922 $x12923 $x12924 $x12925 $x12926 $x12927 $x12928 $x12929 $x12930 $x12931 $x12932 $x12933 $x12934 $x12935 $x12936 $x12937 $x12938 $x12939 $x12940 $x12941 $x12942 $x12943 $x12944 $x12945 $x12946 $x12947 $x12948 $x12949 $x12950 $x12951 $x12952 $x12953 $x12954 $x12955 $x12956 $x12957 $x12958 $x12959 $x12960 $x12961 $x12962 $x12963 $x12964 $x12965 $x12966 $x12967 $x12968 $x12969 $x12970 $x12971 $x12972 $x12973 $x12974 $x12975)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
:formula
true
)

