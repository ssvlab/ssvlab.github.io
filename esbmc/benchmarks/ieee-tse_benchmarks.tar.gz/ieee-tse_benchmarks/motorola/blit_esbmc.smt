(benchmark ESBMC
:status unknown
:logic QF_AUFBV
:extrapreds ((l1 ))
:extrapreds ((l2 ))
:extrapreds ((execution_statet___guard_exec_0_0_0_0_1 ))
:extrapreds ((l3 ))
:extrapreds ((l4 ))
:extrapreds ((l5 ))
:extrapreds ((l6 ))
:extrapreds ((l7 ))
:extrapreds ((l8 ))
:extrapreds ((l9 ))
:extrapreds ((l10 ))
:extrapreds ((l11 ))
:extrapreds ((l12 ))
:extrapreds ((l13 ))
:extrapreds ((l14 ))
:assumption
(flet ($x22 (and l1 false))
(iff l2 $x22))
:assumption
l1
:assumption
(= execution_statet___guard_exec_0_0_0_0_1 true)
:assumption
(flet ($x31 (bvsmul_noovfl bv1000[32] bv32[32]))
(flet ($x32 (bvsmul_noudfl bv1000[32] bv32[32]))
(flet ($x33 (and $x32 $x31))
(flet ($x34 (not $x33))
(iff l3 $x34)))))
:assumption
(flet ($x41 (not l3))
(flet ($x40 (not l1))
(flet ($x42 (or $x40 $x41))
(iff l4 $x42))))
:assumption
(flet ($x50 (bvuge bv12[32] bv0[32]))
(flet ($x49 (bvult bv12[32] bv2147483648[32]))
(flet ($x51 (and $x49 $x50))
(flet ($x52 (not $x51))
(iff l5 $x52)))))
:assumption
(flet ($x56 (not l5))
(flet ($x40 (not l1))
(flet ($x57 (or $x40 $x56))
(iff l6 $x57))))
:assumption
(let (?x62 (bvmul bv4294967295[32] bv12[32]))
(let (?x63 (bvadd bv32[32] ?x62))
(flet ($x67 (bvslt ?x63 bv0[32]))
(flet ($x65 (bvslt ?x62 bv0[32]))
(flet ($x64 (bvslt bv32[32] bv0[32]))
(flet ($x66 (and $x64 $x65))
(flet ($x68 (implies $x66 $x67))
(flet ($x69 (bvslt bv0[32] bv12[32]))
(flet ($x70 (implies (and $x69 $x66) $x67))
(flet ($x77 (bvslt bv0[32] ?x63))
(flet ($x75 (bvslt bv0[32] ?x62))
(flet ($x74 (bvslt bv0[32] bv32[32]))
(flet ($x76 (and $x74 $x75))
(flet ($x78 (implies $x76 $x77))
(let (?x73 (bvshl bv1[32] bv31[32]))
(flet ($x79 (= bv12[32] ?x73))
(flet ($x80 (if_then_else $x79 $x64 $x78))
(flet ($x81 (and $x80 $x70))
(flet ($x82 (not $x81))
(iff l7 $x82))))))))))))))))))))
:assumption
(flet ($x102 (not l7))
(flet ($x40 (not l1))
(flet ($x103 (or $x40 $x102))
(iff l8 $x103))))
:assumption
(iff l9 true)
:assumption
(flet ($x109 (not l9))
(flet ($x40 (not l1))
(flet ($x110 (or $x40 $x109))
(iff l10 $x110))))
:assumption
(iff l11 true)
:assumption
(flet ($x116 (not l11))
(flet ($x40 (not l1))
(flet ($x117 (or $x40 $x116))
(iff l12 $x117))))
:assumption
(iff l13 true)
:assumption
(flet ($x123 (not l13))
(flet ($x40 (not l1))
(flet ($x124 (or $x40 $x123))
(iff l14 $x124))))
:assumption
(flet ($x133 (not l14))
(flet ($x132 (not l12))
(flet ($x131 (not l10))
(flet ($x130 (not l8))
(flet ($x129 (not l6))
(flet ($x128 (not l4))
(or $x128 $x129 $x130 $x131 $x132 $x133 l1)))))))
:formula
true
)

