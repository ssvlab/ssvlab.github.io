;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; File:        LCD.a51
; Abstract:    Functions to access the LCD in Assembly
; Platform:    AT89S8252
; Project      Pulse Oximeter
; Author(s):   Lucas Cordeiro
; Copyright (C)2007 DCC, Federal University of Amazonas
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

.globl _lcd_init

_lcd_init:

;TIMER          EQU 45535                       ;50.000us

                lcall inic_display
                mov a,#0x01
                lcall wrcar
                mov a,#0x80
                lcall wrcar
		mov R1,#0x33


inic_display:
               
                lcall t5ms
                MOV A,#0x38              ;00111000b   | 0001 1100
                LCALL wrcar             ;                 1  c
                MOV A,#0x06              ; 00000110 | 0110 0000
                LCALL wrcar             ;              6   0
                MOV A,#0x0E              ; 00001110  | 0111 0000
                LCALL wrcar             ;                7   0
                MOV A,#0x01              ; 00000001  | 1000 0000 (Limpa display
                LCALL wrcar             ;               8  0
                MOV A,#0x0C              ;desliga cursor
                LCALL wrcar                
                LCALL t5ms
                RET

wrcar:         
        	push  DPH
        	push  DPL
        
        	mov DPTR,#0x8000
        	movx  @DPTR,A
        	lcall t5ms
        
        	pop   DPL
        	pop   DPH
        	ret

t5ms:
                MOV TL0,#0xdf
                MOV TH0,#0xb1
                SETB TR0
;                JNB TF0,$
                CLR TR0 
                CLR TF0
                RET                

			; SOURCE LINE # 3
; 
; }
			; SOURCE LINE # 5
	RET  	
; END OF lcd_init
