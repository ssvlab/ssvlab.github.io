;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; File:        LCD.a51
; Abstract:    Functions to access the LCD in Assembly
; Platform:    AT89S8252
; Project      Pulse Oximeter
; Author(s):   Lucas Cordeiro
; Copyright (C)2007 DCC, Federal University of Amazonas
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

.globl _write2lcd_PARM_1 
.globl _write2lcd

_write2lcd_PARM_1: 
        	.ds 1  
        	.area CSEG 

_write2lcd:	
                mov a,dpl
                lcall wrcar1
        	RET

wrcar1: 
        	push  DPH
        	push  DPL
        
        	mov DPTR,#0x8001
        	movx  @DPTR,A
        	lcall t5ms
        
        	pop   DPL
        	pop   DPH
        	ret            
                 
t5ms:
        	MOV TL0,#0xdf
        	MOV TH0,#0xb1
        	SETB TR0
;        	JNB TF0,$
        	CLR TR0 
        	CLR TF0
        	RET                

; END OF _write2lcd
