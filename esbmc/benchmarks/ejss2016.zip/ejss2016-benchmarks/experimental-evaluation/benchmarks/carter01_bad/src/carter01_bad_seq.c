#include <stdio.h>

int nondet_int();
int diag = nondet_int();
int cs[] = { 21, 31, 41, 11};

int A = 0, B = 0, m = 0, l = 0;

void f0() {
    m = 1;
    int v = (diag == 17 ? nondet_int() : B + 1);
    B = v;
    if (B == 1) l = 1;
    m = 0;
    //perform class B operation
    // m = 1;
    // B--;
    // if (B == 0) l = 0;
    // m = 0;
}

void f1() {
}

void f2() {
}

void f3() {
    m = 1;
    A++;
    if (A == 1) {
        __ESBMC_assume(l == 0);
        l = 1;
    }
    m = 0;
    //perform class A operation
    m = 1;
    A--;
    if (A == 0) l = 0;
    m = 0;
}

int main(void) {
    int i;
    for (i = 0; i != 4; i++) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f3();
                } break;
            } break;
            case 2: {
                case 21: {
                    f0();
                } break;
            } break;
            case 3: {
                case 31: {
                    f1();
                } break;
            } break;
            case 4: {
                case 41: {
                    f2();
                } break;
            } break;
        }
    }
    // __ESBMC_assume(diag != 17);
    assert(0);
    return 0;
}
