#include <pthread.h>
#define N 2

#define NR_CONTEXT_SWITCHES 4

int nondet_int();
int diag = nondet_int();
_Bool nondet_bool();
int order[NR_CONTEXT_SWITCHES] = {11, 21, 31, 22};

int num;
int m;
int empty, full;

int main()
{
	int order_index;

	for (order_index = 0; order_index < NR_CONTEXT_SWITCHES; order_index++)
	{
		switch (order[order_index])
		{
			case 1:
				case 11:
				{
					num = (diag == 30? nondet_int(): 2);
					m = (diag == 31? nondet_bool(): 0);
					empty = (diag == 32? nondet_bool(): 0);
					full = (diag == 33? nondet_bool(): 0);
				}
				break;
			case 2:
				case 21:
				{
					void *arg = NULL;
					int i = (diag == 7? nondet_int(): 0);
					while (i < N)
					{
						m = (diag == 9? nondet_bool(): 1);
						while (num > 0)
						{ 
							empty = (diag == 11? nondet_bool(): 1);
							break;
						}
						if (order[order_index] == 21) break;
						num++; //produce
						m = (diag == 13? nondet_bool(): 0);
						full = (diag == 14? nondet_bool(): 0);
						i++;
					}
				}
				case 22:
				{
					void *arg = NULL;
					int i = (diag == 7? nondet_int(): 0);
					while (i < N)
					{
						m = (diag == 9? nondet_bool(): 1);
						while (num > 0)
						{ 
							empty = (diag == 11? nondet_bool(): 1);
							break;
						}
						if (order[order_index] == 22) break;
						num = (diag == 12? nondet_int(): num + 1); //consume
						m = (diag == 13? nondet_bool(): 0);
						full = (diag == 14? nondet_bool(): 0);
						i++;
					}
				}
				break;
			case 3:
				case 31:
				{
					void *arg = NULL;
					int j = (diag == 18? nondet_int(): 0);
					while (j < N)
					{
						m = (diag == 20? nondet_bool(): 1);
						while (num == 0)
						{
							full = (diag == 22? nondet_bool(): 1);
							break;
						}
						num = (diag == 23? nondet_int(): num - 1); //consume
						m = (diag == 24? nondet_bool(): 0);
						empty = (diag == 25? nondet_bool(): 0);
						j++;
					}
					if (order[order_index] == 31) break;
				}
				break;
			default:
				break;
		}
	}
	__ESBMC_assume(diag!=18);
	__ESBMC_assume(diag!=19);
	assert(0);
	return 1;
}
