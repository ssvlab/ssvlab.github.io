#include <assert.h>
#include <stdlib.h>
#include <string.h>

int nondet_int(void);

int cs[] = { 11, 21, 12, 22, 13, 23, 14, 24, 15, 25, 31 };
int diag = nondet_int();

int i = 1, j = 1;

#define NUM 5

void f1() {
    i += j;
}

void f2() {
    j += i;
}

void f3() {
    i += j;
}

void f4() {
    j += i;
}

void f5() {
    i += j;
}

void f6() {
    j += i;
}

void f7() {
    i += j;
}

void f8() {
    j += i;
}

void f9() {
    i += j;
}

void f10() {
    j += i;
}

void f11() {
    int ti = (diag == 39 ? nondet_int() : i);
    int tj = (diag == 40 ? nondet_int() : j);
    __ESBMC_assume(ti >= 144 || tj >= 144);
}

int main()
{
    int k;
    for (k = 0; k != 11; ++k) {
        switch (cs[k]) {
            case 1: {
                case 11: {
                    f1();
                } break;
                case 12: {
                    f3();
                } break;
                case 13: {
                    f5();
                } break;
                case 14: {
                    f7();
                } break;
                case 15: {
                    f9();
                } break;
            }
            case 2: {
                case 21: {
                    f2();
                } break;
                case 22: {
                    f4();
                } break;
                case 23: {
                    f6();
                } break;
                case 24: {
                    f8();
                } break;
                case 25: {
                    f10();
                } break;
            }
            case 3: {
                case 31: {
                    f11();
                    break;
                }
            }
        }
    }
    // __ESBMC_assume(diag != 40);
    // __ESBMC_assume(diag != 39);
    assert(0);
    return 0;
}
