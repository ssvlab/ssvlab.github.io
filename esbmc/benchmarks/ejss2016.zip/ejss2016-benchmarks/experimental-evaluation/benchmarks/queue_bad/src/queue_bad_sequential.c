#include <pthread.h>
#include <stdio.h>
#include <assert.h>

#define SIZE (20)
#define EMPTY (-1)
#define FULL (-2)
#define FALSE (0)
#define TRUE (1)

typedef struct {
	int element[SIZE];
	int head;
	int tail;
	int amount;
} QType;

int nondet_int();
_Bool nondet_bool();

int stored_elements[SIZE];
_Bool enqueue_flag, dequeue_flag;
QType queue;

int init(QType *q) 
{
  q->head=0;
  q->tail=0;
  q->amount=0;
}

int empty(QType * q) 
{
  if (q->head == q->tail) 
  { 
    printf("queue is empty\n");
    return EMPTY;
  }
  else 
    return 0;
}

int full(QType * q) 
{
  if (q->amount == SIZE) 
  {  
	printf("queue is full\n");
	return FULL;
  } 
  else
    return 0;
}

int enqueue(QType *q, int x) 
{
	q->element[q->tail] = x;
	q->amount++;
	if (q->tail == SIZE) 
	{
		q->tail = 1;
	} 
	else 
	{
		q->tail++;
	}
	
	return 0;
}

int dequeue(QType *q) 
{
	int x;

	x = q->element[q->head];
	q->amount--;
	if (q->head == SIZE) 
	{
		q->head = 1;
	} 
	else 
		q->head++;

	return x;
}

int diag = nondet_int();

int order[4] = {11, 31, 21, 32};

int main()
{
	int order_index;
	for (order_index = 0; order_index < 4; order_index++)
	{
		switch (order[order_index])
		{
			case 1:
				case 11:
				{
					enqueue_flag=(diag == 136? nondet_bool(): TRUE);
					dequeue_flag=(diag == 137? nondet_bool(): FALSE);

					init(&queue);

					__ESBMC_assume(empty(&queue)==EMPTY);
					if (order[order_index] == 11) break;
				}
				break;
			case 2:
				case 21:
				{
					void *arg = NULL;

					int value, i;

					value = nondet_int();
					__ESBMC_assume(!enqueue(&queue,value));
					stored_elements[0]=(diag == 92? nondet_int(): value);
					__ESBMC_assume(!empty(&queue));

					for(i=0; i<(diag == 96? nondet_int(): SIZE-1); i++)
					{
						if ((diag == 120? nondet_bool(): enqueue_flag))
						{
							value = nondet_int();
							enqueue(&queue,value);
							stored_elements[i+1]=(diag == 103? nondet_int(): value);
							enqueue_flag=(diag == 104? nondet_bool(): FALSE);
							dequeue_flag=(diag == 105? nondet_bool(): TRUE);
						}
					}
				}
				break;
			case 3:
				case 31:
				{
					void *arg = NULL;

					int value, i;

					value = nondet_int();
					__ESBMC_assume(!enqueue(&queue,value));
					stored_elements[0]=(diag == 92? nondet_int(): value);
					__ESBMC_assume(!empty(&queue));

					for(i=0; i<SIZE-1; i++)
					{
						if ((diag == 120? nondet_bool(): enqueue_flag))
						{
							value = nondet_int();
							enqueue(&queue,value);
							stored_elements[i+1]=(diag == 103? nondet_int(): value);
							enqueue_flag=(diag == 104? nondet_bool(): FALSE);
							dequeue_flag=(diag == 105? nondet_bool(): TRUE);
						}
						if (order[order_index] == 21) break;
					}
				}
				case 32:
				{
					void *arg = NULL;

					int value, i;

					value = nondet_int();
					__ESBMC_assume(!enqueue(&queue,value));
					stored_elements[0]=(diag == 92? nondet_int(): value);
					__ESBMC_assume(!empty(&queue));

					for(i=0; i<SIZE-1; i++)
					{
						if ((diag == 120? nondet_bool(): enqueue_flag))
						{
							value = nondet_int();
							enqueue(&queue,value);
							stored_elements[i+1]=(diag == 103? nondet_int(): value);
							enqueue_flag=(diag == 104? nondet_bool(): FALSE);
							dequeue_flag=(diag == 105? nondet_bool(): TRUE);
						}
						if (order[order_index] == 21) break;
					}
				}
				break;
		}
	}
	__ESBMC_assume(diag!=96);
	__ESBMC_assume(diag!=136);
	__ESBMC_assume(diag!=137);
	__ESBMC_assume(diag!=139);
	assert(0);
	return 1;
}
