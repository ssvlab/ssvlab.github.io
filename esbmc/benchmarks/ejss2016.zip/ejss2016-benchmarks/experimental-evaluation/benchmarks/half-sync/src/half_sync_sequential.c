#include <assert.h>
#include <stdio.h>

int nondet_int(void);

int cs[] = { 11, 21, 12 };
int diag = nondet_int();

unsigned int x = diag == 5 ? nondet_int() : 0;

void f1() {
    unsigned int t = x + 1;
    x = diag == 8 ? nondet_int() : t;
}

void f2() {
    unsigned int t = x + 1;
    x = diag == 12 ? nondet_int() : t;
}


int main(void) {
    int i;
    for (i = 0; i != 1; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                }
                case 12: {
                }
                break;
            }
            case 2: {
                case 21: {
                    f1();
                }
            }
        }
    }
    __ESBMC_assume(x == 2);
    assert(0);
    return 0;
}
