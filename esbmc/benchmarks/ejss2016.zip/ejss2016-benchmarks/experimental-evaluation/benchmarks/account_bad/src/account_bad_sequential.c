#include <pthread.h>
#include <stdio.h>

int nondet_int();
int diag1 = nondet_int();
int diag2 = nondet_int();
int x, y, z, balance;
_Bool deposit_done=0, withdraw_done=0;
int order[4] = {11, 31, 41, 21};

int main()
{
	int order_index;
	
	for (order_index = 0; order_index < 4; order_index++)
	{
		switch (order[order_index])
		{
			case 1: //thread 0
				case 11:
				{
					x = (diag1 == 39 ? nondet_int() : nondet_int());
					y = (diag1 == 40 ? nondet_int() : nondet_int());
					z = (diag1 == 41 ? nondet_int() : nondet_int());
					balance = (diag1 == 42 ? nondet_int() : x);
					if (order[order_index] == 11) break;
				}
				break;
			case 2: //thread 1
				case 21:
				{
					void *arg = NULL;
					if ((diag1 == 28 ? nondet_int() : deposit_done) && (diag2 == 28 ? nondet_int() : withdraw_done))
						__ESBMC_assume(balance == (x - y) - z); /* BAD */
					if (order[order_index] == 21) break;
				}
				break;
			case 3: //thread 2
				case 31:
				{
					void *arg = NULL;
					balance = (diag1 == 12 ? nondet_int() : balance + y);
					deposit_done = (diag1 == 13 ? nondet_int() : 1);
					if (order[order_index] == 31) break;
				}
				break;
			case 4: //thread 3
				case 41:
				{
					void *arg = NULL;
					balance = (diag1 == 20 ? nondet_int() : balance - z);
					withdraw_done = (diag1 == 21 ? nondet_int() : 1);
					if (order[order_index] == 41) break;
				}
				break;
			default:
				break;
		}
	}
	__ESBMC_assume(diag1!=20);
	__ESBMC_assume(diag1!=12);
	__ESBMC_assume(diag1!=42);
	__ESBMC_assume(diag1!=13);
	__ESBMC_assume(diag1!=21);
	__ESBMC_assume(diag1!=28);
	__ESBMC_assume(diag2!=28);
	assert(0);
	return 1;
}
