#include <assert.h>

int nondet_int(void);

int cs[] = { 11, 21, 31, 12 };
int diag = nondet_int();

int data1, data2;

void f0() {
    data1 = 10;
    data2 = 10;
}

void f1()
{
    data1++;

    data2++;
}

void f2()
{
    data1 += 5;

    data2 -= 6;
}

void f3() {
    int tdata1 = (diag == 48 ? nondet_int() : 16);
    int tdata2 = (diag == 49 ? nondet_int() : 5);
    __ESBMC_assume(data1 != tdata1 || data2 != tdata2);
}

int main()
{
    int i;
    for (i = 0; i != 4; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f0();
                } break;
                case 12: {
                    f3();
                } break;
            }
            case 2: {
                case 21: {
                    f1();
                } break;
            }
            case 3: {
                case 31: {
                    f2();
                    break;
                }
            }
        }
    }
    // __ESBMC_assume(diag != 48);
    // __ESBMC_assume(diag != 49);
    assert(0);
    return 0;
}
