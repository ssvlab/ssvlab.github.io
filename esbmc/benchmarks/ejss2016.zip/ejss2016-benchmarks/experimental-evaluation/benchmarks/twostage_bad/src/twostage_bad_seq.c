#include <stdio.h>
#include <assert.h>

int nondet_int();
int diag = nondet_int();
int cs[] = { 11, 21, 12, 22 };

static int iTThreads = 1;
static int iRThreads = 1;
static int data1Value = 0;
static int data2Value = 0;
int t1 = -1;
int t2 = -1;

void f0() {
    data1Value = 1;
}

void f1() {
    t1 = data1Value;
    t2 = data2Value;
}

void f2() {
    data2Value = data1Value + 1;
}

void f3() {
    int expr = (diag == 46 ? nondet_int() : t2 != (t1 + 1));
    __ESBMC_assume(expr == 0);
}

int main(void) {
    int i;
    for (i = 0; i != 4; i++) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f0();
                } break;
                case 12: {
                    f2();
                } break;
            } break;
            case 2: {
                case 21: {
                    f1();
                } break;
                case 22: {
                    f3();
                } break;
            } break;
        }
    }
    assert(0);
    return 0;
}
