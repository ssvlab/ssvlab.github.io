#include <pthread.h>
#include <assert.h>

#define BUFFER_MAX  10
#define N 7
#define ERROR -1
#define FALSE 0
#define TRUE 1

int nondet_int();
int diag = nondet_int();
int order[4] = {11, 31, 21, 32};

static char  buffer[BUFFER_MAX];     /* BUFFER */

static unsigned int first;           /* Pointer to the input buffer   */
static unsigned int next;            /* Pointer to the output pointer */
static int  buffer_size;             /* Max amount of elements in the buffer */

_Bool send, receive;

int loop1;
int loop2;

int main()
{
	int order_index;
	for (order_index = 0; order_index < 4; order_index++)
	{
		switch (order[order_index])
		{
			case 1:
				case 11:
				{
					{
						int max = (diag == 21 ? nondet_int(): buffer_size);
						max = (diag == 21 ? nondet_int(): 10);
						buffer_size = (diag == 22 ? nondet_int(): max);
					}
					send=(diag == 98 ? nondet_int(): TRUE);
					receive=(diag == 99 ? nondet_int(): FALSE);

					if (order[order_index] == 11) break;
				}
				break;
			case 2:
				case 21:
				{
					void *arg = NULL;
					int i;
					loop1 = 0;
					for(i=0; i<N; i++)
					{
						if (send)
						{
							int ret;
							{
								int b = (diag == 41 ? nondet_int(): buffer[next]);
								b = (diag == 41 ? nondet_int(): i);
								if (next < buffer_size && buffer_size > 0) 
								{
									buffer[next] = (diag == 45 ? nondet_int(): b);
									next = (diag == 46 ? nondet_int(): (next+1)%buffer_size);
									__ESBMC_assume(next<buffer_size);
								}
								else
								{
									ret = (diag == 51 ? nondet_int(): ERROR);
								}

								ret = (diag == 54 ? nondet_int(): b);
							}
							send=(diag == 67 ? nondet_int(): FALSE);
							receive=(diag == 68 ? nondet_int(): TRUE);
						}
						loop1++;
					}
					if (order[order_index] == 21) break;
				}
				break;
			case 3:
				case 31:
				{
					void *arg = NULL;
					int i;

					loop2 = 0;
					for(i=0; i<N; i++)
					{
						if ((diag == 81 ? nondet_int(): receive))
						{
							int ret;
							{
								__ESBMC_assume(first>=0);

								if ((diag == 30 ? nondet_int(): next > 0) && (diag == 30 ? nondet_int(): first) < (diag == 30 ? nondet_int(): buffer_size)) 
								{
									first = (diag == 32 ? nondet_int(): first + 1);
									ret = (diag == 33 ? nondet_int(): buffer[first-1]);
								}
								else
								{
									ret = (diag == 37 ? nondet_int(): ERROR);
								}
							}
							
							__ESBMC_assume(ret==i); /* BAD */
							receive=(diag == 84 ? nondet_int(): FALSE);
							send=(diag == 85 ? nondet_int(): TRUE);
							loop2++;
						}
						if (order[order_index] == 31) break;
					}
				}
				case 32:
				{
							if (order[order_index] == 32) break;
							receive=(diag == 84 ? nondet_int(): FALSE);
							send=(diag == 85 ? nondet_int(): TRUE);
				}
				break;
			default:
				break;
		}
	}	
	__ESBMC_assume(diag!=78);
	__ESBMC_assume(diag!=37);
	__ESBMC_assume(diag!=30);
	__ESBMC_assume(diag!=21);
	__ESBMC_assume(diag!=22);
	__ESBMC_assume(diag!=46);
	__ESBMC_assume(diag!=67);
	assert(0);
	return 1;
}
