#include <assert.h>
#include <stdio.h>

int nondet_int(void);

int cs[] = { 11 };
int diag = nondet_int();

unsigned int x = diag == 5 ? nondet_int() : 0;

int main(void) {
    int i;
    for (i = 0; i != 1; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                }
                break;
            }
        }
    }
    __ESBMC_assume(x == 2);
    assert(0);
    return 0;
}
