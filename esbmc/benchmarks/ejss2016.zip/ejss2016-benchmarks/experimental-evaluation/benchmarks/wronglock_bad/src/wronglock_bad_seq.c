#include <stdio.h>
#include <assert.h>

int nondet_int();
int diag = nondet_int();
int cs[] = { 11, 21, 12 };

int dataValue = 0;
int x;

void f0() {
    x = dataValue;
    dataValue++;
}

void f1() {
    dataValue++;
}

void f2() {
    int expr = (diag == 21 ? nondet_int() : dataValue != (x + 1));
    __ESBMC_assume(expr == 0);
}

int main(void) {
    int i;
    for (i = 0; i != 3; i++) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f0();
                } break;
                case 12: {
                    f2();
                } break;
            }
            case 2: {
                case 21: {
                    f1();
                } break;
            }
        }
    }
    assert(0);
    return 0;
}
