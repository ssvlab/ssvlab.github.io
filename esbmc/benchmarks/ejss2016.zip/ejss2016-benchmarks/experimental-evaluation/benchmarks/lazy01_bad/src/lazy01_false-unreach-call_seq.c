#include <assert.h>

int nondet_int(void);

int cs[] = { 11, 21, 31 };
int diag = nondet_int();

int data = 0;

void f1()
{
    data++;
}

void f2()
{
    data+=2;
}


void f3()
{
    int t = (diag == 28 ? nondet_int() : 3);
    __ESBMC_assume(data < t);
}


int main()
{
    int i;
    for (i = 0; i != 3; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f1();
                } break;
            }
            case 2: {
                case 21: {
                    f2();
                } break;
            }
            case 3: {
                case 31: {
                    f3();
                    break;
                }
            }
        }
    }
    assert(0);
    return 0;
}
