#include <stdio.h>
#include <assert.h>

int nondet_int();
int diag = nondet_int();
int cs[] = { 21, 11, 22, 31, 41 };

int x1 = 1;
int x2 = 2;
int x3 = 1;

_Bool flag1 = 0, flag2 = 0, flag3 = 0;

void __ESBMC_atomic_begin();
void __ESBMC_atomic_end();

void f0() {
    __ESBMC_atomic_begin();
    x2 = x1;
    flag2 = 1;
}

void f1() {
    __ESBMC_atomic_begin();
    x1 = (x3 + 1) % 4;
    flag1 = 1;
    __ESBMC_atomic_end();
}

void f2() {
    __ESBMC_atomic_end();
}

void f3() {
    __ESBMC_atomic_begin();
    x3 = x2;
    flag3 = 1;
    __ESBMC_atomic_end();
}

void f4() {
    __ESBMC_atomic_begin();
    if (flag1 && flag2 && flag3) {
        int expr1 = (diag == 41 ? nondet_int() : x1 == x2);
        int expr2 = (diag == 42 ? nondet_int() : x2 == x3);
        __ESBMC_assume(expr1 != 0 && expr2 != 0);
    }
    __ESBMC_atomic_end();
}

int main(void) {
    int i;
    for (i = 0; i != 5; i++) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f1();
                } break;
            } break;
            case 2: {
                case 21: {
                    f0();
                } break;
                case 22: {
                    f2();
                } break;
            } break;
            case 3: {
                case 31: {
                    f3();
                } break;
            } break;
            case 4: {
                case 41: {
                    f4();
                } break;
            } break;
        }
    }
    // __ESBMC_assume(diag != 41);
    assert(0);
    return 0;
}
