#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int nondet_int(void);
int cs[] = { 11, 21, 12 };

int pdev;
int diag = nondet_int();

void f1() {
    int t = (diag == 24 ? nondet_int() : 1);
    pdev = t;
    __ESBMC_assume(pdev==1);
    t = (diag == 35 ? nondet_int() : 3);
    pdev = t;
}

void f2() {
    int t = (diag == 16 ? nondet_int() : 6);
    pdev = t;
    __ESBMC_assume(pdev==6);
}

void f3() {
    __ESBMC_assume(pdev==(diag == 36 ? nondet_int() : 3));
}

int main(void) {
    int i;
    for (i = 0; i != 3; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f1();
                } break;
                case 12: {
                    f3();
                } break;
            }
            case 2: {
                case 21: {
                    f2();
                } break;
            }
        }
    }
    __ESBMC_assume(diag != 36);
    assert(0);
    return 0;
}
