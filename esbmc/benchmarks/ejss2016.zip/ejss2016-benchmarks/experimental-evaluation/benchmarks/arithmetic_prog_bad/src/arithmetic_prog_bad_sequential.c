#include <pthread.h>
#include <assert.h>

#define N 3

int nondet_int();
int diag = nondet_int();
_Bool nondet_bool();

int num;
unsigned long total;
int flag;

int m;
int empty, full;

int order[3] = {11, 21, 31};

int loop1;
int loop2;

int main()
{
	int order_index;
	
	for (order_index = 0; order_index < 4; order_index++)
	{
		switch (order[order_index])
		{
			case 1:
				case 11:
				{
					num = (diag == 63? nondet_int(): 0);
					total = (diag == 64? nondet_int(): 0);

					m = (diag == 66? nondet_bool(): 0);
					empty = (diag == 67? nondet_bool(): 0);
					full = (diag == 68? nondet_bool(): 0);

					if (order[order_index] == 11) break;

					if ((diag == 77? nondet_bool(): flag))
						__ESBMC_assume(total!=((N*(N+1))/2)); /* BAD */
				}
				break;
			case 2:
				case 21:
				{
					void *arg = NULL;

					int i;

					i = (diag == 17? nondet_int(): 0);
					loop1 = 0;
					while (i < N){
						m = (diag == 19? nondet_bool(): 1);
						while (num > (diag == 20? nondet_int(): 0)) 
						{ 
							empty = (diag == 21? nondet_bool(): 1);
							break;
						}

						if (order[order_index] == 21 && loop1 == N) break;
	
						num++;
	
						printf ("produce ....%d\n", i);
						m = (diag == 26? nondet_bool(): 0);
	
						full = (diag == 28? nondet_bool(): 0);
	
						i++;
						loop1++;
					}
				}
				break;
			case 3:
				case 31:
				{
					void *arg = NULL;

					int j;

					loop2 = 0;

					j = (diag == 38? nondet_int(): 0);
					while (j < N) {
						m = (diag == 40? nondet_bool(): 1);
						while (num == (diag == 41? nondet_int(): 0))
						{
							full = (diag == 42? nondet_bool(): 1);
							break;
						}
						if (order[order_index] == 31 && loop2 == N) break;

						total=(diag == 44? nondet_int(): total+j);
						printf("total ....%d\n",total);
						num--;
						printf("consume ....%d\n",j);
						m = (diag == 48? nondet_bool(): 0);
		
						empty = (diag == 50? nondet_bool(): 0);
						j++;
						loop2++;
					}
					total=(diag == 53? nondet_int(): total+j);
					printf("total ....%d\n",total);
					flag=(diag == 55? nondet_bool(): 1);
				}
				break;
		}
	}
	__ESBMC_assume(diag!=38);
	__ESBMC_assume(diag!=39);
	assert(0);
	return 1;
}
