#include <stdio.h>
#include <pthread.h>

#define N 1

int nondet_int();
_Bool nondet_bool();

int diag = nondet_int();

int num;

int m;
int empty, full;

int order[4] = {11, 21, 31, 22};

int main()
{
	int order_index;

	for (order_index = 0; order_index < 3; order_index++)
	{
		switch (order[order_index])
		{
			case 1:
				case 11:
				{
					void *arg = NULL;
					num = 1;

					m = (diag == 50? nondet_bool(): 0);
					empty = (diag == 51? nondet_bool(): 0);
					full = (diag == 52? nondet_bool(): 0);

					if (order[order_index] == 11) break;
				}
				break;
			case 2:
				case 21:
				{
					void *arg = NULL;
					m = (diag == 14? nondet_bool(): 1);

					while (num > 0)
					{
						empty = (diag == 17? nondet_bool(): 1);/* BAD: deadlock */
						break;
					}

					if (order[order_index] == 21) break;
				}
				case 22:
				{
					void *arg = NULL;
					num++;

					m = (diag == 21? nondet_bool(): 0);
					full = (diag == 22? nondet_bool(): 0);
				}
				break;
			case 3:
				case 31:
				{
					void *arg = NULL;
					#if 1
					m = (diag == 29? nondet_bool(): 1);

					while (num == 0)
					{
						full = (diag == 32? nondet_bool(): 1);

						break;
					}

					//  num--;
					//  printf("consume ....\n");

					m = (diag == 37? nondet_bool(): 0);

					empty = (diag == 39? nondet_bool(): 0);
					#endif					
				}
				break;
		}
	}
	__ESBMC_assume(diag!=0);
	assert(0);
	return 1;
}
