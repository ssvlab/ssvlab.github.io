#include <assert.h>
#include <stdlib.h>
#include <string.h>

int nondet_int(void);
int nondet_bool(void) {
    int r;
    __ESBMC_assume(r == 0 || r == 1);
    return r;
}

int cs[] = { 11, 21, 12 };
int diag = nondet_int();

char *v = NULL;

void f1() {
  if (v) {
      strcpy(v, "Bigshot");
  }
}

void f2() {
  v = malloc(sizeof(char) * 8);
}

void f3() {
    int c2 = v[0] == 'B';
    __ESBMC_assume((diag == 31 ? nondet_bool() : !v));
}


int main()
{
    int i;
    for (i = 0; i != 3; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f1();
                } break;
                case 12: {
                    f3();
                } break;
            }
            case 2: {
                case 21: {
                    f2();
                } break;
            }
        }
    }
    assert(0);
    return 0;
}
