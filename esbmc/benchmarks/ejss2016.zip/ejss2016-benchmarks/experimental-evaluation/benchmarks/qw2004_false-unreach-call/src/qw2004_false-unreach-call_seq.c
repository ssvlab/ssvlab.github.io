#include <assert.h>

int nondet_int(void);

int cs[] = { 11, 21, 12, 22 };
int diag = nondet_int();

volatile int stoppingFlag;
volatile int pendingIo;
volatile int stoppingEvent;
volatile int stopped;
int status;

void f0() {
    pendingIo = 1;
    stoppingFlag = 0;
    stoppingEvent = 0;
    stopped = 0;
}

void f1() {
    if (stoppingFlag) {
        status = -1;
    } else {
        pendingIo = pendingIo + 1;
        status = 0;
    }
}

void f2() {
    stoppingFlag = 1;
    int pending;
    pendingIo--;
    pending = pendingIo;
    if (pending == 0) {
        stoppingEvent = 1;
    }
    stopped = 1;
}

void f3() {
    if (status == 0) {
        __ESBMC_assume(diag == 39 ? nondet_int() : !stopped);
    }
}

int main() {
    int i;
    for (i = 0; i != 4; ++i) {
        switch (cs[i]) {
            case 1: {
                case 11: {
                    f0();
                } break;
                case 12: {
                    f2();
                } break;
            }
            case 2: {
                case 21: {
                    f1();
                } break;
                case 22: {
                    f3();
                } break;
            }
        }
    }
    assert(0);
    return 0;
}
