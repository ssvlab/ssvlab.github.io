#include <assert.h>
#include <stdio.h>
#include <pthread.h>

unsigned int x = 0;

void *f1(void *args) {
    x++;
}

void *f2(void *args) {
    x++;
}

int main(void) {
    pthread_t t1, t2;
    pthread_create(&t1, NULL, f1, NULL);
    pthread_create(&t2, NULL, f2, NULL);
    assert(x == 2);
    return 0;
}
