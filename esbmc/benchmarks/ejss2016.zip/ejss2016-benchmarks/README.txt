README

These is the description of the steps needed to reproduce the results presented in our paper.

Requirements:
- ESBMC (http://esbmc.org/) [http://svlab.hussamaismail.eti.br/binaries/esbmc-v3.0.0-linux-static-64.tgz]
- Lazy-CSeq (http://users.ecs.soton.ac.uk/gp4/cseq/cseq.html) [http://users.ecs.soton.ac.uk/gp4/cseq/files/lazy-cseq-1.0.tar.gz]
- CEX Parser (https://github.com/ericksonalves/cex-parser) [https://github.com/ericksonalves/cex-parser/archive/master.zip]
- Text editor (Atom is used as an example here)

Step 1: Check for counterexamples, i.e., deadlock, assertion, lock acquisition errors, division by zero, pointer safety, arithmetic overflow, and/or out-of-bounds arrays violations, using a model checker (ESBMC or Lazy-CSeq), and save such trace in a text file.

Step 2: Open a new C file and copy the structure of the presented sequentialization framework available in the paper.

Step 3: With the obtained counterexample, use CEX Parser to obtain the faulty execution step-by-step. With such trace, it is possible to extract the tuples (line and related thread) needed in the method, as described in the paper. With such data, it is possible to create the sequentialized version of the program which is able to reproduce the same faulty behavior as in the concurrent program.

Step 4: Verify the new sequential code with a model checker and save the obtained counterexample. Such trace contains the diag values, i.e., the faulty lines, and possible repair to produce a successful execution of the concurrent program. Annotating these values leads to the set of faults in the concurrent program.

Example:

# Step 1
$ esbmc --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-slice --boolector --deadlock-check concurrent_program.c > deadlock_check.txt
$ esbmc --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-slice --boolector concurrent_program.c > violations_check.txt

# Step 2
$ atom concurrent_program_seq.c
// Copy sequentialization framework structure

# Step 3
$ ./cex_parser deadlock_check.txt > deadlock_check_interleavings.txt
$ ./cex_parser violations_check.txt > violations_check_interleavings.txt
// Create sequentialized program

# Step 4
$ esbmc --no-bounds-check --no-div-by-zero-check --no-pointer-check --no-slice --boolector concurrent_program_seq.c > diagnosis.txt
// Faulty lines are available in this diagnosis file
