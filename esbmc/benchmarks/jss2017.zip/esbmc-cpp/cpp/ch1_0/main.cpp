#include <cassert>

int main()
{
  if(1 or 0)
    assert(0);
  return 0;
}

