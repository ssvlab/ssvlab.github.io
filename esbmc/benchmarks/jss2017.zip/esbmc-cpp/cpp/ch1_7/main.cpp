#include <cassert>

int main()
{
  if(1 and 1)
    assert(0);
  return 0;
}

