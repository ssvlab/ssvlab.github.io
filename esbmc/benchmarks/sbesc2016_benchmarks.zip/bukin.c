#include<stdio.h>

int nondet_int();
double raiz (double val);
double abs (double val);
int main() {
	int p = 1;
	double f_ant = -0.0001;
	int v = (int) (f_ant*p + 1);

	//variáveis a modificadas a cada execução do código para aumentar a precisão
	int lim_inf_x = -15*p;
	int lim_sup_x = -5*p;
	int lim_inf_y = -3*p;
	int lim_sup_y = 3*p;

	//variáveis a serem definidas para minimizar a função objetivo
	int x = nondet_int();
	int y = nondet_int();
	double X1, X2;
	double fobj;

	//definição do espaço de estados
	__ESBMC_assume( (x>=lim_inf_x) && (x<=lim_sup_x) );
	__ESBMC_assume( (y>=lim_inf_y) && (y<=lim_sup_y) );

	//cálculo da função de Styblinski-Tang (função objetivo) para cada estado
	X1 = (double) x/p;
	X2 = (double) y/p;
	fobj = (double) 100*raiz( abs( X2 - 0.01*X1*X1 ) ) + 0.01*abs( X1 + 10 );
	
	//restrição para excluir estados onde fobj>f_ant
	__ESBMC_assume( fobj < f_ant );

	double val;
	//val: valor candidato a mínimo da função

	int i = 0;
	while (i <= v){
		val = (double) i/p;
		assert( fobj > val );
		i++;
	}
	
	return 0;
}

double raiz (double val)
{
	double r = val/10;
	double dx;
	double diff;
	double min_tol = 0.00001;
	int i, flag = 0;

	if (val==0) r = 0;
	else {
		for (i = 0; i < 20; ++i)
        	if (!flag){
				dx = (val-(r*r)) / (2.0*r);
				r = r + dx;
				diff = val - (r*r);
				if (__ESBMC_abs(diff)<=min_tol) flag = 1;
			}
			else r = r;
	}
	return r;
}

double abs (double val)
{
	if (val < 0)
		return -val;
	else return val;
}
