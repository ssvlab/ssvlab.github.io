#!/bin/bash
chmod 777 -R dados.sh
#inicialização das variáveis
check=0
f_ant=654.8164
f_novo=$f_ant
p=1
f_inicial=0
#define a função a ser minimizada
#i=0  minimiza a função de himmelblau1
#i=1  minimiza a função de himmelblau2
#i=2  minimiza a função de styblinski-tang
#i=3  minimiza a função de goldstein-price
#i=4  minimiza a função de bukin
i=3
fun=("himmelblau1.c" "himmelblau2.c" "stiblinski.c" "goldstein.c" "bukin.c")
var=("float" "float" "float" "long" "double")
typefun=(0 0 1 2 3)
sed -i 7s/.*/'	int p = '$p';'/ ${fun[i]}
sed -i 8s/.*/'	'${var[i]}' f_ant = '$f_novo';'/ ${fun[i]}
gcc verifica.c -o verifica
gcc tratamento.c -o tratamento -lm
gcc limite.c -o limite
while [ $p -ne 10000 ]
do
	echo '------------------------'
	check=0
	sed -i 7s/.*/'	int p = '$p';'/ ${fun[i]}
	while [ $check -eq 0 ]
	do
		echo "$f_ant+0.0001"|bc
		{ ./esbmc ${fun[i]} \
		> log.txt;
		} 2>> log.txt
		
		#verifica se houve sucesso ou falha
		grep "VERIFICATION" log.txt | tac | head -n1 | sed "s/ nil,//g" > teste.txt
		./verifica
		check=$?
		if [ $check -eq 1 ]
		then break
		fi

		#grava os valores do ponto mínimo atual
		grep ":x=" log.txt | tac | head -n1 | sed "s/ nil,//g" > x.txt
		grep ":y=" log.txt | tac | head -n1 | sed "s/ nil,//g" > y.txt
		./tratamento $p ${typefun[i]}
		
		f_novo=$(tail -1 output.txt)
		
		./limite $f_ant $f_novo $p
		v=$?
		f_ant=$f_novo
		sed -i 8s/.*/'	'${var[i]}' f_ant = '$f_novo';'/ ${fun[i]}
		if [ $v -eq 1 ]
		then
			echo "$f_ant+0.0001"|bc
			break
		fi
	done
	aux=$(echo "$f_ant+0.0001 <= $f_inicial"|bc)
	if [ $aux -eq 1 ]
	then break
	fi	
	p=$(($p*10))
done
