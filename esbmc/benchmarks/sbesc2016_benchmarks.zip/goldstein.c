#include<stdio.h>
#include<math.h>

int nondet_int();

int main() {
	int p = 1000;
	long f_ant = 2.9999;
	int v = (int) (f_ant*p + 1);

	//variáveis a modificadas a cada execução do código para aumentar a precisão
	int lim_inf_x = -2*p;
	int lim_sup_x = 2*p;
	int lim_inf_y = -2*p;
	int lim_sup_y = 2*p;

	//variáveis a serem definidas para minimizar a função objetivo
	int x = nondet_int();
	int y = nondet_int();
	long X1, X2;
	long fobj;

	//definição do espaço de estados
	__ESBMC_assume( (x>=lim_inf_x) && (x<=lim_sup_x) );
	__ESBMC_assume( (y>=lim_inf_y) && (y<=lim_sup_y) );

	//cálculo da função de Styblinski-Tang (função objetivo) para cada estado
	X1 = (long) x/p;
	X2 = (long) y/p;

	fobj = ( 1 + (X1+X2+1)*(X1+X2+1) * (19-14*X1+3*X1*X1-14*X2+6*X1*X2+3*X2*X2) ) * ( 30 + (2*X1-3*X2)*(2*X1-3*X2) * (18-32*X1+12*X1*X1+48*X2-36*X1*X2+27*X2*X2) );

	//restrição para excluir estados onde fobj>f_ant
	__ESBMC_assume( fobj < f_ant );

	long val;
	//val: valor candidato a mínimo da função

	int i = 0;
	while (i <= v){
		val = (long) i/p;
		assert( fobj > val );
		i++;
	}
	
	return 0;
}
