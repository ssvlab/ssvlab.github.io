#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[]){
	
	float f_ant, f_novo, p;
	int val;
	
	if (argc != 4) return 1;
	sscanf(argv[1], "%f", &f_ant);
	sscanf(argv[2], "%f", &f_novo);
	sscanf(argv[3], "%f", &p);

	float v = (f_ant - f_novo) * p;
	if (v < 1.0)
		val = 1;
	else val = 0;
	//printf("%d\n",val);
	return val;
}
