#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[]){
	
	FILE * fp;
	FILE * fp2;
	char url[2][12] = {"x.txt","y.txt"};
	char var[2] = {'x','y'};
	char p;
	char val[100];
	float prec;
	float x[3];
	int fun;

	if (argc != 3) return 1;
	sscanf(argv[1], "%f", &prec);
	sscanf(argv[2], "%d", &fun);

	fp2 = fopen("output.txt","w+");
	
	for (int i = 0; i < 2; i++){
		fp = fopen (url[i], "r");
		if (fp == NULL)
			printf("Erro, nao foi possivel abrir o arquivo\n");
		else {
			fscanf(fp,"%c",&p);
			while (p != var[i]){
				fscanf(fp,"%c",&p);
			}
			fscanf(fp,"%c",&p);
			if (p == '='){
				if(fp2==NULL){
					printf("Erro, nao foi possivel abrir o arquivo\n");
					break;				
				}
				else {
					fscanf(fp,"%s",val);
					x[i] = atof(val)/prec;
					fprintf(fp2,"%.3f\n",x[i]);
				}
			}
		}
	}
	fclose(fp);
	if (fun == 0){
		x[2] = (x[0]*x[0] + x[1] - 11) * (x[0]*x[0] + x[1] - 11) + (x[0] + x[1]*x[1] - 7) * (x[0] + x[1]*x[1] - 7);
	}
	else {
		if (fun == 1){
			x[2] = ( (x[0]*x[0]*x[0]*x[0] - 16*x[0]*x[0] + 5*x[0]) + (x[1]*x[1]*x[1]*x[1] - 16*x[1]*x[1] + 5*x[1]) ) / 2;
		}
	     	else {
			if (fun == 2){
				x[2] = ( 1 + (x[0]+x[1]+1)*(x[0]+x[1]+1) * (19-14*x[0]+3*x[0]*x[0]-14*x[1]+6*x[0]*x[1]+3*x[1]*x[1]) ) * ( 30 + (2*x[0]-3*x[1])*(2*x[0]-3*x[1]) * (18-32*x[0]+12*x[0]*x[0]+48*x[1]-36*x[0]*x[1]+27*x[1]*x[1]) );
			}
			else {
				if (fun == 3){
					x[2] = 100 * sqrt( fabs( x[1]-0.01*x[0]*x[0] ) ) + 0.01 * fabs( x[0]+10 );
				}
			}
		}
		
	}
	fprintf(fp2,"%.4f\n",x[2]-0.0001);
	fclose(fp2);
	return 0;
}
