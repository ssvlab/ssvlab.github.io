#include<stdio.h>
#include<math.h>

int nondet_int();

int main() {
	int p = 1000;
	float f_ant = -78.3321;
	int v = (int) (f_ant*p + 1);

	//variáveis a modificadas a cada execução do código para aumentar a precisão
	int lim_inf_x = -5*p;
	int lim_sup_x = 5*p;
	int lim_inf_y = -5*p;
	int lim_sup_y = 5*p;

	//variáveis a serem definidas para minimizar a função objetivo
	int x = nondet_int();
	int y = nondet_int();
	float X, Y;
	float fobj;

	//definição do espaço de estados
	__ESBMC_assume( (x>=lim_inf_x) && (x<=lim_sup_x) );
	__ESBMC_assume( (y>=lim_inf_y) && (y<=lim_sup_y) );

	//cálculo da função de Styblinski-Tang (função objetivo) para cada estado
	X = (float) x/p;
	Y = (float) y/p;

	fobj = ( (X*X*X*X - 16*X*X + 5*X) + (Y*Y*Y*Y - 16*Y*Y + 5*Y) ) / 2;
	
	//restrição para excluir estados onde fobj>f_ant
	__ESBMC_assume( fobj < f_ant );

	float val;
	//val: valor candidato a mínimo da função

	int i = -100*p;
	while ( i<= v){
		val = (float) i/p;
		assert( fobj > val );
		i++;
	}
	
	return 0;
}
