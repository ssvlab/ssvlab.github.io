#include<assert.h>

int main()
{
  float a[] =  {

   1.000000000000000,   1.968750000000000,  1.968750000000000,   1.562500000000000,   0.312500000000000


};
 float b[] =  {

     0,     0,     0 ,    0,     0
     };
  assert(check_stability(a, b));
  return 0;
}
