import sys
import os
import subprocess



def main():
  arquivo = "lista.txt"
  f = open(arquivo,"r")
    
  for line in f:
    line = line.rstrip();
    saida = open("logs/" + line + ".txt" , "w")
    proc = subprocess.Popen(['time','esbmc', '--fixedbv', line], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out, err) = proc.communicate()
    saida.write(out)
  f.close()
  exit(0);
 

if __name__ == "__main__":
    main()
