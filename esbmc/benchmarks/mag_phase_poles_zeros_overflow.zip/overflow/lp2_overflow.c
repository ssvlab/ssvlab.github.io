#include <stdlib.h>
#include <stdio.h>
//#include <string.h>
#include <assert.h>
//#include <math.h>

//const int xLen = 13;
const int xLen = 9;
const int Alen = 3;
const int Blen = 3;


int powInt(int x, unsigned int y)
{
	int i;
	int ret = 1;
	for(i=0; i<y; ++i)
	{
		ret *= x;
	}
	return ret;
}

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
    printf("Value of real number must be greater than 1\n");
    exit(0);
  }
  result[0] = -1*powInt(2,real-1);
  result[1] = powInt(2,real-1)- (1.0)/powInt(2,frac);
  //printf("%f %f\n", result[0], result[1]);
}

double nondet_double();
int main()
{
  /*IIR Filter coefficients */
  double A[] = {  1.000000000000000e+00,    -3.750000000000000e-01,     1.875000000000000e-01}; //Den
  double B[] = {  2.187500000000000e-01,     4.062500000000000e-01,     2.187500000000000e-01}; //Num
  
  /*input*/
  //double x[] = {1.6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  //double x[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  double x[xLen];
  /*declarations*/
  int i,j;
  for (j=0;j<xLen;j++)
  {
    x[j] = nondet_double();
    __ESBMC_assume((x[j]>=-1.6) && (x[j] <= 1.6));
  }

  double x_aux[] = {0,0,0};
  double y[xLen];
  double y_aux[] = {0,0};
  
  
  printf("initial value: %f\n", x[0]);
  float limits[2];// = malloc(sizeof(float)*2);
  update_limits(2,5, limits); //creating the limits
  printf("limits: %f %f\n", limits[0], limits[1]);

  /*Filtering*/
  for (i=0;i<xLen;i++)
  {
    y[i] = 0; //clear y
    
    /* Updating past x values */
    for (j=Blen-1;j>=1;j--)
    {
      x_aux[j] = x_aux[j-1];
    }
    x_aux[0] = x[i];

    
    /* Num, x values */
    for(j = 0; j < Blen; j++) 
    {
      y[i] = y[i] + B[j]*x_aux[j];  
      //assert((y[i] >= limits[0]) && (y[i] <= limits[1]));
    }
    
    /* Den, y values */
    for(j=0;j<Alen-1;j++) 
    {
      y[i] = y[i] - A[j+1]*y_aux[j];
      //assert((y[i] >= limits[0]) && (y[i] <= limits[1]));
    }
    printf("##### %.15f\n",y[i]);
    //assert((y[i] >= limits[0]) && (y[i] <= limits[1]));
//    limits[0] = -1.7;
//    limits[1] = 1.7;
    assert((y[i] >= limits[0]) && (y[i] <= limits[1]));

    /* Updating past y values */
    for (j=Alen-2;j>=1;j--)
    {
      y_aux[j] = y_aux[j-1];
    }
    y_aux[0] = y[i];
    
  }
  return 0;
}
