#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int Blen = 11;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

#if 0
double inline fabs(double x) {
  return (x < 0) ? -x : x;
}

double fmod(double a, double b) {
  return a - (b * (int)(a/b));
}

double cos1(double x)
{
    double t , s;
    int p;
    p = 0;
    s = 1.0;
    t = 1.0;
    x = fmod(x + M_PI, M_PI * 2) - M_PI; // restrict x so that -M_PI < x < M_PI
    double xsqr = x*x;
    double ab = 1;
    while((ab > PREC) && (p < 15))
    {
        p++;
        t = (-t * xsqr) / (((p<<1) - 1) * (p<<1));
        s += t;
        ab = (s==0) ? 1 : fabs(t/s);
    }
    return s;
}

double sin1(double x)
{
   return cos1(x-M_PI_2);
}

/*Returns the square root of n. Note that the function */
/*Babylonian method*/
/*http://www.geeksforgeeks.org/square-root-of-a-perfect-square/*/
double sqrt1(double n)
{
  /*We are using n itself as initial approximation
   This can definitely be improved */
  double x = n;
  double y = 1;
  //float e = 0.000001; /* e decides the accuracy level*/
  //double e = 1e-16;
  double e = 1;
  int i = 0;
//  while(fabs(x - y) > e)
  while(i++ < 15) //Change this line to increase precision
  {
    x = (x + y)/2.0;
    y = n/x;
  }
  return x;
}

#endif
/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_fir_mag(double* num, int lnum, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%f ", w);
     //printf("\n%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     res[i] = sqrt(out_r[i]*out_r[i]+out_i[i]*out_i[i]); //numerator abs
//     res[i] = 20*log10(res[i]);
  }
//  assert(0);
  /*PRINT do modulo*/
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_r[i], out_i[i]);
  }
  printf("\n########################\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};


/*
 * Verifies Magnitude response for Low Pass filter
 */
void verifyMagrespHP(double *res, struct Properties prop, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      if(w <= prop.wr) {
          assert(res[i] <= prop.Ar);
      }
      else if (w == prop.wc) {
          assert(res[i] <= prop.Ac);
      }
      else if ((w >= prop.wp) && (w <= 1)) {
          assert(res[i] >= prop.Ap);
      }
  }
}

int main()
{
  /*FIR Filter coefficients - hp10 - Kaiser - 9600 - 48000*/
//  assert(0);
  double B[] = {   0.000000000000000,   0.069826220804030,   0.058540107746826,  -0.088889751527421,  -0.289759871088689,   0.575687534763057,
  -0.289759871088689,  -0.088889751527421,   0.058540107746826,   0.069826220804030,   0.000000000000000  }; //Num
  /*input*/

  /*var*/
  int N = 100;
  double res[N+1];
  int i,j;

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    B[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("B[%d]=%f \n", i, B[i]);
  }
  
 // assert(0);
  
  freqz_fir_mag(B, Blen, res, N);
  /*propriedades do filtro*/
   
  struct Properties prop = {
        .Ap =  0.81, .Ac =  0.707945784384138, .Ar = 0.3,
        .wp = 0.5, .wc = 0.4, .wr = 0.3
    };
  verifyMagrespHP(res, prop, N);
  return 0;
}
