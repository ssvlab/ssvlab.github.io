#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int xLen = 10;
const int Alen = 13;
const int Blen = 13;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

#if 0
double inline fabs(double x) {
  return (x < 0) ? -x : x;
}

double fmod(double a, double b) {
  return a - (b * (int)(a/b));
}

double cos1(double x)
{
    double t , s;
    int p;
    p = 0;
    s = 1.0;
    t = 1.0;
    x = fmod(x + M_PI, M_PI * 2) - M_PI; // restrict x so that -M_PI < x < M_PI
    double xsqr = x*x;
    double ab = 1;
    while((ab > PREC) && (p < 15))
    {
        p++;
        t = (-t * xsqr) / (((p<<1) - 1) * (p<<1));
        s += t;
        ab = (s==0) ? 1 : fabs(t/s);
    }
    return s;
}

double sin1(double x)
{
   return cos1(x-M_PI_2);
}

/*Returns the square root of n. Note that the function */
/*Babylonian method*/
/*http://www.geeksforgeeks.org/square-root-of-a-perfect-square/*/
double sqrt1(double n)
{
  /*We are using n itself as initial approximation
   This can definitely be improved */
  double x = n;
  double y = 1;
  //float e = 0.000001; /* e decides the accuracy level*/
  //double e = 1e-16;
  double e = 1;
  int i = 0;
//  while(fabs(x - y) > e)
  while(i++ < 15) //Change this line to increase precision
  {
    x = (x + y)/2.0;
    y = n/x;
  }
  return x;
}
#endif

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_mag(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i]; 
     }

     res[i] = sqrt(out_r[i]*out_r[i]+out_i[i]*out_i[i]); //numerator abs
     res[i] = res[i] / sqrt(out_denr[i]*out_denr[i]+out_deni[i]*out_deni[i]); //den abs
//     res[i] = 20*log10(res[i]);
  }
//  assert(0);
  /*PRINT do modulo*/
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########################\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Magnitude response for Low Pass filter
 */
void verifyMagrespLP(double *res, struct Properties prop, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      if(w <= prop.wp) {
          assert(res[i] >= prop.Ap);
//          printf("ERRO!\n");
//          exit(1);
      }
      else if (w == prop.wc) {
          assert(res[i] <= prop.Ac);
//          printf("ERRO!!\n");
//          exit(1);
      }
      else if ((w >= prop.wr) && (w <= 1)) {
//          printf("\nres[%d] = %f", i, res[i]);
//          printf("\nfreq = %f", w);
//          printf("\nprop = %f", prop.Ar);
          assert(res[i] <= prop.Ar);
//          exit(1);
      }
  }
}

int main()
{
  /*IIR Filter coefficients - lp12*/
//  assert(0);
  double A[] = { 1.000000000000000e+00,    -1.198742216327245e+01,
     6.586238609185780e+01,    -2.193156340418796e+02,
     4.929579893998396e+02,    -7.879381068321766e+02,
     9.183442642893741e+02,    -7.863751150910240e+02,
     4.910042161185110e+02,    -2.180130811812226e+02,
     6.534134403647741e+01,    -1.186899740360133e+01,
     9.881567771166367e-01 }; //Den
  double B[] = { 9.952044965921512e-05,    -1.193721715759009e-03,
     6.563113493495153e-03,    -2.187093825791819e-02,
     4.919979825133906e-02,   -7.871025787377142e-02,
     9.182497130591041e-02,    -7.871025787377141e-02,
     4.919979825133905e-02,    -2.187093825791819e-02,
     6.563113493495153e-03,    -1.193721715759009e-03,
     9.952044965921512e-05  }; //Num
  /*input*/

  /*var*/
  int N = 50;
  double res[N+1];
  int i,j;
  double y[xLen]; /*output*/

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    B[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("B[%d]=%f \n", i, B[i]);
  }
  for (i=0; i<Alen; i++) {
    A[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("A[%d]=%f \n", i, A[i]);
  }
 // assert(0);
  
  freqz_mag(B, Blen, A, Alen, res, N);
  /*propriedades do filtro*/

  struct Properties prop = {
        .Ap =  0.8, .Ac =  0.707945784384138, .Ar = 0.5,
        .wp = 0.3, .wc = 0.4, .wr = 0.5
    };

  verifyMagrespLP(res, prop, N);
  return 0;
}




