#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int xLen = 10;
const int Alen = 13;
const int Blen = 13;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_phase(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i]; 
     }

     res[i] = atan2(out_i[i],out_r[i]); //numerator abs
     res[i] = res[i] - atan2(out_deni[i],out_denr[i]); //den abs
  }
//  assert(0);
  /*PRINT do modulo*/
  printf("\n########### Num #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_r[i], out_i[i]);
  }
  printf("\n########### Den #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########## Phase response ##############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Phase response
 */
void verifyPhaseResp(double *res, double *fi, double dif, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      printf("fi= %f %f\n", w, fi[i]);
    
      assert(fabs(res[i]-fi[i]) <= dif);
  }

}

int main()
{
  /*IIR Filter coefficients - lp4*/
  double A[] = {  1.000000000000000,  -5.404665918364392,  16.960081356001968, -36.727483117539698,  60.278389859797088, -77.628523419257078,
  80.039117265692568, -66.291378112023807,  43.804494024829822, -22.583115724536590,   8.692845362522137,  -2.273925278557364,
   0.318740450215500
 }; //Den
  double B[] = {    0.002754647698347,   0.001642241954847,   0.011751968187564,   0.009382946290712,   0.023074275043114,   0.019550792882983,
   0.028190456392856,   0.019550792882983,   0.023074275043114,   0.009382946290712,   0.011751968187564,   0.001642241954847,
   0.002754647698347 }; //Num
  
  double Afi[Alen];
  double Bfi[Blen];

  /*var*/
  int N = 50;
  double res[N+1], resfi[N+1];
  int i,j;
  double y[xLen]; /*output*/

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    Bfi[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("Bfi[%d]=%f \n", i, Bfi[i]);
  }
  for (i=0; i<Alen; i++) {
    Afi[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("Afi[%d]=%f \n", i, Afi[i]);
  }

  printf("### Freqz_phase: \n");
  freqz_phase(B, Blen, A, Alen, res, N);
  printf("### Freqz_phase fixed: \n");
  freqz_phase(Bfi, Blen, Afi, Alen, resfi, N);
 
  verifyPhaseResp(res, resfi, 0.3, N);
  return 0;
}
