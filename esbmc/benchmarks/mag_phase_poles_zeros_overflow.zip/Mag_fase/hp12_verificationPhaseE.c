#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int xLen = 10;
const int Alen = 13;
const int Blen = 13;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_phase(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i]; 
     }

     res[i] = atan2(out_i[i],out_r[i]); //numerator abs
     res[i] = res[i] - atan2(out_deni[i],out_denr[i]); //den abs
  }
//  assert(0);
  /*PRINT do modulo*/
  printf("\n########### Num #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_r[i], out_i[i]);
  }
  printf("\n########### Den #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########## Phase response ##############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Phase response
 */
void verifyPhaseResp(double *res, double *fi, double dif, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      printf("fi= %f %f\n", w, fi[i]);
    
      assert(fabs(res[i]-fi[i]) <= dif);
  }

}

int main()
{
  /*IIR Filter coefficients - lp12 - E - 9600*/
//0.4
 double A[] = { 1.000000000000000e+00,    -5.404665918364392e+00,     1.696008135600197e+01,
    -3.672748311753970e+01,     6.027838985979709e+01,    -7.762852341925708e+01,
     8.003911726569257e+01,    -6.629137811202381e+01,     4.380449402482982e+01,
    -2.258311572453659e+01,     8.692845362522137e+00,    -2.273925278557364e+00,
     3.187404502154997e-01  };
  double B[] = {2.754647698346944e-03,     1.642241954846722e-03,     1.175196818756391e-02,
     9.382946290711743e-03,     2.307427504311415e-02,     1.955079288298315e-02,
     2.819045639285557e-02,     1.955079288298315e-02,     2.307427504311415e-02,
     9.382946290711739e-03,     1.175196818756391e-02,     1.642241954846722e-03,
     2.754647698346944e-03};
  double Afi[Alen];
  double Bfi[Blen];

  /*var*/
  int N = 50;
  double res[N+1], resfi[N+1];
  int i,j;
  double y[xLen]; /*output*/

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    Bfi[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("Bfi[%d]=%f \n", i, Bfi[i]);
  }
  for (i=0; i<Alen; i++) {
    Afi[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("Afi[%d]=%f \n", i, Afi[i]);
  }

  printf("### Freqz_phase: \n");
  freqz_phase(B, Blen, A, Alen, res, N);
  printf("### Freqz_phase fixed: \n");
  freqz_phase(Bfi, Blen, Afi, Alen, resfi, N);

  verifyPhaseResp(res, resfi, 0.3, N);
  return 0;
}
