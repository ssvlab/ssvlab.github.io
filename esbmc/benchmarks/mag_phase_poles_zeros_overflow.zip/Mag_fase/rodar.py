import sys
import os
import subprocess



def main():
  arquivo = "lista.txt"
  f = open(arquivo,"r")
    
  for line in f:
    line = line.rstrip() 
    print line
    with open(line) as fil:
      umavez = 0
      for linha in fil:
        if "int N = " in linha:
          valor =  linha.split()[3][0:-1]
          if (int(valor) > 10):  
            umavez = umavez + 1;
            N = valor
            print str(int(N)+15)
            if (umavez != 1):
              sys.stderr.write("error: mais de uma vez\n")
              exit(0)

    saida = open("logs/" + line + ".txt" , "w")
    proc = subprocess.Popen(['time','esbmc', '--fixedbv', line, '--unwind', str(int(N)+10)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out, err) = proc.communicate()
    saida.write(out)
  f.close()
  exit(0);
 

if __name__ == "__main__":
    main()
