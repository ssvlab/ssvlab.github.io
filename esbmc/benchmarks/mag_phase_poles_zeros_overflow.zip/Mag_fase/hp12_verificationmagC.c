#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int xLen = 10;
const int Alen = 13;
const int Blen = 13;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

#if 0
double inline fabs(double x) {
  return (x < 0) ? -x : x;
}

double fmod(double a, double b) {
  return a - (b * (int)(a/b));
}

double cos1(double x)
{
    double t , s;
    int p;
    p = 0;
    s = 1.0;
    t = 1.0;
    x = fmod(x + M_PI, M_PI * 2) - M_PI; // restrict x so that -M_PI < x < M_PI
    double xsqr = x*x;
    double ab = 1;
    while((ab > PREC) && (p < 15))
    {
        p++;
        t = (-t * xsqr) / (((p<<1) - 1) * (p<<1));
        s += t;
        ab = (s==0) ? 1 : fabs(t/s);
    }
    return s;
}

double sin1(double x)
{
   return cos1(x-M_PI_2);
}

/*Returns the square root of n. Note that the function */
/*Babylonian method*/
/*http://www.geeksforgeeks.org/square-root-of-a-perfect-square/*/
double sqrt1(double n)
{
  /*We are using n itself as initial approximation
   This can definitely be improved */
  double x = n;
  double y = 1;
  //float e = 0.000001; /* e decides the accuracy level*/
  //double e = 1e-16;
  double e = 1;
  int i = 0;
//  while(fabs(x - y) > e)
  while(i++ < 15) //Change this line to increase precision
  {
    x = (x + y)/2.0;
    y = n/x;
  }
  return x;
}

#endif
/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_mag(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i]; 
     }

     res[i] = sqrt(out_r[i]*out_r[i]+out_i[i]*out_i[i]); //numerator abs
     res[i] = res[i] / sqrt(out_denr[i]*out_denr[i]+out_deni[i]*out_deni[i]); //den abs
//     res[i] = 20*log10(res[i]);
  }
//  assert(0);
  /*PRINT do modulo*/
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########################\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};


/*
 * Verifies Magnitude response for Low Pass filter
 */
void verifyMagrespHP(double *res, struct Properties prop, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      if(w <= prop.wr) {
          assert(res[i] <= prop.Ar);
      }
      else if (w == prop.wc) {
          assert(res[i] <= prop.Ac);
      }
      else if ((w >= prop.wp) && (w <= 1)) {
          assert(res[i] >= prop.Ap);
      }
  }
}

int main()
{
  /*IIR Filter coefficients - hp12*/
//  assert(0);
//  double A[] = {1                , -0.369527377351241, 0.195815712655833}; //Den
//  double B[] = {0.206572083826148,  0.413144167652296, 0.206572083826148}; //Num
//  d = fdesign.highpass('N,F3dB',2,.6);
//  0.4
//  hd = design(d,'butter');
  double A[] = { 1.000000000000000,  -1.276247689889290,   2.776103549835551,  -2.645110682028040,   2.795558536616230,  -1.939083083416806,
   1.253445071015432,  -0.604568772051592,   0.245380454624386,  -0.074737017924551,   0.017001295237337,  -0.002513121328463,
   0.000185788123619 };
  double B[] = {0.013625188788510,  -0.101049957292186,   0.384363261306428,  -0.972879705046480,   1.807716098818892,  -2.583515467825938,
   2.903635703934429,  -2.583515467825938,   1.807716098818892,  -0.972879705046480,   0.384363261306428,  -0.101049957292186,
   0.013625188788510};
  /*input*/

  /*var*/
  int N = 50;
  double res[N+1];
  int i,j;
  double y[xLen]; /*output*/
  enum {lowpass, highpass, bandstop, bandpass};
  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    B[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("B[%d]=%f \n", i, B[i]);
  }
  for (i=0; i<Alen; i++) {
    A[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("A[%d]=%f \n", i, A[i]);
  }
 // assert(0);
  
  freqz_mag(B, Blen, A, Alen, res, N);
  /*propriedades do filtro*/
   

  struct Properties prop = {
        .Ap =  0.81, .Ac =  0.7, .Ar = 0.5,
        .wp = 0.55, .wc = 0.4, .wr = 0.3, 
    };
  verifyMagrespHP(res, prop, N);
  return 0;
}
