/*
 * fixedop.h
 *
 *  Created on: 31/01/2013
 *      Author: kenny
 */

#ifndef FIXEDOP_H_
#define FIXEDOP_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

const int lSTR = 15;
const int lFRAC = 10;

//const int lSTR = 7;
//const int lFRAC = 5;



#define lDEC (lSTR-lFRAC)

/*
 * Function to transform decimal numbers to binary
 */
void getBin(int num, char *str, int len)
{
  *(str+len) = '\0';
  int mask = 0x1 << len;
  if (num<0) {
      *str++ = '1';
      num = abs(num);
      mask >>= 1;
  }
  while(mask >>= 1)
    *str++ = !!(mask & num) + '0';
}

/*
 * roundInt - function to replace round from math.h
 */
int roundInt(double a) {
  if (a>=0)
    return (int)(a+0.5);
  else
    return (int)(a-0.5);
}

/*
 * Transform float to fixed
 */
int fixed(double a) {
  double b = a* (0x1 << lFRAC);
//  printf("%f\n", b);
  b = roundInt(b);
  printf("%f in fixed: %d\n", a, (int)b);
  return b;
}

double fixedfloat(int b, int len, int frac) {
  char str[len+1];
  getBin((int)b,str, len);
  printf("Transformig fixed to float...\n");
  printf("bin: %s\n", str);

  double result=0;
  int i,j;
  int aux;
  int neg=0;
//  printf("POSITIVO\n");
  if (str[0]=='1') { /*First bit, sign representation*/
//      printf("NEGATIVO\n");
      neg=1;
  }
  int dec = len-frac-1;
  printf("len: %d, dec: %d, frac: %d\n", len, len-frac, frac);
  printf("Decimal: ");
  for (i=dec, j = 0; i>=1 ;--i, ++j) {
      aux = str[i] - '0';
      printf("%d",aux);
      result+=(0x1 << j)*aux;
  }

  printf("\nresult: %f\n", result);
  printf("Fractional: ");
  for (i=dec+1,j=1; (i < len) ; ++i,++j) {
      //           __asm("int $3");
      aux = str[i] - '0';
      printf("%d",aux);
      result+=1.0/(0x1 << j)*aux;
  }
  if (neg) { /*Changing the sign*/
      result*=-1;
  }

  printf("\nresult: %f\n\n", result);
  return result;
}

int mult(int a, int b) {
  int mu;
  mu = a*b;
  printf("mult %d*%d = %d\n", a, b, mu);
  return mu;
//  return fixedfloat(mu, 2*lSTR, 2*lDEC);
}

#endif /* FIXEDOP_H_ */
