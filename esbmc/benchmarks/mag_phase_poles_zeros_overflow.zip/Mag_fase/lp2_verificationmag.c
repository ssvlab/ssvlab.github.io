#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "../../../fixedop1.h"

/* Constants */
const int xLen = 10;
const int Alen = 3;
const int Blen = 3;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_mag(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i]; 
     }

     res[i] = sqrt(out_r[i]*out_r[i]+out_i[i]*out_i[i]); //numerator abs
     res[i] = res[i] / sqrt(out_denr[i]*out_denr[i]+out_deni[i]*out_deni[i]); //den abs
//     res[i] = 20*log10(res[i]);
  }
//  assert(0);
  /*PRINT do modulo*/
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########################\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Magnitude response for Low Pass filter
 */
void verifyMagrespLP(double *res, struct Properties prop, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      if(w <= prop.wp) {
          assert(res[i] >= prop.Ap);
//          printf("ERRO!\n");
//          exit(1);
      }
      else if (w == prop.wc) {
          assert(res[i] <= prop.Ac);
//          printf("ERRO!!\n");
//          exit(1);
      }
      else if ((w >= prop.wr) && (w <= 1)) {
//          printf("\nres[%d] = %f", i, res[i]);
//          printf("\nfreq = %f", w);
//          printf("\nprop = %f", prop.Ar);
          assert(res[i] <= prop.Ar);
//          exit(1);
      }
  }
}

int main()
{
  /*IIR Filter coefficients - lp2*/
//  assert(0);
  double A[] = {1                , -0.369527377351241, 0.195815712655833}; //Den
  double B[] = {0.206572083826148,  0.413144167652296, 0.206572083826148}; //Num

  /*input*/

  /*var*/
  int N = 100;
  double res[N+1];
  int i,j;
  double y[xLen]; /*output*/

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    B[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("B[%d]=%f \n", i, B[i]);
  }
  for (i=0; i<Alen; i++) {
    A[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("A[%d]=%f \n", i, A[i]);
  }
 // assert(0);
  
  freqz_mag(B, Blen, A, Alen, res, N);
  /*propriedades do filtro*/

 /* struct Properties prop = {
        .Ap =  0.891250938133746, .Ac =  0.707945784384138, .Ar = 0.5,
        .wp = 0.3, .wc = 0.4, .wr = 0.5
    };
*/
  struct Properties prop = {
        .Ap =  0.8, .Ac =  0.707945784384138, .Ar = 0.5,
        .wp = 0.3, .wc = 0.4, .wr = 0.5
    };
  verifyMagrespLP(res, prop, N);
  return 0;
}

#if 0
/*#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "../../../fixedop1.h"

//#define M_PI 3.14159265358979323846

/* Constants */
const int Alen = 3;
const int Blen = 3;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_mag(double* num, int lnum, double* den, int lden, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0;
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i];
     }

     out_denr[i] = den[0];
     out_deni[i] = 0;
     for(m=1; m < lden; ++m) {
         old_out_r = out_denr[i];
         out_denr[i] = cos(w)*out_denr[i]-sin(w)*out_deni[i]+den[m];
         out_deni[i] = sin(w)*old_out_r+cos(w)*out_deni[i];
     }

     res[i] = sqrt(out_r[i]*out_r[i]+out_i[i]*out_i[i]); //numerator abs
     res[i] = res[i] / sqrt(out_denr[i]*out_denr[i]+out_deni[i]*out_deni[i]); //den abs
//     res[i] = 20*log10(res[i]);
  }
//  assert(0);
  /*PRINT do modulo*/
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }
  printf("\n########################\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Magnitude response for Low Pass filter
 */
void verifyMagrespLP(double *res, struct Properties prop, int N) {

  int i;
  double w;
 
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      if(w <= prop.wp) {
          //assert(res[i] >= prop.Ap);
          __ESBMC_assume(res[i] >= prop.Ap);
//          printf("ERRO!\n");
//          exit(1);
      }
      else if (w == prop.wc) {
          //assert(res[i] <= prop.Ac);
          __ESBMC_assume(res[i] <= prop.Ac);
//          printf("ERRO!!\n");
//          exit(1);
      }
      else if ((w >= prop.wr) && (w <= 1)) {
//          printf("\nres[%d] = %f", i, res[i]);
//          printf("\nfreq = %f", w);
//          printf("\nprop = %f", prop.Ar);
          //assert(res[i] <= prop.Ar);
          __ESBMC_assume(res[i] <= prop.Ar);
//          exit(1);
      }
  }
}

int main()
{
  /*IIR Filter coefficients - lp2*/
//  assert(0);
  double A[] = {1                , -0.369527377351241, 0.195815712655833}; //Den
  double B[] = {0.206572083826148,  0.413144167652296, 0.206572083826148}; //Num

  /*input*/

  /*var*/
  int N = 5;
  double res[N+1];
  int i,j;

  int nondet_int();
  float nondet_double();

  int diag;
  diag = nondet_int();
 
 
  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    B[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("B[%d]=%f \n", i, B[i]);
    //B[i] = (diag == i? nondet_float(): B[i]);
  }
  for (i=0; i<Alen; i++) {
    A[i] = fixedfloat(fixed(A[i]), lSTR, lFRAC);
    printf("A[%d]=%f \n", i, A[i]);
    A[i] = (diag == i+Blen? nondet_float(): A[i]);
  }

   // assert(0);
 
  freqz_mag(B, Blen, A, Alen, res, N);
  /*propriedades do filtro*/

  struct Properties prop = {
        .Ap =  0.891250938133746, .Ac =  0.707945784384138, .Ar = 0.5,
        .wp = 0.3, .wc = 0.4, .wr = 0.5
    };

  verifyMagrespLP(res, prop, N);
  assert(0);
  return 0;
}
#endif
