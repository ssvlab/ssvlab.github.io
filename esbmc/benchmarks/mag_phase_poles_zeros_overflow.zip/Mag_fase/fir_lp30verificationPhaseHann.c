#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "fixedop_lp12.h"

/* Constants */
const int Blen = 31;
#define M_PI     3.14159265358979323846
#define M_PI_2   1.57079632679489661923132169164      // Pi/2
#define PREC 1e-16
#define M_LN10   2.30258509299404568402
#define DBL_EPSILON 2.2204460492503131e-16

/*  Adding the limits for k real bits and l frac bits
 *  to check overflow
 */
void update_limits(int real, int frac, float* result) {
  if (real<=1)
  {
      printf("Value of real number must be greater than 1\n");
      exit(0);
  }
//  assert(0);
  result[0] = -1*(0x1 << (real-1));
  result[1] = (0x1 << (real-1)) - (1.0)/(0x1 << frac);
  //printf("%f %f\n", result[0], result[1]);
}

void print_result(double* y, int tam) {
  int i;
  printf("\nFinal result: ");
  for (i=0;i< tam; ++i) {
      printf("%f ", y[i]);
  }
  printf("\n");
}

/*
 * Function to create magnitude response from transfer function
 */
void freqz_phase_fir(double* num, int lnum, double* res, int N) {
  double w;
  int m,i;
  double out_r[N+1], old_out_r;
  double out_i[N+1];
  double out_denr[N+1], out_deni[N+1];
  for(w=0, i=0; w <= M_PI; w+=M_PI/N, ++i) {
     printf("%d ", i);
     out_r[i] = num[0];
     out_i[i] = 0; 
     for(m=1; m < lnum; ++m) {
         old_out_r = out_r[i];
         out_r[i] = cos(w)*out_r[i]-sin(w)*out_i[i]+num[m];
         out_i[i] = sin(w)*old_out_r+cos(w)*out_i[i]; 
     }

     res[i] = -atan2(out_i[i],out_r[i]); //numerator abs
  }
//  assert(0);
  /*PRINT do modulo*/
  printf("\n########### Num #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_r[i], out_i[i]);
  }
  /*printf("\n########### Den #############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f + j*%.16f \n", out_denr[i], out_deni[i]);
  }*/
  printf("\n########## Phase response ##############\n");
  for (i=0;i<N+1;++i) {
      printf("%.16f\n", res[i]);
  }
}

struct Properties {
  float   Ap, Ar, Ac;
  float wp, wc, wr;
  int type;
};

/*
 * Verifies Phase response
 */
void verifyPhaseResp(double *res, double *fi, double dif, int N) {

  int i;
  double w;
  for (i=0, w=0; (w<=1.0); ++i, w += (1.0/N)) {
      printf("w= %f %f\n", w, res[i]);
      printf("fi= %f %f\n", w, fi[i]);
    
      assert(fabs(res[i]-fi[i]) <= dif);
  }

}

int main()
{
  /*FIR Filter coefficients - lp30 - Hann - 9600 - 48000*/
    double B[] = {   0,  -0.000236155068610,  -0.000621846227125,   0.001488168191543,   0.004550824530708,  -0.000000000000000,
  -0.011615851114965,  -0.010466472551074,   0.014754259300053,   0.033008076298194,  -0.000000000000000,  -0.063133011996516,
  -0.056384525736815,   0.089463797278168,   0.299284946863305,   0.399815580466267,   0.299284946863305,   0.089463797278168,
  -0.056384525736815,  -0.063133011996516,  -0.000000000000000,   0.033008076298194,   0.014754259300053,  -0.010466472551074,
  -0.011615851114965,  -0.000000000000000,  0.004550824530708,   0.001488168191543,  -0.000621846227125,  -0.000236155068610,
                   0 }; //Num
  double Bfi[Blen];

  /*var*/
  int N = 50;
  double res[N+1], resfi[N+1];
  int i,j;

  /*fixed point transformation*/
  for (i=0; i<Blen; i++) {
    Bfi[i] = fixedfloat(fixed(B[i]), lSTR, lFRAC);
    printf("Bfi[%d]=%f \n", i, Bfi[i]);
  }

  printf("### Freqz_phase: \n");
  freqz_phase_fir(B, Blen, res, N);
  printf("### Freqz_phase fixed: \n");
  freqz_phase_fir(Bfi, Blen, resfi, N);
 
  verifyPhaseResp(res, resfi, 0.3, N);
  return 0;
}
