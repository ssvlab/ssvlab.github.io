float nondet_float();

int main()
{
  float x = nondet_float();
  float y = x;
  assert(x==y);
  return 0;
}
