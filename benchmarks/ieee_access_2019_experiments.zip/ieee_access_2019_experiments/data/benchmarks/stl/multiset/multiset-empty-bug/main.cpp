#include <iostream>
#include <set>
#include <cassert>
using namespace std;

int main ()
{
  multiset<int> myset;

  assert(!myset.empty());
  cout << endl;

  return 0;
}
