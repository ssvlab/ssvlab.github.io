#!/bin/bash
#
# DSVerifier - Benchmark Runner
#
#               Universidade Federal do Amazonas - UFAM
# Author:       Hussama Ismail <hussamaismail@gmail.com>
#               Iury Bessa <iury.bessa@gmail.com>
#
# ------------------------------------------------------
#
# Script to run many benchmarks using closedloop in DSVerifier
# 
# Usage Example:
# $ sh script benchmark_file.c
#
# ------------------------------------------------------

if test $# -ne 1; then
   echo "usage: $0 file_benchmark.c" >&2
   exit 1
fi

PROPERTIES=( STABILITY_CLOSED_LOOP );
REALIZATIONS=( DFI );
TIMEOUT="7200" # seconds
CONNECTION_MODE=SERIES; # SERIES FEEDBACK
X_SIZE=10

## default parameters
# PROPERTIES=( OVERFLOW LIMIT_CYCLE TIMING STABILITY MINIMUM_PHASE );
# REALIZATIONS=( DFI DFII TDFII DDFI DDFII DTDFII );

BENCHMARKS_LIBRARY="$1";
BENCHMARKS=$(cat $BENCHMARKS_LIBRARY);
TOTAL_SCHEMAS=$(echo "$BENCHMARKS" | grep 'SCHEMA_ID' | wc -l)
TOTAL_PLANTS=$(echo "$BENCHMARKS" | grep 'PLANT_ID' | wc -l)
TOTAL_CONTROLLERS=$(echo "$BENCHMARKS" | grep 'CONTROL_ID' | wc -l)
OUTPUT_LOGS_DIRECTORY="./logs-closedloop"

# header 
INITIAL_TIMESTAMP=$(date +%s)
CPU_CORE_NUMBER=$(cat /proc/cpuinfo | grep processor | wc -l)
CPU_INFO="CPU:$(cat /proc/cpuinfo | grep "model name" | tail -n1 | cut -d ":" -f2)"
MEM_INFO="RAM: $(cat /proc/meminfo | grep "MemTotal" | cut -d ":" -f2 | cut -d " " -f8) kB"
echo "*** DSVerifier Benchmark Runner v0.1 (closedloop) ***"
echo ""
echo "Date of run: $(date)"
echo "System: $CPU_INFO $MEM_INFO"
echo "Source: $@ "
echo "Total of schemas: $TOTAL_SCHEMAS"
echo "Total of plants: $TOTAL_PLANTS"
echo "Total of controllers: $TOTAL_CONTROLLERS"
echo "";

TOTAL_EXECUTIONS=0;
TOTAL_SUCCESS=0;
TOTAL_FAILS=0;
TOTAL_TIMEOUTS=0;

for CURRENT_SCHEMA in $(seq 1 $TOTAL_SCHEMAS); do

   # get initial and final line of schena block
   START_SCHEMA_BLOCK=$(echo "$BENCHMARKS" | grep -n "SCHEMA_ID == $((CURRENT_SCHEMA))" | cut -d ":" -f1);
   END_SCHEMA_BLOCK=$(echo "$BENCHMARKS" | grep -n "SCHEMA_ID == $((CURRENT_SCHEMA+1))" | cut -d ":" -f1);
   if [ -z "$END_SCHEMA_BLOCK" ]; then
      END_SCHEMA_BLOCK=$(echo "$BENCHMARKS" | wc -l);
   fi

   SCHEMA_BLOCK=$(echo "$BENCHMARKS" | head -n $END_SCHEMA_BLOCK | tail -n $((END_SCHEMA_BLOCK - START_SCHEMA_BLOCK + 1)));

   CURRENT_TOTAL_OF_PLANTS=$(echo "$SCHEMA_BLOCK" | grep "PLANT_ID" | wc -l);     
   CURRENT_TOTAL_OF_CONTROLS=$(echo "$SCHEMA_BLOCK" | grep "CONTROL_ID" | wc -l);
 
   # without controllers go to next schema
   if [ $CURRENT_TOTAL_OF_CONTROLS -eq 0 ]; then
      continue;
   fi

   for CURRENT_PLANT in $(seq 1 $CURRENT_TOTAL_OF_PLANTS); do

       CURRENT_BENCHMARKS=$(echo "$SCHEMA_BLOCK" | grep 'CONTROL_ID\|IMPLEMENTATION_COUNT');

       AUX=2;
       while [ $AUX -le $(($CURRENT_TOTAL_OF_CONTROLS * 2)) ]; do
          CURRENT=$(echo "$CURRENT_BENCHMARKS" | head -n $AUX | tail -n 2);
          CURRENT_CONTROL_ID=$(echo "$CURRENT"  | grep 'CONTROL_ID' | sed -e 's/^[ \t]*//g' |  sed -e 's/ //g' | cut -d "=" -f3);
          TOTAL_OF_IMPLEMENTATIONS=$(echo "$CURRENT"  | grep 'IMPLEMENTATION_COUNT' | cut -d " " -f2);

          # get implemenentations 
          for CURRENT_IMPLEMENTATION in $(seq 1 $TOTAL_OF_IMPLEMENTATIONS); do

             # get realizations	
             for CURRENT_REALIZATION in ${REALIZATIONS[@]}; do

                # get properties
                for CURRENT_PROPERTY in ${PROPERTIES[@]}; do


                    echo "RUNNING: schema $CURRENT_SCHEMA, plant $CURRENT_PLANT and digital controller $CURRENT_CONTROL_ID using implementation $CURRENT_IMPLEMENTATION in $CURRENT_REALIZATION realization checking $CURRENT_PROPERTY property";

                    mkdir -p $OUTPUT_LOGS_DIRECTORY/schema-$CURRENT_SCHEMA/plant-$CURRENT_PLANT/$CURRENT_PROPERTY;
                    OUT_FILE="$OUTPUT_LOGS_DIRECTORY/schema-$CURRENT_SCHEMA/plant-$CURRENT_PLANT/$CURRENT_PROPERTY/result-c$CURRENT_CONTROL_ID-impl$CURRENT_IMPLEMENTATION-$CURRENT_REALIZATION.out";   

                    # do the verification
                   INITIAL_EXECUTION_TIMESTAMP=$(date +%s)
                   timeout $TIMEOUT bash -c "{ time ../model-checker/cbmc --fixedbv -I ../bmc/ -DBMC=CBMC -DSVERIFIER $BENCHMARKS_LIBRARY -DSCHEMA_ID=$CURRENT_SCHEMA -DPLANT_ID=$CURRENT_PLANT -DCONTROL_ID=$CURRENT_CONTROL_ID -DIMPLEMENTATION_ID=$CURRENT_IMPLEMENTATION -DREALIZATION=$CURRENT_REALIZATION -DPROPERTY=$CURRENT_PROPERTY -DX_SIZE=$X_SIZE -DCONNECTION_MODE=$CONNECTION_MODE > $OUT_FILE; } 2>> $OUT_FILE" ;
                   FINAL_EXECUTION_TIMESTAMP=$(date +%s)

                   # analyse the result 
                   OUT=$(cat $OUT_FILE);		
                   TIME=$((FINAL_EXECUTION_TIMESTAMP - INITIAL_EXECUTION_TIMESTAMP));
                   VERIFICATION_SUCCESSFUL=$(echo "$OUT" | grep "SUCCESSFUL" | wc -l); 
                   VERIFICATION_FAILED=$(echo "$OUT" | grep "FAILED" | wc -l);
                   VERIFICATION_TIMEOUT=$(echo "$OUT" | grep "Timed out" | wc -l);
                  
                   # check if manual timeout for cbmc
                   if [ $VERIFICATION_SUCCESSFUL -eq 0 ] && [ $VERIFICATION_FAILED -eq 0 ] && [ $VERIFICATION_TIMEOUT -eq 0 ]; then
                       TIME_PARAMETERS=$(cat $OUT_FILE | grep -w "real\|user\|sys" | wc -l)
                       if [ $TIME_PARAMETERS -lt 3 ]; then
                           VERIFICATION_TIMEOUT=1;
                       fi               
                   fi

                   TOTAL_EXECUTIONS=$((TOTAL_EXECUTIONS + 1));
                   if [ $VERIFICATION_SUCCESSFUL -eq 1 ]; then
            	        TOTAL_SUCCESS=$((TOTAL_SUCCESS + 1));
                      echo "$(echo -e "\033[0;32msuccess\033[0m" | cut -d " " -f2) in "$TIME"s ($OUT_FILE)";       
                   elif [ $VERIFICATION_FAILED -eq 1 ]; then
                      TOTAL_FAILS=$((TOTAL_FAILS + 1));
                      echo "$(echo -e "\033[0;31mfail\033[0m" | cut -d " " -f2) in "$TIME"s ($OUT_FILE)";
                   elif [ $VERIFICATION_TIMEOUT -eq 1 ]; then
                      TOTAL_TIMEOUTS=$((TOTAL_TIMEOUTS + 1));
                      echo "$(echo -e "\033[1;35mtimeout\033[0m" | cut -d " " -f2) in "$TIME"s ($OUT_FILE)";
                   else
                      echo "$(echo -e "\033[0;33munknown\033[0m" | cut -d " " -f2) ($OUT_FILE)"; 
                   fi

                 done
       
             done;
       
          done;
       
          AUX=$((AUX+2));
       done 

   done
 
done;

# show report
echo "";
echo "*** RESULTS *** ";
echo "Total of verifications: $TOTAL_EXECUTIONS";
echo "Total of success: $TOTAL_SUCCESS";
echo "Total of fails: $TOTAL_FAILS";
echo "Total of timeouts: $TOTAL_TIMEOUTS";
