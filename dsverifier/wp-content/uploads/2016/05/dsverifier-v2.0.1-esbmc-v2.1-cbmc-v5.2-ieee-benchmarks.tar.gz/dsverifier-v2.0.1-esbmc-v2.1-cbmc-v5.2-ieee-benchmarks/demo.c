#include <dsverifier.h>

digital_system plant = {
   .b = { 0.00018604, 0.000172886972 },
/* .b_uncertainty = { 5, 5 }, */
   .b_size = 2,
   .a = { 1.0,-1.7989, 0.80248974 },
/* .a_uncertainty = { 5, 5, 5 }, */
   .a_size = 3
};

digital_system controller = { 
   .b = { 1.422, -1.1360358, -1.41689538972, 1.14114041028 },
   .b_size = 4,
   .a = { 1.0, -1.0307, -0.861428, 0.892128 },
   .a_size = 4
};

implementation impl = { 
   .int_bits = 16,
   .frac_bits = 12,
   .min = -1.0,
   .max = 1.0,
   .max_error = 5.0
};
