#include "bmc/dsverifier.h"

digital_system ds = {
    .a = { 1.0, 1.068, 0.1239 },
    .a_size = 3,
    .b = { 2.813, -0.0163, -1.872 },
    .b_size = 3
};

implementation impl = {
    .int_bits = 4,
    .frac_bits = 10,
    .min = -5.0,
    .max = 5.0
};
