makeallbenchmarks

diary('verification_results.out')

run_tf_verification
run_ss_verification
run_cl_verification

diary off