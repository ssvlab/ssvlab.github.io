
controller_daes(1).system=tf([0.15,0.05,0.4],[1.0,0.0,0.3],0.01)
controller_daes(2).system=tf([2.000000,-4.000000,2.000000],[1.000000,0.000000,-0.250000],0.01)
controller_daes(3).system=tf([0.2,-0.4,0.2],[1.0,0.0,-0.25],0.01)
controller_daes(4).system=tf([1.0,-2.819,2.637,-0.8187],[1.0,-1.97,1.033,-0.06068],0.01)
controller_daes(5).system=tf([0.0937,-0.3582,0.5201,-0.3482,0.1003,-0.0078],[1.0000,9.1122,-2.2473,-8.6564,0.6569,0.1355],0.01)
controller_daes(6).system=tf([0.00937,-0.03582,0.05201,-0.03482,0.01003,-0.00078],[1.0000,9.1122,-2.2473,-8.6564,0.6569,0.1355],0.01)
controller_daes(7).system=tf([0.1,-0.2819,0.2637,-0.08187],[1.0,-2.574,2.181,-0.6068],0.01)
controller_daes(8).system=tf([0.10,-0.28,0.26,-0.08],[1.0,-2.57,2.18,-0.60],0.01)
controller_daes(9).system=tf([0.1,-0.28,0.26,-0.08],[1.0,-2.57,2.18,-0.60],0.01)
controller_daes(10).system=tf([0.2,-0.4,0.2],[1.0,0.0,-0.25],0.01)
controller_daes(11).system=tf([0.10,-0.30,0.30,-0.10],[1.000,1.800,1.140,0.272],0.01)
controller_daes(12).system=tf([0.100,-0.250,0.200,-0.050],[1.000,1.500,0.680,0.096],0.01)
controller_daes(13).system=tf([0.0937,-0.3582,0.5201,-0.3482,0.1003,-0.0078],[1.0000,9.1122,-2.2473,-8.6564,0.6569,0.1355],0.01)
controller_daes(14).system=tf([0.010,-0.030,0.030,-0.010],[1.000,1.800,1.140,0.272],0.01)
controller_daes(15).system=tf([0.100,-0.250,0.200,-0.050],[1.000,1.500,0.680,0.096],0.01)
controller_daes(16).system=tf([0.1,-0.28,0.26,-0.08],[1.0,-2.57,2.18,-0.60],0.01)
controller_daes(17).system=tf([7.936,-2.919],[1.00000000,0.3890000],0.01)
controller_daes(18).system=tf([0.9411,-0.4229],[1.00000000,0.2480000],0.01)
controller_daes(19).system=tf([1.1000,-0.6039],[1.00000000,0.0340000],0.01)
controller_daes(20).system=tf([1.2670,-0.8493],[1.0000000,-0.2543000],0.01)
controller_daes(21).system=tf([1.4340,-1.174],[1.0000000,-0.6080000],0.01)
controller_daes(22).system=tf([1.5000,-1.357],[1.0000000,-0.8010000],0.01)
controller_daes(23).system=tf([1.5610,-1.485],[1.0000000,-0.9000000],0.01)
controller_daes(24).system=tf([1.5840,-1.553],[1.0000000,-0.9600000],0.01)
controller_daes(25).system=tf([2.81300000,-0.0163,-1.8720000],[1.000,1.068,0.1239],0.01)
controller_daes(26).system=tf([1.611,3.079,-3.794],[1.00000000,1.0840000,0.1289],0.01)
controller_daes(27).system=tf([-1.692,10.43,-7.915],[1.00000000,1.0460000,0.08148],0.01)
controller_daes(28).system=tf([-1.099,2.978,-1.812],[1.00000000,0.9068000,-0.06514],0.01)
controller_daes(29).system=tf([-0.4603,1.006,-0.5421],[1.00000000,0.5949000,-0.3867],0.01)
controller_daes(30).system=tf([-1.239,2.565,-1.323],[1.00000000,0.3423000,-0.6468],0.01)
controller_daes(31).system=tf([-2.813,5.719,-2.905],[1.00000000,0.18330,-0.8107],0.01)
controller_daes(32).system=tf([-0.753,1.519,-0.766],[1.00000000,0.0762700,-0.9212],0.01)
controller_daes(33).system=tf([-1.553,3.119,-1.566],[1.00000000,0.0387300,-0.96],0.01)


controller_daes(1).rangeMax=1; controller_daes(1).rangeMin=-1;
controller_daes(2).rangeMax=1; controller_daes(2).rangeMin=-1;
controller_daes(3).rangeMax=1; controller_daes(3).rangeMin=-1;
controller_daes(4).rangeMax=1; controller_daes(4).rangeMin=-1;
controller_daes(5).rangeMax=1; controller_daes(5).rangeMin=-1;
controller_daes(6).rangeMax=10; controller_daes(6).rangeMin=-10;
controller_daes(7).rangeMax=4; controller_daes(7).rangeMin=-4;
controller_daes(8).rangeMax=5; controller_daes(8).rangeMin=-5;
controller_daes(9).rangeMax=6; controller_daes(9).rangeMin=-6;
controller_daes(10).rangeMax=1; controller_daes(10).rangeMin=-1;
controller_daes(11).rangeMax=2; controller_daes(11).rangeMin=-2;
controller_daes(12).rangeMax=2; controller_daes(12).rangeMin=-2;
controller_daes(13).rangeMax=10; controller_daes(13).rangeMin=-10;
controller_daes(14).rangeMax=3; controller_daes(14).rangeMin=-3;
controller_daes(15).rangeMax=5; controller_daes(15).rangeMin=-5;
controller_daes(16).rangeMax=10; controller_daes(16).rangeMin=-10;
controller_daes(17).rangeMax=9; controller_daes(17).rangeMin=-9;
controller_daes(18).rangeMax=3; controller_daes(18).rangeMin=-3;
controller_daes(19).rangeMax=3; controller_daes(19).rangeMin=-3;
controller_daes(20).rangeMax=3; controller_daes(20).rangeMin=-3;
controller_daes(21).rangeMax=3; controller_daes(21).rangeMin=-3;
controller_daes(22).rangeMax=3; controller_daes(22).rangeMin=-3;
controller_daes(23).rangeMax=3; controller_daes(23).rangeMin=-3;
controller_daes(24).rangeMax=3; controller_daes(24).rangeMin=-3;
controller_daes(25).rangeMax=5; controller_daes(25).rangeMin=-5;
controller_daes(26).rangeMax=5; controller_daes(26).rangeMin=-5;
controller_daes(27).rangeMax=12; controller_daes(27).rangeMin=-12;
controller_daes(28).rangeMax=4; controller_daes(28).rangeMin=-4;
controller_daes(29).rangeMax=3; controller_daes(29).rangeMin=-3;
controller_daes(30).rangeMax=4; controller_daes(30).rangeMin=-4;
controller_daes(31).rangeMax=6; controller_daes(31).rangeMin=-6;
controller_daes(32).rangeMax=3; controller_daes(32).rangeMin=-3;
controller_daes(33).rangeMax=3; controller_daes(33).rangeMin=-3;


controller_daes(1).int_bits=3; controller_daes(1).frac_bits= 4 ;
controller_daes(2).int_bits=2; controller_daes(2).frac_bits= 6 ;
controller_daes(3).int_bits=3; controller_daes(3).frac_bits= 4 ;
controller_daes(4).int_bits=2; controller_daes(4).frac_bits= 13 ;
controller_daes(5).int_bits=2; controller_daes(5).frac_bits= 13 ;
controller_daes(6).int_bits=2; controller_daes(6).frac_bits= 13 ;
controller_daes(7).int_bits=2; controller_daes(7).frac_bits= 13 ;
controller_daes(8).int_bits=2; controller_daes(8).frac_bits= 8 ;
controller_daes(9).int_bits=4; controller_daes(9).frac_bits= 11 ;
controller_daes(10).int_bits=3; controller_daes(10).frac_bits= 12 ;
controller_daes(11).int_bits=2; controller_daes(11).frac_bits= 13 ;
controller_daes(12).int_bits=2; controller_daes(12).frac_bits= 13 ;
controller_daes(13).int_bits=2; controller_daes(13).frac_bits= 13 ;
controller_daes(14).int_bits=3; controller_daes(14).frac_bits= 10 ;
controller_daes(15).int_bits=4; controller_daes(15).frac_bits= 11 ;
controller_daes(16).int_bits=5; controller_daes(16).frac_bits= 10 ;
controller_daes(17).int_bits=5; controller_daes(17).frac_bits= 10 ;
controller_daes(18).int_bits=3; controller_daes(18).frac_bits= 5 ;
controller_daes(19).int_bits=3; controller_daes(19).frac_bits= 5 ;
controller_daes(20).int_bits=3; controller_daes(20).frac_bits= 5 ;
controller_daes(21).int_bits=3; controller_daes(21).frac_bits= 5 ;
controller_daes(22).int_bits=3; controller_daes(22).frac_bits= 5 ;
controller_daes(23).int_bits=3; controller_daes(23).frac_bits= 5 ;
controller_daes(24).int_bits=3; controller_daes(24).frac_bits= 5 ;
controller_daes(25).int_bits=4; controller_daes(25).frac_bits= 5 ;
controller_daes(26).int_bits=4; controller_daes(26).frac_bits= 5 ;
controller_daes(27).int_bits=6; controller_daes(27).frac_bits= 7 ;
controller_daes(28).int_bits=4; controller_daes(28).frac_bits= 5 ;
controller_daes(29).int_bits=3; controller_daes(29).frac_bits= 7 ;
controller_daes(30).int_bits=4; controller_daes(30).frac_bits= 5 ;
controller_daes(31).int_bits=4; controller_daes(31).frac_bits= 5 ;
controller_daes(32).int_bits=3; controller_daes(32).frac_bits= 5 ;
controller_daes(33).int_bits=3; controller_daes(33).frac_bits= 5 ;


controller_daes(1).realization='DFI'
controller_daes(2).realization='DFII'
controller_daes(3).realization='TDFII'
controller_daes(4).realization='DFI'
controller_daes(5).realization='DFII'
controller_daes(6).realization='TDFII'
controller_daes(7).realization='DFI'
controller_daes(8).realization='DFII'
controller_daes(9).realization='TDFII'
controller_daes(10).realization='DFI'
controller_daes(11).realization='DFII'
controller_daes(12).realization='TDFII'
controller_daes(13).realization='DFI'
controller_daes(14).realization='DFII'
controller_daes(15).realization='TDFII'
controller_daes(16).realization='DFI'
controller_daes(17).realization='DFII'
controller_daes(18).realization='TDFII'
controller_daes(19).realization='DFI'
controller_daes(20).realization='DFII'
controller_daes(21).realization='TDFII'
controller_daes(22).realization='DFI'
controller_daes(23).realization='DFII'
controller_daes(24).realization='TDFII'
controller_daes(25).realization='DFI'
controller_daes(26).realization='DFII'
controller_daes(27).realization='TDFII'
controller_daes(28).realization='DFI'
controller_daes(29).realization='DFII'
controller_daes(30).realization='TDFII'
controller_daes(31).realization='DFI'
controller_daes(32).realization='DFII'
controller_daes(33).realization='TDFII'