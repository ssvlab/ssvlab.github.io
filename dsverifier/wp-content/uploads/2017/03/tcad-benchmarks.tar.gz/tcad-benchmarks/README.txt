Directory structure
 * benchmarks: benchmark set
 * dsverifier: DSVerifier source directory

In directory benchmarks:

"run-limit-cycle.sh"       run the verification for limit-cycle property to the set of controllers.
"run-saturate-overflow.sh" run the verification for overflow property to the set of controllers using saturate mode.
"run-wraparound-overflow.sh" run the verification for overflow property to the set of controllers using wrap-around mode.

In directory dsverifier:

"dsverifier"	the binary executable for the DSVerifier.
"bmc"		the folder with the respective needed libraries and functions to perform the verification.
"mode-checker"	the folder with the CBMC and ESBMC binaries files that are used as back-end in verification.

In order to configure the DSVerifier in your system:

Before using DSVerifier, we need to configure an environment variable called DSVERIFIER_HOME. You should add it to your .bashrc file as follows:

$export DSVERIFIER_HOME='path to dsverifier folder'
$export PATH=$PATH:$DSVERIFIER_HOME

After that, you should save it and use the following command:

$ source .bashrc

To run all experiments use the following commands:
chmod +x *.sh
./run-limit-cycle.sh
./run-saturate-overflow.sh
./run-wraparound-overflow.sh

The benchmarks store verification results and runtime as well as status information in a .out file per controller with the implementation and realization in the benchmark directory.
