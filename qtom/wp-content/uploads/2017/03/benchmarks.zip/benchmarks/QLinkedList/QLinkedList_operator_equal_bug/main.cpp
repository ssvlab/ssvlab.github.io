#include <iostream>
#include <QLinkedList>
#include <QString>
#include <cassert>
using namespace std;

int main ()
{
    QLinkedList<QString> first;
    first << "A" << "B" << "C";
    QLinkedList<QString> second;
    second << "A" << "B" << "C";
    assert(!(first == second));
  return 0;
}
