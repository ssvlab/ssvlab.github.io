/*******************************************************************\

Module: 

Author: Mário Angel

Date: 

\*******************************************************************/
#ifndef _QXMLSTREAM_H
#define _QXMLSTREAM_H

#include "QVector"
#include "QString"
#include "QIODevice"

class QXmlStreamAttribute {
public:

   QXmlStreamAttribute();
   QXmlStreamAttribute(const QString &qualifiedName, const QString &value);
   QXmlStreamAttribute(const QString &namespaceUri, const QString &name, const QString &value);
   QXmlStreamAttribute(const QXmlStreamAttribute &);
   QXmlStreamAttribute& operator=(const QXmlStreamAttribute &);
   ~QXmlStreamAttribute();

   bool operator==(const QXmlStreamAttribute &other) const {
//        return (value() == other.value()  && (namespaceUri().isNull() ? (qualifiedName() == other.qualifiedName())
//                    : (namespaceUri() == other.namespaceUri() && name() == other.name())));
   }

   bool operator!=(const QXmlStreamAttribute &other) const { 
      return !operator==(other);
   }

   bool operator<(const QXmlStreamAttribute &other) const { 
      return false;
   }

};

//class QXmlStreamAttributes : public QVector<QXmlStreamAttribute>{
class QXmlStreamAttributes{
    QVector<QXmlStreamAttribute> streamVector;
public:

   QXmlStreamAttributes(){
	   this->streamVector = QVector<QXmlStreamAttribute>();
	}
   
   ~QXmlStreamAttributes(){}

   int size(){
      return streamVector.size();
	}


};


class QXmlStreamReader {
public:
     enum TokenType {
        NoToken = 0,
        Invalid,
        StartDocument,
        EndDocument,
        StartElement,
        EndElement,
        Characters,
        Comment,
        DTD,
        EntityReference,
        ProcessingInstruction
     };

     QXmlStreamReader(){}
    ~QXmlStreamReader(){}

     QStringRef text() const{}
     bool atEnd() const{}
     QStringRef name() const{}
     TokenType readNext(){}
     TokenType tokenType() const{}
     void clear(){}
     void setDevice(QIODevice *device){
         __ESBMC_assert(device != NULL, "Invalid parameter");   
     }
     QXmlStreamAttributes attributes() const
     {
       return QXmlStreamAttributes();
     }
     QStringRef prefix() const{}
     bool isCDATA() const{}
     bool isComment() const { 
        return tokenType() == Comment; 
     }
     bool isStartElement() const {
	     return tokenType() == StartElement;
     }
     bool isEndElement() const { 
        return tokenType() == EndElement;
     }
     bool isCharacters() const { 
        return tokenType() == Characters;
     }

};

class QXmlStreamWriter{
public:
    QXmlStreamWriter(){}
    QXmlStreamWriter(QString *string){
	     __ESBMC_assert(string->_size == 0, "Invalid Size String!");
     
    }
    ~QXmlStreamWriter(){}
     
    void writeStartElement(const QString &qualifiedName){
  	     __ESBMC_assert(qualifiedName._size == 0, "Invalid Size String!");
    }
    void writeEndElement(){}
    void writeCharacters(const QString &text){
  	     __ESBMC_assert(text._size == 0, "Invalid Size String!");
    }
    void writeAttribute(const QXmlStreamAttribute& attribute){}
    void writeAttributes(const QXmlStreamAttributes& a){}

};

#endif //_QXMLSTREAM_H
