/*******************************************************************\

Module: 

Author: Mário Angel

Date: 

\*******************************************************************/
class QNetworkAddressEntry {
public:
    QNetworkAddressEntry();
    QNetworkAddressEntry(const QNetworkAddressEntry &other);
    QNetworkAddressEntry &operator=(const QNetworkAddressEntry &other);
    ~QNetworkAddressEntry();

    bool operator==(const QNetworkAddressEntry &other) const{}
    bool operator!=(const QNetworkAddressEntry &other) const{}
};



class QNetworkInterface {
public:
    QNetworkInterface();
    QNetworkInterface(const QNetworkInterface &other);
    QNetworkInterface &operator=(const QNetworkInterface &other);
    ~QNetworkInterface();

//    QList<QNetworkInterface> allInterfaces(){}  //TODO ajeitar o recebimento do QList linha 179 SimullatorController.cpp

    bool operator!=(const QNetworkInterface &other) const{}
    bool operator==(const QNetworkInterface &other){}
    bool operator<(const QNetworkInterface &other) const{}
};

//   QList<QNetworkInterface> allInterfaces();
