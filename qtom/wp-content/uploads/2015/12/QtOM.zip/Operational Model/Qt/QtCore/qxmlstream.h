/*******************************************************************\

Module: 

Author: Mário Angel

Date: 

\*******************************************************************/
#ifndef _QXMLSTREAM_H
#define _QXMLSTREAM_H

#include "QVector"
#include "QString"
#include "QIODevice"

class QXmlStreamAttribute {
public:

   QXmlStreamAttribute();
   QXmlStreamAttribute(const QString &qualifiedName, const QString &value);
   QXmlStreamAttribute(const QString &namespaceUri, const QString &name, const QString &value);
   QXmlStreamAttribute(const QXmlStreamAttribute &);
   QXmlStreamAttribute& operator=(const QXmlStreamAttribute &);
   ~QXmlStreamAttribute();

   bool operator==(const QXmlStreamAttribute &other) const {
//        return (value() == other.value()  && (namespaceUri().isNull() ? (qualifiedName() == other.qualifiedName())
//                    : (namespaceUri() == other.namespaceUri() && name() == other.name())));
   }

   bool operator!=(const QXmlStreamAttribute &other) const { 
      return !operator==(other);
   }

   bool operator<(const QXmlStreamAttribute &other) const { 
      return false;
   }

};


class QXmlStreamAttributes : public QVector<QXmlStreamAttribute>{
public:

    QXmlStreamAttributes(){}
   ~QXmlStreamAttributes(){}

};


class QXmlStreamReader {
public:
     enum TokenType {
        NoToken = 0,
        Invalid,
        StartDocument,
        EndDocument,
        StartElement,
        EndElement,
        Characters,
        Comment,
        DTD,
        EntityReference,
        ProcessingInstruction
     };

     QXmlStreamReader(){}
    ~QXmlStreamReader(){}

     QStringRef text() const{}
     bool atEnd() const{}
     QStringRef name() const{}
     TokenType readNext(){}
     TokenType tokenType() const{}
     void clear(){}
     void setDevice(QIODevice *device){}
     QXmlStreamAttributes attributes() const{}
     QStringRef prefix() const{}
     bool isCDATA() const{}
     bool isComment() const { 
        return tokenType() == Comment; 
     }
     bool isStartElement() const {
	return tokenType() == StartElement;
     }
     bool isEndElement() const { 
        return tokenType() == EndElement;
     }
     bool isCharacters() const { 
        return tokenType() == Characters;
     }

};

class QXmlStreamWriter{
public:
    QXmlStreamWriter(){}
    QXmlStreamWriter(QString *string){}
    ~QXmlStreamWriter(){}
     
    void writeStartElement(const QString &qualifiedName){}
    void writeEndElement(){}
    void writeCharacters(const QString &text){}
    void writeAttribute(const QXmlStreamAttribute& attribute){}
    void writeAttributes(const QXmlStreamAttributes& attributes){}

};

#endif //_QXMLSTREAM_H
