/*******************************************************************\
 *
 *
 * Author: Blanc Nicolas
 *
 * 
\*******************************************************************/


#include <iostream>


std::istream cin(0);
std::ostream cout(0);
std::ostream cerr(1);

