 #include <iostream>
 #include <QString>

 int main()
 {
     QString str("HelloWorld");
     std::cout<<str.toStdString();
     return 0;
 }
