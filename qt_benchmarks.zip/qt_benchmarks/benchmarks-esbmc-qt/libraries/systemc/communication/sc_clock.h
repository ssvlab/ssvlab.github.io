#ifndef SC_CLOCK_H
#define SC_CLOCK_H

class sc_clock
{
	public :
		sc_clock() {}
};



#endif
