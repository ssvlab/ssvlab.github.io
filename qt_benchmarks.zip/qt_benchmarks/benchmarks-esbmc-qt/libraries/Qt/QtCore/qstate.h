/*******************************************************************
 Module:

 Author: Felipe Rodrigues

 Date: October 2012

 \*******************************************************************/

#ifndef __QSTATE
#define __QSTATE

#endif
